<?php
/**
 * Template Name: TF — Wedding Planner & Event Venue
 *
 * Namespace : --wed-*
 * Fonts     : Cormorant (headings) + Lato (body)
 * Palette   : blush #f2e0da · ivory #faf8f3 · rose #c47a8a · gold #c9a84c · night #2a2028
 */

/* ── deterministic randomness ── */
srand( crc32( get_the_permalink() ) );

/* ── petal data (falling petals in hero) ── */
$petals = [];
for ( $i = 0; $i < 30; $i++ ) {
    $petals[] = [
        'x'     => rand( 2, 98 ),
        'size'  => rand( 8, 18 ),
        'delay' => round( lcg_value() * 10, 2 ),
        'dur'   => round( 7 + lcg_value() * 8, 2 ),
        'swing' => rand( 20, 60 ),
        'rot'   => rand( 0, 360 ),
        'color' => [ '#f2bfc8','#f5d0d8','#fce4e8','#f0b0bc','#fad8e0','#e8a8b8' ][ rand(0,5) ],
    ];
}

/* ── fairy lights ── */
$lights = [];
for ( $i = 0; $i < 60; $i++ ) {
    $lights[] = [
        'x'     => rand( 1, 99 ),
        'y'     => rand( 5, 45 ),
        'size'  => rand( 3, 7 ),
        'delay' => round( lcg_value() * 4, 2 ),
        'dur'   => round( 1.5 + lcg_value() * 2.5, 2 ),
        'color' => [ '#fff9e0','#ffeaa0','#f5e8c0','#fff5cc','#ffe4b0' ][ rand(0,4) ],
    ];
}

/* ── gallery / portfolio ── */
$weddings = [
    [ 'title'=>'Charlotte & Edward',  'style'=>'Garden',     'cat'=>'garden',    'season'=>'Summer', 'color'=>'#c47a8a' ],
    [ 'title'=>'Isabella & Marco',    'style'=>'Rustic Barn', 'cat'=>'rustic',    'season'=>'Autumn', 'color'=>'#a07850' ],
    [ 'title'=>'Sophia & James',      'style'=>'Ballroom',   'cat'=>'ballroom',  'season'=>'Winter', 'color'=>'#6070a0' ],
    [ 'title'=>'Anika & Thomas',      'style'=>'Coastal',    'cat'=>'coastal',   'season'=>'Spring', 'color'=>'#4a9090' ],
    [ 'title'=>'Florence & Hugo',     'style'=>'Garden',     'cat'=>'garden',    'season'=>'Summer', 'color'=>'#c47a8a' ],
    [ 'title'=>'Rosalind & Oliver',   'style'=>'Rustic Barn','cat'=>'rustic',    'season'=>'Autumn', 'color'=>'#a07850' ],
];

/* ── packages ── */
$packages = [
    [
        'name'     => 'Ceremony Only',
        'price'    => '£2,500',
        'includes' => ['Venue for 2 hours','Celebrant coordination','Floral arch dressing','Ceremony music','Photography intro session'],
        'highlight'=> false,
    ],
    [
        'name'     => 'Full Day Bliss',
        'price'    => '£7,900',
        'includes' => ['Ceremony + reception (12 hrs)','Dedicated planner','Florals & centrepieces','3-course seated dinner','Evening entertainment','Photography & videography'],
        'highlight'=> true,
    ],
    [
        'name'     => 'Destination Wedding',
        'price'    => 'From £14,000',
        'includes' => ['Overseas venue sourcing','Full logistics management','Bespoke florals','Catering coordination','Guest concierge service','Luxury transport'],
        'highlight'=> false,
    ],
];

/* ── services ── */
$services = [
    [ 'icon'=>'💐', 'title'=>'Florals & Décor',    'desc'=>'From intimate posies to cascading ceiling installations, our florists create bespoke arrangements that express your story.' ],
    [ 'icon'=>'🍽',  'title'=>'Catering & Cake',    'desc'=>'Award-winning menus crafted around your dietary needs and cultural traditions, paired with a show-stopping wedding cake.' ],
    [ 'icon'=>'📸',  'title'=>'Photography & Film', 'desc'=>'Documentary and fine-art photographers who capture the unguarded moments that make each wedding uniquely yours.' ],
    [ 'icon'=>'🎵',  'title'=>'Music & Entertainment','desc'=>'String quartets, jazz trios, DJs, and live bands curated for every part of your day — from aisle to after-party.' ],
    [ 'icon'=>'🚗',  'title'=>'Transport & Logistics','desc'=>'Vintage Rolls-Royces, horse-drawn carriages, and shuttle coordination for guests near and far.' ],
    [ 'icon'=>'🏩',  'title'=>'Accommodation',      'desc'=>'Exclusive hire of our estate rooms and preferred rates at nearby boutique hotels for your bridal party.' ],
];

/* ── team / planners ── */
$team = [
    [ 'name'=>'Genevieve Hartley',  'role'=>'Lead Wedding Planner',  'years'=>'12 yrs', 'female'=>true,  'glasses'=>false, 'hair_color'=>'#3a1808' ],
    [ 'name'=>'Pierre Fontaine',    'role'=>'Creative Director',      'years'=>'9 yrs',  'female'=>false, 'glasses'=>true,  'hair_color'=>'#2a1a10' ],
    [ 'name'=>'Beatrice Okonkwo',   'role'=>'Floral & Décor',        'years'=>'7 yrs',  'female'=>true,  'glasses'=>false, 'hair_color'=>'#0a0804' ],
    [ 'name'=>'James Whitfield',    'role'=>'Venue & Logistics',      'years'=>'11 yrs', 'female'=>false, 'glasses'=>false, 'hair_color'=>'#4a3820' ],
];

/* ── testimonials ── */
$testimonials = [
    [ 'couple'=>'Charlotte & Edward', 'text'=>'Genevieve turned our dream into reality without us once feeling stressed. Every single detail — down to the hand-tied buttonholes — was exactly right.', 'year'=>'2025' ],
    [ 'couple'=>'Anika & Thomas',     'text'=>'We were blown away. Our coastal ceremony felt like a scene from a film. Guests are still talking about it six months later.', 'year'=>'2024' ],
    [ 'couple'=>'Florence & Hugo',    'text'=>'The team managed everything so we could simply be present. The most perfect day of our lives, and we didn\'t lift a finger.', 'year'=>'2025' ],
];

/* ── marquee items ── */
$marquee_raw  = [ 'Garden Weddings', '✦', 'Rustic Barns', '✦', 'Ballrooms', '✦', 'Coastal Elopements', '✦', 'Destination Weddings', '✦', 'Micro Weddings', '✦', 'Vow Renewals', '✦', 'Styled Shoots', '✦' ];
$marquee_items = array_merge( $marquee_raw, $marquee_raw );
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   WEDDING PLANNER — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════ */
:root{
  --wed-blush:#f2e0da;
  --wed-ivory:#faf8f3;
  --wed-rose:#c47a8a;
  --wed-gold:#c9a84c;
  --wed-night:#2a2028;
  --wed-dusty:#9a7a84;
  --wed-sage:#8a9878;
  --wed-radius:6px;
  --wed-serif:'Cormorant',serif;
  --wed-sans:'Lato',sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.wed-page{
  font-family:var(--wed-sans);
  font-weight:300;
  color:var(--wed-night);
  background:var(--wed-ivory);
  line-height:1.7;
  overflow-x:hidden;
}
.wed-wrap{max-width:1180px;margin:0 auto;padding:0 24px}

/* typography */
.wed-eyebrow{
  font-family:var(--wed-sans);
  font-size:.7rem;
  font-weight:700;
  letter-spacing:.28em;
  text-transform:uppercase;
  color:var(--wed-rose);
  display:block;
  margin-bottom:14px;
}
.wed-section-title{
  font-family:var(--wed-serif);
  font-size:clamp(2rem,4vw,3rem);
  font-weight:300;
  color:var(--wed-night);
  margin-bottom:18px;
  line-height:1.2;
}
.wed-btn{
  display:inline-block;
  padding:13px 34px;
  border-radius:40px;
  font-family:var(--wed-sans);
  font-size:.75rem;
  font-weight:700;
  letter-spacing:.14em;
  text-transform:uppercase;
  text-decoration:none;
  cursor:pointer;
  border:none;
  transition:transform .25s,box-shadow .25s,background .25s;
}
.wed-btn:hover{transform:translateY(-2px)}
.wed-btn-rose{background:var(--wed-rose);color:#fff}
.wed-btn-rose:hover{background:#b06878;box-shadow:0 8px 24px rgba(196,122,138,.4)}
.wed-btn-outline{background:transparent;border:1.5px solid var(--wed-rose);color:var(--wed-rose)}
.wed-btn-outline:hover{background:var(--wed-rose);color:#fff}
.wed-btn-gold{background:var(--wed-gold);color:#fff}
.wed-btn-gold:hover{background:#b8942a;box-shadow:0 8px 24px rgba(201,168,76,.4)}
.wed-btn-light{background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.3)}
.wed-btn-light:hover{background:rgba(255,255,255,.28)}

.wed-reveal{opacity:0;transform:translateY(26px);transition:opacity .7s ease,transform .7s ease}
.wed-reveal.visible{opacity:1;transform:none}

/* ══════════════════════════════
   HERO
══════════════════════════════ */
.wed-hero{
  position:relative;
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
  background:linear-gradient(170deg,#2e1f28 0%,#3a2530 35%,#2c1e22 65%,#1e1416 100%);
}

/* dawn sky blush wash */
.wed-hero::before{
  content:'';
  position:absolute;inset:0;
  background:radial-gradient(ellipse 90% 55% at 50% 110%,rgba(242,186,200,.14) 0%,transparent 65%),
              radial-gradient(ellipse 50% 40% at 25% 5%,rgba(201,168,76,.06) 0%,transparent 55%),
              radial-gradient(ellipse 40% 30% at 75% 8%,rgba(242,186,200,.06) 0%,transparent 50%);
  pointer-events:none;
}

/* fairy lights string */
.wed-fairy-light{
  position:absolute;
  border-radius:50%;
  filter:blur(1.5px);
  animation:wed-twinkle var(--wed-dur,2s) ease-in-out var(--wed-del,0s) infinite alternate;
}
/* petal */
.wed-petal{
  position:absolute;
  top:-20px;
  border-radius:50% 50% 50% 50% / 40% 40% 60% 60%;
  animation:wed-petal-fall var(--wed-pdur,8s) linear var(--wed-pdel,0s) infinite;
  pointer-events:none;
}

/* ── garden arch scene ── */
.wed-arch-wrap{
  position:absolute;
  bottom:0;left:50%;
  transform:translateX(-50%);
  width:480px;
}
/* arch legs */
.wed-arch-leg{
  position:absolute;
  bottom:0;
  width:22px;
  background:linear-gradient(to top,#4a3020,#5a4030);
  border-radius:11px 11px 0 0;
}
/* arch arch (curved top) */
.wed-arch-top{
  position:absolute;
  bottom:0;
  left:0;right:0;
  height:340px;
  border:18px solid #5a4030;
  border-bottom:none;
  border-radius:200px 200px 0 0;
  pointer-events:none;
}
/* arch flowers overlay */
.wed-arch-bloom{
  position:absolute;
  border-radius:50%;
  background:var(--wed-rose);
  filter:blur(1px);
}
/* path to altar */
.wed-aisle{
  position:absolute;
  bottom:0;left:50%;
  transform:translateX(-50%);
  width:120px;
  height:260px;
  background:linear-gradient(to top,rgba(245,235,210,.35),transparent);
  perspective:400px;
  border-left:2px solid rgba(245,235,210,.15);
  border-right:2px solid rgba(245,235,210,.15);
}
/* ground lawn */
.wed-ground{
  position:absolute;
  bottom:0;left:0;right:0;
  height:180px;
  background:linear-gradient(to top,rgba(60,80,40,.6),rgba(60,80,40,.1),transparent);
}
/* candles on aisle */
.wed-candle{
  position:absolute;
  bottom:0;
  width:8px;
  background:linear-gradient(to top,#d4c090,#f5f0e0);
  border-radius:4px;
}
.wed-candle-flame{
  position:absolute;
  top:-10px;left:50%;
  transform:translateX(-50%);
  width:8px;height:12px;
  background:radial-gradient(ellipse at 50% 70%,#ffe87a,#ff9030 60%,transparent);
  border-radius:50% 50% 30% 30%;
  animation:wed-flame 1.8s ease-in-out infinite;
}
/* trees flanking */
.wed-tree{
  position:absolute;
  bottom:0;
  display:flex;
  flex-direction:column;
  align-items:center;
}
.wed-tree-trunk{
  width:16px;
  background:linear-gradient(to top,#5a3820,#7a5030);
  border-radius:2px;
}
.wed-tree-crown{
  border-radius:50% 50% 40% 40%;
  position:relative;
  bottom:-4px;
  opacity:.85;
}
/* moon behind arch */
.wed-moon{
  position:absolute;
  top:12%;left:50%;
  transform:translateX(-50%);
  width:80px;height:80px;
  border-radius:50%;
  background:radial-gradient(circle at 38% 36%,#fffde8,#f0e8c0);
  box-shadow:0 0 50px rgba(255,253,232,.35),0 0 120px rgba(255,253,232,.12);
}

/* hero copy */
.wed-hero-content{
  position:relative;
  z-index:20;
  text-align:center;
  padding:160px 24px 100px;
  max-width:800px;
  margin:0 auto;
}
.wed-hero-ornament{
  display:flex;
  align-items:center;
  justify-content:center;
  gap:16px;
  margin-bottom:24px;
  color:rgba(201,168,76,.6);
  font-size:1rem;
  letter-spacing:.3em;
}
.wed-hero-ornament::before,
.wed-hero-ornament::after{
  content:'';
  width:60px;height:1px;
  background:linear-gradient(to right,transparent,rgba(201,168,76,.5),transparent);
}
.wed-hero h1{
  font-family:var(--wed-serif);
  font-size:clamp(3.2rem,9vw,7rem);
  font-weight:300;
  color:#faf5f0;
  line-height:1.05;
  letter-spacing:-.01em;
  margin-bottom:24px;
  text-shadow:0 2px 40px rgba(0,0,0,.5);
}
.wed-hero h1 em{
  font-style:italic;
  color:rgba(242,186,200,.9);
}
.wed-hero-sub{
  font-size:1rem;
  font-weight:300;
  color:rgba(250,248,243,.7);
  max-width:480px;
  margin:0 auto 40px;
  line-height:1.8;
}
.wed-hero-badges{
  display:flex;
  justify-content:center;
  gap:28px;
  margin-bottom:44px;
  flex-wrap:wrap;
}
.wed-hero-badge{
  font-size:.68rem;
  font-weight:700;
  letter-spacing:.16em;
  text-transform:uppercase;
  color:rgba(250,248,243,.5);
  display:flex;align-items:center;gap:8px;
}
.wed-hero-badge::before{content:'✦';color:var(--wed-gold);font-size:.6rem}
.wed-hero-scroll{
  position:absolute;
  bottom:36px;left:50%;transform:translateX(-50%);
  display:flex;flex-direction:column;align-items:center;gap:8px;
  color:rgba(250,248,243,.35);
  font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;
}
.wed-scroll-line{
  width:1px;height:48px;
  background:linear-gradient(to bottom,rgba(250,248,243,.45),transparent);
  animation:wed-scroll-pulse 2s ease-in-out infinite;
}

/* keyframes */
@keyframes wed-twinkle{0%{opacity:.2;transform:scale(.8)}100%{opacity:1;transform:scale(1.15)}}
@keyframes wed-petal-fall{
  0%{transform:translateY(0) rotate(var(--wed-rot,0deg)) translateX(0);opacity:1}
  100%{transform:translateY(120vh) rotate(calc(var(--wed-rot,0deg) + 540deg)) translateX(var(--wed-swing,30px));opacity:0}
}
@keyframes wed-flame{0%,100%{transform:translateX(-50%) scaleX(1) scaleY(1)}50%{transform:translateX(-50%) scaleX(.85) scaleY(1.12)}}
@keyframes wed-scroll-pulse{0%,100%{opacity:.35}50%{opacity:.8}}
@keyframes wed-counter{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

/* ══════════════════════════════
   MARQUEE
══════════════════════════════ */
.wed-marquee-wrap{
  background:var(--wed-blush);
  padding:15px 0;
  overflow:hidden;
}
.wed-marquee-track{
  display:flex;
  width:max-content;
  animation:wed-marquee 32s linear infinite;
}
.wed-marquee-track:hover{animation-play-state:paused}
.wed-marquee-item{
  padding:0 22px;
  font-size:.72rem;
  font-weight:700;
  letter-spacing:.2em;
  text-transform:uppercase;
  color:var(--wed-rose);
  white-space:nowrap;
}
@keyframes wed-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ══════════════════════════════
   GALLERY / PORTFOLIO
══════════════════════════════ */
.wed-gallery{
  padding:100px 0;
  background:var(--wed-ivory);
}
.wed-section-header{text-align:center;margin-bottom:52px}
.wed-filter-bar{
  display:flex;flex-wrap:wrap;justify-content:center;gap:10px;
  margin-bottom:40px;
}
.wed-filter-btn{
  padding:8px 22px;
  border-radius:40px;
  border:1.5px solid var(--wed-dusty);
  background:transparent;
  color:var(--wed-dusty);
  font-family:var(--wed-sans);
  font-size:.72rem;
  font-weight:700;
  letter-spacing:.12em;
  text-transform:uppercase;
  cursor:pointer;
  transition:all .2s;
}
.wed-filter-btn.active,
.wed-filter-btn:hover{background:var(--wed-rose);border-color:var(--wed-rose);color:#fff}
.wed-gallery-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:20px;
}
.wed-gallery-item{
  position:relative;
  border-radius:12px;
  overflow:hidden;
  aspect-ratio:3/4;
  cursor:pointer;
  transition:transform .3s;
}
.wed-gallery-item:hover{transform:scale(1.02)}
.wed-gallery-item.hidden{display:none}
.wed-gallery-art{
  width:100%;height:100%;
  position:relative;
  display:flex;align-items:center;justify-content:center;
}
.wed-gallery-overlay{
  position:absolute;inset:0;
  background:linear-gradient(to top,rgba(42,32,40,.85) 0%,rgba(42,32,40,.1) 55%,transparent 100%);
  display:flex;flex-direction:column;justify-content:flex-end;
  padding:22px 18px;
  opacity:0;
  transition:opacity .3s;
}
.wed-gallery-item:hover .wed-gallery-overlay{opacity:1}
.wed-gallery-couple{
  font-family:var(--wed-serif);
  font-size:1.15rem;
  font-style:italic;
  color:#fff;
  margin-bottom:4px;
}
.wed-gallery-style{
  font-size:.68rem;
  font-weight:700;
  letter-spacing:.14em;
  text-transform:uppercase;
  color:var(--wed-gold);
}

/* ══════════════════════════════
   PACKAGES / PRICING
══════════════════════════════ */
.wed-packages{
  padding:100px 0;
  background:var(--wed-blush);
}
.wed-packages .wed-section-header{text-align:center}
.wed-package-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:28px;
  max-width:980px;
  margin:0 auto;
}
.wed-pkg-card{
  background:#fff;
  border-radius:16px;
  padding:38px 30px;
  position:relative;
  border:1.5px solid transparent;
  transition:transform .25s,box-shadow .25s;
  text-align:center;
}
.wed-pkg-card.highlight{
  border-color:var(--wed-rose);
  box-shadow:0 12px 40px rgba(196,122,138,.18);
}
.wed-pkg-card:hover{
  transform:translateY(-4px);
  box-shadow:0 16px 44px rgba(0,0,0,.1);
}
.wed-popular-badge{
  position:absolute;
  top:-14px;left:50%;transform:translateX(-50%);
  background:var(--wed-rose);
  color:#fff;
  font-size:.62rem;
  font-weight:700;
  letter-spacing:.15em;
  text-transform:uppercase;
  padding:5px 18px;
  border-radius:20px;
  white-space:nowrap;
}
/* ornamental divider */
.wed-ornament-divider{
  display:flex;align-items:center;gap:10px;
  margin:16px auto;
  color:var(--wed-gold);
  font-size:.7rem;
  width:80%;
  justify-content:center;
}
.wed-ornament-divider::before,
.wed-ornament-divider::after{
  content:'';
  flex:1;height:1px;
  background:linear-gradient(to right,transparent,rgba(201,168,76,.4),transparent);
}
.wed-pkg-name{
  font-family:var(--wed-serif);
  font-size:1.5rem;
  font-weight:400;
  color:var(--wed-night);
  margin-bottom:8px;
}
.wed-pkg-price{
  font-family:var(--wed-serif);
  font-size:2.6rem;
  font-weight:300;
  color:var(--wed-rose);
  line-height:1;
  margin-bottom:24px;
}
.wed-pkg-features{
  list-style:none;
  text-align:left;
  margin-bottom:30px;
}
.wed-pkg-features li{
  font-size:.83rem;
  color:var(--wed-night);
  padding:7px 0;
  border-bottom:1px solid rgba(0,0,0,.05);
  display:flex;align-items:center;gap:10px;
}
.wed-pkg-features li::before{
  content:'✦';
  color:var(--wed-gold);
  font-size:.6rem;
  flex-shrink:0;
}

/* ══════════════════════════════
   SERVICES
══════════════════════════════ */
.wed-services{
  padding:100px 0;
  background:var(--wed-night);
}
.wed-services .wed-eyebrow{color:rgba(201,168,76,.7)}
.wed-services .wed-section-title{color:var(--wed-blush)}
.wed-services-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:2px;
  background:rgba(255,255,255,.05);
  border-radius:12px;
  overflow:hidden;
}
.wed-svc-item{
  padding:38px 30px;
  background:var(--wed-night);
  border:1px solid rgba(255,255,255,.07);
  transition:background .25s;
}
.wed-svc-item:hover{background:rgba(255,255,255,.04)}
.wed-svc-icon{
  font-size:2rem;
  margin-bottom:18px;
  display:block;
}
.wed-svc-title{
  font-family:var(--wed-serif);
  font-size:1.25rem;
  font-weight:400;
  color:var(--wed-blush);
  margin-bottom:10px;
}
.wed-svc-desc{
  font-size:.82rem;
  color:rgba(242,224,218,.5);
  line-height:1.75;
}

/* ══════════════════════════════
   VENUE ABOUT ART
══════════════════════════════ */
.wed-about{
  padding:110px 0;
  background:var(--wed-ivory);
}
.wed-about-inner{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:80px;
  align-items:center;
}
.wed-about-text .wed-section-title{font-size:clamp(1.8rem,3vw,2.6rem)}
.wed-about-text p{
  color:var(--wed-dusty);
  font-size:.9rem;line-height:1.85;
  margin-bottom:16px;
}
.wed-venue-art{
  position:relative;
  height:480px;
  border-radius:20px;
  overflow:hidden;
  background:linear-gradient(to bottom,#1e1824 0%,#2a2432 50%,#3a4030 100%);
}

/* manor house CSS art */
/* sky */
.wed-venue-sky{
  position:absolute;top:0;left:0;right:0;
  height:55%;
  background:linear-gradient(180deg,#1e1428 0%,#2a1e38 40%,#3a2848 70%,#5a3850 100%);
}
/* lawn */
.wed-venue-lawn{
  position:absolute;bottom:0;left:0;right:0;
  height:30%;
  background:linear-gradient(to top,#2a3820 0%,#3a4a28 60%,transparent 100%);
}
/* manor building */
.wed-manor{
  position:absolute;
  bottom:28%;left:50%;
  transform:translateX(-50%);
  width:280px;
}
.wed-manor-main{
  height:130px;
  background:linear-gradient(to bottom,#c8c0b8,#e0d8d0);
  border-radius:2px 2px 0 0;
  position:relative;
}
.wed-manor-roof{
  width:0;height:0;
  border-left:145px solid transparent;
  border-right:145px solid transparent;
  border-bottom:50px solid #5a4838;
  position:absolute;
  top:-50px;left:0;
}
.wed-manor-door{
  position:absolute;
  bottom:0;left:50%;
  transform:translateX(-50%);
  width:36px;height:52px;
  background:#2a1e1a;
  border-radius:18px 18px 0 0;
}
.wed-manor-door::after{
  content:'';
  position:absolute;
  top:4px;left:4px;right:4px;bottom:0;
  border:1px solid rgba(255,255,255,.1);
  border-radius:14px 14px 0 0;
}
/* windows row */
.wed-manor-windows{
  position:absolute;
  top:28px;left:0;right:0;
  display:flex;
  justify-content:space-evenly;
  padding:0 20px;
}
.wed-manor-win{
  width:28px;height:38px;
  background:radial-gradient(ellipse at 40% 35%,rgba(255,240,160,.8),rgba(200,160,80,.6));
  border:2px solid #7a6850;
  border-radius:14px 14px 0 0;
}
/* wing extensions */
.wed-manor-wing{
  position:absolute;
  bottom:0;
  height:80px;
  background:linear-gradient(to bottom,#bab0a8,#d0c8c0);
  width:60px;
}
/* columns on facade */
.wed-manor-columns{
  position:absolute;
  bottom:0;left:50%;
  transform:translateX(-50%);
  display:flex;gap:18px;
}
.wed-manor-col{
  width:8px;height:80px;
  background:linear-gradient(to right,rgba(255,255,255,.3),rgba(255,255,255,.6),rgba(255,255,255,.3));
  border-radius:4px 4px 0 0;
}
/* driveway */
.wed-manor-drive{
  position:absolute;
  bottom:-1px;left:50%;
  transform:translateX(-50%);
  width:100px;height:50px;
  background:linear-gradient(to top,rgba(180,160,120,.4),transparent);
  clip-path:polygon(20% 0%,80% 0%,100% 100%,0% 100%);
}
/* stars */
.wed-star{
  position:absolute;
  border-radius:50%;
  background:#fff;
  opacity:.6;
}

/* ══════════════════════════════
   STATS
══════════════════════════════ */
.wed-stats{
  padding:80px 0;
  background:var(--wed-rose);
}
.wed-stats-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:40px;
  text-align:center;
}
.wed-stat-num{
  font-family:var(--wed-serif);
  font-size:clamp(2.5rem,5vw,4rem);
  color:#fff;
  font-weight:300;
  line-height:1;
  margin-bottom:8px;
}
.wed-stat-label{
  font-size:.72rem;
  font-weight:700;
  letter-spacing:.16em;
  text-transform:uppercase;
  color:rgba(255,255,255,.7);
}

/* ══════════════════════════════
   TEAM
══════════════════════════════ */
.wed-team{
  padding:100px 0;
  background:var(--wed-ivory);
}
.wed-team-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
  gap:28px;
}
.wed-team-card{
  text-align:center;
  padding:36px 20px 28px;
  background:#fff;
  border-radius:16px;
  transition:transform .25s,box-shadow .25s;
}
.wed-team-card:hover{
  transform:translateY(-4px);
  box-shadow:0 16px 44px rgba(0,0,0,.08);
}
.wed-team-avatar{
  position:relative;
  width:100px;height:120px;
  margin:0 auto 20px;
}
.wed-team-head{
  position:absolute;
  top:0;left:50%;transform:translateX(-50%);
  width:46px;height:46px;border-radius:50%;
  background:#d4b090;
}
.wed-team-torso{
  position:absolute;
  top:50px;left:50%;transform:translateX(-50%);
  width:56px;height:52px;
  border-radius:28px 28px 0 0;
}
.wed-team-legs{
  position:absolute;
  bottom:0;left:50%;transform:translateX(-50%);
  display:flex;gap:4px;
}
.wed-team-leg{
  width:23px;height:26px;
  border-radius:0 0 8px 8px;
}
.wed-team-name{
  font-family:var(--wed-serif);
  font-size:1.2rem;
  color:var(--wed-night);
  margin-bottom:4px;
}
.wed-team-role{
  font-size:.72rem;
  font-weight:700;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--wed-rose);
  margin-bottom:8px;
}
.wed-team-years{
  font-size:.8rem;
  color:var(--wed-dusty);
}

/* ══════════════════════════════
   TESTIMONIALS
══════════════════════════════ */
.wed-testimonials{
  padding:100px 0;
  background:var(--wed-blush);
}
.wed-testi-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:28px;
}
.wed-testi-card{
  background:#fff;
  border-radius:14px;
  padding:36px 30px;
  text-align:center;
  position:relative;
}
.wed-testi-rings{
  display:flex;justify-content:center;gap:6px;
  margin-bottom:18px;font-size:1.1rem;
}
.wed-testi-text{
  font-family:var(--wed-serif);
  font-size:1.05rem;
  font-style:italic;
  color:var(--wed-night);
  line-height:1.75;
  margin-bottom:20px;
}
.wed-testi-couple{
  font-size:.75rem;
  font-weight:700;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--wed-rose);
}
.wed-testi-year{
  font-size:.7rem;
  color:var(--wed-dusty);
  display:block;margin-top:2px;
}

/* ══════════════════════════════
   CONTACT / ENQUIRY FORM
══════════════════════════════ */
.wed-contact{
  padding:110px 0;
  background:linear-gradient(135deg,#2a2028 0%,#3a2530 50%,#2a2028 100%);
  position:relative;
  overflow:hidden;
}
.wed-contact::before{
  content:'';
  position:absolute;
  top:-160px;left:50%;transform:translateX(-50%);
  width:600px;height:600px;
  border-radius:50%;
  background:radial-gradient(circle,rgba(196,122,138,.15),transparent 70%);
  pointer-events:none;
}
.wed-contact-inner{
  position:relative;z-index:2;
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:80px;
  align-items:start;
}
.wed-contact-info h2{
  font-family:var(--wed-serif);
  font-size:clamp(1.8rem,3.5vw,2.8rem);
  font-weight:300;
  color:var(--wed-blush);
  margin-bottom:18px;
}
.wed-contact-info p{
  color:rgba(242,224,218,.6);
  font-size:.88rem;line-height:1.85;
  margin-bottom:30px;
}
.wed-contact-details{
  list-style:none;
  display:flex;flex-direction:column;gap:14px;
}
.wed-contact-details li{
  font-size:.82rem;
  color:rgba(242,224,218,.65);
  display:flex;align-items:center;gap:12px;
}
.wed-contact-icon{
  width:36px;height:36px;
  border-radius:50%;
  background:rgba(196,122,138,.25);
  display:flex;align-items:center;justify-content:center;
  font-size:.85rem;
  flex-shrink:0;
}
.wed-form{
  background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.12);
  border-radius:16px;
  padding:38px 36px;
}
.wed-form h3{
  font-family:var(--wed-serif);
  font-size:1.6rem;
  font-weight:400;
  color:var(--wed-blush);
  margin-bottom:8px;
}
.wed-form .wed-ornament-divider{margin-bottom:24px;color:rgba(201,168,76,.5)}
.wed-field{margin-bottom:18px}
.wed-field label{
  display:block;
  font-size:.68rem;
  font-weight:700;
  letter-spacing:.14em;
  text-transform:uppercase;
  color:rgba(242,224,218,.55);
  margin-bottom:7px;
}
.wed-field input,
.wed-field select,
.wed-field textarea{
  width:100%;
  padding:12px 16px;
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.14);
  border-radius:8px;
  color:var(--wed-blush);
  font-family:var(--wed-sans);
  font-size:.86rem;
  transition:border-color .2s,background .2s;
}
.wed-field select option{background:#2a2028;color:var(--wed-blush)}
.wed-field input:focus,
.wed-field select:focus,
.wed-field textarea:focus{outline:none;border-color:var(--wed-rose);background:rgba(255,255,255,.1)}
.wed-field textarea{height:90px;resize:vertical}
.wed-field-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.wed-consent{
  display:flex;gap:12px;align-items:flex-start;
  margin-bottom:22px;
}
.wed-consent input[type="checkbox"]{
  width:16px;height:16px;
  margin-top:2px;
  accent-color:var(--wed-rose);
  flex-shrink:0;
}
.wed-consent label{
  font-size:.75rem;
  color:rgba(242,224,218,.45);
  line-height:1.6;
  text-transform:none;
  letter-spacing:0;
}
.wed-form .wed-btn{width:100%;text-align:center}
.wed-form-success{
  display:none;
  text-align:center;
  padding:28px;
  font-family:var(--wed-serif);
  font-size:1.1rem;
  font-style:italic;
  color:var(--wed-blush);
}

/* responsive */
@media(max-width:860px){
  .wed-about-inner,.wed-contact-inner{grid-template-columns:1fr;gap:48px}
  .wed-about-inner{direction:ltr}
  .wed-venue-art{height:320px}
  .wed-services-grid{grid-template-columns:1fr 1fr}
  .wed-stats-grid{grid-template-columns:repeat(2,1fr)}
  .wed-gallery-grid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:600px){
  .wed-gallery-grid{grid-template-columns:1fr}
  .wed-services-grid{grid-template-columns:1fr}
  .wed-stats-grid{grid-template-columns:1fr 1fr}
  .wed-field-row{grid-template-columns:1fr}
  .wed-hero h1{font-size:3rem}
}
</style>
<?php get_header(); ?>
<div class="wed-page">
">
<?php wp_body_open(); ?>

<!-- ══════════════════════════════
     HERO
══════════════════════════════ -->
<section class="wed-hero">

  <!-- fairy lights -->
  <?php foreach ( $lights as $l ) : ?>
  <div class="wed-fairy-light" style="
    left:<?php echo $l['x']; ?>%;
    top:<?php echo $l['y']; ?>%;
    width:<?php echo $l['size']; ?>px;
    height:<?php echo $l['size']; ?>px;
    background:<?php echo $l['color']; ?>;
    --wed-dur:<?php echo $l['dur']; ?>s;
    --wed-del:<?php echo $l['del']; ?>s;
    box-shadow:0 0 <?php echo $l['size'] * 2; ?>px <?php echo $l['color']; ?>;
  "></div>
  <?php endforeach; ?>

  <!-- falling petals -->
  <?php foreach ( $petals as $p ) : ?>
  <div class="wed-petal" style="
    left:<?php echo $p['x']; ?>%;
    width:<?php echo $p['size']; ?>px;
    height:<?php echo (int)($p['size'] * 0.75); ?>px;
    background:<?php echo $p['color']; ?>;
    --wed-pdur:<?php echo $p['dur']; ?>s;
    --wed-pdel:<?php echo $p['delay']; ?>s;
    --wed-rot:<?php echo $p['rot']; ?>deg;
    --wed-swing:<?php echo (rand(0,1)?'':'-').$p['swing']; ?>px;
    opacity:.7;
  "></div>
  <?php endforeach; ?>

  <!-- moon -->
  <div class="wed-moon"></div>

  <!-- garden arch -->
  <div class="wed-arch-wrap">
    <div class="wed-arch-top" style="left:50px;right:50px"></div>
    <!-- arch legs -->
    <div class="wed-arch-leg" style="left:50px;height:340px"></div>
    <div class="wed-arch-leg" style="right:50px;height:340px"></div>
    <!-- floral blooms on arch -->
    <?php
    $arch_bloom_positions = [
      [50,5],[60,18],[48,32],[62,48],[52,62],[58,76],
      [290,5],[280,18],[295,32],[278,48],[292,62],[282,76],
      [110,2],[140,0],[170,2],[200,0],[230,2],[260,0],
      [120,16],[150,12],[180,16],[210,12],[240,16],
    ];
    $bloom_colors=['#f2bfc8','#e8a8b8','#fce4e8','#f0b0bc','#fad8e0','#d4906a','#f5d0d8'];
    foreach($arch_bloom_positions as $bi=>$bp):
      $bc=$bloom_colors[$bi%count($bloom_colors)];
      $bsize=rand(10,22);
    ?>
    <div class="wed-arch-bloom" style="
      left:<?php echo $bp[0]; ?>px;
      bottom:<?php echo (300 - ($bp[1] * 4)); ?>px;
      width:<?php echo $bsize; ?>px;height:<?php echo $bsize; ?>px;
      background:<?php echo $bc; ?>;
    "></div>
    <?php endforeach; ?>

    <!-- candles lining aisle -->
    <?php for($ci=0;$ci<6;$ci++): $cx=$ci*40+30; ?>
    <?php for($side=0;$side<2;$side++): ?>
    <div class="wed-candle" style="
      <?php echo $side===0 ? 'left:'.($cx).'px' : 'right:'.($cx).'px'; ?>;
      height:<?php echo rand(36,48); ?>px;
    ">
      <div class="wed-candle-flame" style="animation-delay:<?php echo lcg_value()*.8; ?>s"></div>
    </div>
    <?php endfor; ?>
    <?php endfor; ?>
  </div>

  <!-- trees flanking -->
  <div class="wed-tree" style="left:6%">
    <div class="wed-tree-crown" style="width:80px;height:130px;background:linear-gradient(to bottom,#2a4a20,#3a5a28)"></div>
    <div class="wed-tree-trunk" style="height:60px"></div>
  </div>
  <div class="wed-tree" style="left:13%">
    <div class="wed-tree-crown" style="width:60px;height:100px;background:linear-gradient(to bottom,#3a5a28,#4a6a38)"></div>
    <div class="wed-tree-trunk" style="height:45px"></div>
  </div>
  <div class="wed-tree" style="right:6%">
    <div class="wed-tree-crown" style="width:80px;height:130px;background:linear-gradient(to bottom,#2a4a20,#3a5a28)"></div>
    <div class="wed-tree-trunk" style="height:60px"></div>
  </div>
  <div class="wed-tree" style="right:13%">
    <div class="wed-tree-crown" style="width:60px;height:100px;background:linear-gradient(to bottom,#3a5a28,#4a6a38)"></div>
    <div class="wed-tree-trunk" style="height:45px"></div>
  </div>

  <div class="wed-ground"></div>

  <!-- hero copy -->
  <div class="wed-hero-content">
    <div class="wed-hero-ornament">✦</div>
    <h1>Your Perfect<br><em>Wedding Day</em></h1>
    <p class="wed-hero-sub">Bespoke weddings crafted with love, artistry, and meticulous attention to every detail that matters to you.</p>
    <div class="wed-hero-badges">
      <span class="wed-hero-badge">Award-Winning Planners</span>
      <span class="wed-hero-badge">500+ Weddings</span>
      <span class="wed-hero-badge">Destination Experts</span>
    </div>
    <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap">
      <a href="#enquiry" class="wed-btn wed-btn-rose">Begin Your Story</a>
      <a href="#gallery" class="wed-btn wed-btn-light">View Our Work</a>
    </div>
  </div>

  <div class="wed-hero-scroll">
    <span>Scroll</span>
    <div class="wed-scroll-line"></div>
  </div>

</section>

<!-- MARQUEE -->
<div class="wed-marquee-wrap">
  <div class="wed-marquee-track">
    <?php foreach ( $marquee_items as $item ) : ?>
    <span class="wed-marquee-item"><?php echo esc_html( $item ); ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══════════════════════════════
     GALLERY
══════════════════════════════ -->
<section class="wed-gallery" id="gallery">
  <div class="wed-wrap">
    <div class="wed-section-header wed-reveal">
      <span class="wed-eyebrow">Our Couples</span>
      <h2 class="wed-section-title">Stories We've Told</h2>
    </div>
    <div class="wed-filter-bar wed-reveal">
      <button class="wed-filter-btn active" data-filter="all">All Weddings</button>
      <button class="wed-filter-btn" data-filter="garden">Garden</button>
      <button class="wed-filter-btn" data-filter="rustic">Rustic Barn</button>
      <button class="wed-filter-btn" data-filter="ballroom">Ballroom</button>
      <button class="wed-filter-btn" data-filter="coastal">Coastal</button>
    </div>
    <div class="wed-gallery-grid" id="wed-gallery-grid">
      <?php
      $gallery_bgs = [
        'garden'   => 'linear-gradient(160deg,#2a4020,#4a7040 40%,#8aab80 80%,#a0c898)',
        'rustic'   => 'linear-gradient(160deg,#3a2818,#6a4830 40%,#a07850 80%,#c09870)',
        'ballroom' => 'linear-gradient(160deg,#1e1e2e,#2e2a4a 40%,#4a4070 80%,#6a60a0)',
        'coastal'  => 'linear-gradient(160deg,#0a1e30,#1a3a5a 40%,#2a6080 80%,#60a0c0)',
      ];
      foreach ( $weddings as $wi => $w ) :
        $bg = $gallery_bgs[ $w['cat'] ] ?? $gallery_bgs['garden'];
      ?>
      <div class="wed-gallery-item wed-reveal" data-cat="<?php echo esc_attr($w['cat']); ?>">
        <div class="wed-gallery-art" style="background:<?php echo $bg; ?>">
          <!-- simple scene element per style -->
          <?php if ($w['cat']==='garden'): ?>
          <div style="font-size:4rem;opacity:.3">🌸</div>
          <?php elseif ($w['cat']==='rustic'): ?>
          <div style="font-size:4rem;opacity:.3">🌾</div>
          <?php elseif ($w['cat']==='ballroom'): ?>
          <div style="font-size:4rem;opacity:.2">✨</div>
          <?php elseif ($w['cat']==='coastal'): ?>
          <div style="font-size:4rem;opacity:.3">🌊</div>
          <?php endif; ?>
          <!-- rings icon overlay -->
          <div style="position:absolute;bottom:40%;left:50%;transform:translateX(-50%);font-size:2.5rem;filter:drop-shadow(0 4px 12px rgba(0,0,0,.5))">💍</div>
        </div>
        <div class="wed-gallery-overlay">
          <div class="wed-gallery-couple"><?php echo esc_html($w['title']); ?></div>
          <div class="wed-gallery-style"><?php echo esc_html($w['style']); ?> · <?php echo esc_html($w['season']); ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     PACKAGES
══════════════════════════════ -->
<section class="wed-packages" id="packages">
  <div class="wed-wrap">
    <div class="wed-section-header wed-reveal">
      <span class="wed-eyebrow">Our Collections</span>
      <h2 class="wed-section-title">Wedding Packages</h2>
    </div>
    <div class="wed-package-grid">
      <?php foreach ( $packages as $pkg ) : ?>
      <div class="wed-pkg-card wed-reveal <?php echo $pkg['highlight'] ? 'highlight' : ''; ?>">
        <?php if ($pkg['highlight']): ?><span class="wed-popular-badge">Our Signature Package</span><?php endif; ?>
        <div class="wed-pkg-name"><?php echo esc_html($pkg['name']); ?></div>
        <div class="wed-ornament-divider">✦</div>
        <div class="wed-pkg-price"><?php echo esc_html($pkg['price']); ?></div>
        <ul class="wed-pkg-features">
          <?php foreach ( $pkg['includes'] as $feature ) : ?>
          <li><?php echo esc_html($feature); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#enquiry" class="wed-btn <?php echo $pkg['highlight'] ? 'wed-btn-rose' : 'wed-btn-outline'; ?>" style="width:100%;text-align:center">Enquire Now</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     SERVICES
══════════════════════════════ -->
<section class="wed-services">
  <div class="wed-wrap">
    <div class="wed-section-header wed-reveal">
      <span class="wed-eyebrow">Everything You Need</span>
      <h2 class="wed-section-title">Our Services</h2>
    </div>
    <div class="wed-services-grid">
      <?php foreach ( $services as $svc ) : ?>
      <div class="wed-svc-item wed-reveal">
        <span class="wed-svc-icon"><?php echo $svc['icon']; ?></span>
        <div class="wed-svc-title"><?php echo esc_html($svc['title']); ?></div>
        <p class="wed-svc-desc"><?php echo esc_html($svc['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     ABOUT / VENUE ART
══════════════════════════════ -->
<section class="wed-about">
  <div class="wed-wrap">
    <div class="wed-about-inner">
      <div class="wed-venue-art wed-reveal">
        <div class="wed-venue-sky">
          <!-- stars -->
          <?php for($si=0;$si<28;$si++): $sz=rand(1,3); ?>
          <div class="wed-star" style="
            left:<?php echo rand(2,98); ?>%;
            top:<?php echo rand(5,85); ?>%;
            width:<?php echo $sz; ?>px;
            height:<?php echo $sz; ?>px;
            opacity:<?php echo round(.3+lcg_value()*.5,2); ?>;
          "></div>
          <?php endfor; ?>
        </div>
        <div class="wed-venue-lawn"></div>

        <!-- manor house -->
        <div class="wed-manor">
          <!-- wings -->
          <div class="wed-manor-wing" style="left:-55px"></div>
          <div class="wed-manor-wing" style="right:-55px"></div>
          <!-- main -->
          <div class="wed-manor-main">
            <div class="wed-manor-roof"></div>
            <div class="wed-manor-windows">
              <div class="wed-manor-win"></div>
              <div class="wed-manor-win"></div>
              <div class="wed-manor-win"></div>
              <div class="wed-manor-win"></div>
            </div>
            <div class="wed-manor-door"></div>
            <div class="wed-manor-columns">
              <div class="wed-manor-col"></div>
              <div class="wed-manor-col"></div>
              <div class="wed-manor-col"></div>
              <div class="wed-manor-col"></div>
            </div>
          </div>
          <div class="wed-manor-drive"></div>
        </div>

        <!-- fairy lights on venue art -->
        <?php for($fl=0;$fl<20;$fl++): $fls=rand(3,6); ?>
        <div class="wed-fairy-light" style="
          left:<?php echo rand(5,95); ?>%;
          top:<?php echo rand(5,40); ?>%;
          width:<?php echo $fls; ?>px;height:<?php echo $fls; ?>px;
          background:#fff9e0;
          box-shadow:0 0 <?php echo $fls*2; ?>px #ffe4a0;
          animation:wed-twinkle <?php echo round(1.5+lcg_value()*2,2); ?>s ease-in-out <?php echo round(lcg_value()*3,2); ?>s infinite alternate;
        "></div>
        <?php endfor; ?>
      </div>
      <div class="wed-about-text wed-reveal">
        <span class="wed-eyebrow">Our Estate</span>
        <h2 class="wed-section-title">A Setting Made for Love</h2>
        <p>Nestled in ten acres of landscaped gardens in the Cotswolds, our Georgian manor has been welcoming couples since 1994. The wisteria-draped stone walls, the candlelit Great Hall, and the rose garden at golden hour have become the backdrop for over five hundred love stories.</p>
        <p>Our dedicated team of planners, florists, and chefs work exclusively from our estate, ensuring every element is held to the same exceptional standard. We do not juggle multiple weddings on the same day — your day is your day alone.</p>
        <div class="wed-ornament-divider" style="justify-content:flex-start;width:auto;margin:20px 0">✦</div>
        <a href="#enquiry" class="wed-btn wed-btn-rose">Arrange a Visit</a>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     STATS
══════════════════════════════ -->
<section class="wed-stats">
  <div class="wed-wrap">
    <div class="wed-stats-grid">
      <?php
      $stats = [
        ['num'=>500, 'suffix'=>'+',   'label'=>'Weddings Planned'],
        ['num'=>30,  'suffix'=>' yrs','label'=>'Years of Excellence'],
        ['num'=>10,  'suffix'=>' ac', 'label'=>'Estate Grounds'],
        ['num'=>99,  'suffix'=>'%',   'label'=>'Recommend Us'],
      ];
      foreach ( $stats as $st ) :
      ?>
      <div class="wed-reveal">
        <div class="wed-stat-num" data-target="<?php echo $st['num']; ?>" data-suffix="<?php echo esc_attr($st['suffix']); ?>">0</div>
        <div class="wed-stat-label"><?php echo esc_html($st['label']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     TEAM
══════════════════════════════ -->
<section class="wed-team">
  <div class="wed-wrap">
    <div class="wed-section-header wed-reveal">
      <span class="wed-eyebrow">The People Behind the Magic</span>
      <h2 class="wed-section-title">Meet Your Planners</h2>
    </div>
    <div class="wed-team-grid">
      <?php
      $team_palettes = [
        ['torso'=>'#c47a8a','leg'=>'#b06878','skin'=>'#d4b090','hair'=>'#3a1808'],
        ['torso'=>'#2a2028','leg'=>'#1a1018','skin'=>'#c8a870','hair'=>'#2a1a10'],
        ['torso'=>'#8a9878','leg'=>'#7a8868','skin'=>'#c89060','hair'=>'#0a0804'],
        ['torso'=>'#c9a84c','leg'=>'#b8942a','skin'=>'#d4a870','hair'=>'#4a3820'],
      ];
      foreach ( $team as $ti => $t ) :
        $tp = $team_palettes[ $ti % count($team_palettes) ];
      ?>
      <div class="wed-team-card wed-reveal">
        <div class="wed-team-avatar">
          <div class="wed-team-head" style="background:<?php echo $tp['skin']; ?>">
            <!-- hair -->
            <div style="position:absolute;top:-5px;left:1px;right:1px;height:<?php echo $t['female'] ? '22px' : '13px'; ?>;background:<?php echo $t['hair_color']; ?>;border-radius:12px 12px 0 0"></div>
            <?php if ($t['female'] && $ti===0): ?>
            <!-- updo for Genevieve -->
            <div style="position:absolute;top:-9px;right:-3px;width:13px;height:13px;border-radius:50%;background:<?php echo $t['hair_color']; ?>"></div>
            <?php elseif ($t['female'] && $ti===2): ?>
            <!-- natural hair Beatrice -->
            <div style="position:absolute;top:-4px;left:-4px;right:-4px;height:18px;border-radius:50%;background:<?php echo $t['hair_color']; ?>"></div>
            <?php endif; ?>
            <?php if ($t['glasses']): ?>
            <div style="position:absolute;bottom:8px;left:3px;right:3px;height:4px;background:rgba(0,0,0,.35);border-radius:2px;display:flex;gap:2px">
              <div style="flex:1;border:1px solid rgba(0,0,0,.4);border-radius:2px"></div>
              <div style="flex:1;border:1px solid rgba(0,0,0,.4);border-radius:2px"></div>
            </div>
            <?php endif; ?>
          </div>
          <div class="wed-team-torso" style="background:<?php echo $tp['torso']; ?>">
            <!-- lapel detail -->
            <div style="position:absolute;top:6px;left:50%;transform:translateX(-50%);width:16px;height:22px;border-left:2px solid rgba(255,255,255,.25);border-right:2px solid rgba(255,255,255,.25);clip-path:polygon(50% 0%,0% 100%,100% 100%)"></div>
          </div>
          <div class="wed-team-legs" style="position:absolute;bottom:0;left:50%;transform:translateX(-50%);display:flex;gap:4px">
            <div class="wed-team-leg" style="background:<?php echo $tp['leg']; ?>"></div>
            <div class="wed-team-leg" style="background:<?php echo $tp['leg']; ?>"></div>
          </div>
        </div>
        <div class="wed-team-name"><?php echo esc_html($t['name']); ?></div>
        <div class="wed-team-role"><?php echo esc_html($t['role']); ?></div>
        <div class="wed-team-years"><?php echo esc_html($t['years']); ?> experience</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     TESTIMONIALS
══════════════════════════════ -->
<section class="wed-testimonials">
  <div class="wed-wrap">
    <div class="wed-section-header wed-reveal">
      <span class="wed-eyebrow">Love Letters</span>
      <h2 class="wed-section-title">From Our Couples</h2>
    </div>
    <div class="wed-testi-grid">
      <?php foreach ( $testimonials as $t ) : ?>
      <div class="wed-testi-card wed-reveal">
        <div class="wed-testi-rings">💍 💍</div>
        <p class="wed-testi-text">"<?php echo esc_html($t['text']); ?>"</p>
        <div class="wed-testi-couple"><?php echo esc_html($t['couple']); ?></div>
        <span class="wed-testi-year"><?php echo esc_html($t['year']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     ENQUIRY FORM
══════════════════════════════ -->
<section class="wed-contact" id="enquiry">
  <div class="wed-wrap">
    <div class="wed-contact-inner">
      <div class="wed-contact-info wed-reveal">
        <span class="wed-eyebrow" style="color:rgba(201,168,76,.7)">Get In Touch</span>
        <h2>Let's Start Planning Your Day</h2>
        <p>Every extraordinary wedding begins with a conversation. Tell us about your vision and a dedicated planner will be in touch within 24 hours.</p>
        <ul class="wed-contact-details">
          <li><span class="wed-contact-icon">📍</span>Hartley Manor, Chipping Norton, Oxfordshire OX7 5QA</li>
          <li><span class="wed-contact-icon">📞</span>+44 1608 649 000</li>
          <li><span class="wed-contact-icon">✉</span>hello@hartleymanor.co.uk</li>
          <li><span class="wed-contact-icon">🕐</span>Mon – Fri: 09:00 – 18:00 · Sat: 10:00 – 15:00</li>
        </ul>
      </div>
      <div class="wed-form wed-reveal">
        <h3>Your Enquiry</h3>
        <div class="wed-ornament-divider">✦</div>
        <?php wp_nonce_field('tf_wed_enquiry','tf_wed_nonce'); ?>
        <div class="wed-field-row">
          <div class="wed-field">
            <label>Your Name</label>
            <input type="text" name="wed_name1" placeholder="Charlotte" required>
          </div>
          <div class="wed-field">
            <label>Partner's Name</label>
            <input type="text" name="wed_name2" placeholder="Edward" required>
          </div>
        </div>
        <div class="wed-field">
          <label>Email Address</label>
          <input type="email" name="wed_email" placeholder="charlotte@example.com" required>
        </div>
        <div class="wed-field">
          <label>Phone Number</label>
          <input type="tel" name="wed_phone" placeholder="+44 7700 900000">
        </div>
        <div class="wed-field-row">
          <div class="wed-field">
            <label>Wedding Date</label>
            <input type="date" name="wed_date">
          </div>
          <div class="wed-field">
            <label>Guest Count</label>
            <select name="wed_guests">
              <option value="">— Approx. guests —</option>
              <option>Intimate (up to 20)</option>
              <option>Small (21–50)</option>
              <option>Medium (51–100)</option>
              <option>Large (101–150)</option>
              <option>Grand (150+)</option>
            </select>
          </div>
        </div>
        <div class="wed-field">
          <label>Wedding Style</label>
          <select name="wed_style">
            <option value="">— Preferred style —</option>
            <option>Garden / Outdoor</option>
            <option>Rustic Barn</option>
            <option>Ballroom / Formal</option>
            <option>Coastal / Beach</option>
            <option>Destination</option>
            <option>Not sure yet</option>
          </select>
        </div>
        <div class="wed-field">
          <label>Tell Us Your Vision</label>
          <textarea name="wed_message" placeholder="Share your dream…"></textarea>
        </div>
        <div class="wed-consent">
          <input type="checkbox" id="wed-consent" name="wed_consent" required>
          <label for="wed-consent">I agree to be contacted about my wedding enquiry and confirm I have read the privacy policy.</label>
        </div>
        <button type="submit" class="wed-btn wed-btn-rose" id="wed-submit-btn">Send My Enquiry</button>
        <div class="wed-form-success" id="wed-success">
          ✦ Thank you, <?php echo isset($_POST['wed_name1']) ? esc_html($_POST['wed_name1']) : 'lovely couple'; ?>. We can't wait to hear your story. We'll be in touch very soon.
        </div>
      </div>
    </div>
  </div>
</section>
<script>
(function(){
  /* scroll reveal */
  const reveals = document.querySelectorAll('.wed-reveal');
  const ro = new IntersectionObserver(e=>{
    e.forEach(en=>{if(en.isIntersecting){en.target.classList.add('visible');ro.unobserve(en.target);}});
  },{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  reveals.forEach(el=>ro.observe(el));

  /* animated counters */
  const easeOut=t=>1-Math.pow(1-t,3);
  const nums=document.querySelectorAll('.wed-stat-num[data-target]');
  const co=new IntersectionObserver(e=>{
    e.forEach(en=>{
      if(!en.isIntersecting)return;
      const el=en.target,target=+el.dataset.target,suffix=el.dataset.suffix||'',dur=1800;
      let start=null;
      (function tick(ts){
        if(!start)start=ts;
        const p=Math.min((ts-start)/dur,1);
        el.textContent=Math.round(easeOut(p)*target)+suffix;
        if(p<1)requestAnimationFrame(tick);
      })(performance.now());
      co.unobserve(el);
    });
  },{threshold:.4});
  nums.forEach(el=>co.observe(el));

  /* gallery filter */
  const filterBtns=document.querySelectorAll('.wed-filter-btn');
  const galleryCards=document.querySelectorAll('#wed-gallery-grid .wed-gallery-item');
  filterBtns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      filterBtns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');btn.setAttribute('aria-pressed','true');
      const f=btn.dataset.filter;
      galleryCards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f));
    });
    btn.setAttribute('aria-pressed',btn.classList.contains('active')?'true':'false');
  });

  /* form submit */
  const form=document.querySelector('.wed-form');
  if(form){
    form.addEventListener('submit',function(e){
      e.preventDefault();
      const btn=document.getElementById('wed-submit-btn');
      const suc=document.getElementById('wed-success');
      if(btn)btn.style.display='none';
      if(suc)suc.style.display='block';
    });
  }
})();
</script>
</div><!-- .wed-page -->
<?php get_footer(); ?>
