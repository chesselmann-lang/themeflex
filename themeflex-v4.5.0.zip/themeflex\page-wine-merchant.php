<?php
/**
 * Template Name: Wine Merchant — Fine Wine & Spirits
 *
 * Premium fine wine merchant page for ThemeFlex.
 * Concept : Stone cellar at candlelight — arched brick ceiling, floor-to-ceiling
 *           wine rack wall, oak barrels, crystal decanters on a tasting table,
 *           floating golden dust motes, a single illuminated bottle.
 * Palette : Deep burgundy / aged oak / champagne gold / candlelight cream.
 * Fonts   : Playfair Display SC (headings) + Lato (body).
 * Namespace: --wm-*
 *
 * @package ThemeFlex
 */

if ( ! defined( 'ABSPATH' ) ) exit;

srand( crc32( get_the_permalink() ) );

/* ── wine rack (rows × cols) ─────────────────── */
$wm_rack_rows = 8;
$wm_rack_cols = 12;
/* random fill probability and age indicator */
$wm_rack_cells = [];
for($r=0;$r<$wm_rack_rows;$r++){
    $row=[];
    for($c=0;$c<$wm_rack_cols;$c++){
        $filled = (rand(0,10) > 2); // ~73% full
        $hue    = [0,8,16,340,200,60][rand(0,5)]; // red/rosé/white/sparkling
        $row[]  = ['filled'=>$filled,'hue'=>$hue,'sat'=>rand(50,90),'lit'=>rand(25,55)];
    }
    $wm_rack_cells[]=$row;
}

/* ── barrels ─────────────────────────────────── */
$wm_barrels = [
    ['w'=>90,'h'=>70,'x'=>'12%','y'=>0],
    ['w'=>80,'h'=>62,'x'=>'22%','y'=>8],
    ['w'=>95,'h'=>72,'x'=>'74%','y'=>0],
    ['w'=>85,'h'=>65,'x'=>'84%','y'=>6],
];

/* ── floating dust motes ─────────────────────── */
$wm_motes=[];
for($i=0;$i<30;$i++){
    $wm_motes[]=[
        'left'  => rand(3,97),
        'top'   => rand(8,88),
        'size'  => rand(2,5),
        'delay' => rand(0,8000),
        'dur'   => rand(4000,10000),
    ];
}

/* ── tasting candles ─────────────────────────── */
$wm_candles=[
    ['h'=>60,'left'=>'35%'],['h'=>44,'left'=>'40%'],['h'=>52,'left'=>'60%'],['h'=>40,'left'=>'65%'],
];

/* ── stats ───────────────────────────────────── */
$wm_stats=[
    ['val'=>4800, 'suffix'=>'+','label'=>'Labels in Stock'],
    ['val'=>45,   'suffix'=>'', 'label'=>'Years Established'],
    ['val'=>4.9,  'suffix'=>'★','label'=>'Google Rating'],
    ['val'=>12,   'suffix'=>'', 'label'=>'Wine Regions'],
];

/* ── collections ──────────────────────────────── */
$wm_collections=[
    [
        'region'=>'Bordeaux', 'country'=>'France',
        'desc'=>'From the great châteaux of the Left Bank to the plummy delights of Saint-Émilion — classic Bordeaux for every occasion and cellar.',
        'highlight'=>'Château Pichon Baron 2018 · Léoville-Barton 2016',
        'hue'=>0,
    ],
    [
        'region'=>'Burgundy', 'country'=>'France',
        'desc'=>'Precious allocations from Domaine de la Romanée-Conti through to exceptional village-level Pinot Noir and Chardonnay for the discerning palate.',
        'highlight'=>'Gevrey-Chambertin · Meursault Premier Cru',
        'hue'=>330,
    ],
    [
        'region'=>'Tuscany', 'country'=>'Italy',
        'desc'=>'Brunello, Barolo and the Super Tuscans that changed wine history — Italy\'s finest alongside exciting artisan producers from Bolgheri and beyond.',
        'highlight'=>'Sassicaia · Ornellaia · Biondi-Santi',
        'hue'=>16,
    ],
    [
        'region'=>'Napa Valley', 'country'=>'USA',
        'desc'=>'Cult Californian Cabernet Sauvignon from the valley\'s most coveted producers — power and elegance in equal measure.',
        'highlight'=>'Opus One · Screaming Eagle · Harlan Estate',
        'hue'=>8,
    ],
    [
        'region'=>'Champagne', 'country'=>'France',
        'desc'=>'Prestige cuvées and grower Champagnes from the finest houses and récoltants — magnums, single-vineyard and vintage bottlings.',
        'highlight'=>'Krug · Jacques Selosse · Bollinger RD',
        'hue'=>55,
    ],
    [
        'region'=>'Whisky & Spirits', 'country'=>'Scotland & World',
        'desc'=>'An exceptional cellar of single malts, vintage cognac and rare spirits — investment bottles, limited releases and everyday drams alike.',
        'highlight'=>'Macallan · Dalmore · Hennessy Paradis',
        'hue'=>32,
    ],
];

/* ── services ─────────────────────────────────── */
$wm_services=[
    ['icon'=>'🍾','name'=>'Cellar Management',    'desc'=>'We store, insure and manage your collection in our temperature-controlled vault, with full provenance records and market valuations.'],
    ['icon'=>'📦','name'=>'Corporate Supply',     'desc'=>'Bespoke lists for restaurants, hotels and corporate clients — from house pours to sommelier-curated fine wine programmes.'],
    ['icon'=>'🎁','name'=>'Gift Service',         'desc'=>'Beautifully packaged gifts from a single bottle with handwritten card to custom mixed cases and personalised wine boxes.'],
    ['icon'=>'📈','name'=>'Wine Investment',      'desc'=>'Expert guidance on building a fine wine investment portfolio — with market intelligence, provenance verification and exit strategies.'],
    ['icon'=>'🍽','name'=>'Private Tastings',     'desc'=>'Hosted evenings in our cellar for six to thirty guests — themed by region, producer or vintage, led by our Master of Wine.'],
    ['icon'=>'🚚','name'=>'Next-Day Delivery',    'desc'=>'Temperature-controlled delivery to mainland UK addresses. International shipping available to over 45 countries.'],
];

/* ── events ────────────────────────────────────── */
$wm_events=[
    ['title'=>'An Evening in Burgundy',       'date'=>'Thursday 15 May 2026', 'price'=>'£145 pp', 'desc'=>'Six Pinot Noirs and three Chardonnays led by MW David Ashton — from village to Grand Cru.'],
    ['title'=>'Bordeaux First Growths',       'date'=>'Friday 6 June 2026',   'price'=>'£295 pp', 'desc'=>'A rare vertical of five First Growths from the same legendary vintage with matching foods.'],
    ['title'=>'New World vs Old World',       'date'=>'Thursday 26 June 2026','price'=>'£95 pp',  'desc'=>'A blind comparative tasting — classic European producers head-to-head with New World rivals.'],
    ['title'=>'Single Malt Whisky Masterclass','date'=>'Friday 18 July 2026', 'price'=>'£125 pp', 'desc'=>'Twelve expressions charting the regions of Scotland, hosted by our resident whisky specialist.'],
];

/* ── team ──────────────────────────────────────── */
$wm_team=[
    ['name'=>'Edmund Ashby MW',   'role'=>'Founder & Master of Wine','spec'=>'Bordeaux · Burgundy · Investment'],
    ['name'=>'Clara Fontaine',    'role'=>'Head Sommelier',          'spec'=>'Champagne · Italy · Food Pairing'],
    ['name'=>'James Okafor WSET4','role'=>'Spirits Specialist',      'spec'=>'Whisky · Cognac · Armagnac'],
    ['name'=>'Vivienne Crane',    'role'=>'Cellar Manager',          'spec'=>'Storage · Provenance · Valuations'],
];

/* ── testimonials ────────────────────────────── */
$wm_testimonials=[
    ['name'=>'Lord & Lady Pemberton','role'=>'Private Collectors','text'=>'Edmund\'s knowledge is without equal. He has guided our cellar for fifteen years and every recommendation has been impeccable. The storage service is faultless.'],
    ['name'=>'Chef Marco Villani',   'role'=>'The Aldgate, London',  'text'=>'Our restaurant wine list is entirely curated by Clara and the team. Guest response has been extraordinary — our wine sales increased 40% in the first year.'],
    ['name'=>'Charlotte Sayers',     'role'=>'Corporate Client',     'text'=>'We use them for all client gifts and events. The presentation is always stunning and the selection thoughtful. The evening in Burgundy was genuinely one of the best nights of the year.'],
];

/* ── FAQs ─────────────────────────────────────── */
$wm_faqs=[
    ['q'=>'Can you source a specific bottle or vintage I cannot find elsewhere?',
     'a'=>'Very often, yes. Our network of négociants, châteaux and auction partners spans over 40 countries. Contact us with your requirements and we will do our best to locate it.'],
    ['q'=>'Do you offer en primeur (futures) buying?',
     'a'=>'Yes. We offer a full en primeur service each spring for the major Bordeaux, Burgundy and Rhône releases. Subscribers to our mailing list receive priority allocation offers.'],
    ['q'=>'How do you store wine for clients?',
     'a'=>'Our bonded warehouse maintains 12–14°C at 70–75% humidity with vibration-free racking. All stock is insured and segregated under HMRC bond so you pay no duty until withdrawal.'],
    ['q'=>'What is your minimum order for delivery?',
     'a'=>'There is no minimum order. Delivery is free on orders over £150; a flat £9.95 charge applies to smaller orders. We use specialist wine carriers for all shipments.'],
    ['q'=>'Do you buy private cellars?',
     'a'=>'We consider private cellar purchases of any size. Please email us a list with quantities and conditions and we will respond with an offer within 48 hours.'],
];

get_header();
?>

<style>
/* ══════════════════════════════════════════
   WINE MERCHANT — CSS DESIGN SYSTEM
   Namespace: --wm-*
══════════════════════════════════════════ */
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display+SC:ital,wght@0,400;0,700;1,400&family=Lato:wght@300;400;700&display=swap');

:root{
    --wm-burg    : #5C1A1A;
    --wm-burg-d  : #3A0E0E;
    --wm-burg-l  : #8C3030;
    --wm-oak     : #6A4820;
    --wm-oak-l   : #8C6030;
    --wm-cream   : #F8F2E8;
    --wm-sand    : #EDE4D4;
    --wm-gold    : #C4943A;
    --wm-gold-l  : #D8A848;
    --wm-stone   : #C0B49A;
    --wm-mid     : #7A6A5A;
    --wm-dark    : #1A1008;
    --wm-white   : #FFFFFF;
    --wm-font-h  : 'Playfair Display SC', serif;
    --wm-font-b  : 'Lato', sans-serif;
    --wm-shadow  : 0 24px 80px rgba(0,0,0,.35);
}

.wm-wrap *{ box-sizing:border-box; margin:0; padding:0; }
.wm-wrap{ font-family:var(--wm-font-b); color:var(--wm-dark); background:var(--wm-cream); line-height:1.7; }
.wm-container{ max-width:1200px; margin:0 auto; padding:0 40px; }

/* ── Typography ─────────────────────────── */
.wm-h1{ font-family:var(--wm-font-h); font-size:clamp(2.8rem,7vw,5.8rem); font-weight:400; line-height:1.1; color:var(--wm-white); letter-spacing:.04em; }
.wm-h2{ font-family:var(--wm-font-h); font-size:clamp(1.8rem,4vw,2.8rem); font-weight:400; color:var(--wm-burg-d); letter-spacing:.04em; }
.wm-h3{ font-family:var(--wm-font-h); font-size:1.3rem; color:var(--wm-burg-d); }
.wm-lead{ font-size:.97rem; color:var(--wm-mid); font-weight:300; max-width:580px; line-height:1.85; }
.wm-overline{ font-family:var(--wm-font-b); font-size:.68rem; font-weight:700; letter-spacing:.26em; color:var(--wm-gold); text-transform:uppercase; display:block; margin-bottom:1rem; }
.wm-accent{ color:var(--wm-gold); }

/* ── Buttons ─────────────────────────────── */
.wm-btn{
    display:inline-flex; align-items:center; gap:.5rem;
    font-family:var(--wm-font-b); font-size:.78rem; font-weight:700; letter-spacing:.2em;
    padding:.85rem 2.2rem; background:var(--wm-burg); color:var(--wm-white);
    border:none; cursor:pointer; text-decoration:none; text-transform:uppercase;
    transition:background .3s, transform .2s;
}
.wm-btn:hover{ background:var(--wm-burg-l); transform:translateY(-2px); }
.wm-btn-gold{ background:var(--wm-gold); }
.wm-btn-gold:hover{ background:var(--wm-gold-l); }
.wm-btn-outline{
    background:transparent; border:1.5px solid rgba(255,255,255,.5); color:var(--wm-white);
}
.wm-btn-outline:hover{ background:rgba(255,255,255,.12); }
.wm-btn-dark-outline{
    background:transparent; border:1.5px solid var(--wm-burg); color:var(--wm-burg);
}
.wm-btn-dark-outline:hover{ background:var(--wm-burg); color:var(--wm-white); }

/* ── Sections ────────────────────────────── */
.wm-section{ padding:100px 0; }
.wm-section-alt{ background:var(--wm-sand); }
.wm-section-dark{ background:var(--wm-burg-d); }
.wm-section-header{ text-align:center; margin-bottom:64px; }
.wm-divider{ display:inline-block; width:48px; height:1.5px; background:var(--wm-gold); margin:20px 0; }

/* ══════════════════════════════════════════
   HERO — Stone cellar at candlelight
══════════════════════════════════════════ */
.wm-hero{
    position:relative; min-height:100vh;
    background:linear-gradient(180deg,#0E0604 0%, #180C06 50%, #201008 100%);
    overflow:hidden; display:flex; align-items:center;
}

/* arched stone ceiling */
.wm-ceiling{
    position:absolute; top:0; left:0; right:0; height:24%;
    background:linear-gradient(180deg,#0A0402,#160A06);
}
/* arch ribs */
.wm-ceiling::before{
    content:''; position:absolute; bottom:0; left:0; right:0; height:70px;
    background:
        radial-gradient(ellipse 20% 70px at 10% 100%,#1C0E08 99%,transparent 100%),
        radial-gradient(ellipse 20% 70px at 30% 100%,#1C0E08 99%,transparent 100%),
        radial-gradient(ellipse 20% 70px at 50% 100%,#1C0E08 99%,transparent 100%),
        radial-gradient(ellipse 20% 70px at 70% 100%,#1C0E08 99%,transparent 100%),
        radial-gradient(ellipse 20% 70px at 90% 100%,#1C0E08 99%,transparent 100%);
}
/* brick texture on ceiling */
.wm-ceiling::after{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(0deg,transparent 0,transparent 15px,rgba(255,255,255,.015) 15px,rgba(255,255,255,.015) 16px),
        repeating-linear-gradient(90deg,transparent 0,transparent 39px,rgba(255,255,255,.012) 39px,rgba(255,255,255,.012) 40px);
}

/* stone floor */
.wm-floor{
    position:absolute; bottom:0; left:0; right:0; height:22%;
    background:
        repeating-linear-gradient(90deg,rgba(255,255,255,.03) 0,rgba(255,255,255,.03) 1px,transparent 1px,transparent 60px),
        repeating-linear-gradient(0deg, rgba(255,255,255,.02) 0,rgba(255,255,255,.02) 1px,transparent 1px,transparent 40px),
        #16100A;
    border-top:2px solid #2A1C10;
}

/* back wall */
.wm-back-wall{
    position:absolute; top:24%; bottom:22%; left:0; right:0;
    background:
        repeating-linear-gradient(0deg,transparent 0,transparent 19px,rgba(255,255,255,.018) 19px,rgba(255,255,255,.018) 20px),
        repeating-linear-gradient(90deg,transparent 0,transparent 39px,rgba(255,255,255,.012) 39px,rgba(255,255,255,.012) 40px),
        #180E08;
}

/* wine rack on left back wall */
.wm-rack{
    position:absolute; top:24%; bottom:22%; left:0; width:45%;
    background:#200E06;
    border-right:4px solid #3A1E0E;
    padding:4px;
    display:grid;
    grid-template-rows:repeat(<?php echo $wm_rack_rows; ?>,1fr);
    gap:2px;
}
/* rack frame */
.wm-rack::before{
    content:''; position:absolute; inset:0;
    border:4px solid #3A1E0E;
    pointer-events:none;
    z-index:2;
}
.wm-rack-row{ display:grid; grid-template-columns:repeat(<?php echo $wm_rack_cols; ?>,1fr); gap:2px; }
.wm-rack-cell{ background:#2A1208; border-radius:50% 50% 0 0; position:relative; overflow:hidden; }
/* bottle neck in cell */
.wm-rack-cell.filled::before{
    content:''; position:absolute; bottom:0; left:50%; transform:translateX(-50%);
    width:45%; height:75%;
    background:radial-gradient(ellipse at 35% 20%,var(--bc),color-mix(in srgb,var(--bc) 60%,#000));
    border-radius:50% 50% 0 0;
}
/* bottle highlight */
.wm-rack-cell.filled::after{
    content:''; position:absolute; bottom:0; left:calc(50% - 2px);
    width:15%; height:55%;
    background:rgba(255,255,255,.12);
    border-radius:50% 50% 0 0;
}

/* barrel group */
.wm-barrel{
    position:absolute; bottom:22%;
}
.wm-barrel-body{
    width:var(--bw); height:var(--bh);
    background:radial-gradient(ellipse at 30% 30%,#8C5A20,#5A3010);
    border-radius:8px;
    position:relative;
    box-shadow:0 8px 24px rgba(0,0,0,.6);
}
/* barrel staves */
.wm-barrel-body::before{
    content:''; position:absolute; inset:0;
    background:
        repeating-linear-gradient(90deg,rgba(0,0,0,.25) 0,rgba(0,0,0,.25) 1px,transparent 1px,transparent 14px);
    border-radius:8px;
}
/* barrel hoops */
.wm-barrel-body::after{
    content:''; position:absolute; left:-3px; right:-3px;
    top:20%; height:4px; background:#4A3010;
    box-shadow:0 calc(var(--bh) * .3) 0 #4A3010, 0 calc(var(--bh) * .55) 0 #4A3010;
}
.wm-barrel-end{
    width:var(--bw); height:12px;
    background:linear-gradient(180deg,#6A4018,#3A2010);
    border-radius:0 0 4px 4px;
}

/* tasting table */
.wm-table{
    position:absolute; bottom:22%; left:50%; transform:translateX(-50%);
    width:320px; height:14px;
    background:linear-gradient(180deg,#8C6030,#6A4820);
    border-radius:3px 3px 0 0;
    box-shadow:0 4px 16px rgba(0,0,0,.5);
}
.wm-table::after{
    content:''; position:absolute; top:-4px; left:-8px; right:-8px; height:8px;
    background:linear-gradient(180deg,#A07040,#7A5028);
    border-radius:2px;
}
/* table leg left/right */
.wm-table-leg-l,.wm-table-leg-r{
    position:absolute; top:14px; width:10px; height:44px;
    background:linear-gradient(180deg,#6A4820,#4A2E12);
}
.wm-table-leg-l{ left:16px; }
.wm-table-leg-r{ right:16px; }

/* decanter on table */
.wm-decanter{
    position:absolute; bottom:calc(22% + 14px);
}
.wm-dec-base{ width:36px; height:6px; background:#6A4020; border-radius:0 0 4px 4px; }
.wm-dec-body{
    width:28px; height:48px; margin:0 auto;
    background:radial-gradient(ellipse at 30% 20%, rgba(180,80,40,.7), rgba(80,20,10,.8));
    border-radius:2px 2px 0 0;
    border:1px solid rgba(255,255,255,.1);
    position:relative;
}
/* wine in decanter */
.wm-dec-body::before{
    content:''; position:absolute; bottom:0; left:0; right:0; height:60%;
    background:rgba(120,20,20,.6);
    border-top:1px solid rgba(200,60,60,.3);
}
.wm-dec-neck{
    width:8px; height:22px; margin:0 auto;
    background:radial-gradient(ellipse at 30% 20%, rgba(180,80,40,.5), rgba(80,20,10,.6));
    border:1px solid rgba(255,255,255,.08);
}
.wm-dec-stopper{
    width:10px; height:8px; margin:0 auto;
    background:radial-gradient(ellipse at 30% 20%,#C8A050,#8A6028);
    border-radius:50% 50% 0 0;
}

/* hero candles */
.wm-h-candle{
    position:absolute; bottom:22%;
    display:flex; flex-direction:column; align-items:center;
}
.wm-hc-flame{
    width:8px; height:14px;
    background:radial-gradient(ellipse at 50% 80%,#FFF8C0,#F5A820 50%,rgba(200,60,0,.4) 80%,transparent);
    border-radius:50% 50% 30% 30%;
    animation:wm-flame 1.5s ease-in-out infinite;
}
.wm-hc-body{
    width:10px; background:linear-gradient(90deg,#F8F0E0,#E8DCC8,#F8F0E0);
    border-radius:1px 1px 0 0;
}
.wm-hc-glow{
    position:absolute; bottom:0; left:50%; transform:translateX(-50%);
    width:60px; height:40px;
    background:radial-gradient(ellipse at 50% 100%,rgba(245,168,32,.22),transparent 70%);
    pointer-events:none;
}

/* illuminated feature bottle */
.wm-feature-bottle{
    position:absolute; bottom:22%; left:50%; transform:translateX(-50%);
    z-index:5;
}
.wm-fb-label{
    position:absolute; bottom:30px; left:50%; transform:translateX(-50%);
    width:28px; height:22px;
    background:#F8F0E0; border:1px solid #C8B890;
    display:flex; align-items:center; justify-content:center;
    font-size:4px; color:#5A3010; font-weight:700; text-align:center; line-height:1.2;
}
.wm-fb-body{
    width:32px; height:100px;
    background:radial-gradient(ellipse at 28% 15%,rgba(100,30,30,.9),rgba(40,10,10,.95));
    border-radius:2px 2px 0 0;
    position:relative; border:1px solid rgba(255,255,255,.06);
    box-shadow:0 0 40px rgba(200,60,40,.15);
}
.wm-fb-shoulder{
    width:32px; height:16px;
    background:radial-gradient(ellipse at 28% 20%,rgba(100,30,30,.9),rgba(40,10,10,.95));
    border-radius:50% 50% 0 0; margin-top:-2px;
}
.wm-fb-neck{
    width:12px; height:32px; margin:0 auto;
    background:radial-gradient(ellipse at 28% 20%,rgba(80,20,20,.9),rgba(30,6,6,.95));
    border:1px solid rgba(255,255,255,.05);
}
.wm-fb-capsule{
    width:14px; height:10px; margin:0 auto;
    background:linear-gradient(90deg,#8C6030,#C0943A,#8C6030);
    border-radius:4px 4px 0 0;
}
/* spotlight beam on bottle */
.wm-spotlight{
    position:absolute; bottom:22%; left:50%; transform:translateX(-50%);
    width:0; height:0;
    border-left:60px solid transparent;
    border-right:60px solid transparent;
    border-bottom:300px solid rgba(240,200,80,.06);
    z-index:4; pointer-events:none;
}
/* bottle glow on floor */
.wm-bottle-glow{
    position:absolute; bottom:22%; left:50%; transform:translateX(-50%);
    width:120px; height:20px;
    background:radial-gradient(ellipse at 50% 100%,rgba(200,80,40,.18),transparent 70%);
    z-index:3; pointer-events:none;
}

/* floating dust motes */
.wm-mote{
    position:absolute; border-radius:50%;
    background:rgba(212,168,72,.6);
    animation:wm-mote-drift var(--md) ease-in-out var(--mde) infinite alternate;
    pointer-events:none;
}

/* hero inner layout */
.wm-hero-inner{
    position:relative; z-index:10;
    display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:center;
    max-width:1200px; margin:0 auto; padding:120px 40px 80px; width:100%;
}
.wm-hero-crest{
    display:inline-flex; align-items:center; gap:12px; margin-bottom:24px;
}
.wm-hero-crest-line{ flex:1; height:1px; background:rgba(196,148,58,.4); max-width:40px; }
.wm-hero-crest-diamond{ width:8px; height:8px; background:var(--wm-gold); transform:rotate(45deg); }
.wm-hero-actions{ display:flex; gap:16px; flex-wrap:wrap; margin-top:36px; }
.wm-hero-provenance{
    display:flex; gap:20px; margin-top:32px; flex-wrap:wrap;
}
.wm-prov-item{
    font-size:.72rem; letter-spacing:.14em; text-transform:uppercase;
    color:rgba(255,255,255,.45); display:flex; align-items:center; gap:6px;
}
.wm-prov-item::before{ content:'✦'; color:var(--wm-gold); font-size:.5rem; }

/* cellar card */
.wm-cellar-card{
    position:relative; aspect-ratio:2/3; overflow:hidden;
    background:#180C06; border:1px solid rgba(196,148,58,.25);
    box-shadow:var(--wm-shadow);
}
/* mini rack on card */
.wm-cc-rack{
    position:absolute; top:0; left:0; right:0; bottom:32%;
    background:#200E06;
    display:grid; grid-template-rows:repeat(5,1fr); gap:2px; padding:4px;
}
.wm-cc-row{ display:grid; grid-template-columns:repeat(7,1fr); gap:2px; }
.wm-cc-cell{ background:#2A1208; border-radius:50% 50% 0 0; }
.wm-cc-cell.f{ background:radial-gradient(ellipse at 35% 25%,var(--cc),color-mix(in srgb,var(--cc) 50%,#000)); }
.wm-cc-floor{
    position:absolute; bottom:0; left:0; right:0; height:32%;
    background:#16100A; border-top:2px solid #2A1C10;
}
/* mini barrel in card */
.wm-cc-barrel{
    position:absolute; bottom:34%; right:12%;
    width:44px; height:36px;
    background:radial-gradient(ellipse at 30% 30%,#8C5A20,#5A3010);
    border-radius:6px;
}
.wm-float-badge{
    position:absolute; bottom:16px; left:16px; right:16px;
    background:rgba(10,4,2,.9); border:1px solid rgba(196,148,58,.35);
    color:var(--wm-white); font-family:var(--wm-font-h); font-size:.78rem;
    letter-spacing:.1em; padding:12px 16px; text-align:center;
    animation:wm-float 3s ease-in-out infinite;
}

/* ══════════════════════════════════════════
   STATS BAR
══════════════════════════════════════════ */
.wm-stats-bar{ background:var(--wm-burg-d); padding:56px 0; }
.wm-stats-grid{ display:grid; grid-template-columns:repeat(4,1fr); }
.wm-stat-cell{ text-align:center; padding:0 32px; border-right:1px solid rgba(255,255,255,.1); }
.wm-stat-cell:last-child{ border-right:none; }
.wm-stat-val{ font-family:var(--wm-font-h); font-size:3rem; color:var(--wm-white); display:block; }
.wm-stat-label{ font-size:.68rem; letter-spacing:.2em; text-transform:uppercase; color:rgba(255,255,255,.45); margin-top:6px; }

/* ══════════════════════════════════════════
   COLLECTIONS
══════════════════════════════════════════ */
.wm-col-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--wm-stone); }
.wm-col-card{
    background:var(--wm-cream); padding:40px 32px; position:relative;
    border-bottom:3px solid transparent; transition:border-color .3s, background .3s;
}
.wm-col-card:hover{ background:var(--wm-white); border-bottom-color:var(--wm-gold); }
/* wine colour swatch */
.wm-col-swatch{
    width:40px; height:40px; border-radius:50%;
    background:hsl(var(--wh),var(--ws)%,var(--wl)%);
    margin-bottom:16px;
    box-shadow:0 2px 12px rgba(0,0,0,.25);
}
.wm-col-region{ font-family:var(--wm-font-h); font-size:1.3rem; color:var(--wm-burg-d); margin-bottom:4px; letter-spacing:.04em; }
.wm-col-country{ font-size:.7rem; letter-spacing:.18em; text-transform:uppercase; color:var(--wm-gold); font-weight:700; margin-bottom:14px; }
.wm-col-desc{ font-size:.88rem; color:var(--wm-mid); line-height:1.75; margin-bottom:14px; }
.wm-col-highlight{ font-size:.78rem; color:var(--wm-oak); font-style:italic; }

/* ══════════════════════════════════════════
   SERVICES
══════════════════════════════════════════ */
.wm-srv-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.wm-srv-card{
    background:var(--wm-white); border:1px solid #DDD4C0; padding:36px 28px;
    border-left:4px solid transparent; transition:border-color .3s;
}
.wm-srv-card:hover{ border-left-color:var(--wm-gold); }
.wm-srv-icon{ font-size:1.8rem; display:block; margin-bottom:16px; }
.wm-srv-name{ font-family:var(--wm-font-h); font-size:1.1rem; color:var(--wm-burg-d); margin-bottom:12px; letter-spacing:.04em; }
.wm-srv-desc{ font-size:.88rem; color:var(--wm-mid); line-height:1.75; }

/* ══════════════════════════════════════════
   TASTING EVENTS
══════════════════════════════════════════ */
.wm-events-grid{ display:grid; grid-template-columns:repeat(2,1fr); gap:24px; }
.wm-event-card{
    background:var(--wm-burg-d); border:1px solid rgba(255,255,255,.1);
    padding:32px; display:flex; gap:24px;
    transition:border-color .3s;
}
.wm-event-card:hover{ border-color:var(--wm-gold); }
.wm-event-date-box{
    min-width:80px; text-align:center; padding:12px 8px;
    background:rgba(196,148,58,.15); border:1px solid rgba(196,148,58,.3);
    flex-shrink:0;
}
.wm-event-month{ font-size:.65rem; letter-spacing:.18em; text-transform:uppercase; color:var(--wm-gold); }
.wm-event-day{ font-family:var(--wm-font-h); font-size:2rem; color:var(--wm-white); line-height:1; }
.wm-event-yr{ font-size:.72rem; color:rgba(255,255,255,.4); }
.wm-event-body{ flex:1; }
.wm-event-title{ font-family:var(--wm-font-h); font-size:1.1rem; color:var(--wm-white); margin-bottom:8px; letter-spacing:.04em; }
.wm-event-desc{ font-size:.85rem; color:rgba(255,255,255,.55); line-height:1.7; margin-bottom:12px; }
.wm-event-price{ font-size:.78rem; letter-spacing:.12em; text-transform:uppercase; color:var(--wm-gold); font-weight:700; }

/* ══════════════════════════════════════════
   TEAM
══════════════════════════════════════════ */
.wm-team-grid{ display:grid; grid-template-columns:repeat(4,1fr); gap:24px; }
.wm-team-card{ background:var(--wm-white); border:1px solid #DDD4C0; overflow:hidden; }
.wm-team-fig{
    height:200px; background:var(--wm-sand);
    display:flex; align-items:flex-end; justify-content:center; overflow:hidden; position:relative;
}
.wm-team-top{ position:absolute; top:0; left:0; right:0; height:3px; background:var(--wm-gold); }
/* CSS sommelier/wine expert figure */
.wm-figure-s{ position:relative; width:80px; height:180px; }
.wm-fs-head{
    position:absolute; top:10px; left:50%; transform:translateX(-50%);
    width:30px; height:30px; border-radius:50%; background:#D4A878;
}
.wm-fs-head::before{
    content:''; position:absolute; top:0; left:0; right:0; height:12px;
    background:#2A1808; border-radius:50% 50% 0 0;
}
.wm-fs-body{
    position:absolute; top:44px; left:50%; transform:translateX(-50%);
    width:38px; height:52px;
    background:#1A1818; /* black sommelier jacket */
}
/* bow tie */
.wm-fs-body::before{
    content:''; position:absolute; top:4px; left:50%; transform:translateX(-50%);
    width:14px; height:6px;
    background:#4A3020;
    clip-path:polygon(0 0,50% 30%,100% 0,100% 100%,50% 70%,0 100%);
}
/* white shirt */
.wm-fs-body::after{
    content:''; position:absolute; top:0; left:8px; right:8px; height:100%;
    background:#F0ECD8;
    clip-path:polygon(20% 0,80% 0,70% 100%,30% 100%);
}
.wm-fs-arm-l,.wm-fs-arm-r{
    position:absolute; width:10px; height:42px;
    background:#1A1818; border-radius:4px;
}
.wm-fs-arm-l{ top:44px; left:calc(50% - 28px); transform:rotate(4deg); transform-origin:top; }
.wm-fs-arm-r{ top:44px; right:calc(50% - 28px); transform:rotate(-14deg); transform-origin:top; }
/* wine glass in right hand */
.wm-fs-glass{
    position:absolute; top:72px; right:calc(50% - 38px);
    width:14px; height:22px;
}
.wm-fs-glass::before{
    content:''; position:absolute; top:0; left:50%; transform:translateX(-50%);
    width:12px; height:14px;
    background:rgba(180,40,40,.5); border-radius:0 0 50% 50%;
    border:1px solid rgba(255,255,255,.2);
}
.wm-fs-glass::after{
    content:''; position:absolute; top:14px; left:50%; transform:translateX(-50%);
    width:1px; height:8px; background:rgba(255,255,255,.3);
    box-shadow:0 8px 0 0 rgba(255,255,255,.2);
}
.wm-fs-leg-l,.wm-fs-leg-r{
    position:absolute; width:12px; height:50px;
    background:#0E0E0E; border-radius:3px 3px 6px 6px;
}
.wm-fs-leg-l{ top:94px; left:calc(50% - 14px); }
.wm-fs-leg-r{ top:94px; right:calc(50% - 14px); }
.wm-team-info{ padding:20px; border-top:1px solid #DDD4C0; }
.wm-team-name{ font-family:var(--wm-font-h); font-size:1rem; color:var(--wm-burg-d); margin-bottom:4px; letter-spacing:.04em; }
.wm-team-role{ font-size:.7rem; letter-spacing:.16em; text-transform:uppercase; color:var(--wm-gold); font-weight:700; margin-bottom:6px; }
.wm-team-spec{ font-size:.82rem; color:var(--wm-mid); }

/* ══════════════════════════════════════════
   TESTIMONIALS
══════════════════════════════════════════ */
.wm-testi-grid{ display:grid; grid-template-columns:repeat(3,1fr); gap:24px; }
.wm-testi-card{ background:var(--wm-white); border:1px solid #DDD4C0; padding:32px; border-top:3px solid var(--wm-burg); }
.wm-testi-text{ font-size:.95rem; color:var(--wm-dark); line-height:1.8; margin-bottom:20px; font-style:italic; }
.wm-testi-name{ font-family:var(--wm-font-h); font-size:.95rem; color:var(--wm-burg-d); margin-bottom:3px; letter-spacing:.04em; }
.wm-testi-role{ font-size:.72rem; letter-spacing:.14em; text-transform:uppercase; color:var(--wm-mid); }

/* ══════════════════════════════════════════
   FAQ
══════════════════════════════════════════ */
.wm-faq-list{ max-width:760px; margin:0 auto; display:flex; flex-direction:column; }
.wm-faq-item{ border-bottom:1px solid #D8CCB8; }
.wm-faq-item:first-child{ border-top:1px solid #D8CCB8; }
.wm-faq-btn{
    width:100%; text-align:left; padding:22px 0;
    font-family:var(--wm-font-h); font-size:1rem; color:var(--wm-burg-d); letter-spacing:.02em;
    background:none; border:none; cursor:pointer;
    display:flex; justify-content:space-between; align-items:center; gap:16px;
}
.wm-faq-icon{ font-size:1.2rem; color:var(--wm-gold); flex-shrink:0; transition:transform .3s; }
.wm-faq-item.open .wm-faq-icon{ transform:rotate(45deg); }
.wm-faq-body{ max-height:0; overflow:hidden; transition:max-height .4s ease; }
.wm-faq-body-inner{ padding:0 0 24px; font-size:.92rem; color:var(--wm-mid); line-height:1.8; }

/* ══════════════════════════════════════════
   ENQUIRY FORM
══════════════════════════════════════════ */
.wm-contact-grid{ display:grid; grid-template-columns:1fr 1fr; gap:80px; align-items:start; }
.wm-contact-items{ display:flex; flex-direction:column; gap:24px; margin-top:32px; }
.wm-contact-item{ display:flex; gap:16px; }
.wm-contact-icon{ width:42px; height:42px; border:1px solid #DDD4C0; display:flex; align-items:center; justify-content:center; font-size:1.1rem; flex-shrink:0; }
.wm-contact-label{ font-size:.68rem; letter-spacing:.18em; text-transform:uppercase; color:var(--wm-mid); margin-bottom:3px; }
.wm-contact-val{ font-size:.9rem; color:var(--wm-dark); }

.wm-form{ display:flex; flex-direction:column; gap:20px; }
.wm-form-row{ display:grid; grid-template-columns:1fr 1fr; gap:20px; }
.wm-field label{ display:block; font-size:.7rem; font-weight:700; letter-spacing:.18em; color:var(--wm-mid); text-transform:uppercase; margin-bottom:8px; }
.wm-field input,.wm-field select,.wm-field textarea{
    width:100%; padding:13px 16px;
    background:var(--wm-white); border:1px solid #DDD4C0;
    color:var(--wm-dark); font-family:var(--wm-font-b); font-size:.92rem;
    transition:border-color .25s;
}
.wm-field input:focus,.wm-field select:focus,.wm-field textarea:focus{ outline:none; border-color:var(--wm-gold); }
.wm-field select{
    appearance:none;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%23C4943A' fill='none' stroke-width='1.5'/%3E%3C/svg%3E");
    background-repeat:no-repeat; background-position:calc(100% - 14px) 50%; padding-right:36px;
}
.wm-field textarea{ resize:vertical; min-height:110px; }
.wm-form-note{ font-size:.78rem; color:var(--wm-mid); }
.wm-form-note a{ color:var(--wm-gold); }

/* ══════════════════════════════════════════
   FOOTER CTA
══════════════════════════════════════════ */
.wm-cta{ background:var(--wm-burg-d); padding:80px 0; text-align:center; }
.wm-cta-title{ font-family:var(--wm-font-h); font-size:clamp(1.8rem,4vw,3rem); color:var(--wm-white); margin-bottom:16px; letter-spacing:.04em; }
.wm-cta-sub{ font-size:.88rem; color:rgba(255,255,255,.45); margin-bottom:40px; letter-spacing:.08em; }

/* ══════════════════════════════════════════
   KEYFRAMES
══════════════════════════════════════════ */
@keyframes wm-flame{
    0%,100%{ transform:scaleX(1) scaleY(1); }
    33%{ transform:scaleX(.85) scaleY(1.1); }
    66%{ transform:scaleX(1.1) scaleY(.95); }
}
@keyframes wm-mote-drift{
    0%  { transform:translateY(0) translateX(0); opacity:.7; }
    100%{ transform:translateY(-24px) translateX(8px); opacity:0; }
}
@keyframes wm-float{
    0%,100%{ transform:translateY(0); }
    50%    { transform:translateY(-5px); }
}

/* ══════════════════════════════════════════
   RESPONSIVE
══════════════════════════════════════════ */
@media(max-width:1024px){
    .wm-hero-inner,.wm-contact-grid{ grid-template-columns:1fr; gap:48px; }
    .wm-stats-grid{ grid-template-columns:repeat(2,1fr); }
    .wm-stat-cell:nth-child(2){ border-right:none; }
    .wm-stat-cell:nth-child(3){ border-right:1px solid rgba(255,255,255,.1); }
    .wm-col-grid{ grid-template-columns:repeat(2,1fr); }
    .wm-srv-grid{ grid-template-columns:repeat(2,1fr); }
    .wm-events-grid,.wm-testi-grid{ grid-template-columns:1fr; }
    .wm-team-grid{ grid-template-columns:repeat(2,1fr); }
}
@media(max-width:640px){
    .wm-col-grid,.wm-srv-grid,.wm-team-grid{ grid-template-columns:1fr; }
    .wm-form-row{ grid-template-columns:1fr; }
    .wm-stats-grid{ grid-template-columns:1fr; }
    .wm-stat-cell{ border-right:none; border-bottom:1px solid rgba(255,255,255,.1); }
}
</style>

<div class="wm-wrap">

<!-- ══════════════════════════════════════
     HERO
══════════════════════════════════════ -->
<section class="wm-hero">

    <div class="wm-ceiling"></div>
    <div class="wm-back-wall"></div>
    <div class="wm-floor"></div>

    <!-- wine rack -->
    <div class="wm-rack">
        <?php foreach($wm_rack_cells as $row): ?>
        <div class="wm-rack-row">
            <?php foreach($row as $cell): ?>
            <div class="wm-rack-cell <?php echo $cell['filled']?'filled':''; ?>"
                 style="--bc:hsl(<?php echo $cell['hue']; ?>,<?php echo $cell['sat']; ?>%,<?php echo $cell['lit']; ?>%);">
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- barrels -->
    <?php foreach($wm_barrels as $b): ?>
    <div class="wm-barrel" style="left:<?php echo $b['x']; ?>;bottom:calc(22% + <?php echo $b['y']; ?>px);">
        <div class="wm-barrel-body" style="--bw:<?php echo $b['w']; ?>px;--bh:<?php echo $b['h']; ?>px;"></div>
        <div class="wm-barrel-end" style="width:<?php echo $b['w']; ?>px;"></div>
    </div>
    <?php endforeach; ?>

    <!-- tasting table -->
    <div class="wm-table">
        <div class="wm-table-leg-l"></div>
        <div class="wm-table-leg-r"></div>
    </div>

    <!-- decanters on table -->
    <div class="wm-decanter" style="left:calc(50% - 64px);">
        <div class="wm-dec-stopper"></div>
        <div class="wm-dec-neck"></div>
        <div class="wm-dec-body"><div class="wm-fb-label">2019</div></div>
        <div class="wm-dec-base"></div>
    </div>
    <div class="wm-decanter" style="left:calc(50% + 40px);">
        <div class="wm-dec-stopper"></div>
        <div class="wm-dec-neck"></div>
        <div class="wm-dec-body"></div>
        <div class="wm-dec-base"></div>
    </div>

    <!-- hero candles -->
    <?php foreach($wm_candles as $wc): ?>
    <div class="wm-h-candle" style="left:<?php echo $wc['left']; ?>;">
        <div class="wm-hc-flame"></div>
        <div class="wm-hc-body" style="height:<?php echo $wc['h']; ?>px;"></div>
        <div class="wm-hc-glow"></div>
    </div>
    <?php endforeach; ?>

    <!-- illuminated feature bottle -->
    <div class="wm-spotlight"></div>
    <div class="wm-bottle-glow"></div>
    <div class="wm-feature-bottle">
        <div class="wm-fb-capsule"></div>
        <div class="wm-fb-neck"></div>
        <div class="wm-fb-shoulder"></div>
        <div class="wm-fb-body">
            <div class="wm-fb-label">Grand<br>Cru<br>2015</div>
        </div>
    </div>

    <!-- floating dust motes -->
    <?php foreach($wm_motes as $m): ?>
    <div class="wm-mote"
         style="left:<?php echo $m['left']; ?>%;top:<?php echo $m['top']; ?>%;width:<?php echo $m['size']; ?>px;height:<?php echo $m['size']; ?>px;--md:<?php echo $m['dur']; ?>ms;--mde:<?php echo $m['delay']; ?>ms;">
    </div>
    <?php endforeach; ?>

    <!-- hero content -->
    <div class="wm-hero-inner">
        <div>
            <div class="wm-hero-crest">
                <div class="wm-hero-crest-line"></div>
                <div class="wm-hero-crest-diamond"></div>
                <div class="wm-hero-crest-line"></div>
            </div>
            <span class="wm-overline">Fine Wine &amp; Spirits · Est. 1979 · London</span>
            <h1 class="wm-h1">
                Forty-five years<br>
                of <span class="wm-accent">exceptional</span><br>
                provenance.
            </h1>
            <p class="wm-lead" style="margin-top:24px; color:rgba(248,242,232,.6);">
                Ashby &amp; Sons is one of London's most trusted fine wine merchants —
                stocking over 4,800 labels from Bordeaux First Growths to cult
                natural wines, with a bonded cellar, investment service and expert
                curation for private and corporate clients.
            </p>
            <div class="wm-hero-provenance">
                <span class="wm-prov-item">Members BIVB</span>
                <span class="wm-prov-item">WSET Approved</span>
                <span class="wm-prov-item">Decanter Award 2024</span>
            </div>
            <div class="wm-hero-actions">
                <a href="#enquiry" class="wm-btn wm-btn-gold">Enquire Now</a>
                <a href="#collections" class="wm-btn wm-btn-outline">Explore Cellar</a>
            </div>
        </div>

        <!-- cellar card -->
        <div>
            <div class="wm-cellar-card">
                <div class="wm-cc-rack">
                    <?php for($r=0;$r<5;$r++): ?>
                    <div class="wm-cc-row">
                        <?php for($c=0;$c<7;$c++):
                            $fill = rand(0,10)>2;
                            $h = [0,8,330,55][rand(0,3)];
                        ?>
                        <div class="wm-cc-cell <?php echo $fill?'f':''; ?>"
                             style="--cc:hsl(<?php echo $h; ?>,70%,35%);">
                        </div>
                        <?php endfor; ?>
                    </div>
                    <?php endfor; ?>
                </div>
                <div class="wm-cc-floor"></div>
                <div class="wm-cc-barrel"></div>
                <div class="wm-float-badge">✦ Ashby &amp; Sons · Mayfair · London W1</div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     STATS BAR
══════════════════════════════════════ -->
<div class="wm-stats-bar">
    <div class="wm-container">
        <div class="wm-stats-grid">
            <?php foreach($wm_stats as $st):
                $isf = floor($st['val'])!==(float)$st['val']; ?>
            <div class="wm-stat-cell">
                <span class="wm-stat-val"
                      data-target="<?php echo $st['val']; ?>"
                      data-suffix="<?php echo esc_attr($st['suffix']); ?>"
                      data-float="<?php echo $isf?'1':'0'; ?>">
                    0<?php echo esc_html($st['suffix']); ?>
                </span>
                <div class="wm-stat-label"><?php echo esc_html($st['label']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- ══════════════════════════════════════
     COLLECTIONS
══════════════════════════════════════ -->
<section class="wm-section" id="collections">
    <div class="wm-container">
        <div class="wm-section-header">
            <span class="wm-overline">The Cellar</span>
            <h2 class="wm-h2">Our <span class="wm-accent">Collections</span></h2>
            <div class="wm-divider"></div>
            <p class="wm-lead" style="margin:0 auto; text-align:center;">
                Curated with the rigour of forty-five years — exceptional provenance in every bottle.
            </p>
        </div>
        <div class="wm-col-grid">
            <?php foreach($wm_collections as $col): ?>
            <div class="wm-col-card">
                <div class="wm-col-swatch" style="--wh:<?php echo $col['hue']; ?>;--ws:75;--wl:35;"></div>
                <div class="wm-col-region"><?php echo esc_html($col['region']); ?></div>
                <div class="wm-col-country"><?php echo esc_html($col['country']); ?></div>
                <p class="wm-col-desc"><?php echo esc_html($col['desc']); ?></p>
                <div class="wm-col-highlight"><?php echo esc_html($col['highlight']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     SERVICES
══════════════════════════════════════ -->
<section class="wm-section wm-section-alt">
    <div class="wm-container">
        <div class="wm-section-header">
            <span class="wm-overline">What We Offer</span>
            <h2 class="wm-h2">Expert <span class="wm-accent">Services</span></h2>
            <div class="wm-divider"></div>
        </div>
        <div class="wm-srv-grid">
            <?php foreach($wm_services as $s): ?>
            <div class="wm-srv-card">
                <span class="wm-srv-icon"><?php echo $s['icon']; ?></span>
                <div class="wm-srv-name"><?php echo esc_html($s['name']); ?></div>
                <p class="wm-srv-desc"><?php echo esc_html($s['desc']); ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TASTING EVENTS
══════════════════════════════════════ -->
<section class="wm-section wm-section-dark">
    <div class="wm-container">
        <div class="wm-section-header">
            <span class="wm-overline" style="color:var(--wm-gold);">In the Cellar</span>
            <h2 class="wm-h2" style="color:var(--wm-white);">Upcoming <span class="wm-accent">Tasting Events</span></h2>
            <div class="wm-divider"></div>
            <p class="wm-lead" style="margin:0 auto; text-align:center; color:rgba(255,255,255,.45);">
                Hosted by our Masters of Wine in the cellar beneath our Mayfair shop. Limited places.
            </p>
        </div>
        <div class="wm-events-grid">
            <?php foreach($wm_events as $ev):
                $dp = new DateTime($ev['date']);
            ?>
            <div class="wm-event-card">
                <div class="wm-event-date-box">
                    <div class="wm-event-month"><?php echo $dp->format('M'); ?></div>
                    <div class="wm-event-day"><?php echo $dp->format('d'); ?></div>
                    <div class="wm-event-yr"><?php echo $dp->format('Y'); ?></div>
                </div>
                <div class="wm-event-body">
                    <div class="wm-event-title"><?php echo esc_html($ev['title']); ?></div>
                    <p class="wm-event-desc"><?php echo esc_html($ev['desc']); ?></p>
                    <div class="wm-event-price"><?php echo esc_html($ev['price']); ?> per person</div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div style="text-align:center;margin-top:40px;">
            <a href="#enquiry" class="wm-btn wm-btn-gold">Reserve a Place</a>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TEAM
══════════════════════════════════════ -->
<section class="wm-section">
    <div class="wm-container">
        <div class="wm-section-header">
            <span class="wm-overline">Our Experts</span>
            <h2 class="wm-h2">In Trusted <span class="wm-accent">Hands</span></h2>
            <div class="wm-divider"></div>
        </div>
        <div class="wm-team-grid">
            <?php foreach($wm_team as $m): ?>
            <div class="wm-team-card">
                <div class="wm-team-fig">
                    <div class="wm-team-top"></div>
                    <div class="wm-figure-s">
                        <div class="wm-fs-head"></div>
                        <div class="wm-fs-body"></div>
                        <div class="wm-fs-arm-l"></div>
                        <div class="wm-fs-arm-r"></div>
                        <div class="wm-fs-glass"></div>
                        <div class="wm-fs-leg-l"></div>
                        <div class="wm-fs-leg-r"></div>
                    </div>
                </div>
                <div class="wm-team-info">
                    <div class="wm-team-name"><?php echo esc_html($m['name']); ?></div>
                    <div class="wm-team-role"><?php echo esc_html($m['role']); ?></div>
                    <div class="wm-team-spec"><?php echo esc_html($m['spec']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     TESTIMONIALS
══════════════════════════════════════ -->
<section class="wm-section wm-section-alt">
    <div class="wm-container">
        <div class="wm-section-header">
            <span class="wm-overline">Client Words</span>
            <h2 class="wm-h2">Trusted by <span class="wm-accent">Connoisseurs</span></h2>
            <div class="wm-divider"></div>
        </div>
        <div class="wm-testi-grid">
            <?php foreach($wm_testimonials as $t): ?>
            <div class="wm-testi-card">
                <p class="wm-testi-text">"<?php echo esc_html($t['text']); ?>"</p>
                <div class="wm-testi-name"><?php echo esc_html($t['name']); ?></div>
                <div class="wm-testi-role"><?php echo esc_html($t['role']); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FAQ
══════════════════════════════════════ -->
<section class="wm-section">
    <div class="wm-container">
        <div class="wm-section-header">
            <span class="wm-overline">FAQ</span>
            <h2 class="wm-h2">Frequently <span class="wm-accent">Asked</span></h2>
            <div class="wm-divider"></div>
        </div>
        <div class="wm-faq-list">
            <?php foreach($wm_faqs as $i=>$faq): ?>
            <div class="wm-faq-item" id="wm-faq-<?php echo $i; ?>">
                <button class="wm-faq-btn"
                        aria-expanded="false"
                        aria-controls="wm-faq-body-<?php echo $i; ?>">
                    <?php echo esc_html($faq['q']); ?>
                    <span class="wm-faq-icon">+</span>
                </button>
                <div class="wm-faq-body" id="wm-faq-body-<?php echo $i; ?>" role="region">
                    <div class="wm-faq-body-inner"><?php echo esc_html($faq['a']); ?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     ENQUIRY FORM
══════════════════════════════════════ -->
<section class="wm-section wm-section-alt" id="enquiry">
    <div class="wm-container">
        <div class="wm-contact-grid">

            <div>
                <span class="wm-overline">Get in Touch</span>
                <h2 class="wm-h2" style="margin-bottom:16px;">
                    Speak with an <span class="wm-accent">Expert</span>
                </h2>
                <div class="wm-divider"></div>
                <p class="wm-lead">
                    Whether you need a single special bottle, a cellar programme or corporate
                    supply, our team is delighted to help. All enquiries receive a personal response
                    within one working day.
                </p>
                <div class="wm-contact-items">
                    <div class="wm-contact-item">
                        <div class="wm-contact-icon">📍</div>
                        <div>
                            <div class="wm-contact-label">Our Shop & Cellar</div>
                            <div class="wm-contact-val">8 Bruton Lane, Mayfair, London W1J 6QQ</div>
                        </div>
                    </div>
                    <div class="wm-contact-item">
                        <div class="wm-contact-icon">📞</div>
                        <div>
                            <div class="wm-contact-label">Telephone</div>
                            <div class="wm-contact-val">+44 (0)20 7491 7800</div>
                        </div>
                    </div>
                    <div class="wm-contact-item">
                        <div class="wm-contact-icon">⏰</div>
                        <div>
                            <div class="wm-contact-label">Shop Hours</div>
                            <div class="wm-contact-val">Mon–Sat 09:00–19:00 · Sun 11:00–17:00</div>
                        </div>
                    </div>
                </div>
            </div>

            <form class="wm-form"
                  method="post"
                  action="<?php echo esc_url(admin_url('admin-post.php')); ?>">

                <?php wp_nonce_field('tf_wm_enquiry','tf_wm_nonce'); ?>
                <input type="hidden" name="action" value="tf_wm_enquiry">

                <div class="wm-form-row">
                    <div class="wm-field">
                        <label for="wm-name">Full Name <span style="color:var(--wm-gold)">*</span></label>
                        <input type="text" id="wm-name" name="wm_name" required placeholder="Edmund Ashby">
                    </div>
                    <div class="wm-field">
                        <label for="wm-email">Email Address <span style="color:var(--wm-gold)">*</span></label>
                        <input type="email" id="wm-email" name="wm_email" required placeholder="hello@email.com">
                    </div>
                </div>

                <div class="wm-field">
                    <label for="wm-enquiry-type">Nature of Enquiry <span style="color:var(--wm-gold)">*</span></label>
                    <select id="wm-enquiry-type" name="wm_enquiry_type" required>
                        <option value="" disabled selected>Please select…</option>
                        <option>Purchase — Private Client</option>
                        <option>Purchase — Corporate / Restaurant</option>
                        <option>Cellar Management & Storage</option>
                        <option>Wine Investment</option>
                        <option>Private Tasting Event</option>
                        <option>En Primeur Allocation</option>
                        <option>Cellar Purchase / We Want to Sell</option>
                        <option>Gift Service</option>
                        <option>Other</option>
                    </select>
                </div>

                <div class="wm-form-row">
                    <div class="wm-field">
                        <label for="wm-region">Preferred Region or Style</label>
                        <input type="text" id="wm-region" name="wm_region" placeholder="e.g. Burgundy, Barolo, Champagne">
                    </div>
                    <div class="wm-field">
                        <label for="wm-budget">Approximate Budget</label>
                        <select id="wm-budget" name="wm_budget">
                            <option value="" disabled selected>Select range…</option>
                            <option>Under £500</option>
                            <option>£500 – £2,000</option>
                            <option>£2,000 – £10,000</option>
                            <option>£10,000 – £50,000</option>
                            <option>£50,000+</option>
                        </select>
                    </div>
                </div>

                <div class="wm-field">
                    <label for="wm-message">Your Enquiry <span style="color:var(--wm-gold)">*</span></label>
                    <textarea id="wm-message" name="wm_message" required
                              placeholder="Tell us what you're looking for — the more detail you can share, the better we can assist…"></textarea>
                </div>

                <p class="wm-form-note">
                    All enquiries are handled in complete confidence.
                    By submitting you agree to our <a href="#">Privacy Policy</a>.
                </p>

                <button type="submit" class="wm-btn wm-btn-gold" style="width:100%;justify-content:center;">
                    Send Enquiry
                </button>
            </form>

        </div>
    </div>
</section>

<!-- ══════════════════════════════════════
     FOOTER CTA
══════════════════════════════════════ -->
<div class="wm-cta">
    <div class="wm-container">
        <span class="wm-overline" style="text-align:center;display:block;">Est. 1979 · Mayfair · London</span>
        <div class="wm-cta-title">The cellar is open. <span class="wm-accent">Explore it.</span></div>
        <p class="wm-cta-sub">4,800+ labels · Bonded storage · Expert guidance · Worldwide delivery</p>
        <div style="display:flex;gap:16px;justify-content:center;flex-wrap:wrap;">
            <a href="#enquiry" class="wm-btn wm-btn-gold">Enquire Now</a>
            <a href="#collections" class="wm-btn wm-btn-outline" style="border-color:rgba(255,255,255,.3);">Explore Collections</a>
        </div>
    </div>
</div>

</div><!-- /.wm-wrap -->

<script>
(function(){
    /* ── Animated counters ─────────────────────── */
    const easeOut = t => 1 - Math.pow(1 - t, 3);
    const counterEls = document.querySelectorAll('.wm-stat-val[data-target]');
    const seen = new Set();
    const obs = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if(!entry.isIntersecting || seen.has(entry.target)) return;
            seen.add(entry.target);
            const el     = entry.target;
            const target = parseFloat(el.dataset.target);
            const suffix = el.dataset.suffix || '';
            const isFloat= el.dataset.float === '1';
            if(isNaN(target)) return;
            const dur = 1800, start = performance.now();
            const tick = now => {
                const t = Math.min((now - start) / dur, 1);
                const v = easeOut(t) * target;
                el.textContent = (isFloat ? v.toFixed(1) : Math.round(v)) + suffix;
                if(t < 1) requestAnimationFrame(tick);
            };
            requestAnimationFrame(tick);
        });
    }, { threshold: 0.4 });
    counterEls.forEach(el => obs.observe(el));

    /* ── FAQ accordion ─────────────────────────── */
    document.querySelectorAll('.wm-faq-btn').forEach(btn => {
        btn.addEventListener('click', function(){
            const item = this.closest('.wm-faq-item');
            const body = item.querySelector('.wm-faq-body');
            const open = item.classList.contains('open');
            document.querySelectorAll('.wm-faq-item.open').forEach(i => {
                i.classList.remove('open');
                i.querySelector('.wm-faq-body').style.maxHeight = '0';
                i.querySelector('.wm-faq-btn').setAttribute('aria-expanded','false');
            });
            if(!open){
                item.classList.add('open');
                body.style.maxHeight = body.scrollHeight + 'px';
                this.setAttribute('aria-expanded','true');
            }
        });
    });
})();
</script>

<?php get_footer(); ?>
