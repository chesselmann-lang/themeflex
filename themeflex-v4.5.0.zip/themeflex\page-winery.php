<?php
/**
 * Template Name: TF — Winery & Vineyard
 *
 * Namespace : --win-*
 * Fonts     : Libre Baskerville (headings) + Raleway (body)
 * Palette   : burgundy #6b2737 · parchment #f5f0e8 · gold #c9a84c · earth #5a4030 · cream #faf6ef
 */

/* ── deterministic randomness ── */
srand( crc32( get_the_permalink() ) );

/* ── vineyard rows (CSS art) ── */
$vine_rows = [];
for ( $i = 0; $i < 9; $i++ ) {
    $vine_rows[] = [
        'left'   => rand( 2, 18 ),
        'width'  => rand( 18, 28 ),
        'bottom' => 10 + $i * 8,
        'opacity'=> round( 0.5 + $i * 0.05, 2 ),
        'height' => rand( 18, 32 ),
    ];
}

/* ── stars ── */
$stars = [];
for ( $i = 0; $i < 55; $i++ ) {
    $stars[] = [
        'x'    => rand( 1, 99 ),
        'y'    => rand( 2, 55 ),
        'size' => rand( 1, 3 ),
        'op'   => round( 0.3 + lcg_value() * 0.6, 2 ),
        'del'  => round( lcg_value() * 4, 2 ),
        'dur'  => round( 2 + lcg_value() * 3, 2 ),
    ];
}

/* ── fireflies ── */
$fireflies = [];
for ( $i = 0; $i < 20; $i++ ) {
    $fireflies[] = [
        'x'    => rand( 5, 95 ),
        'y'    => rand( 30, 85 ),
        'del'  => round( lcg_value() * 5, 2 ),
        'dur'  => round( 3 + lcg_value() * 4, 2 ),
        'size' => rand( 3, 6 ),
    ];
}

/* ── wine collection ── */
$wines = [
    [
        'name'    => 'Château Noir 2019',
        'variety' => 'Cabernet Sauvignon',
        'cat'     => 'red',
        'notes'   => 'Dark cherry · Cedar · Vanilla · Long tannic finish',
        'score'   => 94,
        'price'   => '£42',
        'vintage' => 2019,
        'bottle_color' => '#1a0a08',
        'label_color'  => '#c9a84c',
    ],
    [
        'name'    => 'Estate Merlot 2021',
        'variety' => 'Merlot',
        'cat'     => 'red',
        'notes'   => 'Plum · Mocha · Tobacco · Silky tannins',
        'score'   => 91,
        'price'   => '£28',
        'vintage' => 2021,
        'bottle_color' => '#1e0c0a',
        'label_color'  => '#d4927a',
    ],
    [
        'name'    => 'Blanc de Blancs 2022',
        'variety' => 'Chardonnay',
        'cat'     => 'white',
        'notes'   => 'Green apple · Lemon curd · Brioche · Crisp acidity',
        'score'   => 92,
        'price'   => '£34',
        'vintage' => 2022,
        'bottle_color' => '#2a3420',
        'label_color'  => '#8aab80',
    ],
    [
        'name'    => 'Rosé d\'Été 2023',
        'variety' => 'Grenache Rosé',
        'cat'     => 'rose',
        'notes'   => 'Strawberry · Peach · Watermelon · Dry & refreshing',
        'score'   => 89,
        'price'   => '£22',
        'vintage' => 2023,
        'bottle_color' => '#2a3420',
        'label_color'  => '#f2bfc8',
    ],
    [
        'name'    => 'Sauvignon Blanc 2023',
        'variety' => 'Sauvignon Blanc',
        'cat'     => 'white',
        'notes'   => 'Elderflower · Grapefruit · Gooseberry · Vibrant finish',
        'score'   => 90,
        'price'   => '£26',
        'vintage' => 2023,
        'bottle_color' => '#1e2a18',
        'label_color'  => '#c9a84c',
    ],
    [
        'name'    => 'Late Harvest Sauternes',
        'variety' => 'Sémillon',
        'cat'     => 'dessert',
        'notes'   => 'Honey · Apricot · Marmalade · Opulent sweetness',
        'score'   => 96,
        'price'   => '£58',
        'vintage' => 2018,
        'bottle_color' => '#2a1808',
        'label_color'  => '#c9a84c',
    ],
];

/* ── tasting experiences ── */
$experiences = [
    [
        'name'  => 'Estate Tour & Tasting',
        'price' => '£35 / person',
        'dur'   => '2 hours',
        'desc'  => 'Walk the vine rows with our sommelier, visit the barrel room, and taste five of our finest wines paired with local artisan cheeses.',
        'icon'  => '🍷',
    ],
    [
        'name'  => 'Winemaker\'s Table',
        'price' => '£95 / person',
        'dur'   => '3.5 hours',
        'desc'  => 'An intimate dinner at the winemaker\'s personal table with six-course menu and paired vertical tasting across five vintages.',
        'icon'  => '🍽',
    ],
    [
        'name'  => 'Harvest Experience',
        'price' => '£65 / person',
        'dur'   => 'Full day',
        'desc'  => 'Join our harvest team in September — pick grapes, crush in the traditional press, and enjoy a rustic vineyard feast at sunset.',
        'icon'  => '🍇',
    ],
    [
        'name'  => 'Barrel Club',
        'price' => '£280 / year',
        'dur'   => 'Annual',
        'desc'  => 'Name a barrel in your honour. Receive two bottles each quarter, invitations to exclusive events, and a discount on all cellar-door purchases.',
        'icon'  => '🛢',
    ],
];

/* ── upcoming events ── */
$events = [
    [ 'title'=>'Midsummer Jazz Night',       'date'=>'21 Jun 2026', 'time'=>'18:00', 'price'=>'£45',  'type'=>'social'   ],
    [ 'title'=>'Organic & Biodynamic Talk',  'date'=>'04 Jul 2026', 'time'=>'14:00', 'price'=>'£18',  'type'=>'education' ],
    [ 'title'=>'Harvest Dinner 2026',        'date'=>'12 Sep 2026', 'time'=>'19:30', 'price'=>'£120', 'type'=>'dining'   ],
    [ 'title'=>'Christmas Sparkling Tasting','date'=>'29 Nov 2026', 'time'=>'16:00', 'price'=>'£40',  'type'=>'social'   ],
];

/* ── team ── */
$team = [
    [ 'name'=>'Henri Marceau',    'role'=>'Head Winemaker',       'years'=>'22 yrs', 'female'=>false, 'glasses'=>false ],
    [ 'name'=>'Élise Fontaine',   'role'=>'Head Sommelier',        'years'=>'14 yrs', 'female'=>true,  'glasses'=>true  ],
    [ 'name'=>'Callum Sinclair',  'role'=>'Vineyard Manager',      'years'=>'18 yrs', 'female'=>false, 'glasses'=>false ],
    [ 'name'=>'Miriam de Vries',  'role'=>'Events & Hospitality',  'years'=>'9 yrs',  'female'=>true,  'glasses'=>false ],
];

/* ── testimonials ── */
$testimonials = [
    [ 'text'=>'The Château Noir 2019 is one of the finest English reds I\'ve tasted. The estate tour with Henri was the highlight of our Cotswolds visit.', 'author'=>'William P.', 'source'=>'Decanter' ],
    [ 'text'=>'We hosted our board dinner at the Winemaker\'s Table last autumn. The food, the wine, the setting — all quite simply perfect.', 'author'=>'Patricia K.', 'source'=>'Private Guest' ],
    [ 'text'=>'Our wedding reception in the barrel room was magical. The team thought of everything. The Late Harvest paired with the wedding cake was inspired.', 'author'=>'James & Clara', 'source'=>'Wedding Guest' ],
];

/* ── marquee ── */
$mq_raw = [ 'Red', '·', 'White', '·', 'Rosé', '·', 'Sparkling', '·', 'Dessert Wines', '·', 'Barrel Club', '·', 'Estate Tours', '·', 'Harvest Dinners', '·', 'Private Events', '·', 'Cellar Door', '·' ];
$marquee_items = array_merge( $mq_raw, $mq_raw );
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Raleway:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════
   WINERY — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════ */
:root{
  --win-burgundy:#6b2737;
  --win-parchment:#f5f0e8;
  --win-gold:#c9a84c;
  --win-earth:#5a4030;
  --win-cream:#faf6ef;
  --win-night:#1a1210;
  --win-stone:#7a6858;
  --win-sage:#6a7a58;
  --win-radius:4px;
  --win-serif:'Libre Baskerville',serif;
  --win-sans:'Raleway',sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body.win-page{
  font-family:var(--win-sans);
  font-weight:300;
  color:var(--win-night);
  background:var(--win-cream);
  line-height:1.7;
  overflow-x:hidden;
}
.win-wrap{max-width:1180px;margin:0 auto;padding:0 24px}
.win-eyebrow{
  font-family:var(--win-sans);
  font-size:.7rem;
  font-weight:600;
  letter-spacing:.26em;
  text-transform:uppercase;
  color:var(--win-gold);
  display:block;
  margin-bottom:14px;
}
.win-section-title{
  font-family:var(--win-serif);
  font-size:clamp(1.9rem,4vw,3rem);
  font-weight:400;
  color:var(--win-night);
  margin-bottom:18px;
  line-height:1.2;
}
.win-btn{
  display:inline-block;
  padding:12px 32px;
  border-radius:var(--win-radius);
  font-family:var(--win-sans);
  font-size:.75rem;
  font-weight:600;
  letter-spacing:.12em;
  text-transform:uppercase;
  text-decoration:none;
  cursor:pointer;
  border:none;
  transition:transform .22s,box-shadow .22s,background .22s;
}
.win-btn:hover{transform:translateY(-2px)}
.win-btn-burg{background:var(--win-burgundy);color:var(--win-parchment)}
.win-btn-burg:hover{background:#5a1a27;box-shadow:0 8px 24px rgba(107,39,55,.4)}
.win-btn-gold{background:var(--win-gold);color:var(--win-night)}
.win-btn-gold:hover{background:#b8942a;box-shadow:0 8px 24px rgba(201,168,76,.35)}
.win-btn-outline{background:transparent;border:1.5px solid var(--win-gold);color:var(--win-gold)}
.win-btn-outline:hover{background:var(--win-gold);color:var(--win-night)}
.win-btn-ghost{background:transparent;border:1px solid rgba(245,240,232,.3);color:var(--win-parchment)}
.win-btn-ghost:hover{background:rgba(245,240,232,.12)}

.win-reveal{opacity:0;transform:translateY(26px);transition:opacity .7s,transform .7s}
.win-reveal.visible{opacity:1;transform:none}

/* ══════════════════════════════
   HERO — VINEYARD AT DUSK
══════════════════════════════ */
.win-hero{
  position:relative;
  min-height:100vh;
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
  background:linear-gradient(175deg,#0e0a08 0%,#1c1208 25%,#2a1a0c 45%,#3a2010 65%,#4a2a18 80%,#3a1c0e 100%);
}
/* dusk sky gradient overlay */
.win-hero::before{
  content:'';
  position:absolute;inset:0;
  background:radial-gradient(ellipse 100% 50% at 50% 0%,rgba(107,39,55,.35) 0%,transparent 60%),
              radial-gradient(ellipse 70% 40% at 20% 5%,rgba(201,168,76,.12) 0%,transparent 50%),
              radial-gradient(ellipse 60% 30% at 80% 8%,rgba(180,100,60,.1) 0%,transparent 45%);
  pointer-events:none;
}

/* stars */
.win-star{
  position:absolute;
  border-radius:50%;
  background:#fff;
  animation:win-twinkle var(--win-dur,3s) ease-in-out var(--win-del,0s) infinite alternate;
}
@keyframes win-twinkle{0%{opacity:var(--win-op,.4)}100%{opacity:1}}

/* fireflies */
.win-firefly{
  position:absolute;
  border-radius:50%;
  background:radial-gradient(circle,#e8ff80,rgba(232,255,128,0));
  filter:blur(1px);
  animation:win-firefly var(--win-ffdur,5s) ease-in-out var(--win-ffdel,0s) infinite;
}
@keyframes win-firefly{
  0%,100%{opacity:0;transform:translate(0,0)}
  20%{opacity:.9}
  50%{opacity:.4;transform:translate(30px,-20px)}
  80%{opacity:.8}
}

/* horizon glow */
.win-horizon{
  position:absolute;
  bottom:0;left:0;right:0;
  height:35%;
  background:linear-gradient(to top,rgba(107,39,55,.55) 0%,rgba(160,60,40,.2) 35%,transparent 70%);
}

/* vineyard rows CSS art */
.win-vineyard{
  position:absolute;
  bottom:0;left:0;right:0;
  height:55%;
  perspective:800px;
  perspective-origin:50% 0%;
}
.win-vine-row{
  position:absolute;
  bottom:0;
  display:flex;
  align-items:flex-end;
  gap:0;
}
.win-vine-post{
  width:3px;
  background:linear-gradient(to top,#5a3820,#7a5838);
  border-radius:2px 2px 0 0;
  position:relative;
}
.win-vine-wire{
  position:absolute;
  top:20%;left:-8px;right:-8px;
  height:1px;
  background:rgba(180,140,80,.4);
}
.win-vine-leaf-cluster{
  position:absolute;
  top:0;left:50%;
  transform:translateX(-50%) translateY(-40%);
  display:flex;flex-wrap:wrap;gap:1px;
}
.win-vine-leaf{
  border-radius:50%;
  background:var(--win-sage);
}
/* winery building in bg */
.win-building{
  position:absolute;
  bottom:32%;
  right:8%;
  display:flex;flex-direction:column;
  align-items:center;
}
.win-building-main{
  width:140px;height:80px;
  background:linear-gradient(to bottom,#8a7868,#9a8878);
  position:relative;
}
.win-building-roof{
  width:0;height:0;
  border-left:75px solid transparent;
  border-right:75px solid transparent;
  border-bottom:40px solid #6a5848;
}
.win-building-chimney{
  position:absolute;
  top:-54px;left:30px;
  width:14px;height:24px;
  background:#6a5848;
}
.win-building-door{
  position:absolute;
  bottom:0;left:50%;transform:translateX(-50%);
  width:24px;height:36px;
  background:#3a2010;
  border-radius:12px 12px 0 0;
}
.win-building-win{
  position:absolute;
  width:18px;height:22px;
  background:rgba(201,168,76,.6);
  border:2px solid #6a5848;
  border-radius:9px 9px 0 0;
}
/* cypress trees */
.win-cypress{
  position:absolute;
  bottom:32%;
  clip-path:polygon(50% 0%,15% 100%,85% 100%);
  background:linear-gradient(to bottom,#2a3a20,#3a5030);
}
/* moon */
.win-moon{
  position:absolute;
  top:8%;right:10%;
  width:70px;height:70px;
  border-radius:50%;
  background:radial-gradient(circle at 36% 34%,#fffde8,#f0d890);
  box-shadow:0 0 40px rgba(255,240,140,.3),0 0 90px rgba(255,240,140,.12);
}

/* hero copy */
.win-hero-content{
  position:relative;z-index:20;
  text-align:center;
  padding:160px 24px 100px;
  max-width:820px;
  margin:0 auto;
}
.win-hero h1{
  font-family:var(--win-serif);
  font-size:clamp(3rem,9vw,6.8rem);
  font-weight:400;
  color:var(--win-parchment);
  line-height:1.08;
  letter-spacing:-.01em;
  margin-bottom:20px;
  text-shadow:0 2px 40px rgba(0,0,0,.6);
}
.win-hero h1 em{font-style:italic;color:rgba(201,168,76,.9)}
.win-hero-sub{
  font-size:1rem;
  font-weight:300;
  color:rgba(245,240,232,.72);
  max-width:500px;
  margin:0 auto 40px;
  line-height:1.8;
}
.win-hero-badges{
  display:flex;justify-content:center;gap:28px;flex-wrap:wrap;
  margin-bottom:44px;
}
.win-hero-badge{
  font-size:.68rem;
  font-weight:600;
  letter-spacing:.16em;
  text-transform:uppercase;
  color:rgba(245,240,232,.5);
  display:flex;align-items:center;gap:8px;
}
.win-hero-badge::before{content:'✦';color:var(--win-gold);font-size:.6rem}
.win-hero-scroll{
  position:absolute;bottom:36px;left:50%;transform:translateX(-50%);
  display:flex;flex-direction:column;align-items:center;gap:8px;
  color:rgba(245,240,232,.35);
  font-size:.65rem;letter-spacing:.15em;text-transform:uppercase;
}
.win-scroll-line{
  width:1px;height:48px;
  background:linear-gradient(to bottom,rgba(245,240,232,.5),transparent);
  animation:win-scroll 2s ease-in-out infinite;
}
@keyframes win-scroll{0%,100%{opacity:.35;transform:scaleY(1)}50%{opacity:.9;transform:scaleY(1.12)}}

/* ══════════════════════════════
   MARQUEE
══════════════════════════════ */
.win-marquee-wrap{
  background:var(--win-burgundy);
  padding:15px 0;
  overflow:hidden;
}
.win-marquee-track{
  display:flex;width:max-content;
  animation:win-marquee 30s linear infinite;
}
.win-marquee-track:hover{animation-play-state:paused}
.win-marquee-item{
  padding:0 20px;
  font-size:.72rem;font-weight:600;
  letter-spacing:.2em;text-transform:uppercase;
  color:rgba(245,240,232,.8);white-space:nowrap;
}
@keyframes win-marquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}

/* ══════════════════════════════
   WINE COLLECTION
══════════════════════════════ */
.win-collection{
  padding:100px 0;
  background:var(--win-cream);
}
.win-section-header{text-align:center;margin-bottom:52px}
.win-filter-bar{
  display:flex;flex-wrap:wrap;justify-content:center;gap:10px;
  margin-bottom:40px;
}
.win-filter-btn{
  padding:8px 22px;border-radius:var(--win-radius);
  border:1.5px solid var(--win-stone);background:transparent;
  color:var(--win-stone);
  font-family:var(--win-sans);font-size:.72rem;font-weight:600;
  letter-spacing:.12em;text-transform:uppercase;cursor:pointer;
  transition:all .2s;
}
.win-filter-btn.active,
.win-filter-btn:hover{background:var(--win-burgundy);border-color:var(--win-burgundy);color:#fff}
.win-wine-grid{
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(260px,1fr));
  gap:28px;
}
.win-wine-card{
  background:#fff;
  border-radius:10px;
  padding:32px 24px;
  text-align:center;
  border-bottom:3px solid var(--win-burgundy);
  transition:transform .25s,box-shadow .25s;
}
.win-wine-card:hover{transform:translateY(-5px);box-shadow:0 18px 44px rgba(0,0,0,.1)}
.win-wine-card.hidden{display:none}

/* CSS wine bottle */
.win-bottle{
  position:relative;
  width:44px;
  margin:0 auto 22px;
}
.win-bottle-neck{
  width:14px;height:46px;
  background:linear-gradient(to right,rgba(255,255,255,.1),rgba(255,255,255,.05),transparent);
  border-radius:7px 7px 0 0;
  margin:0 auto;
  position:relative;
}
.win-bottle-capsule{
  position:absolute;
  top:-10px;left:50%;transform:translateX(-50%);
  width:16px;height:14px;
  border-radius:8px 8px 0 0;
}
.win-bottle-body{
  width:44px;height:80px;
  border-radius:6px 6px 10px 10px;
  position:relative;
  overflow:hidden;
}
.win-bottle-label{
  position:absolute;
  top:18px;left:4px;right:4px;height:34px;
  border-radius:3px;
  display:flex;align-items:center;justify-content:center;
  font-size:.45rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;
  opacity:.9;
}
.win-bottle-shine{
  position:absolute;
  top:0;left:6px;
  width:8px;height:100%;
  background:linear-gradient(to right,rgba(255,255,255,.12),rgba(255,255,255,.05),transparent);
  border-radius:4px;
}
.win-wine-name{
  font-family:var(--win-serif);
  font-size:1.1rem;color:var(--win-night);
  margin-bottom:4px;
}
.win-wine-variety{
  font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;
  color:var(--win-stone);margin-bottom:10px;
}
.win-wine-notes{
  font-size:.78rem;color:var(--win-stone);
  font-style:italic;line-height:1.6;
  margin-bottom:14px;
}
.win-wine-score{
  display:inline-block;
  background:var(--win-burgundy);color:#fff;
  font-size:.72rem;font-weight:700;
  padding:4px 12px;border-radius:20px;
  margin-bottom:14px;
}
.win-wine-price{
  font-family:var(--win-serif);
  font-size:1.5rem;color:var(--win-burgundy);
  margin-bottom:16px;
}

/* ══════════════════════════════
   EXPERIENCES
══════════════════════════════ */
.win-experiences{
  padding:100px 0;
  background:var(--win-night);
}
.win-experiences .win-eyebrow{color:rgba(201,168,76,.7)}
.win-experiences .win-section-title{color:var(--win-parchment)}
.win-exp-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
  gap:24px;
}
.win-exp-card{
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.09);
  border-radius:10px;
  padding:34px 26px;
  transition:background .25s,border-color .25s;
}
.win-exp-card:hover{background:rgba(255,255,255,.07);border-color:rgba(201,168,76,.3)}
.win-exp-icon{font-size:2rem;margin-bottom:16px;display:block}
.win-exp-name{
  font-family:var(--win-serif);font-size:1.2rem;
  color:var(--win-parchment);margin-bottom:6px;
}
.win-exp-meta{
  font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;
  color:var(--win-gold);margin-bottom:12px;
}
.win-exp-desc{
  font-size:.83rem;color:rgba(245,240,232,.5);line-height:1.75;
  margin-bottom:18px;
}
.win-exp-price{
  font-family:var(--win-serif);font-size:1.3rem;
  color:var(--win-gold);
}

/* ══════════════════════════════
   EVENTS
══════════════════════════════ */
.win-events{
  padding:100px 0;
  background:var(--win-parchment);
}
.win-event-list{
  display:flex;flex-direction:column;gap:16px;
  max-width:780px;margin:0 auto;
}
.win-event-item{
  background:#fff;border-radius:10px;
  padding:22px 28px;
  display:grid;
  grid-template-columns:80px 1fr auto;
  gap:24px;align-items:center;
  border-left:4px solid var(--win-burgundy);
  transition:transform .2s,box-shadow .2s;
}
.win-event-item:hover{transform:translateX(4px);box-shadow:0 6px 24px rgba(0,0,0,.08)}
.win-event-date{
  text-align:center;
}
.win-event-day{
  font-family:var(--win-serif);font-size:2rem;color:var(--win-burgundy);line-height:1;
}
.win-event-month{
  font-size:.65rem;font-weight:600;letter-spacing:.14em;text-transform:uppercase;
  color:var(--win-stone);
}
.win-event-title{
  font-family:var(--win-serif);font-size:1.1rem;color:var(--win-night);
  margin-bottom:4px;
}
.win-event-meta{
  font-size:.75rem;color:var(--win-stone);
}
.win-event-price{
  font-family:var(--win-serif);font-size:1.3rem;color:var(--win-gold);
  white-space:nowrap;
}

/* ══════════════════════════════
   ABOUT / CELLAR ART
══════════════════════════════ */
.win-about{
  padding:110px 0;
  background:var(--win-cream);
}
.win-about-inner{
  display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;
}
.win-about-text p{
  color:var(--win-stone);font-size:.9rem;line-height:1.85;margin-bottom:16px;
}
.win-cellar-art{
  position:relative;height:480px;border-radius:16px;overflow:hidden;
  background:linear-gradient(160deg,#1a0e08 0%,#2a1a0c 50%,#1e1208 100%);
}
/* cellar floor */
.win-cellar-floor{
  position:absolute;bottom:0;left:0;right:0;height:28%;
  background:linear-gradient(to top,#4a3020,#6a4830);
}
.win-cellar-floor::after{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(90deg,rgba(0,0,0,.06) 0,rgba(0,0,0,.06) 1px,transparent 1px,transparent 30px);
}
/* stone wall */
.win-cellar-wall{
  position:absolute;top:0;left:0;right:0;bottom:28%;
  background:#2a1a0c;
}
.win-cellar-wall::after{
  content:'';position:absolute;inset:0;
  background:repeating-linear-gradient(0deg,rgba(255,255,255,.03) 0,rgba(255,255,255,.03) 1px,transparent 1px,transparent 24px),
              repeating-linear-gradient(90deg,rgba(255,255,255,.02) 0,rgba(255,255,255,.02) 1px,transparent 1px,transparent 36px);
}
/* barrel row */
.win-barrel-row{
  position:absolute;
  bottom:26%;left:50%;transform:translateX(-50%);
  display:flex;gap:12px;
  align-items:flex-end;
}
.win-barrel{
  position:relative;
  width:56px;height:64px;
  background:linear-gradient(to bottom,#8a5030,#6a3820);
  border-radius:10px 10px 8px 8px;
  border:3px solid #4a2810;
}
.win-barrel::before,
.win-barrel::after{
  content:'';
  position:absolute;left:4px;right:4px;height:3px;
  background:#4a2810;border-radius:2px;
}
.win-barrel::before{top:18px}
.win-barrel::after{top:38px}
.win-barrel-bung{
  position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
  width:10px;height:10px;
  border-radius:50%;
  background:#2a1008;
  border:2px solid #6a4020;
}
/* wine rack on wall */
.win-rack{
  position:absolute;
  top:15%;right:10%;
  width:100px;height:150px;
  background:rgba(90,64,48,.4);
  border:2px solid rgba(120,90,60,.4);
  border-radius:4px;
  display:grid;grid-template-columns:1fr 1fr 1fr;
  grid-template-rows:repeat(4,1fr);
  gap:3px;padding:4px;
}
.win-rack-slot{
  border-radius:50%;
  background:linear-gradient(135deg,rgba(30,10,8,.8),rgba(50,20,10,.6));
  border:1px solid rgba(90,50,30,.5);
  position:relative;overflow:hidden;
}
.win-rack-slot::after{
  content:'';position:absolute;
  top:0;left:20%;
  width:30%;height:100%;
  background:rgba(255,255,255,.06);
  border-radius:50%;
}
/* candelabra */
.win-candelabra{
  position:absolute;
  bottom:27%;left:12%;
}
.win-candelabra-base{
  width:30px;height:6px;
  background:#8a7060;border-radius:3px;
}
.win-candelabra-stem{
  width:4px;height:30px;
  background:#8a7060;
  margin:0 auto;
}
.win-candelabra-arms{
  position:relative;
  width:70px;margin:-2px auto 0;
  height:20px;
  border-top:3px solid #8a7060;
  border-radius:10px 10px 0 0;
}
.win-candelabra-candle{
  position:absolute;
  bottom:100%;
  width:6px;height:26px;
  background:linear-gradient(to top,#d4c090,#f5f0e0);
  border-radius:3px;
}
.win-candelabra-flame{
  position:absolute;
  bottom:100%;left:50%;transform:translateX(-50%);
  width:6px;height:10px;
  background:radial-gradient(ellipse at 50% 70%,#ffe87a,#ff9030 60%,transparent);
  border-radius:50% 50% 30% 30%;
  animation:win-flame 1.9s ease-in-out infinite;
}
@keyframes win-flame{0%,100%{transform:translateX(-50%) scaleX(1)}50%{transform:translateX(-50%) scaleX(.8) scaleY(1.15)}}
/* cellar lamp glow on ceiling */
.win-cellar-lamp{
  position:absolute;
  top:8%;left:50%;transform:translateX(-50%);
}
.win-cellar-lamp-shade{
  width:40px;height:20px;
  background:#8a7060;
  clip-path:polygon(15% 0%,85% 0%,100% 100%,0% 100%);
  margin:0 auto;
}
.win-cellar-lamp-cord{
  width:2px;height:24px;
  background:#6a5040;margin:0 auto;
}
.win-cellar-lamp-glow{
  position:absolute;
  top:44px;left:50%;transform:translateX(-50%);
  width:120px;height:80px;
  background:radial-gradient(ellipse,rgba(201,168,76,.12),transparent 70%);
  pointer-events:none;
}

/* ══════════════════════════════
   STATS
══════════════════════════════ */
.win-stats{
  padding:80px 0;
  background:var(--win-earth);
}
.win-stats-grid{
  display:grid;grid-template-columns:repeat(4,1fr);gap:40px;text-align:center;
}
.win-stat-num{
  font-family:var(--win-serif);
  font-size:clamp(2.4rem,5vw,3.8rem);
  color:var(--win-parchment);line-height:1;margin-bottom:8px;
}
.win-stat-label{
  font-size:.72rem;font-weight:600;letter-spacing:.15em;text-transform:uppercase;
  color:rgba(245,240,232,.55);
}

/* ══════════════════════════════
   TEAM
══════════════════════════════ */
.win-team{
  padding:100px 0;
  background:var(--win-cream);
}
.win-team-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:28px;
}
.win-team-card{
  text-align:center;padding:34px 20px 26px;
  background:#fff;border-radius:10px;
  border-top:3px solid var(--win-burgundy);
  transition:transform .25s,box-shadow .25s;
}
.win-team-card:hover{transform:translateY(-4px);box-shadow:0 14px 36px rgba(0,0,0,.08)}
.win-team-avatar{
  position:relative;width:100px;height:120px;margin:0 auto 18px;
}
.win-team-head{
  position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:44px;height:44px;border-radius:50%;
}
.win-team-torso{
  position:absolute;top:48px;left:50%;transform:translateX(-50%);
  width:56px;height:50px;border-radius:28px 28px 0 0;
}
.win-team-name{
  font-family:var(--win-serif);font-size:1.2rem;color:var(--win-night);margin-bottom:4px;
}
.win-team-role{
  font-size:.72rem;font-weight:600;letter-spacing:.1em;text-transform:uppercase;
  color:var(--win-burgundy);margin-bottom:6px;
}
.win-team-years{font-size:.78rem;color:var(--win-stone)}

/* ══════════════════════════════
   TESTIMONIALS
══════════════════════════════ */
.win-testimonials{
  padding:100px 0;
  background:var(--win-night);
}
.win-testimonials .win-eyebrow{color:rgba(201,168,76,.7)}
.win-testimonials .win-section-title{color:var(--win-parchment)}
.win-testi-grid{
  display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:24px;
}
.win-testi-card{
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.08);
  border-radius:10px;padding:30px 26px;
  border-left:3px solid var(--win-burgundy);
}
.win-testi-quote{
  font-family:var(--win-serif);font-size:2rem;color:var(--win-burgundy);
  opacity:.5;line-height:1;margin-bottom:10px;
}
.win-testi-text{
  font-size:.88rem;color:rgba(245,240,232,.65);
  font-style:italic;line-height:1.8;margin-bottom:16px;
}
.win-testi-author{
  font-size:.75rem;font-weight:600;letter-spacing:.06em;
  color:var(--win-parchment);
}
.win-testi-source{
  font-size:.7rem;color:var(--win-gold);display:block;margin-top:2px;
}

/* ══════════════════════════════
   CONTACT / VISIT FORM
══════════════════════════════ */
.win-contact{
  padding:110px 0;
  background:var(--win-parchment);
  position:relative;overflow:hidden;
}
.win-contact::before{
  content:'';position:absolute;
  top:-200px;right:-100px;
  width:500px;height:500px;border-radius:50%;
  background:radial-gradient(circle,rgba(107,39,55,.08),transparent 70%);
  pointer-events:none;
}
.win-contact-inner{
  position:relative;z-index:2;
  display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:start;
}
.win-contact-info h2{
  font-family:var(--win-serif);font-size:clamp(1.8rem,3.5vw,2.6rem);
  color:var(--win-night);margin-bottom:16px;
}
.win-contact-info p{color:var(--win-stone);font-size:.9rem;line-height:1.85;margin-bottom:28px}
.win-contact-details{list-style:none;display:flex;flex-direction:column;gap:14px}
.win-contact-details li{
  font-size:.83rem;color:var(--win-stone);
  display:flex;align-items:center;gap:12px;
}
.win-contact-icon{
  width:36px;height:36px;border-radius:50%;
  background:rgba(107,39,55,.1);
  display:flex;align-items:center;justify-content:center;
  font-size:.85rem;flex-shrink:0;
}
.win-form{
  background:#fff;border-radius:12px;
  padding:38px 34px;
  box-shadow:0 8px 40px rgba(0,0,0,.08);
}
.win-form h3{
  font-family:var(--win-serif);font-size:1.5rem;
  color:var(--win-night);margin-bottom:24px;
}
.win-field{margin-bottom:18px}
.win-field label{
  display:block;font-size:.68rem;font-weight:600;
  letter-spacing:.14em;text-transform:uppercase;
  color:var(--win-stone);margin-bottom:7px;
}
.win-field input,
.win-field select,
.win-field textarea{
  width:100%;padding:12px 16px;
  background:#faf8f3;border:1.5px solid rgba(90,64,48,.18);
  border-radius:var(--win-radius);
  color:var(--win-night);font-family:var(--win-sans);font-size:.86rem;
  transition:border-color .2s,background .2s;
}
.win-field input:focus,
.win-field select:focus,
.win-field textarea:focus{outline:none;border-color:var(--win-burgundy);background:#fff}
.win-field textarea{height:90px;resize:vertical}
.win-field-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.win-form-note{font-size:.73rem;color:var(--win-stone);margin-bottom:22px;line-height:1.6}
.win-form .win-btn{width:100%;text-align:center}
.win-form-success{
  display:none;text-align:center;padding:24px;
  font-family:var(--win-serif);font-size:1.1rem;font-style:italic;
  color:var(--win-burgundy);
}

/* responsive */
@media(max-width:860px){
  .win-about-inner,.win-contact-inner{grid-template-columns:1fr;gap:48px}
  .win-cellar-art{height:320px}
  .win-stats-grid{grid-template-columns:repeat(2,1fr)}
  .win-event-item{grid-template-columns:60px 1fr;gap:16px}
  .win-event-price{grid-column:2}
}
@media(max-width:600px){
  .win-stats-grid{grid-template-columns:1fr 1fr}
  .win-field-row{grid-template-columns:1fr}
  .win-hero h1{font-size:2.8rem}
  .win-event-item{grid-template-columns:1fr}
  .win-event-date{text-align:left}
}
</style>
<?php get_header(); ?>
<div class="win-page">
">
<?php wp_body_open(); ?>

<!-- ══════════════════════════════
     HERO — VINEYARD AT DUSK
══════════════════════════════ -->
<section class="win-hero">

  <!-- stars -->
  <?php foreach ( $stars as $s ) : ?>
  <div class="win-star" style="
    left:<?php echo $s['x']; ?>%;top:<?php echo $s['y']; ?>%;
    width:<?php echo $s['size']; ?>px;height:<?php echo $s['size']; ?>px;
    --win-op:<?php echo $s['op']; ?>;
    --win-dur:<?php echo $s['dur']; ?>s;
    --win-del:<?php echo $s['del']; ?>s;
  "></div>
  <?php endforeach; ?>

  <!-- fireflies -->
  <?php foreach ( $fireflies as $f ) : ?>
  <div class="win-firefly" style="
    left:<?php echo $f['x']; ?>%;top:<?php echo $f['y']; ?>%;
    width:<?php echo $f['size']; ?>px;height:<?php echo $f['size']; ?>px;
    --win-ffdur:<?php echo $f['dur']; ?>s;
    --win-ffdel:<?php echo $f['del']; ?>s;
  "></div>
  <?php endforeach; ?>

  <!-- moon -->
  <div class="win-moon"></div>

  <!-- cypress trees -->
  <div class="win-cypress" style="left:5%;width:30px;height:160px;bottom:32%"></div>
  <div class="win-cypress" style="left:8%;width:24px;height:120px;bottom:32%"></div>
  <div class="win-cypress" style="right:5%;width:28px;height:150px;bottom:32%"></div>
  <div class="win-cypress" style="right:9%;width:20px;height:110px;bottom:32%"></div>

  <!-- winery building -->
  <div class="win-building">
    <div class="win-building-roof">
      <div class="win-building-chimney"></div>
    </div>
    <div class="win-building-main">
      <div class="win-building-win" style="top:14px;left:18px"></div>
      <div class="win-building-win" style="top:14px;right:18px"></div>
      <div class="win-building-door"></div>
    </div>
  </div>

  <!-- vineyard rows -->
  <div class="win-vineyard">
    <?php for ($ri=0;$ri<8;$ri++):
      $row_bottom = $ri * 10;
      $post_count = 12 - $ri;
      $post_h = 28 + $ri * 4;
      $leaf_s = max(4, 8 - $ri);
    ?>
    <?php for($side=0;$side<2;$side++):
      $row_left = $side===0 ? (2 + $ri * 2).'%' : 'auto';
      $row_right= $side===1 ? (2 + $ri * 2).'%' : 'auto';
    ?>
    <div class="win-vine-row" style="
      <?php echo $side===0 ? "left:$row_left" : "right:$row_right"; ?>;
      bottom:<?php echo $row_bottom; ?>%;
      opacity:<?php echo round(.4 + $ri * .07, 2); ?>;
    ">
      <?php for($pi=0;$pi<$post_count;$pi++): ?>
      <div class="win-vine-post" style="height:<?php echo $post_h; ?>px;margin-right:<?php echo max(8,20-$ri*2); ?>px">
        <div class="win-vine-wire"></div>
        <div class="win-vine-leaf-cluster">
          <?php for($li=0;$li<rand(3,6);$li++): ?>
          <div class="win-vine-leaf" style="
            width:<?php echo $leaf_s; ?>px;
            height:<?php echo $leaf_s; ?>px;
            background:<?php echo $ri>4?'#3a5028':'#4a6738'; ?>;
            opacity:<?php echo round(.6+lcg_value()*.3,2); ?>;
          "></div>
          <?php endfor; ?>
        </div>
      </div>
      <?php endfor; ?>
    </div>
    <?php endfor; ?>
    <?php endfor; ?>
  </div>

  <div class="win-horizon"></div>

  <!-- hero copy -->
  <div class="win-hero-content">
    <span class="win-eyebrow">Estate Bottled Since 1972</span>
    <h1>The Art of the<br><em>Vine</em></h1>
    <p class="win-hero-sub">Fifty years of sun, soil, and patience. Award-winning wines from our single estate vineyard in the English countryside.</p>
    <div class="win-hero-badges">
      <span class="win-hero-badge">Gold Medal 2024</span>
      <span class="win-hero-badge">Decanter 94 pts</span>
      <span class="win-hero-badge">Cellar Door Open Daily</span>
    </div>
    <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap">
      <a href="#shop" class="win-btn win-btn-gold">Shop Wines</a>
      <a href="#experiences" class="win-btn win-btn-ghost">Book a Tasting</a>
    </div>
  </div>

  <div class="win-hero-scroll">
    <span>Explore</span>
    <div class="win-scroll-line"></div>
  </div>

</section>

<!-- MARQUEE -->
<div class="win-marquee-wrap">
  <div class="win-marquee-track">
    <?php foreach ( $marquee_items as $item ) : ?>
    <span class="win-marquee-item"><?php echo esc_html($item); ?></span>
    <?php endforeach; ?>
  </div>
</div>

<!-- ══════════════════════════════
     WINE COLLECTION
══════════════════════════════ -->
<section class="win-collection" id="shop">
  <div class="win-wrap">
    <div class="win-section-header win-reveal">
      <span class="win-eyebrow">Cellar Door</span>
      <h2 class="win-section-title">Our Wines</h2>
    </div>
    <div class="win-filter-bar win-reveal">
      <button class="win-filter-btn active" data-filter="all">All Wines</button>
      <button class="win-filter-btn" data-filter="red">Red</button>
      <button class="win-filter-btn" data-filter="white">White</button>
      <button class="win-filter-btn" data-filter="rose">Rosé</button>
      <button class="win-filter-btn" data-filter="dessert">Dessert</button>
    </div>
    <div class="win-wine-grid" id="win-wine-grid">
      <?php foreach ( $wines as $w ) : ?>
      <div class="win-wine-card win-reveal" data-cat="<?php echo esc_attr($w['cat']); ?>">
        <!-- CSS bottle -->
        <div class="win-bottle">
          <div class="win-bottle-neck" style="background:<?php echo esc_attr($w['bottle_color']); ?>">
            <div class="win-bottle-capsule" style="background:<?php echo esc_attr($w['label_color']); ?>"></div>
          </div>
          <div class="win-bottle-body" style="background:<?php echo esc_attr($w['bottle_color']); ?>">
            <div class="win-bottle-label" style="background:<?php echo esc_attr($w['label_color']); ?>;color:<?php echo ($w['label_color']==='#c9a84c')?'#1a0a08':'#fff'; ?>">
              <?php echo esc_html($w['vintage']); ?>
            </div>
            <div class="win-bottle-shine"></div>
          </div>
        </div>
        <div class="win-wine-name"><?php echo esc_html($w['name']); ?></div>
        <div class="win-wine-variety"><?php echo esc_html($w['variety']); ?></div>
        <p class="win-wine-notes"><?php echo esc_html($w['notes']); ?></p>
        <div><span class="win-wine-score"><?php echo esc_html($w['score']); ?> pts</span></div>
        <div class="win-wine-price"><?php echo esc_html($w['price']); ?></div>
        <a href="#enquiry" class="win-btn win-btn-outline" style="font-size:.68rem;padding:9px 22px">Add to Order</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     EXPERIENCES
══════════════════════════════ -->
<section class="win-experiences" id="experiences">
  <div class="win-wrap">
    <div class="win-section-header win-reveal">
      <span class="win-eyebrow">Visit the Estate</span>
      <h2 class="win-section-title">Tasting Experiences</h2>
    </div>
    <div class="win-exp-grid">
      <?php foreach ( $experiences as $exp ) : ?>
      <div class="win-exp-card win-reveal">
        <span class="win-exp-icon"><?php echo $exp['icon']; ?></span>
        <div class="win-exp-name"><?php echo esc_html($exp['name']); ?></div>
        <div class="win-exp-meta"><?php echo esc_html($exp['dur']); ?></div>
        <p class="win-exp-desc"><?php echo esc_html($exp['desc']); ?></p>
        <div class="win-exp-price"><?php echo esc_html($exp['price']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     EVENTS
══════════════════════════════ -->
<section class="win-events">
  <div class="win-wrap">
    <div class="win-section-header win-reveal">
      <span class="win-eyebrow">At the Estate</span>
      <h2 class="win-section-title">Upcoming Events</h2>
    </div>
    <div class="win-event-list">
      <?php
      $event_colors = [
        'social'    => var_export('#6b2737',true),
        'education' => var_export('#5a4030',true),
        'dining'    => var_export('#c9a84c',true),
      ];
      foreach ( $events as $ev ) :
        $date_parts = explode(' ',$ev['date']);
        $day_num    = $date_parts[0];
        $month_str  = $date_parts[1];
        $border_c   = ['social'=>'#6b2737','education'=>'#5a4030','dining'=>'#c9a84c'][$ev['type']] ?? '#6b2737';
      ?>
      <div class="win-event-item win-reveal" style="border-left-color:<?php echo esc_attr($border_c); ?>">
        <div class="win-event-date">
          <div class="win-event-day"><?php echo esc_html($day_num); ?></div>
          <div class="win-event-month"><?php echo esc_html($month_str.' '.($date_parts[2]??'')); ?></div>
        </div>
        <div>
          <div class="win-event-title"><?php echo esc_html($ev['title']); ?></div>
          <div class="win-event-meta">🕐 <?php echo esc_html($ev['time']); ?></div>
        </div>
        <div class="win-event-price"><?php echo esc_html($ev['price']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     ABOUT / CELLAR ART
══════════════════════════════ -->
<section class="win-about">
  <div class="win-wrap">
    <div class="win-about-inner">
      <div class="win-cellar-art win-reveal">
        <div class="win-cellar-wall"></div>
        <div class="win-cellar-floor"></div>
        <!-- lamp -->
        <div class="win-cellar-lamp">
          <div class="win-cellar-lamp-cord"></div>
          <div class="win-cellar-lamp-shade"></div>
          <div class="win-cellar-lamp-glow"></div>
        </div>
        <!-- wine rack -->
        <div class="win-rack">
          <?php for($ri=0;$ri<12;$ri++): ?>
          <div class="win-rack-slot" style="background:<?php
            $bottlecolors=['#1a0a08','#1e1208','#1e2a18','#2a1808'];
            echo $bottlecolors[$ri%4];
          ?>"></div>
          <?php endfor; ?>
        </div>
        <!-- barrel row -->
        <div class="win-barrel-row">
          <?php for($bi=0;$bi<3;$bi++): ?>
          <div class="win-barrel">
            <div class="win-barrel-bung"></div>
          </div>
          <?php endfor; ?>
        </div>
        <!-- candelabra -->
        <div class="win-candelabra">
          <div class="win-candelabra-base"></div>
          <div class="win-candelabra-stem"></div>
          <div class="win-candelabra-arms">
            <!-- left candle -->
            <div class="win-candelabra-candle" style="left:-2px">
              <div class="win-candelabra-flame" style="animation-delay:0s"></div>
            </div>
            <!-- center candle -->
            <div class="win-candelabra-candle" style="left:50%;transform:translateX(-50%)">
              <div class="win-candelabra-flame" style="animation-delay:.3s"></div>
            </div>
            <!-- right candle -->
            <div class="win-candelabra-candle" style="right:-2px">
              <div class="win-candelabra-flame" style="animation-delay:.6s"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="win-about-text win-reveal">
        <span class="win-eyebrow">Our Heritage</span>
        <h2 class="win-section-title">Fifty Years of Crafting Wine</h2>
        <p>In 1972, Jean-Paul Marceau planted the first vines on this south-facing chalk hillside. He was told England was too cold for fine wine. He proved them wrong. Today, his grandson Henri tends the same vines — now venerable, gnarly, and deeply expressive.</p>
        <p>Our philosophy has never changed: minimum intervention in the cellar, maximum attention in the vineyard. Every bottle is an honest portrait of a specific place in a specific year.</p>
        <p>The cellar door is open every day. Come taste for yourself.</p>
        <div style="margin-top:28px;display:flex;gap:14px;flex-wrap:wrap">
          <a href="#experiences" class="win-btn win-btn-burg">Book a Tasting</a>
          <a href="#shop" class="win-btn win-btn-outline">Shop Wines</a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     STATS
══════════════════════════════ -->
<section class="win-stats">
  <div class="win-wrap">
    <div class="win-stats-grid">
      <?php
      $stats=[
        ['num'=>1972,'suffix'=>'','label'=>'Est. Year'],
        ['num'=>52,  'suffix'=>' ac','label'=>'Estate Acres'],
        ['num'=>8,   'suffix'=>' vars','label'=>'Grape Varieties'],
        ['num'=>94,  'suffix'=>' pts','label'=>'Decanter Score'],
      ];
      foreach($stats as $st):
      ?>
      <div class="win-reveal" style="text-align:center">
        <div class="win-stat-num" data-target="<?php echo $st['num']; ?>" data-suffix="<?php echo esc_attr($st['suffix']); ?>">0</div>
        <div class="win-stat-label"><?php echo esc_html($st['label']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     TEAM
══════════════════════════════ -->
<section class="win-team">
  <div class="win-wrap">
    <div class="win-section-header win-reveal">
      <span class="win-eyebrow">The People</span>
      <h2 class="win-section-title">Meet the Team</h2>
    </div>
    <div class="win-team-grid">
      <?php
      $tpalettes=[
        ['torso'=>'#6b2737','skin'=>'#c8a870','hair'=>'#4a3820','legs'=>'#2a1018'],
        ['torso'=>'#5a4030','skin'=>'#d4a87a','hair'=>'#1a0a04','legs'=>'#3a2010'],
        ['torso'=>'#4a6738','skin'=>'#c89060','hair'=>'#2a1808','legs'=>'#2a3820'],
        ['torso'=>'#c9a84c','skin'=>'#d4b080','hair'=>'#3a2a18','legs'=>'#8a6828'],
      ];
      foreach($team as $ti=>$t):
        $tp=$tpalettes[$ti%count($tpalettes)];
      ?>
      <div class="win-team-card win-reveal">
        <div class="win-team-avatar">
          <div class="win-team-head" style="background:<?php echo $tp['skin']; ?>">
            <div style="position:absolute;top:-5px;left:1px;right:1px;height:<?php echo $t['female']?'20px':'12px'; ?>;background:<?php echo $tp['hair']; ?>;border-radius:11px 11px 0 0"></div>
            <?php if ($t['female'] && $ti===1): // élise chignon ?>
            <div style="position:absolute;top:-8px;right:-3px;width:12px;height:12px;border-radius:50%;background:<?php echo $tp['hair']; ?>"></div>
            <?php endif; ?>
            <?php if ($t['glasses']): ?>
            <div style="position:absolute;bottom:7px;left:3px;right:3px;height:4px;background:rgba(0,0,0,.35);border-radius:2px;display:flex;gap:2px">
              <div style="flex:1;border:1px solid rgba(0,0,0,.4);border-radius:2px"></div>
              <div style="flex:1;border:1px solid rgba(0,0,0,.4);border-radius:2px"></div>
            </div>
            <?php endif; ?>
          </div>
          <div class="win-team-torso" style="background:<?php echo $tp['torso']; ?>">
            <!-- pocket square or apron detail -->
            <?php if ($ti===0||$ti===2): ?>
            <div style="position:absolute;top:6px;left:50%;transform:translateX(-50%);width:30px;height:24px;background:rgba(245,240,232,.2);border-radius:2px;clip-path:polygon(0% 0%,100% 0%,100% 70%,50% 100%,0% 70%)"></div>
            <?php endif; ?>
          </div>
        </div>
        <div class="win-team-name"><?php echo esc_html($t['name']); ?></div>
        <div class="win-team-role"><?php echo esc_html($t['role']); ?></div>
        <div class="win-team-years"><?php echo esc_html($t['years']); ?> experience</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     TESTIMONIALS
══════════════════════════════ -->
<section class="win-testimonials">
  <div class="win-wrap">
    <div class="win-section-header win-reveal">
      <span class="win-eyebrow">Acclaim</span>
      <h2 class="win-section-title">What They Say</h2>
    </div>
    <div class="win-testi-grid">
      <?php foreach($testimonials as $t): ?>
      <div class="win-testi-card win-reveal">
        <div class="win-testi-quote">"</div>
        <p class="win-testi-text"><?php echo esc_html($t['text']); ?></p>
        <div class="win-testi-author"><?php echo esc_html($t['author']); ?></div>
        <span class="win-testi-source"><?php echo esc_html($t['source']); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══════════════════════════════
     CONTACT / VISIT FORM
══════════════════════════════ -->
<section class="win-contact" id="enquiry">
  <div class="win-wrap">
    <div class="win-contact-inner">
      <div class="win-contact-info win-reveal">
        <span class="win-eyebrow">Visit Us</span>
        <h2>Plan Your Visit to the Estate</h2>
        <p>Whether you'd like to book a tasting, arrange a private event, or enquire about our Barrel Club, we'd love to welcome you to the vineyard.</p>
        <ul class="win-contact-details">
          <li><span class="win-contact-icon">📍</span>Marceau Estate, Faversham Road, Kent CT5 3AQ</li>
          <li><span class="win-contact-icon">📞</span>+44 1227 840 291</li>
          <li><span class="win-contact-icon">✉</span>cellar@marceauestate.co.uk</li>
          <li><span class="win-contact-icon">🕐</span>Cellar Door: Daily 10:00 – 17:00</li>
        </ul>
      </div>
      <div class="win-form win-reveal">
        <h3>Make an Enquiry</h3>
        <?php wp_nonce_field('tf_win_enquiry','tf_win_nonce'); ?>
        <div class="win-field-row">
          <div class="win-field">
            <label>First Name</label>
            <input type="text" name="win_fname" placeholder="William" required>
          </div>
          <div class="win-field">
            <label>Last Name</label>
            <input type="text" name="win_lname" placeholder="Porter" required>
          </div>
        </div>
        <div class="win-field">
          <label>Email Address</label>
          <input type="email" name="win_email" placeholder="william@example.com" required>
        </div>
        <div class="win-field">
          <label>Phone Number</label>
          <input type="tel" name="win_phone" placeholder="+44 7700 900000">
        </div>
        <div class="win-field">
          <label>I'm Interested In</label>
          <select name="win_interest">
            <option value="">— Select —</option>
            <option>Estate Tour &amp; Tasting (£35pp)</option>
            <option>Winemaker's Table (£95pp)</option>
            <option>Harvest Experience (£65pp)</option>
            <option>Barrel Club (£280/yr)</option>
            <option>Private Event at the Estate</option>
            <option>Trade / Press Enquiry</option>
          </select>
        </div>
        <div class="win-field-row">
          <div class="win-field">
            <label>Preferred Date</label>
            <input type="date" name="win_date">
          </div>
          <div class="win-field">
            <label>Party Size</label>
            <select name="win_party">
              <option value="">— Guests —</option>
              <option>Just me</option>
              <option>2 guests</option>
              <option>3–6 guests</option>
              <option>7–12 guests</option>
              <option>13+ guests</option>
            </select>
          </div>
        </div>
        <div class="win-field">
          <label>Message</label>
          <textarea name="win_message" placeholder="Tell us more about what you're looking for…"></textarea>
        </div>
        <p class="win-form-note">We respond to all enquiries within one business day. We look forward to welcoming you to the estate.</p>
        <button type="submit" class="win-btn win-btn-burg" id="win-submit-btn">Send Enquiry</button>
        <div class="win-form-success" id="win-success">
          🍷 Thank you for your enquiry. We'll be in touch very soon.
        </div>
      </div>
    </div>
  </div>
</section>
<script>
(function(){
  /* scroll reveal */
  const ro=new IntersectionObserver(e=>{
    e.forEach(en=>{if(en.isIntersecting){en.target.classList.add('visible');ro.unobserve(en.target);}});
  },{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  document.querySelectorAll('.win-reveal').forEach(el=>ro.observe(el));

  /* animated counters */
  const easeOut=t=>1-Math.pow(1-t,3);
  const co=new IntersectionObserver(e=>{
    e.forEach(en=>{
      if(!en.isIntersecting)return;
      const el=en.target,target=+el.dataset.target,suffix=el.dataset.suffix||'',dur=1800;
      let start=null;
      (function tick(ts){
        if(!start)start=ts;
        const p=Math.min((ts-start)/dur,1);
        el.textContent=Math.round(easeOut(p)*target)+suffix;
        if(p<1)requestAnimationFrame(tick);
      })(performance.now());
      co.unobserve(el);
    });
  },{threshold:.4});
  document.querySelectorAll('.win-stat-num[data-target]').forEach(el=>co.observe(el));

  /* wine filter */
  const filterBtns=document.querySelectorAll('.win-filter-btn');
  const wineCards=document.querySelectorAll('#win-wine-grid .win-wine-card');
  filterBtns.forEach(btn=>{
    btn.addEventListener('click',()=>{
      filterBtns.forEach(b=>{b.classList.remove('active');b.setAttribute('aria-pressed','false');});
      btn.classList.add('active');btn.setAttribute('aria-pressed','true');
      const f=btn.dataset.filter;
      wineCards.forEach(c=>c.classList.toggle('hidden',f!=='all'&&c.dataset.cat!==f));
    });
    btn.setAttribute('aria-pressed',btn.classList.contains('active')?'true':'false');
  });

  /* form */
  const form=document.querySelector('.win-form');
  if(form){
    form.addEventListener('submit',function(e){
      e.preventDefault();
      document.getElementById('win-submit-btn').style.display='none';
      document.getElementById('win-success').style.display='block';
    });
  }
})();
</script>
</div><!-- .win-page -->
<?php get_footer(); ?>
