<?php
/**
 * Template Name: Yoga Instructor
 *
 * Premium landing page for a yoga instructor / holistic wellness studio.
 * CSS art: animated mandala with rotating petal rings, floating chakra
 * orbs, yoga pose silhouette, sunrise gradient, and drifting lotus petals.
 *
 * Namespace   : --yo-*
 * Fonts       : Josefin Sans (headings) + Hind (body) via Google Fonts
 * Palette     : terracotta #C4622D / deep indigo #2B2D6B / saffron #F5A623
 *               ivory cream #FBF6EE / sage mist #7EA88F / blush #E8C4B8
 * Keyframes   : yo-mandala-spin, yo-petal-drift, yo-chakra-pulse,
 *               yo-sunrise, yo-float, yo-breath, yo-slide-up, yo-fade-in
 *
 * @package ThemeFlex
 */
srand( crc32( get_the_permalink() ) );

/* ── instructor info ─────────────────────────────────────── */
$yo_instructor  = 'Maya Sutton';
$yo_credential  = 'RYT-500 · Yin Yoga Teacher · Mindfulness Coach';
$yo_years       = 12;
$yo_location    = 'Bristol & Online';
$yo_phone       = '0117 456 8921';
$yo_email       = 'namaste@mayayoga.co.uk';

/* ── chakra data ─────────────────────────────────────────── */
$yo_chakras = [
    [ 'name' => 'Crown',    'colour' => '#9B59B6', 'delay' => 0.0 ],
    [ 'name' => 'Third Eye','colour' => '#5B6BC0', 'delay' => 0.4 ],
    [ 'name' => 'Throat',   'colour' => '#3498DB', 'delay' => 0.8 ],
    [ 'name' => 'Heart',    'colour' => '#27AE60', 'delay' => 1.2 ],
    [ 'name' => 'Solar',    'colour' => '#F39C12', 'delay' => 1.6 ],
    [ 'name' => 'Sacral',   'colour' => '#E67E22', 'delay' => 2.0 ],
    [ 'name' => 'Root',     'colour' => '#E74C3C', 'delay' => 2.4 ],
];

/* ── mandala rings ───────────────────────────────────────── */
$yo_rings = [
    [ 'r' => 160, 'petals' => 12, 'dir' => 1,  'speed' => 40 ],
    [ 'r' => 120, 'petals' => 8,  'dir' => -1, 'speed' => 30 ],
    [ 'r' => 80,  'petals' => 6,  'dir' => 1,  'speed' => 20 ],
];

/* ── floating lotus petals ───────────────────────────────── */
$yo_petals = [];
for ( $i = 0; $i < 14; $i++ ) {
    $yo_petals[] = [
        'left'     => rand( 0, 100 ),
        'delay'    => round( rand( 0, 9000 ) / 1000, 2 ),
        'duration' => round( rand( 8000, 18000 ) / 1000, 2 ),
        'size'     => rand( 12, 22 ),
        'hue'      => rand( 0, 40 ),
        'rotate'   => rand( 0, 360 ),
    ];
}

/* ── class types ─────────────────────────────────────────── */
$yo_classes = [
    [ 'icon' => '🌅', 'name' => 'Sunrise Hatha',      'desc' => 'Wake your body gently with this accessible morning flow. Perfect for all levels to start the day with clarity.' ],
    [ 'icon' => '🌊', 'name' => 'Vinyasa Flow',        'desc' => 'A dynamic breath-to-movement practice linking postures in a creative, energising sequence.' ],
    [ 'icon' => '🌙', 'name' => 'Yin & Restorative',   'desc' => 'Long-held poses targeting deep connective tissue. Deeply calming for the nervous system.' ],
    [ 'icon' => '🔥', 'name' => 'Power Yoga',          'desc' => 'Strength-building sequences using bodyweight and breath. A full-body challenge for those who want to sweat.' ],
    [ 'icon' => '🤰', 'name' => 'Pregnancy Yoga',      'desc' => 'Safe, supportive practice for every trimester — relieving back pain, improving sleep and preparing for birth.' ],
    [ 'icon' => '🧘', 'name' => 'Meditation & Pranayama', 'desc' => 'Dedicated breathwork and sitting practice to cultivate stillness and a deeper relationship with the mind.' ],
    [ 'icon' => '🌿', 'name' => 'Yoga for Stress',     'desc' => 'Specifically designed to calm an anxious nervous system using gentle movement, breathwork and yoga nidra.' ],
    [ 'icon' => '👶', 'name' => 'Mum & Baby Yoga',     'desc' => 'Post-natal recovery and bonding classes for new mothers and their babies from 6 weeks post-partum.' ],
];

/* ── benefits ────────────────────────────────────────────── */
$yo_benefits = [
    [ 'icon' => '💪', 'title' => 'Strength & Flexibility', 'desc' => 'Consistent practice builds functional strength while improving joint mobility and reducing injury risk.' ],
    [ 'icon' => '🧠', 'title' => 'Mental Clarity',         'desc' => 'The breath-body connection quiets mental chatter, sharpens focus and reduces anxiety and depression.' ],
    [ 'icon' => '😴', 'title' => 'Better Sleep',           'desc' => 'Evening yin and restorative practices regulate the nervous system for deeper, more restful sleep.' ],
    [ 'icon' => '❤️', 'title' => 'Heart Health',           'desc' => 'Regular yoga practice lowers blood pressure, reduces cortisol and supports cardiovascular health.' ],
    [ 'icon' => '🌬️', 'title' => 'Breath Capacity',        'desc' => 'Pranayama training expands lung capacity and teaches respiratory efficiency under stress.' ],
    [ 'icon' => '🤝', 'title' => 'Community',              'desc' => 'Our classes create real connection — many students form friendships and accountability partnerships.' ],
];

/* ── schedule ────────────────────────────────────────────── */
$yo_schedule = [
    [ 'day' => 'Mon', 'time' => '07:00', 'class' => 'Sunrise Hatha',      'level' => 'All', 'format' => 'In-Person' ],
    [ 'day' => 'Tue', 'time' => '18:30', 'class' => 'Vinyasa Flow',        'level' => 'Int/Adv', 'format' => 'Online' ],
    [ 'day' => 'Wed', 'time' => '10:00', 'class' => 'Yoga for Stress',     'level' => 'All', 'format' => 'In-Person' ],
    [ 'day' => 'Wed', 'time' => '19:00', 'class' => 'Power Yoga',          'level' => 'Int/Adv', 'format' => 'Online' ],
    [ 'day' => 'Thu', 'time' => '11:00', 'class' => 'Pregnancy Yoga',      'level' => 'All', 'format' => 'In-Person' ],
    [ 'day' => 'Fri', 'time' => '07:00', 'class' => 'Sunrise Hatha',       'level' => 'All', 'format' => 'Online' ],
    [ 'day' => 'Sat', 'time' => '09:00', 'class' => 'Vinyasa Flow',        'level' => 'All', 'format' => 'In-Person' ],
    [ 'day' => 'Sat', 'time' => '17:00', 'class' => 'Yin & Restorative',   'level' => 'All', 'format' => 'In-Person' ],
    [ 'day' => 'Sun', 'time' => '10:30', 'class' => 'Meditation & Pranayama','level' => 'All', 'format' => 'Online' ],
];

/* ── testimonials ────────────────────────────────────────── */
$yo_testimonials = [
    [ 'name' => 'Helen R.',  'stars' => 5, 'text' => 'Maya's Yin class has completely transformed how I manage stress. I sleep better, feel calmer and am genuinely happier.' ],
    [ 'name' => 'Tom K.',    'stars' => 5, 'text' => 'I was a complete beginner and Maya made me feel welcome from day one. Eight months in and I practice every day.' ],
    [ 'name' => 'Priya S.',  'stars' => 5, 'text' => 'The pregnancy yoga classes kept me feeling strong and connected throughout. Maya's knowledge and warmth are exceptional.' ],
    [ 'name' => 'James L.',  'stars' => 5, 'text' => 'Power Yoga has replaced my gym sessions entirely — I'm stronger, more mobile and far less prone to injury.' ],
    [ 'name' => 'Anna W.',   'stars' => 5, 'text' => 'Maya's online classes are as good as being in the room. The quality of instruction, cues and energy is extraordinary.' ],
    [ 'name' => 'Chloe B.',  'stars' => 5, 'text' => 'I've tried many teachers and none compare. Maya reads the room, adjusts the practice and always leaves us feeling whole.' ],
];

/* ── packages ────────────────────────────────────────────── */
$yo_packages = [
    [
        'name'     => 'Drop-In Class',
        'price'    => '£14',
        'unit'     => 'per session',
        'featured' => false,
        'colour'   => '#7EA88F',
        'items'    => [
            'Access to any single class',
            'Online or in-person',
            'No commitment required',
            'Full props & mat provided (in-person)',
        ],
    ],
    [
        'name'     => 'Monthly Unlimited',
        'price'    => '£55',
        'unit'     => 'per month',
        'featured' => true,
        'colour'   => '#2B2D6B',
        'items'    => [
            'Unlimited weekly classes',
            'Online + in-person access',
            'Priority booking on all sessions',
            'Recorded class library access',
            'Monthly live Q&A with Maya',
            'Community app access',
        ],
    ],
    [
        'name'     => '1-to-1 Private',
        'price'    => '£80',
        'unit'     => 'per hour',
        'featured' => false,
        'colour'   => '#C4622D',
        'items'    => [
            'Personalised session tailored to you',
            'Therapeutic & remedial options',
            'Goal-setting & home practice plan',
            'Online or home visits (Bristol)',
            'Suitable for injuries & pregnancy',
        ],
    ],
];

/* ── FAQ ─────────────────────────────────────────────────── */
$yo_faqs = [
    [ 'q' => 'Do I need to be flexible to start yoga?',
      'a' => 'Absolutely not — inflexibility is a great reason to start yoga, not a barrier. We meet your body where it is and work from there. Beginners are always welcome.' ],
    [ 'q' => 'What do I need to bring to an in-person class?',
      'a' => 'Comfortable clothes you can move in. Mats, blocks, straps and bolsters are all provided. You're welcome to bring your own mat if preferred.' ],
    [ 'q' => 'Is yoga safe during pregnancy?',
      'a' => 'Yes, with a qualified pregnancy yoga teacher. My classes are designed specifically for the second and third trimester with modifications for every stage.' ],
    [ 'q' => 'How do online classes work?',
      'a' => 'Online classes run live via Zoom so you get the same real-time guidance and energy as an in-person session. All you need is a device, a mat and enough space to lie down.' ],
    [ 'q' => 'Can I cancel or pause my membership?',
      'a' => 'Yes — memberships can be paused for up to 8 weeks (e.g. for injury or holiday) and cancelled with 30 days' notice. No admin fees, no fuss.' ],
    [ 'q' => 'Do you offer corporate wellness sessions?',
      'a' => 'Yes — I work with companies to deliver lunchtime or team sessions online or at your office. Packages start from £120 per session for up to 20 participants.' ],
];
?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&family=Hind:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════
   YOGA INSTRUCTOR  –  --yo-* token namespace
═══════════════════════════════════════════════════════════ */
:root {
  --yo-terra:       #C4622D;
  --yo-terra-light: #D9835A;
  --yo-indigo:      #2B2D6B;
  --yo-indigo-light:#3E4090;
  --yo-saffron:     #F5A623;
  --yo-ivory:       #FBF6EE;
  --yo-sage:        #7EA88F;
  --yo-sage-dark:   #5C8A72;
  --yo-blush:       #E8C4B8;
  --yo-blush-dark:  #C49A88;
  --yo-grey:        #8A7A70;
  --yo-grey-light:  #C0B0A8;
  --yo-card-bg:     #FFFFFF;
  --yo-border:      rgba(196,98,45,0.12);
  --yo-font-head:   'Josefin Sans', sans-serif;
  --yo-font-body:   'Hind', sans-serif;
  --yo-radius:      14px;
  --yo-transition:  0.33s ease;
}

*,*::before,*::after { box-sizing:border-box; margin:0; padding:0; }
.yo-page { font-family:var(--yo-font-body); color:var(--yo-indigo); background:var(--yo-ivory); overflow-x:hidden; }
.yo-page a { color:var(--yo-sage-dark); text-decoration:none; }

/* ── keyframes ── */
@keyframes yo-mandala-spin-cw  { from{transform:rotate(0deg);} to{transform:rotate(360deg);} }
@keyframes yo-mandala-spin-ccw { from{transform:rotate(0deg);} to{transform:rotate(-360deg);} }
@keyframes yo-chakra-pulse {
  0%,100% { box-shadow:0 0 10px 4px var(--yo-ck-col,#fff); transform:translate(-50%,-50%) scale(1); }
  50%     { box-shadow:0 0 30px 14px var(--yo-ck-col,#fff); transform:translate(-50%,-50%) scale(1.15); }
}
@keyframes yo-petal-drift {
  0%   { transform:translateY(-40px) rotate(var(--yo-pr,0deg)); opacity:0; }
  10%  { opacity:0.7; }
  90%  { opacity:0.5; }
  100% { transform:translateY(calc(100vh + 60px)) rotate(calc(var(--yo-pr,0deg) + 220deg)); opacity:0; }
}
@keyframes yo-breath {
  0%,100% { transform:translate(-50%,-50%) scale(1); opacity:0.9; }
  50%     { transform:translate(-50%,-50%) scale(1.06); opacity:1; }
}
@keyframes yo-float {
  0%,100% { transform:translateY(0); }
  50%     { transform:translateY(-16px); }
}
@keyframes yo-slide-up { from{opacity:0;transform:translateY(40px);} to{opacity:1;transform:translateY(0);} }
@keyframes yo-fade-in  { from{opacity:0;} to{opacity:1;} }
@keyframes yo-sunrise  { from{opacity:0;transform:scaleX(0.6);} to{opacity:1;transform:scaleX(1);} }

/* ══ NAV ═════════════════════════════════════════════════ */
.yo-nav {
  position:fixed; top:0; left:0; width:100%; z-index:1000;
  background:rgba(43,45,107,0.94); backdrop-filter:blur(14px);
  border-bottom:1px solid rgba(245,166,35,0.2);
  display:flex; align-items:center; justify-content:space-between;
  padding:0 44px; height:68px;
}
.yo-nav__logo { font-family:var(--yo-font-head); font-size:1.5rem; font-weight:600; letter-spacing:0.12em; text-transform:uppercase; color:var(--yo-ivory); }
.yo-nav__logo span { color:var(--yo-saffron); }
.yo-nav__links { display:flex; gap:28px; list-style:none; }
.yo-nav__links a { color:rgba(251,246,238,0.8); font-size:0.88rem; font-weight:500; letter-spacing:0.06em; transition:color var(--yo-transition); text-transform:uppercase; }
.yo-nav__links a:hover { color:var(--yo-saffron); }
.yo-nav__cta { background:var(--yo-terra); color:#fff; padding:10px 24px; border-radius:30px; font-size:0.85rem; font-weight:600; transition:all var(--yo-transition); letter-spacing:0.06em; }
.yo-nav__cta:hover { background:var(--yo-terra-light); color:#fff; }

/* ══ HERO ════════════════════════════════════════════════ */
.yo-hero {
  min-height:100vh; display:flex; align-items:center;
  background:linear-gradient(160deg, #1A1C55 0%, #2B2D6B 40%, #3A2860 70%, #C4622D 100%);
  position:relative; overflow:hidden; padding:100px 44px 60px;
}
/* sunrise arc */
.yo-hero::after {
  content:''; position:absolute; bottom:-40px; left:50%; transform:translateX(-50%);
  width:900px; height:450px; border-radius:50% 50% 0 0;
  background:radial-gradient(ellipse at 50% 100%, rgba(245,166,35,0.25) 0%, transparent 70%);
  pointer-events:none;
}
.yo-hero__petals { position:absolute; inset:0; pointer-events:none; z-index:1; }
.yo-petal {
  position:absolute; top:-30px;
  border-radius:50% 0 50% 0;
  background:radial-gradient(circle, rgba(232,196,184,0.85) 0%, rgba(232,196,184,0.2) 100%);
  animation:yo-petal-drift var(--yo-pd,12s) var(--yo-pdelay,0s) infinite linear;
  --yo-pr:var(--yo-prot,0deg);
}
.yo-hero__inner { position:relative; z-index:2; display:grid; grid-template-columns:1fr 480px; gap:56px; align-items:center; max-width:1280px; margin:0 auto; width:100%; }

/* TEXT */
.yo-hero__text { animation:yo-slide-up 0.8s ease both; }
.yo-hero__badge { display:inline-flex; align-items:center; gap:8px; background:rgba(245,166,35,0.18); border:1px solid rgba(245,166,35,0.4); color:var(--yo-saffron); padding:6px 16px; border-radius:20px; font-size:0.75rem; font-weight:600; letter-spacing:0.1em; text-transform:uppercase; margin-bottom:24px; }
.yo-hero__eyebrow { font-family:var(--yo-font-head); font-size:1rem; color:var(--yo-blush); letter-spacing:0.08em; margin-bottom:12px; font-style:italic; }
.yo-hero__title { font-family:var(--yo-font-head); font-size:clamp(2.8rem,4.5vw,4.2rem); font-weight:700; color:var(--yo-ivory); line-height:1.12; margin-bottom:20px; letter-spacing:0.03em; text-transform:uppercase; }
.yo-hero__title em { color:var(--yo-saffron); font-style:italic; text-transform:none; }
.yo-hero__subtitle { font-size:1.05rem; color:rgba(251,246,238,0.8); line-height:1.78; max-width:480px; margin-bottom:36px; font-weight:300; }
.yo-hero__actions { display:flex; gap:16px; flex-wrap:wrap; margin-bottom:44px; }
.yo-btn-primary   { background:var(--yo-terra); color:#fff; padding:16px 36px; border-radius:30px; font-size:0.97rem; font-weight:600; transition:all var(--yo-transition); box-shadow:0 8px 28px rgba(196,98,45,0.4); letter-spacing:0.05em; }
.yo-btn-primary:hover { background:var(--yo-terra-light); color:#fff; transform:translateY(-2px); }
.yo-btn-secondary { border:1.5px solid rgba(251,246,238,0.35); color:var(--yo-ivory); padding:14px 32px; border-radius:30px; font-size:0.97rem; font-weight:500; transition:all var(--yo-transition); }
.yo-btn-secondary:hover { border-color:var(--yo-ivory); }
.yo-hero__trust { display:flex; gap:20px; flex-wrap:wrap; }
.yo-trust-item { display:flex; align-items:center; gap:7px; color:rgba(251,246,238,0.65); font-size:0.82rem; }
.yo-trust-item::before { content:'✿'; color:var(--yo-saffron); }

/* MANDALA SCENE */
.yo-mandala-wrap {
  width:480px; height:480px; position:relative; flex-shrink:0;
  animation:yo-fade-in 1.2s 0.5s ease both;
}
.yo-mandala-center {
  position:absolute; top:50%; left:50%; transform:translate(-50%,-50%);
  width:60px; height:60px; border-radius:50%;
  background:radial-gradient(circle, var(--yo-saffron) 0%, var(--yo-terra) 70%);
  animation:yo-breath 4s infinite ease-in-out;
  box-shadow:0 0 30px rgba(245,166,35,0.6);
  z-index:10;
}
.yo-mandala-ring {
  position:absolute; top:50%; left:50%;
  transform-origin:center center;
  border-radius:50%; border:1px solid rgba(251,246,238,0.15);
}
.yo-mandala-petal {
  position:absolute; top:50%; left:50%; transform-origin:50% 0;
  border-radius:50% 50% 0 0;
  background:rgba(232,196,184,0.3);
  border:1px solid rgba(232,196,184,0.4);
}

/* chakra orbs on body */
.yo-chakra {
  position:absolute; width:18px; height:18px; border-radius:50%;
  background:var(--yo-ck-col,#fff); opacity:0.9;
  transform:translate(-50%,-50%);
  animation:yo-chakra-pulse 3s var(--yo-ck-delay,0s) infinite ease-in-out;
  cursor:pointer; z-index:10;
}
.yo-chakra::after {
  content:attr(data-name); position:absolute; left:24px; top:50%; transform:translateY(-50%);
  background:rgba(43,45,107,0.9); color:var(--yo-ivory); padding:3px 8px; border-radius:6px;
  font-size:0.65rem; white-space:nowrap; opacity:0; pointer-events:none; transition:opacity 0.2s;
  font-family:var(--yo-font-head); letter-spacing:0.06em;
}
.yo-chakra:hover::after { opacity:1; }

/* yoga silhouette (lotus pose) */
.yo-pose { position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); z-index:5; }
.yo-pose-body    { width:50px; height:80px; background:rgba(43,45,107,0.7); border-radius:20px; position:relative; margin:0 auto; }
.yo-pose-head    { width:40px; height:44px; border-radius:50%; background:rgba(43,45,107,0.7); margin:0 auto -10px; }
.yo-pose-arms    { position:absolute; top:30px; left:50%; transform:translateX(-50%); width:130px; height:3px; background:rgba(43,45,107,0.7); border-radius:2px; }
.yo-pose-larm    { position:absolute; left:0; top:50%; transform:translateY(-50%); width:12px; height:12px; border-radius:50%; background:rgba(43,45,107,0.6); }
.yo-pose-rarm    { position:absolute; right:0; top:50%; transform:translateY(-50%); width:12px; height:12px; border-radius:50%; background:rgba(43,45,107,0.6); }
.yo-pose-crossed { position:absolute; bottom:-20px; left:50%; transform:translateX(-50%); width:80px; height:36px; background:rgba(43,45,107,0.7); border-radius:0 0 30px 30px; }

/* ══ COUNTERS ════════════════════════════════════════════ */
.yo-counters { background:var(--yo-indigo); padding:56px 44px; }
.yo-counters__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:2px; max-width:960px; margin:0 auto; }
.yo-counter-item { text-align:center; padding:36px 20px; background:rgba(255,255,255,0.04); border-radius:4px; }
.yo-counter-item:hover { background:rgba(245,166,35,0.08); }
.yo-counter-number { font-family:var(--yo-font-head); font-size:3rem; font-weight:700; color:var(--yo-ivory); display:flex; align-items:baseline; justify-content:center; gap:4px; }
.yo-counter-number .yo-suffix { font-size:1.8rem; color:var(--yo-saffron); }
.yo-counter-label { color:var(--yo-grey-light); font-size:0.82rem; margin-top:6px; letter-spacing:0.06em; text-transform:uppercase; font-family:var(--yo-font-head); }

/* ══ CLASSES ═════════════════════════════════════════════ */
.yo-classes { padding:100px 44px; background:var(--yo-ivory); }
.yo-section-header { text-align:center; margin-bottom:60px; }
.yo-eyebrow { font-family:var(--yo-font-head); font-style:italic; color:var(--yo-terra); font-size:1rem; letter-spacing:0.06em; margin-bottom:14px; }
.yo-section-title { font-family:var(--yo-font-head); font-size:clamp(1.9rem,3.5vw,2.8rem); color:var(--yo-indigo); margin-bottom:14px; font-weight:600; letter-spacing:0.04em; text-transform:uppercase; }
.yo-section-desc { color:var(--yo-grey); font-size:1rem; max-width:560px; margin:0 auto; line-height:1.78; }
.yo-classes__grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; max-width:1280px; margin:0 auto; }
.yo-class-card {
  background:var(--yo-card-bg); border:1px solid var(--yo-border); border-radius:var(--yo-radius);
  padding:28px 22px; transition:all var(--yo-transition); position:relative; overflow:hidden; text-align:center;
}
.yo-class-card::after {
  content:''; position:absolute; bottom:0; left:0; right:0; height:3px;
  background:linear-gradient(90deg, var(--yo-terra), var(--yo-saffron));
  transform:scaleX(0); transform-origin:left; transition:transform var(--yo-transition);
}
.yo-class-card:hover { transform:translateY(-6px); box-shadow:0 16px 44px rgba(43,45,107,0.1); border-color:rgba(196,98,45,0.25); }
.yo-class-card:hover::after { transform:scaleX(1); }
.yo-class-icon { font-size:2rem; margin-bottom:14px; }
.yo-class-name { font-family:var(--yo-font-head); font-size:1.05rem; color:var(--yo-indigo); margin-bottom:8px; font-weight:600; letter-spacing:0.04em; }
.yo-class-desc { color:var(--yo-grey); font-size:0.85rem; line-height:1.65; }

/* ══ BENEFITS ════════════════════════════════════════════ */
.yo-benefits { padding:80px 44px; background:#F0EAE2; }
.yo-benefits__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; max-width:1100px; margin:0 auto; }
.yo-benefit-card {
  background:var(--yo-card-bg); border-radius:var(--yo-radius); padding:28px 24px;
  border:1px solid var(--yo-border); display:flex; gap:16px; align-items:flex-start;
  transition:transform var(--yo-transition);
}
.yo-benefit-card:hover { transform:translateY(-4px); box-shadow:0 12px 36px rgba(43,45,107,0.08); }
.yo-benefit-icon { font-size:1.8rem; flex-shrink:0; }
.yo-benefit-title { font-family:var(--yo-font-head); font-size:1rem; color:var(--yo-indigo); margin-bottom:6px; font-weight:600; }
.yo-benefit-desc  { color:var(--yo-grey); font-size:0.85rem; line-height:1.65; }

/* ══ SCHEDULE ════════════════════════════════════════════ */
.yo-schedule { padding:80px 44px; background:var(--yo-ivory); }
.yo-schedule__table { max-width:900px; margin:0 auto; border-radius:var(--yo-radius); overflow:hidden; box-shadow:0 4px 24px rgba(43,45,107,0.08); }
.yo-schedule__table table { width:100%; border-collapse:collapse; }
.yo-schedule__table th { background:var(--yo-indigo); color:var(--yo-ivory); padding:14px 16px; text-align:left; font-family:var(--yo-font-head); font-size:0.78rem; letter-spacing:0.08em; text-transform:uppercase; }
.yo-schedule__table td { padding:13px 16px; border-bottom:1px solid var(--yo-border); font-size:0.88rem; color:var(--yo-indigo); }
.yo-schedule__table tr:last-child td { border-bottom:none; }
.yo-schedule__table tr:nth-child(even) td { background:rgba(43,45,107,0.03); }
.yo-schedule__table tr:hover td { background:rgba(196,98,45,0.04); }
.yo-format-badge {
  display:inline-block; padding:3px 10px; border-radius:10px; font-size:0.72rem; font-weight:600;
  letter-spacing:0.05em; font-family:var(--yo-font-head);
}
.yo-format-badge--online    { background:rgba(126,168,143,0.15); color:var(--yo-sage-dark); }
.yo-format-badge--inperson  { background:rgba(196,98,45,0.12); color:var(--yo-terra); }

/* ══ PACKAGES ════════════════════════════════════════════ */
.yo-packages { padding:100px 44px; background:#F0EAE2; }
.yo-packages__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:24px; max-width:1080px; margin:0 auto; align-items:start; }
.yo-package-card { border-radius:20px; overflow:hidden; background:var(--yo-card-bg); box-shadow:0 8px 36px rgba(43,45,107,0.1); transition:transform var(--yo-transition); }
.yo-package-card:hover { transform:translateY(-7px); }
.yo-package-card--featured { transform:scale(1.04); box-shadow:0 20px 60px rgba(43,45,107,0.18); }
.yo-package-card--featured:hover { transform:scale(1.04) translateY(-7px); }
.yo-package-header { padding:32px 28px; color:#fff; background:var(--yo-card-colour,var(--yo-indigo)); }
.yo-package-badge { display:inline-block; background:rgba(255,255,255,0.2); color:#fff; padding:4px 12px; border-radius:16px; font-size:0.7rem; font-weight:700; letter-spacing:0.08em; text-transform:uppercase; font-family:var(--yo-font-head); margin-bottom:14px; }
.yo-package-name  { font-family:var(--yo-font-head); font-size:1.5rem; font-weight:700; margin-bottom:8px; letter-spacing:0.04em; }
.yo-package-price { font-family:var(--yo-font-head); font-size:2.6rem; font-weight:300; }
.yo-package-unit  { font-size:0.8rem; opacity:0.75; margin-top:4px; font-family:var(--yo-font-head); }
.yo-package-body  { padding:24px 28px; }
.yo-package-features { list-style:none; margin-bottom:24px; }
.yo-package-features li { padding:9px 0; border-bottom:1px solid var(--yo-border); font-size:0.88rem; color:var(--yo-grey); display:flex; gap:10px; }
.yo-package-features li::before { content:'✿'; color:var(--yo-terra); flex-shrink:0; }
.yo-package-features li:last-child { border-bottom:none; }
.yo-package-btn {
  display:block; width:100%; padding:14px; border-radius:30px; text-align:center;
  font-family:var(--yo-font-head); font-weight:600; font-size:0.9rem; letter-spacing:0.04em;
  border:2px solid var(--yo-card-colour,var(--yo-indigo));
  color:var(--yo-card-colour,var(--yo-indigo)); background:transparent;
  cursor:pointer; transition:all var(--yo-transition);
}
.yo-package-btn:hover,
.yo-package-card--featured .yo-package-btn { background:var(--yo-card-colour,var(--yo-indigo)); color:#fff; }

/* ══ PROFILE ═════════════════════════════════════════════ */
.yo-profile { padding:100px 44px; background:var(--yo-ivory); }
.yo-profile__inner { max-width:1080px; margin:0 auto; display:grid; grid-template-columns:280px 1fr; gap:80px; align-items:center; }
.yo-profile__figure {
  width:210px; height:270px; background:linear-gradient(150deg, #3A2860 0%, #2B2D6B 100%);
  border-radius:50% 50% 40% 40%; margin:0 auto 24px; position:relative;
  box-shadow:0 16px 50px rgba(43,45,107,0.25);
}
.yo-profile__figure::before {
  content:''; position:absolute; top:-56px; left:50%; transform:translateX(-50%);
  width:78px; height:84px; border-radius:50%;
  background:linear-gradient(145deg,#F5DEB3 0%,#DEB887 100%);
}
.yo-profile__figure-hair {
  position:absolute; top:-72px; left:50%; transform:translateX(-50%);
  width:84px; height:50px; border-radius:50% 50% 0 0; background:#3A2A10;
}
.yo-profile__figure-wrap {
  position:absolute; inset:0; border-radius:50% 50% 40% 40%;
  background:rgba(255,255,255,0.1); border:1px solid rgba(245,166,35,0.2);
}
.yo-profile__figure-lotus {
  position:absolute; bottom:16px; left:50%; transform:translateX(-50%);
  font-size:2rem;
}
.yo-profile__cred {
  background:var(--yo-indigo); color:var(--yo-ivory); padding:18px 24px;
  border-radius:14px; text-align:center; box-shadow:0 8px 28px rgba(43,45,107,0.2);
}
.yo-profile__cred-name  { font-family:var(--yo-font-head); font-size:1.2rem; margin-bottom:6px; font-weight:600; letter-spacing:0.04em; }
.yo-profile__cred-title { font-size:0.78rem; color:var(--yo-saffron); font-family:var(--yo-font-head); letter-spacing:0.06em; }
.yo-profile__content h2 { font-family:var(--yo-font-head); font-size:2.2rem; color:var(--yo-indigo); margin-bottom:18px; font-weight:600; letter-spacing:0.04em; text-transform:uppercase; }
.yo-profile__content p { color:var(--yo-grey); line-height:1.8; margin-bottom:14px; font-size:0.96rem; }
.yo-quals { display:flex; flex-wrap:wrap; gap:10px; margin-top:24px; }
.yo-qual-badge { background:rgba(196,98,45,0.1); border:1px solid rgba(196,98,45,0.25); color:var(--yo-terra); padding:6px 14px; border-radius:20px; font-size:0.8rem; font-family:var(--yo-font-head); letter-spacing:0.05em; }

/* ══ TESTIMONIALS ════════════════════════════════════════ */
.yo-testimonials { padding:100px 44px; background:#F0EAE2; }
.yo-testimonials__grid { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; max-width:1200px; margin:0 auto; }
.yo-testimonial-card {
  background:var(--yo-card-bg); border-radius:var(--yo-radius); padding:28px;
  box-shadow:0 4px 18px rgba(43,45,107,0.06); border-top:4px solid var(--yo-terra);
  transition:transform var(--yo-transition);
}
.yo-testimonial-card:hover { transform:translateY(-4px); }
.yo-stars { color:var(--yo-saffron); font-size:0.95rem; margin-bottom:14px; letter-spacing:2px; }
.yo-testimonial-text { color:var(--yo-indigo); font-size:0.92rem; line-height:1.75; font-style:italic; font-family:var(--yo-font-head); margin-bottom:16px; font-weight:300; }
.yo-testimonial-name { color:var(--yo-terra); font-weight:600; font-size:0.82rem; font-family:var(--yo-font-head); letter-spacing:0.06em; }

/* ══ FAQ ═════════════════════════════════════════════════ */
.yo-faq { padding:100px 44px; background:var(--yo-ivory); }
.yo-faq__list { max-width:760px; margin:0 auto; }
.yo-faq-item { border-bottom:1px solid var(--yo-border); }
.yo-faq-q {
  width:100%; text-align:left; background:none; border:none; cursor:pointer;
  padding:20px 0; display:flex; justify-content:space-between; align-items:center;
  font-family:var(--yo-font-head); font-size:1rem; color:var(--yo-indigo); font-weight:600; gap:16px; letter-spacing:0.03em;
}
.yo-faq-q svg { flex-shrink:0; color:var(--yo-terra); transition:transform 0.3s; }
.yo-faq-item.open .yo-faq-q svg { transform:rotate(45deg); }
.yo-faq-a { max-height:0; overflow:hidden; transition:max-height 0.4s ease; }
.yo-faq-a-inner { padding:0 0 18px; color:var(--yo-grey); line-height:1.8; font-size:0.92rem; }
.yo-faq-item.open .yo-faq-a { max-height:250px; }

/* ══ BOOKING ═════════════════════════════════════════════ */
.yo-booking { padding:100px 44px; background:linear-gradient(160deg, var(--yo-indigo) 0%, #1A1C55 100%); }
.yo-booking__inner { max-width:840px; margin:0 auto; }
.yo-booking .yo-section-title { color:var(--yo-ivory); }
.yo-booking .yo-eyebrow { color:var(--yo-saffron); }
.yo-booking .yo-section-desc { color:rgba(251,246,238,0.7); }
.yo-booking-form {
  background:rgba(255,255,255,0.06); border:1px solid rgba(245,166,35,0.2);
  border-radius:20px; padding:44px; backdrop-filter:blur(10px); margin-top:44px;
}
.yo-form-grid  { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
.yo-form-full  { grid-column:1/-1; }
.yo-form-group { display:flex; flex-direction:column; gap:8px; }
.yo-form-label { color:rgba(251,246,238,0.6); font-size:0.75rem; font-weight:600; letter-spacing:0.08em; text-transform:uppercase; font-family:var(--yo-font-head); }
.yo-form-input, .yo-form-select, .yo-form-textarea {
  background:rgba(255,255,255,0.07); border:1px solid rgba(245,166,35,0.2);
  border-radius:8px; padding:13px 16px; color:var(--yo-ivory);
  font-family:var(--yo-font-body); font-size:0.93rem;
  transition:border-color var(--yo-transition); width:100%;
}
.yo-form-input::placeholder, .yo-form-textarea::placeholder { color:rgba(251,246,238,0.3); }
.yo-form-input:focus, .yo-form-select:focus, .yo-form-textarea:focus { outline:none; border-color:var(--yo-saffron); }
.yo-form-select option { background:var(--yo-indigo); }
.yo-form-textarea { resize:vertical; min-height:90px; }
.yo-form-privacy { color:rgba(251,246,238,0.45); font-size:0.76rem; line-height:1.65; }
.yo-form-privacy a { color:var(--yo-saffron); }
.yo-form-submit {
  background:var(--yo-terra); color:#fff; border:none;
  padding:18px 52px; border-radius:30px; font-size:1rem; font-weight:700;
  font-family:var(--yo-font-head); letter-spacing:0.06em; cursor:pointer;
  transition:all var(--yo-transition); box-shadow:0 8px 28px rgba(196,98,45,0.4);
}
.yo-form-submit:hover { background:var(--yo-terra-light); transform:translateY(-2px); }
.yo-form-message { padding:14px; border-radius:8px; margin-bottom:18px; font-size:0.88rem; display:none; }
.yo-form-message.success { background:rgba(126,168,143,0.2); border:1px solid var(--yo-sage); color:var(--yo-sage-dark); display:block; }
.yo-form-message.error   { background:rgba(196,98,45,0.15); border:1px solid var(--yo-terra); color:var(--yo-terra-light); display:block; }

/* ══ FOOTER ══════════════════════════════════════════════ */
.yo-footer { background:var(--yo-indigo); border-top:1px solid rgba(245,166,35,0.15); padding:28px 44px; text-align:center; color:var(--yo-grey-light); font-size:0.8rem; font-family:var(--yo-font-head); line-height:1.9; letter-spacing:0.04em; }
.yo-footer a { color:var(--yo-saffron); }

/* ══ RESPONSIVE ══════════════════════════════════════════ */
@media (max-width:1100px) {
  .yo-classes__grid { grid-template-columns:repeat(2,1fr); }
  .yo-hero__inner { grid-template-columns:1fr; }
  .yo-mandala-wrap { display:none; }
  .yo-profile__inner { grid-template-columns:1fr; text-align:center; }
  .yo-benefits__grid { grid-template-columns:repeat(2,1fr); }
}
@media (max-width:768px) {
  .yo-nav__links { display:none; }
  .yo-counters__grid { grid-template-columns:repeat(2,1fr); }
  .yo-packages__grid, .yo-testimonials__grid { grid-template-columns:1fr; }
  .yo-package-card--featured { transform:none; }
  .yo-form-grid { grid-template-columns:1fr; }
  .yo-classes__grid, .yo-benefits__grid { grid-template-columns:1fr; }
}
</style>
<?php get_header(); ?>
<div class="yo-page">
>
<?php wp_body_open(); ?>

<!-- NAV -->
<nav class="yo-nav" role="navigation" aria-label="Main navigation">
  <div class="yo-nav__logo">Maya<span>✿</span>Yoga</div>
  <ul class="yo-nav__links">
    <li><a href="#classes">Classes</a></li>
    <li><a href="#schedule">Schedule</a></li>
    <li><a href="#packages">Pricing</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#booking">Book</a></li>
  </ul>
  <a href="#booking" class="yo-nav__cta">Book a Class</a>
</nav>

<!-- HERO -->
<section class="yo-hero" aria-label="Hero">
  <!-- falling petals -->
  <div class="yo-hero__petals" aria-hidden="true">
    <?php foreach ($yo_petals as $p) : ?>
    <div class="yo-petal" style="
      left:<?php echo $p['left']; ?>%;
      width:<?php echo $p['size']; ?>px;
      height:<?php echo $p['size']; ?>px;
      --yo-pd:<?php echo $p['duration']; ?>s;
      --yo-pdelay:<?php echo $p['delay']; ?>s;
      --yo-prot:<?php echo $p['rotate']; ?>deg;
    "></div>
    <?php endforeach; ?>
  </div>

  <div class="yo-hero__inner">
    <!-- TEXT -->
    <div class="yo-hero__text">
      <div class="yo-hero__badge">✿ RYT-500 Certified · <?php echo esc_html($yo_location); ?></div>
      <p class="yo-hero__eyebrow">Yoga · Mindfulness · Wellbeing</p>
      <h1 class="yo-hero__title">
        Find Your<br>
        Inner <em>Balance.</em>
      </h1>
      <p class="yo-hero__subtitle">
        Expert-led yoga classes for every body, every level and every goal.
        Whether you're recovering from stress, building strength or simply
        searching for stillness — <?php echo esc_html($yo_instructor); ?> will guide you home.
      </p>
      <div class="yo-hero__actions">
        <a href="#booking" class="yo-btn-primary">Join a Class →</a>
        <a href="#schedule" class="yo-btn-secondary">View Schedule</a>
      </div>
      <div class="yo-hero__trust">
        <span class="yo-trust-item">All Levels Welcome</span>
        <span class="yo-trust-item">Online &amp; In-Person</span>
        <span class="yo-trust-item">Free Trial Class</span>
        <span class="yo-trust-item">Pregnancy Specialist</span>
      </div>
    </div>

    <!-- MANDALA / CHAKRA SCENE -->
    <div class="yo-mandala-wrap" aria-hidden="true">
      <!-- rotating rings -->
      <?php foreach ($yo_rings as $ri => $ring) :
        $dir = $ring['dir'] === 1 ? 'yo-mandala-spin-cw' : 'yo-mandala-spin-ccw';
        $size = $ring['r'] * 2;
        $half = $ring['r'];
        $petal_w = round($ring['r'] * 0.35);
        $petal_h = round($ring['r'] * 0.55);
      ?>
      <div class="yo-mandala-ring" style="
        width:<?php echo $size; ?>px; height:<?php echo $size; ?>px;
        margin-left:-<?php echo $half; ?>px; margin-top:-<?php echo $half; ?>px;
        animation:<?php echo $dir; ?> <?php echo $ring['speed']; ?>s linear infinite;
      ">
        <?php for ($pi = 0; $pi < $ring['petals']; $pi++) :
          $angle = ($pi / $ring['petals']) * 360;
        ?>
        <div class="yo-mandala-petal" style="
          width:<?php echo $petal_w; ?>px;
          height:<?php echo $petal_h; ?>px;
          margin-left:-<?php echo round($petal_w/2); ?>px;
          margin-top:-<?php echo $half; ?>px;
          transform:rotate(<?php echo $angle; ?>deg) translateY(-<?php echo round($half*0.1); ?>px);
          transform-origin:50% <?php echo $half; ?>px;
          opacity:<?php echo round(0.2 + $ri * 0.05, 2); ?>;
        "></div>
        <?php endfor; ?>
      </div>
      <?php endforeach; ?>

      <!-- lotus pose figure -->
      <div class="yo-pose">
        <div class="yo-pose-head"></div>
        <div class="yo-pose-body">
          <div class="yo-pose-arms">
            <div class="yo-pose-larm"></div>
            <div class="yo-pose-rarm"></div>
          </div>
        </div>
        <div class="yo-pose-crossed"></div>
      </div>

      <!-- chakra orbs -->
      <?php
      $yo_chakra_positions = [
        ['x'=>50,'y'=>15],['x'=>50,'y'=>23],['x'=>50,'y'=>32],
        ['x'=>50,'y'=>42],['x'=>50,'y'=>54],['x'=>50,'y'=>64],['x'=>50,'y'=>74],
      ];
      foreach ($yo_chakras as $ci => $ch) :
        $pos = $yo_chakra_positions[$ci];
      ?>
      <div class="yo-chakra" style="
        left:<?php echo $pos['x']; ?>%;
        top:<?php echo $pos['y']; ?>%;
        --yo-ck-col:<?php echo $ch['colour']; ?>;
        --yo-ck-delay:<?php echo $ch['delay']; ?>s;
        background:<?php echo $ch['colour']; ?>;
      " data-name="<?php echo esc_attr($ch['name']); ?> Chakra"
         title="<?php echo esc_attr($ch['name']); ?> Chakra"></div>
      <?php endforeach; ?>

      <!-- center -->
      <div class="yo-mandala-center"></div>
    </div>
  </div>
</section>

<!-- COUNTERS -->
<section class="yo-counters" aria-label="Statistics">
  <div class="yo-counters__grid">
    <div class="yo-counter-item">
      <div class="yo-counter-number"><span class="yo-count-val" data-target="<?php echo $yo_years; ?>"><?php echo $yo_years; ?></span><span class="yo-suffix">yrs</span></div>
      <div class="yo-counter-label">Teaching</div>
    </div>
    <div class="yo-counter-item">
      <div class="yo-counter-number"><span class="yo-count-val" data-target="2400">2,400</span><span class="yo-suffix">+</span></div>
      <div class="yo-counter-label">Students</div>
    </div>
    <div class="yo-counter-item">
      <div class="yo-counter-number"><span class="yo-count-val" data-target="4" data-float="1">4.9</span><span class="yo-suffix">★</span></div>
      <div class="yo-counter-label">Rating</div>
    </div>
    <div class="yo-counter-item">
      <div class="yo-counter-number"><span class="yo-count-val" data-target="9">9</span><span class="yo-suffix">cls/wk</span></div>
      <div class="yo-counter-label">Live Classes</div>
    </div>
  </div>
</section>

<!-- CLASSES -->
<section class="yo-classes" id="classes" aria-label="Class types">
  <div class="yo-section-header">
    <p class="yo-eyebrow">What's On</p>
    <h2 class="yo-section-title">Class Types</h2>
    <p class="yo-section-desc">Nine live classes each week — from gentle beginners' flows to challenging power sequences. Something for everyone.</p>
  </div>
  <div class="yo-classes__grid">
    <?php foreach ($yo_classes as $cls) : ?>
    <div class="yo-class-card">
      <div class="yo-class-icon" aria-hidden="true"><?php echo $cls['icon']; ?></div>
      <h3 class="yo-class-name"><?php echo esc_html($cls['name']); ?></h3>
      <p class="yo-class-desc"><?php echo esc_html($cls['desc']); ?></p>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BENEFITS -->
<section class="yo-benefits" aria-label="Benefits of yoga">
  <div class="yo-section-header">
    <p class="yo-eyebrow">Why Yoga Works</p>
    <h2 class="yo-section-title">The Benefits</h2>
    <p class="yo-section-desc">Science-backed, experience-proven — here's what consistent yoga practice does for your body and mind.</p>
  </div>
  <div class="yo-benefits__grid">
    <?php foreach ($yo_benefits as $b) : ?>
    <div class="yo-benefit-card">
      <div class="yo-benefit-icon" aria-hidden="true"><?php echo $b['icon']; ?></div>
      <div>
        <h3 class="yo-benefit-title"><?php echo esc_html($b['title']); ?></h3>
        <p class="yo-benefit-desc"><?php echo esc_html($b['desc']); ?></p>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- SCHEDULE -->
<section class="yo-schedule" id="schedule" aria-label="Class schedule">
  <div class="yo-section-header">
    <p class="yo-eyebrow">Weekly Timetable</p>
    <h2 class="yo-section-title">Class Schedule</h2>
    <p class="yo-section-desc">All times are UK (GMT/BST). Online classes can be joined from anywhere in the world.</p>
  </div>
  <div class="yo-schedule__table">
    <table>
      <thead>
        <tr>
          <th>Day</th>
          <th>Time</th>
          <th>Class</th>
          <th>Level</th>
          <th>Format</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($yo_schedule as $row) : ?>
        <tr>
          <td><strong><?php echo esc_html($row['day']); ?></strong></td>
          <td><?php echo esc_html($row['time']); ?></td>
          <td><?php echo esc_html($row['class']); ?></td>
          <td><?php echo esc_html($row['level']); ?></td>
          <td>
            <span class="yo-format-badge yo-format-badge--<?php echo $row['format'] === 'Online' ? 'online' : 'inperson'; ?>">
              <?php echo esc_html($row['format']); ?>
            </span>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<!-- PACKAGES -->
<section class="yo-packages" id="packages" aria-label="Membership packages">
  <div class="yo-section-header">
    <p class="yo-eyebrow">Invest in Yourself</p>
    <h2 class="yo-section-title">Pricing</h2>
    <p class="yo-section-desc">Flexible options for every budget and commitment level. First class always free.</p>
  </div>
  <div class="yo-packages__grid">
    <?php foreach ($yo_packages as $pkg) :
      $is_feat = $pkg['featured'];
    ?>
    <div class="yo-package-card<?php echo $is_feat ? ' yo-package-card--featured' : ''; ?>"
         style="--yo-card-colour:<?php echo esc_attr($pkg['colour']); ?>;">
      <div class="yo-package-header">
        <?php if ($is_feat) : ?><div class="yo-package-badge">Best Value</div><?php endif; ?>
        <div class="yo-package-name"><?php echo esc_html($pkg['name']); ?></div>
        <div class="yo-package-price"><?php echo esc_html($pkg['price']); ?></div>
        <div class="yo-package-unit"><?php echo esc_html($pkg['unit']); ?></div>
      </div>
      <div class="yo-package-body">
        <ul class="yo-package-features">
          <?php foreach ($pkg['items'] as $item) : ?>
          <li><?php echo esc_html($item); ?></li>
          <?php endforeach; ?>
        </ul>
        <a href="#booking" class="yo-package-btn">Get Started</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- PROFILE -->
<section class="yo-profile" id="about" aria-label="About Maya">
  <div class="yo-profile__inner">
    <div>
      <div class="yo-profile__figure" aria-label="Portrait illustration of <?php echo esc_attr($yo_instructor); ?>">
        <div class="yo-profile__figure-hair" aria-hidden="true"></div>
        <div class="yo-profile__figure-wrap" aria-hidden="true"></div>
        <div class="yo-profile__figure-lotus" aria-hidden="true">🪷</div>
      </div>
      <div class="yo-profile__cred">
        <div class="yo-profile__cred-name"><?php echo esc_html($yo_instructor); ?></div>
        <div class="yo-profile__cred-title"><?php echo esc_html($yo_credential); ?></div>
      </div>
    </div>
    <div class="yo-profile__content">
      <h2><?php echo $yo_years; ?> Years on the Mat</h2>
      <p>
        I came to yoga in my twenties during a period of burnout and anxiety, and within six months it had
        changed my life. That experience — of arriving broken and leaving whole — is the reason I became
        a teacher. I want every student to feel that possibility in their very first class.
      </p>
      <p>
        I completed my 200-hour training in Mysore, India, followed by a 300-hour advanced certification
        focusing on therapeutic yoga and pranayama. I'm also a Mindfulness-Based Stress Reduction (MBSR)
        facilitator and a specialist in yoga for anxiety and pre/post-natal wellbeing.
      </p>
      <p>
        My classes blend the traditional wisdom of yoga with a warm, accessible, thoroughly modern approach.
        No spiritual jargon, no expectations — just breath, movement, and genuine presence. Everyone belongs here.
      </p>
      <div class="yo-quals">
        <span class="yo-qual-badge">RYT-500 Registered</span>
        <span class="yo-qual-badge">Yin Yoga Teacher</span>
        <span class="yo-qual-badge">MBSR Facilitator</span>
        <span class="yo-qual-badge">Pregnancy Yoga Cert.</span>
        <span class="yo-qual-badge">Therapeutic Yoga</span>
        <span class="yo-qual-badge">DBS Checked</span>
        <span class="yo-qual-badge">First Aid Cert.</span>
      </div>
    </div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="yo-testimonials" id="testimonials" aria-label="Student reviews">
  <div class="yo-section-header">
    <p class="yo-eyebrow">Student Stories</p>
    <h2 class="yo-section-title">What Students Say</h2>
    <p class="yo-section-desc">The practice speaks for itself — here's how yoga has changed lives in our community.</p>
  </div>
  <div class="yo-testimonials__grid">
    <?php foreach ($yo_testimonials as $t) : ?>
    <div class="yo-testimonial-card">
      <div class="yo-stars" aria-label="<?php echo (int)$t['stars']; ?> stars"><?php echo str_repeat('★',(int)$t['stars']); ?></div>
      <p class="yo-testimonial-text">"<?php echo esc_html($t['text']); ?>"</p>
      <div class="yo-testimonial-name">— <?php echo esc_html($t['name']); ?></div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- FAQ -->
<section class="yo-faq" id="faq" aria-label="FAQ">
  <div class="yo-section-header">
    <p class="yo-eyebrow">Questions</p>
    <h2 class="yo-section-title">Frequently Asked</h2>
  </div>
  <div class="yo-faq__list" role="list">
    <?php foreach ($yo_faqs as $fi => $faq) : ?>
    <div class="yo-faq-item" role="listitem">
      <button class="yo-faq-q" aria-expanded="false" aria-controls="yo-faq-a-<?php echo $fi; ?>">
        <?php echo esc_html($faq['q']); ?>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
      </button>
      <div class="yo-faq-a" id="yo-faq-a-<?php echo $fi; ?>" role="region">
        <div class="yo-faq-a-inner"><?php echo esc_html($faq['a']); ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BOOKING -->
<section class="yo-booking" id="booking" aria-label="Book a class">
  <div class="yo-booking__inner">
    <div class="yo-section-header">
      <p class="yo-eyebrow">Begin Your Practice</p>
      <h2 class="yo-section-title">Book a Class</h2>
      <p class="yo-section-desc">Your first class is always free. Fill in the form and I'll confirm your spot within a few hours.</p>
    </div>
    <div class="yo-booking-form">
      <div class="yo-form-message" id="yo-form-msg" role="alert" aria-live="polite"></div>
      <form id="yo-booking-form" novalidate>
        <?php wp_nonce_field('tf_yo_booking','tf_yo_nonce'); ?>
        <div class="yo-form-grid">
          <div class="yo-form-group">
            <label class="yo-form-label" for="yo-name">Your Name *</label>
            <input class="yo-form-input" type="text" id="yo-name" name="yo_name" placeholder="Full name" required autocomplete="name">
          </div>
          <div class="yo-form-group">
            <label class="yo-form-label" for="yo-email">Email Address *</label>
            <input class="yo-form-input" type="email" id="yo-email" name="yo_email" placeholder="you@email.com" required autocomplete="email">
          </div>
          <div class="yo-form-group">
            <label class="yo-form-label" for="yo-phone">Phone</label>
            <input class="yo-form-input" type="tel" id="yo-phone" name="yo_phone" placeholder="07700 900 000" autocomplete="tel">
          </div>
          <div class="yo-form-group">
            <label class="yo-form-label" for="yo-class">Class Type *</label>
            <select class="yo-form-select" id="yo-class" name="yo_class" required>
              <option value="">Select class…</option>
              <?php foreach ($yo_classes as $cls) : ?>
              <option value="<?php echo esc_attr($cls['name']); ?>"><?php echo esc_html($cls['name']); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="yo-form-group">
            <label class="yo-form-label" for="yo-level">Your Experience</label>
            <select class="yo-form-select" id="yo-level" name="yo_level">
              <option value="">Select level…</option>
              <option value="complete-beginner">Complete Beginner</option>
              <option value="some-experience">Some Experience (under 1 year)</option>
              <option value="regular">Regular Practitioner (1–3 years)</option>
              <option value="experienced">Experienced (3+ years)</option>
            </select>
          </div>
          <div class="yo-form-group">
            <label class="yo-form-label" for="yo-format">Format Preference</label>
            <select class="yo-form-select" id="yo-format" name="yo_format">
              <option value="online">Online (Zoom)</option>
              <option value="inperson">In-Person (Bristol)</option>
              <option value="either">Either works for me</option>
            </select>
          </div>
          <div class="yo-form-group yo-form-full">
            <label class="yo-form-label" for="yo-notes">Health Notes</label>
            <textarea class="yo-form-textarea" id="yo-notes" name="yo_notes" placeholder="Any injuries, health conditions, pregnancy, or anything you'd like me to know about before your first session…" rows="3"></textarea>
          </div>
          <div class="yo-form-group yo-form-full">
            <p class="yo-form-privacy">Your information is kept in confidence. By submitting you agree to our <a href="/privacy-policy">Privacy Policy</a>.</p>
          </div>
          <div class="yo-form-full" style="text-align:center;">
            <button type="submit" class="yo-form-submit">Reserve My Spot ✿</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</section>

<!-- FOOTER -->
<footer class="yo-footer" role="contentinfo">
  <p>© <?php echo date('Y'); ?> <?php echo esc_html($yo_instructor); ?> — <?php echo esc_html($yo_credential); ?></p>
  <p><?php echo esc_html($yo_location); ?> · <a href="tel:<?php echo esc_attr(preg_replace('/\s+/','',$yo_phone)); ?>"><?php echo esc_html($yo_phone); ?></a> · <a href="mailto:<?php echo esc_attr($yo_email); ?>"><?php echo esc_html($yo_email); ?></a> · <a href="/privacy-policy">Privacy Policy</a></p>
</footer>

<script>
(function(){
  'use strict';

  /* ── animated counters ─────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  const cObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const isFloat = el.dataset.float === '1';
      const endVal = isFloat ? 4.9 : parseFloat(el.dataset.target);
      if (isNaN(endVal)) return;
      const dur = 1800; let start = null;
      const tick = ts => {
        if (!start) start = ts;
        const p = Math.min((ts - start) / dur, 1);
        const v = endVal * easeOut(p);
        el.textContent = isFloat ? v.toFixed(1) : Math.round(v).toLocaleString();
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
      cObs.unobserve(el);
    });
  }, {threshold:0.3});
  document.querySelectorAll('.yo-count-val').forEach(el => cObs.observe(el));

  /* ── FAQ ───────────────────────────────────────────── */
  document.querySelectorAll('.yo-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.yo-faq-item');
      const open = item.classList.contains('open');
      document.querySelectorAll('.yo-faq-item.open').forEach(i => {
        i.classList.remove('open');
        i.querySelector('.yo-faq-q').setAttribute('aria-expanded','false');
      });
      if (!open) { item.classList.add('open'); btn.setAttribute('aria-expanded','true'); }
    });
  });

  /* ── booking form ──────────────────────────────────── */
  const form = document.getElementById('yo-booking-form');
  const msg  = document.getElementById('yo-form-msg');
  if (form && msg) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      msg.className = 'yo-form-message';
      const name  = document.getElementById('yo-name').value.trim();
      const email = document.getElementById('yo-email').value.trim();
      const cls   = document.getElementById('yo-class').value;
      if (!name || !email || !cls) {
        msg.className = 'yo-form-message error';
        msg.textContent = 'Please complete all required fields.';
        msg.scrollIntoView({behavior:'smooth',block:'center'}); return;
      }
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        msg.className = 'yo-form-message error';
        msg.textContent = 'Please enter a valid email address.'; return;
      }
      const data = new FormData(form);
      data.append('action','tf_yo_booking');
      fetch('<?php echo esc_url(admin_url("admin-ajax.php")); ?>', {method:'POST',body:data})
        .catch(() => {})
        .finally(() => {
          msg.className = 'yo-form-message success';
          msg.textContent = 'Namaste! 🙏 Your spot is reserved. I\'ll confirm within a few hours. See you on the mat!';
          form.reset();
          msg.scrollIntoView({behavior:'smooth',block:'center'});
        });
    });
  }

  /* ── scroll reveal ─────────────────────────────────── */
  const revObs = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        revObs.unobserve(entry.target);
      }
    });
  }, {threshold:0.08});
  document.querySelectorAll('.yo-class-card,.yo-package-card,.yo-testimonial-card,.yo-benefit-card').forEach((el,i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(26px)';
    el.style.transition = `opacity 0.5s ${i*0.05}s ease, transform 0.5s ${i*0.05}s ease`;
    revObs.observe(el);
  });

})();
</script>

</body>
</html>
</div><!-- .yo-page -->
<?php get_footer(); ?>
