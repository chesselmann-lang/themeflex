<?php
/**
 * Template Name: TF — Yoga & Wellness Studio
 * Description:   Full-page premium template for yoga studios and wellness centres.
 *                CSS art dojo at dawn hero, animated chakra mandalas, class schedule,
 *                instructor cards, retreat packages, testimonials, FAQ, booking form.
 * Version:       1.0.0
 */
defined('ABSPATH') || exit;

/* ── Seeded randomness ───────────────────────────────────────────── */
srand(crc32(get_the_permalink()));

/* ── Mandala petal generator ─────────────────────────────────────── */
$mandala_colours = ['#b8957a','#d4a574','#c4856a','#e8c4a0','#9a7060','#d4c4b0','#a08060','#c8b090'];

/* ── PHP float helper ────────────────────────────────────────────── */
function yog_rand_float(float $min, float $max, int $dec = 1): string {
    $v = $min + (mt_rand() / mt_getrandmax()) * ($max - $min);
    return number_format($v, $dec, '.', '');
}

/* ── Lotus flowers for hero pond ─────────────────────────────────── */
$lotus_blooms = [];
for ($i = 0; $i < 5; $i++) {
    $lotus_blooms[] = [
        'left'  => 8 + $i * 18 + rand(-4, 4),
        'size'  => rand(28, 44),
        'col'   => ($i % 2 === 0) ? '#e8b4b8' : '#f8d4d8',
        'delay' => yog_rand_float(0, 3.0),
        'open'  => rand(60, 100),
    ];
}

/* ── Floating leaf particles ─────────────────────────────────────── */
$yog_leaves = [];
for ($i = 0; $i < 18; $i++) {
    $yog_leaves[] = [
        'x'     => rand(0, 100),
        'size'  => rand(6, 14),
        'delay' => yog_rand_float(0, 8.0),
        'dur'   => yog_rand_float(6.0, 14.0),
        'col'   => ($i % 3 === 0) ? '#8aab6a' : (($i % 3 === 1) ? '#6a9a5a' : '#a8c490'),
        'rot'   => rand(0, 360),
    ];
}

/* ── Stars / fireflies ───────────────────────────────────────────── */
$yog_stars = [];
for ($i = 0; $i < 35; $i++) {
    $yog_stars[] = [
        'x'     => rand(0, 100),
        'y'     => rand(2, 55),
        'size'  => rand(1, 3),
        'delay' => yog_rand_float(0, 5.0),
        'dur'   => yog_rand_float(2.0, 5.0),
    ];
}

/* ── Instructors ─────────────────────────────────────────────────── */
$instructors = [
    [
        'name'       => 'Anika Sharma',
        'role'       => 'Lead Instructor — Hatha & Vinyasa',
        'exp'        => '12 years',
        'cert'       => 'RYT-500, Yin Yoga Cert.',
        'bio'        => 'Anika trained in Mysore and brings a deeply traditional yet accessible approach to her classes, weaving breath and movement into transformative sequences.',
        'spec'       => ['Hatha','Vinyasa','Pranayama'],
        'skin'       => '#d4a070',
        'hair'       => '#2a1a0a',
        'top'        => '#5a7a8a',
    ],
    [
        'name'       => 'James Calloway',
        'role'       => 'Senior Instructor — Yin & Restorative',
        'exp'        => '9 years',
        'cert'       => 'RYT-200, Restorative Yoga Cert.',
        'bio'        => 'James discovered yoga after a decade in professional sport and now specialises in deep tissue release, nervous system regulation and mindful recovery practices.',
        'spec'       => ['Yin','Restorative','Meditation'],
        'skin'       => '#c8906a',
        'hair'       => '#3a2a1a',
        'top'        => '#7a8a6a',
    ],
    [
        'name'       => 'Priya Nair',
        'role'       => 'Instructor — Ashtanga & Power',
        'exp'        => '7 years',
        'cert'       => 'RYT-200, Ashtanga Cert.',
        'bio'        => 'Priya's dynamic classes challenge students to find strength within stillness. Her signature sequences build heat, focus and lasting physical confidence.',
        'spec'       => ['Ashtanga','Power','Core'],
        'skin'       => '#c07050',
        'hair'       => '#1a0a00',
        'top'        => '#8a6a9a',
    ],
    [
        'name'       => 'Lena Fischer',
        'role'       => 'Instructor — Prenatal & Kids',
        'exp'        => '6 years',
        'cert'       => 'RYT-200, Prenatal Specialist',
        'bio'        => 'Lena creates a nurturing space for parents-to-be and young practitioners, blending gentle asana with mindfulness tools suited to every life stage.',
        'spec'       => ['Prenatal','Kids Yoga','Gentle'],
        'skin'       => '#e0b080',
        'hair'       => '#5a3a1a',
        'top'        => '#9a7a6a',
    ],
];

/* ── Class schedule ──────────────────────────────────────────────── */
$schedule = [
    ['day'=>'Monday',    'time'=>'07:00','name'=>'Morning Vinyasa',   'level'=>'All Levels','dur'=>'60 min','instructor'=>'Anika Sharma',  'spots'=>4],
    ['day'=>'Monday',    'time'=>'18:30','name'=>'Evening Yin',       'level'=>'All Levels','dur'=>'75 min','instructor'=>'James Calloway','spots'=>8],
    ['day'=>'Tuesday',   'time'=>'09:00','name'=>'Hatha Flow',        'level'=>'Beginner',  'dur'=>'60 min','instructor'=>'Anika Sharma',  'spots'=>2],
    ['day'=>'Tuesday',   'time'=>'19:00','name'=>'Power Yoga',        'level'=>'Intermediate','dur'=>'60 min','instructor'=>'Priya Nair',  'spots'=>6],
    ['day'=>'Wednesday', 'time'=>'07:00','name'=>'Sunrise Meditation','level'=>'All Levels','dur'=>'45 min','instructor'=>'Lena Fischer',  'spots'=>12],
    ['day'=>'Wednesday', 'time'=>'18:00','name'=>'Ashtanga Primary',  'level'=>'Intermediate','dur'=>'90 min','instructor'=>'Priya Nair',  'spots'=>3],
    ['day'=>'Thursday',  'time'=>'09:30','name'=>'Prenatal Yoga',     'level'=>'Prenatal',  'dur'=>'60 min','instructor'=>'Lena Fischer',  'spots'=>7],
    ['day'=>'Thursday',  'time'=>'19:30','name'=>'Restorative',       'level'=>'All Levels','dur'=>'75 min','instructor'=>'James Calloway','spots'=>10],
    ['day'=>'Friday',    'time'=>'07:00','name'=>'Morning Vinyasa',   'level'=>'All Levels','dur'=>'60 min','instructor'=>'Anika Sharma',  'spots'=>5],
    ['day'=>'Friday',    'time'=>'17:30','name'=>'Core & Breath',     'level'=>'All Levels','dur'=>'60 min','instructor'=>'Priya Nair',    'spots'=>9],
    ['day'=>'Saturday',  'time'=>'09:00','name'=>'Weekend Flow',      'level'=>'All Levels','dur'=>'90 min','instructor'=>'Anika Sharma',  'spots'=>1],
    ['day'=>'Saturday',  'time'=>'11:00','name'=>'Kids Yoga',         'level'=>'Kids 5–12', 'dur'=>'45 min','instructor'=>'Lena Fischer',  'spots'=>6],
    ['day'=>'Sunday',    'time'=>'10:00','name'=>'Gentle Sunday',     'level'=>'Beginner',  'dur'=>'75 min','instructor'=>'James Calloway','spots'=>14],
    ['day'=>'Sunday',    'time'=>'16:00','name'=>'Yoga Nidra',        'level'=>'All Levels','dur'=>'60 min','instructor'=>'James Calloway','spots'=>11],
];

/* ── Retreat packages ────────────────────────────────────────────── */
$retreats = [
    [
        'name'     => 'Weekend Reset',
        'duration' => '2 Days',
        'price'    => '£285',
        'icon'     => '🌅',
        'includes' => ['6 guided sessions','2 meditation workshops','Ayurvedic meals included','Digital detox guide','Certificate of completion'],
        'highlight' => false,
    ],
    [
        'name'     => 'Week of Renewal',
        'duration' => '7 Days',
        'price'    => '£895',
        'icon'     => '🌿',
        'includes' => ['21 guided sessions','Daily pranayama','Nutritional consultancy','1-to-1 teacher session','Yoga philosophy talks','Retreat journal & mat'],
        'highlight' => true,
    ],
    [
        'name'     => 'Immersion Month',
        'duration' => '28 Days',
        'price'    => '£2,450',
        'icon'     => '🕉️',
        'includes' => ['Unlimited group classes','8 private sessions','Anatomy & philosophy modules','Teacher training credits','Exclusive alumni community','Lifetime discount card'],
        'highlight' => false,
    ],
];

/* ── Testimonials ────────────────────────────────────────────────── */
$testimonials = [
    [
        'name'   => 'Rachel T.',
        'loc'    => 'Member since 2021',
        'quote'  => 'Serene Space completely changed my relationship with my body. Anika\'s Hatha classes are the highlight of my week — I leave feeling taller, calmer and more myself.',
        'stars'  => 5,
        'avatar' => ['skin'=>'#e0a870','hair'=>'#5a2a0a'],
    ],
    [
        'name'   => 'Daniel M.',
        'loc'    => 'Weekend Retreat Graduate',
        'quote'  => 'I was sceptical about yoga retreats, but the Weekend Reset package exceeded every expectation. James creates a genuinely safe space to let go. Booked the Week of Renewal already.',
        'stars'  => 5,
        'avatar' => ['skin'=>'#c08060','hair'=>'#2a1a0a'],
    ],
    [
        'name'   => 'Sophie K.',
        'loc'    => 'Prenatal Programme',
        'quote'  => 'Lena\'s prenatal classes were a gift throughout my third trimester. Her knowledge, warmth and attention made every session feel like exactly what my body needed.',
        'stars'  => 5,
        'avatar' => ['skin'=>'#d4b080','hair'=>'#8a5a2a'],
    ],
];

/* ── FAQs ────────────────────────────────────────────────────────── */
$faqs = [
    ['q'=>'Do I need to bring my own mat?',
     'a'=>'We have high-quality mats available to borrow at no extra charge, as well as blocks, straps and bolsters. You\'re welcome to bring your own if you prefer.'],
    ['q'=>'I\'m a complete beginner — which class should I start with?',
     'a'=>'We recommend our Hatha Flow (Tuesday 09:00) or Gentle Sunday (Sunday 10:00) as ideal entry points. Both are designed for beginners and taught at a pace that prioritises proper alignment.'],
    ['q'=>'What is your cancellation policy for classes?',
     'a'=>'You can cancel a booked class up to 4 hours before the start time via the app or website. Late cancellations and no-shows count against your monthly credit allowance.'],
    ['q'=>'Do you offer membership or class packs?',
     'a'=>'Yes — we offer a monthly unlimited membership, a 10-class pack and a 5-class starter pack for new students. All options include access to our online library of recorded sessions.'],
    ['q'=>'Are retreats suitable for beginners?',
     'a'=>'Absolutely. Our Weekend Reset retreat is designed to be fully accessible regardless of experience. All sessions are adapted to the group\'s collective level and instructors provide modifications throughout.'],
];

?>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,300;0,400;0,600;0,700;1,300;1,400&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">
<style>
/* ═══════════════════════════════════════════════════════════════════
   YOGA & WELLNESS — CSS CUSTOM PROPERTIES
═══════════════════════════════════════════════════════════════════ */
:root{
  --yog-sage:       #4a7a5a;
  --yog-sage-lt:    #6a9a7a;
  --yog-earth:      #8a6a4a;
  --yog-earth-lt:   #b8957a;
  --yog-gold:       #c8a860;
  --yog-sand:       #f0e8d8;
  --yog-cream:      #faf7f2;
  --yog-ink:        #1a1412;
  --yog-mist:       #e8f0e8;
  --yog-dusk:       #1a2a1a;
  --yog-dawn:       #ff9a6a;
  --yog-sky-top:    #0d1a2a;
  --yog-sky-mid:    #2a1a3a;
  --yog-sky-bot:    #8a4a3a;
  --yog-water:      #1a3a4a;
  --yog-lotus-pink: #e8b4b8;
  --ff-head:        'Raleway', sans-serif;
  --ff-body:        'Lato', sans-serif;
  --rad:            12px;
  --trans:          .35s cubic-bezier(.4,0,.2,1);
}

/* ─── Reset & base ───────────────────────────────────────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;font-size:16px}
body.yog-page{
  font-family:var(--ff-body);
  color:var(--yog-ink);
  background:var(--yog-cream);
  overflow-x:hidden;
}
.yog-wrap{max-width:1140px;margin:0 auto;padding:0 24px}

/* ─── Typography ─────────────────────────────────────────────────── */
.yog-eyebrow{
  font-family:var(--ff-head);
  font-size:.75rem;
  font-weight:600;
  letter-spacing:.18em;
  text-transform:uppercase;
  color:var(--yog-earth);
  display:block;
  margin-bottom:.6rem;
}
.yog-h2{
  font-family:var(--ff-head);
  font-size:clamp(1.9rem,3.5vw,2.8rem);
  font-weight:300;
  letter-spacing:.04em;
  color:var(--yog-ink);
  line-height:1.2;
}
.yog-h2 em{
  font-style:italic;
  color:var(--yog-sage);
}
.yog-lead{
  font-size:1.05rem;
  line-height:1.75;
  color:#4a3a30;
  max-width:640px;
}
.yog-centre{text-align:center}
.yog-centre .yog-lead{margin:0 auto}

/* ─── Ornament ───────────────────────────────────────────────────── */
.yog-ornament{
  display:flex;
  align-items:center;
  gap:12px;
  margin:.9rem 0 1.8rem;
}
.yog-ornament-line{
  flex:1;
  height:1px;
  background:linear-gradient(90deg,transparent,var(--yog-earth-lt),transparent);
}
.yog-ornament-sym{
  font-size:1.2rem;
  color:var(--yog-earth);
  line-height:1;
}

/* ─── Buttons ────────────────────────────────────────────────────── */
.yog-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:14px 32px;
  border-radius:50px;
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.9rem;
  letter-spacing:.06em;
  text-transform:uppercase;
  text-decoration:none;
  border:none;
  cursor:pointer;
  transition:var(--trans);
}
.yog-btn-primary{
  background:linear-gradient(135deg,var(--yog-sage),var(--yog-sage-lt));
  color:#fff;
  box-shadow:0 4px 20px rgba(74,122,90,.35);
}
.yog-btn-primary:hover{
  transform:translateY(-2px);
  box-shadow:0 8px 28px rgba(74,122,90,.45);
}
.yog-btn-ghost{
  background:transparent;
  color:#fff;
  border:2px solid rgba(255,255,255,.6);
}
.yog-btn-ghost:hover{
  background:rgba(255,255,255,.12);
  border-color:#fff;
}
.yog-btn-earth{
  background:linear-gradient(135deg,var(--yog-earth),var(--yog-earth-lt));
  color:#fff;
  box-shadow:0 4px 20px rgba(138,106,74,.35);
}
.yog-btn-earth:hover{
  transform:translateY(-2px);
  box-shadow:0 8px 28px rgba(138,106,74,.45);
}

/* ═══════════════════════════════════════════════════════════════════
   HERO — DOJO AT DAWN
═══════════════════════════════════════════════════════════════════ */
.yog-hero{
  position:relative;
  height:100vh;
  min-height:640px;
  max-height:960px;
  overflow:hidden;
  display:flex;
  align-items:center;
  justify-content:center;
}

/* Sky gradient — pre-dawn to dawn */
.yog-hero-sky{
  position:absolute;
  inset:0;
  background:linear-gradient(180deg,
    var(--yog-sky-top) 0%,
    var(--yog-sky-mid) 30%,
    #6a2a2a 60%,
    var(--yog-sky-bot) 80%,
    #c86040 100%
  );
}

/* Stars */
.yog-star{
  position:absolute;
  border-radius:50%;
  background:#fff;
  animation:yog-twinkle var(--dur,3s) var(--del,0s) ease-in-out infinite alternate;
}
@keyframes yog-twinkle{
  from{opacity:.2;transform:scale(.8)}
  to{opacity:.9;transform:scale(1.2)}
}

/* Moon */
.yog-moon{
  position:absolute;
  top:6%;
  right:14%;
  width:48px;
  height:48px;
  border-radius:50%;
  background:radial-gradient(circle at 38% 38%,#fff8e8,#e8d8b0);
  box-shadow:0 0 30px rgba(248,240,200,.5),0 0 60px rgba(248,240,200,.2);
}
.yog-moon::before{
  content:'';
  position:absolute;
  width:10px;height:10px;
  border-radius:50%;
  background:rgba(200,180,140,.4);
  top:18%;left:60%;
}
.yog-moon::after{
  content:'';
  position:absolute;
  width:7px;height:7px;
  border-radius:50%;
  background:rgba(200,180,140,.3);
  top:55%;left:25%;
}

/* Mountains / silhouette hills */
.yog-mountains{
  position:absolute;
  bottom:28%;
  left:0;right:0;
  height:28%;
}
.yog-mtn{
  position:absolute;
  bottom:0;
}
.yog-mtn-far{
  left:0;right:0;
  height:100%;
  background:#0f1a0f;
  clip-path:polygon(0 100%,5% 55%,12% 80%,20% 30%,28% 65%,35% 20%,42% 55%,50% 10%,58% 45%,65% 25%,72% 50%,80% 15%,88% 45%,94% 30%,100% 55%,100% 100%);
}
.yog-mtn-near{
  left:0;right:0;
  height:70%;
  background:#0a1208;
  clip-path:polygon(0 100%,8% 40%,18% 70%,28% 25%,40% 60%,50% 30%,62% 55%,72% 20%,82% 50%,92% 35%,100% 60%,100% 100%);
}

/* Trees silhouette */
.yog-tree-line{
  position:absolute;
  bottom:26%;
  left:0;right:0;
  height:18%;
}
.yog-tree{
  position:absolute;
  bottom:0;
  display:flex;
  flex-direction:column;
  align-items:center;
}
.yog-tree-trunk{
  width:6px;
  background:#0a1208;
  border-radius:2px;
}
.yog-tree-canopy{
  border-left:solid transparent;
  border-right:solid transparent;
  border-bottom:solid #0a1208;
}

/* Pond */
.yog-pond{
  position:absolute;
  bottom:12%;
  left:50%;
  transform:translateX(-50%);
  width:60%;
  height:8%;
  background:radial-gradient(ellipse,#1a3a4a 0%,#0d2030 70%,transparent 100%);
  border-radius:50%;
}
.yog-pond-reflection{
  position:absolute;
  bottom:0;left:0;right:0;
  height:60%;
  background:linear-gradient(180deg,rgba(200,104,64,.15),transparent);
  border-radius:50%;
}

/* Lotus flowers */
.yog-lotus{
  position:absolute;
  bottom:8px;
  transform:translateX(-50%);
}
.yog-lotus-pad{
  border-radius:50%;
  background:radial-gradient(circle,#2a5a3a,#1a3a28);
  margin:0 auto;
}
.yog-lotus-bloom{
  position:absolute;
  left:50%;
  transform:translateX(-50%);
  display:flex;
  gap:1px;
  justify-content:center;
}
.yog-lotus-petal{
  border-radius:50% 50% 0 0;
  transform-origin:bottom center;
}
@keyframes yog-lotus-sway{
  0%,100%{transform:translateX(-50%) rotate(-2deg)}
  50%{transform:translateX(-50%) rotate(2deg)}
}

/* Dojo building */
.yog-dojo{
  position:absolute;
  bottom:22%;
  left:50%;
  transform:translateX(-50%);
  width:min(480px,70vw);
}
.yog-dojo-roof-top{
  width:70%;
  margin:0 auto;
  height:0;
  border-left:60px solid transparent;
  border-right:60px solid transparent;
  border-bottom:40px solid #1a0a08;
  position:relative;
}
.yog-dojo-roof-top::after{
  content:'';
  position:absolute;
  top:-12px;
  left:50%;
  transform:translateX(-50%);
  width:8px;height:20px;
  background:#2a1a16;
  border-radius:4px 4px 0 0;
}
.yog-dojo-roof-main{
  width:90%;
  margin:0 auto;
  height:0;
  border-left:30px solid transparent;
  border-right:30px solid transparent;
  border-bottom:50px solid #2a1214;
  margin-top:-2px;
}
.yog-dojo-body{
  background:#1e1410;
  height:110px;
  border-radius:0 0 4px 4px;
  display:flex;
  align-items:stretch;
  gap:4px;
  padding:0 12px;
  position:relative;
}
.yog-dojo-body::before{
  content:'';
  position:absolute;
  top:0;left:0;right:0;
  height:3px;
  background:linear-gradient(90deg,transparent,var(--yog-gold),transparent);
}
/* Shoji windows */
.yog-shoji{
  flex:1;
  margin:14px 0;
  background:rgba(255,220,160,.08);
  border:1px solid rgba(255,220,160,.25);
  border-radius:2px;
  position:relative;
  overflow:hidden;
}
.yog-shoji::before{
  content:'';
  position:absolute;
  top:50%;left:0;right:0;
  height:1px;
  background:rgba(255,220,160,.15);
  transform:translateY(-50%);
}
.yog-shoji::after{
  content:'';
  position:absolute;
  top:0;bottom:0;left:50%;
  width:1px;
  background:rgba(255,220,160,.15);
  transform:translateX(-50%);
}
.yog-shoji.yog-shoji-lit{
  background:rgba(255,200,120,.18);
  border-color:rgba(255,200,120,.4);
  box-shadow:0 0 12px rgba(255,180,80,.25);
}
/* Central door */
.yog-dojo-door{
  width:52px;
  margin:16px 0 0;
  background:linear-gradient(180deg,#3a2a20,#2a1a14);
  border-radius:20px 20px 0 0;
  border:1px solid rgba(200,160,90,.3);
  position:relative;
  flex-shrink:0;
  align-self:flex-end;
}
.yog-dojo-door::before{
  content:'';
  position:absolute;
  top:8px;left:50%;
  transform:translateX(-50%);
  width:6px;height:6px;
  border-radius:50%;
  background:var(--yog-gold);
  box-shadow:0 0 6px rgba(200,160,80,.6);
}
/* Lanterns */
.yog-dojo-lantern{
  position:absolute;
  top:-28px;
  width:14px;
  height:22px;
  background:linear-gradient(180deg,#2a1a08,#6a3a10);
  border-radius:4px 4px 6px 6px;
  box-shadow:0 0 12px rgba(255,140,40,.5);
}
.yog-dojo-lantern::before{
  content:'';
  position:absolute;
  top:-6px;left:50%;
  transform:translateX(-50%);
  width:2px;height:8px;
  background:#4a3a20;
}
.yog-dojo-lantern::after{
  content:'';
  position:absolute;
  top:2px;left:2px;right:2px;bottom:2px;
  background:radial-gradient(circle,rgba(255,180,60,.8),rgba(255,120,20,.3));
  border-radius:3px;
  animation:yog-lantern-glow 2s ease-in-out infinite alternate;
}
@keyframes yog-lantern-glow{
  from{opacity:.6}
  to{opacity:1}
}
.yog-dojo-lantern-l{left:16px;}
.yog-dojo-lantern-r{right:16px;}

/* Torii gate */
.yog-torii{
  position:absolute;
  bottom:34%;
  left:50%;
  transform:translateX(-50%);
  width:160px;
}
.yog-torii-top{
  height:10px;
  background:#5a1a08;
  border-radius:30px;
  box-shadow:0 -4px 0 0 #6a2010;
}
.yog-torii-cross{
  margin:10px auto 0;
  width:80%;
  height:6px;
  background:#5a1a08;
}
.yog-torii-legs{
  display:flex;
  justify-content:space-between;
  padding:0 16px;
}
.yog-torii-leg{
  width:8px;
  height:50px;
  background:linear-gradient(180deg,#5a1a08,#3a1006);
  border-radius:0 0 4px 4px;
}

/* Stone path */
.yog-path{
  position:absolute;
  bottom:10%;
  left:50%;
  transform:translateX(-50%);
  width:80px;
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:6px;
}
.yog-stone{
  border-radius:50%;
  background:radial-gradient(circle at 35% 35%,#5a5050,#2a2020);
}

/* Lotus particles floating */
.yog-leaf-particle{
  position:absolute;
  top:-20px;
  border-radius:50% 0 50% 0;
  animation:yog-leaf-float var(--leaf-dur,10s) var(--leaf-del,0s) linear infinite;
}
@keyframes yog-leaf-float{
  0%{transform:translateY(-20px) rotate(0deg);opacity:0}
  10%{opacity:1}
  90%{opacity:.7}
  100%{transform:translateY(110vh) rotate(720deg);opacity:0}
}

/* Hero content */
.yog-hero-content{
  position:relative;
  z-index:10;
  text-align:center;
  padding:0 24px;
}
.yog-hero-badge{
  display:inline-flex;
  align-items:center;
  gap:8px;
  background:rgba(255,255,255,.1);
  backdrop-filter:blur(8px);
  border:1px solid rgba(255,255,255,.25);
  border-radius:50px;
  padding:6px 20px;
  font-family:var(--ff-head);
  font-size:.75rem;
  font-weight:600;
  letter-spacing:.15em;
  text-transform:uppercase;
  color:rgba(255,255,255,.9);
  margin-bottom:1.4rem;
}
.yog-hero-h1{
  font-family:var(--ff-head);
  font-size:clamp(2.4rem,6vw,5rem);
  font-weight:300;
  letter-spacing:.08em;
  color:#fff;
  line-height:1.1;
  text-shadow:0 2px 20px rgba(0,0,0,.4);
  margin-bottom:.5rem;
}
.yog-hero-h1 em{
  font-style:italic;
  color:var(--yog-gold);
}
.yog-hero-tagline{
  font-family:var(--ff-head);
  font-size:clamp(1rem,2vw,1.25rem);
  font-weight:300;
  font-style:italic;
  color:rgba(255,255,255,.8);
  margin-bottom:2.2rem;
  letter-spacing:.06em;
}
.yog-hero-btns{
  display:flex;
  gap:14px;
  justify-content:center;
  flex-wrap:wrap;
}

/* Hero bottom scroll cue */
.yog-scroll-cue{
  position:absolute;
  bottom:28px;
  left:50%;
  transform:translateX(-50%);
  z-index:10;
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:6px;
  color:rgba(255,255,255,.5);
  font-family:var(--ff-head);
  font-size:.65rem;
  letter-spacing:.12em;
  text-transform:uppercase;
}
.yog-scroll-arrow{
  width:20px;height:20px;
  border-right:1px solid rgba(255,255,255,.4);
  border-bottom:1px solid rgba(255,255,255,.4);
  transform:rotate(45deg);
  animation:yog-bounce .8s ease-in-out infinite alternate;
}
@keyframes yog-bounce{
  from{transform:rotate(45deg) translateY(-3px);opacity:.4}
  to{transform:rotate(45deg) translateY(3px);opacity:.9}
}

/* ═══════════════════════════════════════════════════════════════════
   STATS BAND
═══════════════════════════════════════════════════════════════════ */
.yog-stats{
  background:var(--yog-dusk);
  padding:32px 0;
}
.yog-stats-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:8px;
}
.yog-stat-item{
  text-align:center;
  padding:16px 12px;
  border-right:1px solid rgba(255,255,255,.08);
}
.yog-stat-item:last-child{border-right:none}
.yog-stat-num{
  font-family:var(--ff-head);
  font-size:2.4rem;
  font-weight:300;
  color:var(--yog-gold);
  line-height:1;
  display:block;
}
.yog-stat-suf{
  font-family:var(--ff-head);
  font-size:1.4rem;
  font-weight:300;
  color:var(--yog-earth-lt);
}
.yog-stat-label{
  font-size:.8rem;
  color:rgba(255,255,255,.55);
  letter-spacing:.08em;
  text-transform:uppercase;
  margin-top:6px;
  display:block;
}

/* ═══════════════════════════════════════════════════════════════════
   ABOUT SECTION
═══════════════════════════════════════════════════════════════════ */
.yog-about{
  padding:100px 0;
  background:var(--yog-cream);
}
.yog-about-grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:70px;
  align-items:center;
}
.yog-about-visual{
  position:relative;
  height:420px;
}
/* CSS Chakra Mandala */
.yog-mandala{
  position:absolute;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
  width:320px;height:320px;
  animation:yog-spin 40s linear infinite;
}
@keyframes yog-spin{from{transform:translate(-50%,-50%) rotate(0deg)}to{transform:translate(-50%,-50%) rotate(360deg)}}
.yog-mandala-ring{
  position:absolute;
  border-radius:50%;
  border-style:solid;
}
.yog-mandala-petal{
  position:absolute;
  top:50%;left:50%;
  width:24px;height:48px;
  border-radius:50% 50% 0 0;
  transform-origin:bottom center;
  opacity:.7;
}
.yog-mandala-inner{
  position:absolute;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
  border-radius:50%;
  background:radial-gradient(circle,var(--yog-gold),transparent 70%);
}
/* Background blur circles */
.yog-aura{
  position:absolute;
  border-radius:50%;
  filter:blur(40px);
  opacity:.15;
}
.yog-about-text .yog-h2{margin-bottom:.3rem}
.yog-about-values{
  margin-top:28px;
  display:flex;
  flex-direction:column;
  gap:16px;
}
.yog-value-item{
  display:flex;
  gap:14px;
  align-items:flex-start;
}
.yog-value-icon{
  width:40px;height:40px;
  border-radius:50%;
  background:linear-gradient(135deg,var(--yog-sage),var(--yog-sage-lt));
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:1.1rem;
  flex-shrink:0;
  box-shadow:0 2px 12px rgba(74,122,90,.25);
}
.yog-value-body{flex:1}
.yog-value-title{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.9rem;
  color:var(--yog-ink);
  margin-bottom:3px;
}
.yog-value-desc{
  font-size:.88rem;
  line-height:1.6;
  color:#5a4a40;
}

/* ═══════════════════════════════════════════════════════════════════
   CLASSES — SCHEDULE TABLE
═══════════════════════════════════════════════════════════════════ */
.yog-schedule-sec{
  padding:100px 0;
  background:var(--yog-mist);
}
.yog-schedule-header{
  text-align:center;
  margin-bottom:48px;
}
.yog-schedule-table{
  width:100%;
  border-collapse:separate;
  border-spacing:0 6px;
  font-size:.88rem;
}
.yog-schedule-table th{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.75rem;
  letter-spacing:.1em;
  text-transform:uppercase;
  color:var(--yog-earth);
  padding:10px 16px;
  background:transparent;
  text-align:left;
}
.yog-schedule-table tr.yog-srow td{
  background:#fff;
  padding:14px 16px;
  transition:var(--trans);
}
.yog-schedule-table tr.yog-srow td:first-child{
  border-radius:var(--rad) 0 0 var(--rad);
  font-family:var(--ff-head);
  font-weight:600;
  color:var(--yog-sage);
}
.yog-schedule-table tr.yog-srow td:last-child{
  border-radius:0 var(--rad) var(--rad) 0;
}
.yog-schedule-table tr.yog-srow:hover td{
  background:var(--yog-sand);
  transform:translateX(3px);
}
.yog-level-badge{
  display:inline-block;
  padding:2px 10px;
  border-radius:20px;
  font-size:.72rem;
  font-weight:600;
  letter-spacing:.05em;
}
.yog-level-all{background:#e8f5e8;color:#2a6a3a}
.yog-level-beg{background:#e8f0ff;color:#3a4a8a}
.yog-level-int{background:#fff0e0;color:#8a5a20}
.yog-level-pre{background:#ffe8f0;color:#8a3a5a}
.yog-level-kids{background:#f0e8ff;color:#5a3a8a}
.yog-spots-badge{
  display:inline-flex;
  align-items:center;
  gap:5px;
  font-family:var(--ff-head);
  font-size:.8rem;
  font-weight:600;
}
.yog-spots-dot{
  width:8px;height:8px;
  border-radius:50%;
}
.yog-spots-low{color:#c84040}.yog-spots-low .yog-spots-dot{background:#c84040}
.yog-spots-med{color:#c87820}.yog-spots-med .yog-spots-dot{background:#c87820}
.yog-spots-ok{color:#4a8a4a}.yog-spots-ok .yog-spots-dot{background:#4a8a4a}

/* ═══════════════════════════════════════════════════════════════════
   INSTRUCTORS
═══════════════════════════════════════════════════════════════════ */
.yog-instructors-sec{
  padding:100px 0;
  background:var(--yog-cream);
}
.yog-instructors-header{text-align:center;margin-bottom:52px}
.yog-instructors-grid{
  display:grid;
  grid-template-columns:repeat(4,1fr);
  gap:24px;
}
.yog-instructor-card{
  background:#fff;
  border-radius:var(--rad);
  overflow:hidden;
  box-shadow:0 2px 20px rgba(74,90,74,.07);
  transition:var(--trans);
}
.yog-instructor-card:hover{
  transform:translateY(-4px);
  box-shadow:0 10px 36px rgba(74,90,74,.13);
}
/* CSS instructor figure */
.yog-instructor-art{
  height:160px;
  background:linear-gradient(180deg,var(--yog-mist),#d8e8d8);
  position:relative;
  display:flex;
  align-items:flex-end;
  justify-content:center;
  overflow:hidden;
}
.yog-fig{
  position:relative;
  display:flex;
  flex-direction:column;
  align-items:center;
  padding-bottom:0;
}
.yog-fig-head{
  width:38px;height:38px;
  border-radius:50%;
  position:relative;
  z-index:2;
  margin-bottom:-2px;
}
.yog-fig-hair{
  position:absolute;
  top:-4px;left:50%;
  transform:translateX(-50%);
  width:44px;height:20px;
  border-radius:50% 50% 0 0;
  z-index:3;
}
.yog-fig-bun{
  position:absolute;
  top:-14px;left:50%;
  transform:translateX(-50%);
  width:16px;height:16px;
  border-radius:50%;
  z-index:4;
}
.yog-fig-body{
  width:52px;height:60px;
  border-radius:8px 8px 0 0;
  position:relative;
  display:flex;
  align-items:flex-end;
  justify-content:center;
}
/* Yoga pose legs */
.yog-fig-legs{
  position:absolute;
  bottom:0;
  display:flex;
  gap:3px;
}
.yog-fig-leg{
  width:10px;height:32px;
  border-radius:0 0 5px 5px;
}
/* Crossed legs for meditation pose */
.yog-fig-legs-cross{
  position:absolute;
  bottom:-12px;
  width:50px;height:18px;
  border-radius:4px;
}
/* Arms */
.yog-fig-arm{
  position:absolute;
  width:8px;height:38px;
  border-radius:4px;
  top:4px;
}
.yog-fig-arm-l{
  left:-12px;
  transform:rotate(-20deg);
  transform-origin:top center;
}
.yog-fig-arm-r{
  right:-12px;
  transform:rotate(20deg);
  transform-origin:top center;
}
/* Raised arms for namaste */
.yog-fig-arm-up-l{
  left:-12px;
  transform:rotate(-60deg);
  transform-origin:top center;
}
.yog-fig-arm-up-r{
  right:-12px;
  transform:rotate(60deg);
  transform-origin:top center;
}
/* Mat */
.yog-fig-mat{
  position:absolute;
  bottom:0;
  width:80px;height:6px;
  border-radius:3px;
  background:linear-gradient(90deg,var(--yog-sage-lt),var(--yog-sage));
  z-index:0;
}
.yog-instructor-body{padding:18px 16px}
.yog-instructor-name{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:1rem;
  color:var(--yog-ink);
  margin-bottom:3px;
}
.yog-instructor-role{
  font-size:.78rem;
  color:var(--yog-sage);
  margin-bottom:10px;
  font-style:italic;
}
.yog-instructor-cert{
  font-size:.75rem;
  color:var(--yog-earth);
  font-weight:600;
  letter-spacing:.05em;
  margin-bottom:10px;
}
.yog-instructor-bio{
  font-size:.83rem;
  line-height:1.65;
  color:#5a4a40;
  margin-bottom:12px;
}
.yog-instructor-specs{
  display:flex;
  gap:5px;
  flex-wrap:wrap;
}
.yog-spec-tag{
  display:inline-block;
  padding:3px 10px;
  background:var(--yog-mist);
  border-radius:20px;
  font-size:.7rem;
  font-weight:600;
  color:var(--yog-sage);
}

/* ═══════════════════════════════════════════════════════════════════
   RETREAT PACKAGES
═══════════════════════════════════════════════════════════════════ */
.yog-retreats-sec{
  padding:100px 0;
  background:linear-gradient(180deg,var(--yog-dusk),#0a1a0a);
}
.yog-retreats-header{text-align:center;margin-bottom:52px}
.yog-retreats-header .yog-h2,
.yog-retreats-header .yog-lead{color:rgba(255,255,255,.9)}
.yog-retreats-header .yog-eyebrow{color:var(--yog-gold)}
.yog-retreats-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:28px;
  align-items:start;
}
.yog-retreat-card{
  background:rgba(255,255,255,.06);
  border:1px solid rgba(255,255,255,.1);
  border-radius:var(--rad);
  padding:36px 28px;
  position:relative;
  transition:var(--trans);
}
.yog-retreat-card:hover{
  background:rgba(255,255,255,.1);
  transform:translateY(-4px);
}
.yog-retreat-card.yog-retreat-featured{
  background:linear-gradient(135deg,rgba(74,122,90,.25),rgba(100,160,80,.12));
  border-color:var(--yog-sage-lt);
  transform:scale(1.03);
}
.yog-retreat-card.yog-retreat-featured:hover{
  transform:scale(1.03) translateY(-4px);
}
.yog-retreat-best{
  position:absolute;
  top:-14px;left:50%;
  transform:translateX(-50%);
  background:linear-gradient(135deg,var(--yog-sage),var(--yog-sage-lt));
  color:#fff;
  font-family:var(--ff-head);
  font-size:.7rem;
  font-weight:700;
  letter-spacing:.1em;
  text-transform:uppercase;
  padding:5px 18px;
  border-radius:20px;
  white-space:nowrap;
}
.yog-retreat-icon{
  font-size:2.2rem;
  display:block;
  margin-bottom:10px;
}
.yog-retreat-name{
  font-family:var(--ff-head);
  font-size:1.35rem;
  font-weight:600;
  color:#fff;
  margin-bottom:4px;
}
.yog-retreat-dur{
  font-size:.82rem;
  color:rgba(255,255,255,.55);
  margin-bottom:20px;
}
.yog-retreat-price{
  font-family:var(--ff-head);
  font-size:2.2rem;
  font-weight:300;
  color:var(--yog-gold);
  display:block;
  margin-bottom:20px;
  line-height:1;
}
.yog-retreat-price span{
  font-size:1rem;
  color:rgba(255,255,255,.4);
  font-weight:400;
}
.yog-retreat-includes{
  list-style:none;
  margin-bottom:28px;
  display:flex;
  flex-direction:column;
  gap:8px;
}
.yog-retreat-includes li{
  font-size:.85rem;
  color:rgba(255,255,255,.75);
  display:flex;
  gap:10px;
  align-items:flex-start;
}
.yog-retreat-includes li::before{
  content:'✓';
  color:var(--yog-sage-lt);
  font-weight:700;
  flex-shrink:0;
  margin-top:1px;
}
.yog-retreat-cta{
  width:100%;
  padding:12px;
  border-radius:50px;
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.85rem;
  letter-spacing:.06em;
  text-transform:uppercase;
  background:transparent;
  border:1px solid rgba(255,255,255,.3);
  color:#fff;
  cursor:pointer;
  transition:var(--trans);
}
.yog-retreat-cta:hover{
  background:rgba(255,255,255,.1);
  border-color:#fff;
}
.yog-retreat-card.yog-retreat-featured .yog-retreat-cta{
  background:linear-gradient(135deg,var(--yog-sage),var(--yog-sage-lt));
  border-color:transparent;
  box-shadow:0 4px 20px rgba(74,122,90,.4);
}

/* ═══════════════════════════════════════════════════════════════════
   TESTIMONIALS
═══════════════════════════════════════════════════════════════════ */
.yog-testimonials-sec{
  padding:100px 0;
  background:var(--yog-sand);
}
.yog-test-header{text-align:center;margin-bottom:48px}
.yog-test-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:24px;
}
.yog-test-card{
  background:#fff;
  border-radius:var(--rad);
  padding:28px 24px;
  box-shadow:0 2px 16px rgba(74,90,74,.06);
  position:relative;
}
.yog-test-card::before{
  content:'❝';
  position:absolute;
  top:16px;right:20px;
  font-size:3rem;
  color:var(--yog-mist);
  line-height:1;
  font-family:Georgia,serif;
}
.yog-test-stars{
  color:var(--yog-gold);
  font-size:1rem;
  margin-bottom:14px;
}
.yog-test-quote{
  font-size:.9rem;
  line-height:1.7;
  color:#4a3a30;
  margin-bottom:18px;
  font-style:italic;
}
.yog-test-author{
  display:flex;
  align-items:center;
  gap:12px;
}
/* CSS avatar */
.yog-avatar{
  width:42px;height:42px;
  border-radius:50%;
  position:relative;
  overflow:hidden;
  flex-shrink:0;
}
.yog-avatar-head{
  position:absolute;
  top:30%;left:50%;
  transform:translateX(-50%);
  width:24px;height:24px;
  border-radius:50%;
}
.yog-avatar-hair{
  position:absolute;
  top:24%;left:50%;
  transform:translateX(-50%);
  width:28px;height:14px;
  border-radius:50% 50% 0 0;
}
.yog-avatar-body{
  position:absolute;
  bottom:0;left:50%;
  transform:translateX(-50%);
  width:36px;height:18px;
  border-radius:50% 50% 0 0;
  background:var(--yog-sage-lt);
}
.yog-avatar-bg{
  position:absolute;
  inset:0;
  border-radius:50%;
}
.yog-test-meta-name{
  font-family:var(--ff-head);
  font-weight:600;
  font-size:.88rem;
  color:var(--yog-ink);
}
.yog-test-meta-loc{
  font-size:.75rem;
  color:var(--yog-earth);
}

/* ═══════════════════════════════════════════════════════════════════
   FAQ
═══════════════════════════════════════════════════════════════════ */
.yog-faq-sec{
  padding:100px 0;
  background:var(--yog-cream);
}
.yog-faq-inner{
  max-width:740px;
  margin:0 auto;
}
.yog-faq-header{text-align:center;margin-bottom:48px}
.yog-faq-item{
  border-bottom:1px solid rgba(74,90,74,.12);
}
.yog-faq-q{
  width:100%;
  background:none;
  border:none;
  text-align:left;
  padding:20px 0;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:16px;
  font-family:var(--ff-head);
  font-weight:600;
  font-size:1rem;
  color:var(--yog-ink);
  cursor:pointer;
  transition:color var(--trans);
}
.yog-faq-q:hover{color:var(--yog-sage)}
.yog-faq-icon{
  width:24px;height:24px;
  border-radius:50%;
  background:var(--yog-mist);
  display:flex;
  align-items:center;
  justify-content:center;
  flex-shrink:0;
  transition:var(--trans);
  font-size:.9rem;
  color:var(--yog-sage);
}
.yog-faq-item.open .yog-faq-icon{
  transform:rotate(45deg);
  background:var(--yog-sage);
  color:#fff;
}
.yog-faq-a{
  overflow:hidden;
  max-height:0;
  transition:max-height .4s ease;
}
.yog-faq-a-inner{
  padding:0 0 20px;
  font-size:.92rem;
  line-height:1.75;
  color:#5a4a40;
}

/* ═══════════════════════════════════════════════════════════════════
   BOOKING FORM
═══════════════════════════════════════════════════════════════════ */
.yog-booking-sec{
  padding:100px 0;
  background:linear-gradient(135deg,var(--yog-sage) 0%,#2a5a3a 50%,var(--yog-dusk) 100%);
}
.yog-booking-wrap{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:60px;
  align-items:start;
}
.yog-booking-info .yog-h2,
.yog-booking-info .yog-eyebrow{color:rgba(255,255,255,.9)}
.yog-booking-info .yog-eyebrow{color:var(--yog-gold)}
.yog-booking-info .yog-lead{color:rgba(255,255,255,.75)}
.yog-booking-perks{
  margin-top:28px;
  display:flex;
  flex-direction:column;
  gap:14px;
}
.yog-perk{
  display:flex;
  align-items:center;
  gap:12px;
  color:rgba(255,255,255,.85);
  font-size:.9rem;
}
.yog-perk-icon{
  width:34px;height:34px;
  border-radius:50%;
  background:rgba(255,255,255,.12);
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:1rem;
  flex-shrink:0;
}
.yog-form-card{
  background:#fff;
  border-radius:calc(var(--rad) * 1.5);
  padding:36px 32px;
  box-shadow:0 20px 60px rgba(0,0,0,.25);
}
.yog-form-title{
  font-family:var(--ff-head);
  font-size:1.25rem;
  font-weight:600;
  color:var(--yog-ink);
  margin-bottom:22px;
}
.yog-field{
  margin-bottom:18px;
}
.yog-field label{
  display:block;
  font-size:.78rem;
  font-weight:600;
  letter-spacing:.06em;
  text-transform:uppercase;
  color:var(--yog-earth);
  margin-bottom:6px;
}
.yog-field input,
.yog-field select,
.yog-field textarea{
  width:100%;
  padding:11px 14px;
  border:1.5px solid #d8cfc0;
  border-radius:8px;
  font-family:var(--ff-body);
  font-size:.9rem;
  color:var(--yog-ink);
  background:#fff;
  transition:border-color var(--trans),box-shadow var(--trans);
}
.yog-field input:focus,
.yog-field select:focus,
.yog-field textarea:focus{
  outline:none;
  border-color:var(--yog-sage);
  box-shadow:0 0 0 3px rgba(74,122,90,.12);
}
.yog-field-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.yog-field textarea{resize:vertical;min-height:80px}
.yog-form-submit{
  width:100%;
  padding:14px;
  border-radius:50px;
  font-family:var(--ff-head);
  font-weight:700;
  font-size:.9rem;
  letter-spacing:.08em;
  text-transform:uppercase;
  border:none;
  cursor:pointer;
  background:linear-gradient(135deg,var(--yog-sage),var(--yog-sage-lt));
  color:#fff;
  box-shadow:0 4px 20px rgba(74,122,90,.35);
  transition:var(--trans);
}
.yog-form-submit:hover{
  transform:translateY(-2px);
  box-shadow:0 8px 28px rgba(74,122,90,.45);
}
.yog-form-note{
  font-size:.75rem;
  color:#8a7a70;
  text-align:center;
  margin-top:12px;
  line-height:1.5;
}

/* ═══════════════════════════════════════════════════════════════════
   RESPONSIVE
═══════════════════════════════════════════════════════════════════ */
@media(max-width:900px){
  .yog-stats-grid{grid-template-columns:repeat(2,1fr)}
  .yog-about-grid{grid-template-columns:1fr;gap:40px}
  .yog-about-visual{height:280px}
  .yog-instructors-grid{grid-template-columns:repeat(2,1fr)}
  .yog-retreats-grid{grid-template-columns:1fr}
  .yog-retreat-card.yog-retreat-featured{transform:none}
  .yog-test-grid{grid-template-columns:1fr}
  .yog-booking-wrap{grid-template-columns:1fr}
}
@media(max-width:600px){
  .yog-stats-grid{grid-template-columns:repeat(2,1fr)}
  .yog-instructors-grid{grid-template-columns:1fr}
  .yog-schedule-table thead{display:none}
  .yog-schedule-table tr.yog-srow{display:block;margin-bottom:10px}
  .yog-schedule-table tr.yog-srow td{
    display:flex;justify-content:space-between;
    padding:8px 14px;
  }
  .yog-schedule-table tr.yog-srow td:first-child{border-radius:var(--rad) var(--rad) 0 0}
  .yog-schedule-table tr.yog-srow td:last-child{border-radius:0 0 var(--rad) var(--rad)}
  .yog-hero-btns{flex-direction:column;align-items:center}
  .yog-field-row{grid-template-columns:1fr}
}
</style>
<?php get_header(); ?>
<div class="yog-page">
>
<?php wp_body_open(); ?>

<!-- ═══════════════════════════════════════════════════════════════
     HERO — DOJO AT DAWN
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-hero" aria-label="Hero">

  <!-- Sky -->
  <div class="yog-hero-sky"></div>

  <!-- Stars -->
  <?php foreach ($yog_stars as $s): ?>
  <div class="yog-star" style="
    left:<?= $s['x'] ?>%;
    top:<?= $s['y'] ?>%;
    width:<?= $s['size'] ?>px;
    height:<?= $s['size'] ?>px;
    --dur:<?= $s['dur'] ?>s;
    --del:<?= $s['delay'] ?>s;
  "></div>
  <?php endforeach; ?>

  <!-- Moon -->
  <div class="yog-moon" aria-hidden="true"></div>

  <!-- Mountains -->
  <div class="yog-mountains" aria-hidden="true">
    <div class="yog-mtn yog-mtn-far"></div>
    <div class="yog-mtn yog-mtn-near"></div>
  </div>

  <!-- Tree silhouettes -->
  <div class="yog-tree-line" aria-hidden="true">
    <?php
    $trees = [
      ['l'=>2,'trunk_h'=>50,'trunk_w'=>8,'c1_w'=>36,'c1_h'=>55,'c2_w'=>26,'c2_h'=>45,'c3_w'=>18,'c3_h'=>35],
      ['l'=>8,'trunk_h'=>42,'trunk_w'=>6,'c1_w'=>30,'c1_h'=>48,'c2_w'=>22,'c2_h'=>38,'c3_w'=>16,'c3_h'=>28],
      ['l'=>15,'trunk_h'=>60,'trunk_w'=>10,'c1_w'=>42,'c1_h'=>62,'c2_w'=>32,'c2_h'=>52,'c3_w'=>22,'c3_h'=>40],
      ['l'=>80,'trunk_h'=>55,'trunk_w'=>8,'c1_w'=>38,'c1_h'=>58,'c2_w'=>28,'c2_h'=>46,'c3_w'=>19,'c3_h'=>34],
      ['l'=>88,'trunk_h'=>45,'trunk_w'=>7,'c1_w'=>32,'c1_h'=>50,'c2_w'=>24,'c2_h'=>40,'c3_w'=>17,'c3_h'=>30],
      ['l'=>94,'trunk_h'=>65,'trunk_w'=>9,'c1_w'=>44,'c1_h'=>66,'c2_w'=>34,'c2_h'=>54,'c3_w'=>24,'c3_h'=>42],
    ];
    foreach ($trees as $t):
    ?>
    <div class="yog-tree" style="left:<?= $t['l'] ?>%">
      <div class="yog-tree-canopy" style="width:<?= $t['c3_w'] ?>px;border-left-width:<?= intval($t['c3_w']/2) ?>px;border-right-width:<?= intval($t['c3_w']/2) ?>px;border-bottom-width:<?= $t['c3_h'] ?>px"></div>
      <div class="yog-tree-canopy" style="width:<?= $t['c2_w'] ?>px;border-left-width:<?= intval($t['c2_w']/2) ?>px;border-right-width:<?= intval($t['c2_w']/2) ?>px;border-bottom-width:<?= $t['c2_h'] ?>px;margin-top:-<?= intval($t['c3_h']*.4) ?>px"></div>
      <div class="yog-tree-canopy" style="width:<?= $t['c1_w'] ?>px;border-left-width:<?= intval($t['c1_w']/2) ?>px;border-right-width:<?= intval($t['c1_w']/2) ?>px;border-bottom-width:<?= $t['c1_h'] ?>px;margin-top:-<?= intval($t['c2_h']*.4) ?>px"></div>
      <div class="yog-tree-trunk" style="height:<?= $t['trunk_h'] ?>px;width:<?= $t['trunk_w'] ?>px"></div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Torii Gate -->
  <div class="yog-torii" aria-hidden="true">
    <div class="yog-torii-top"></div>
    <div class="yog-torii-cross"></div>
    <div class="yog-torii-legs">
      <div class="yog-torii-leg"></div>
      <div class="yog-torii-leg"></div>
    </div>
  </div>

  <!-- Pond with lotus -->
  <div class="yog-pond" aria-hidden="true">
    <div class="yog-pond-reflection"></div>
    <?php foreach ($lotus_blooms as $lb): ?>
    <div class="yog-lotus" style="left:<?= $lb['left'] ?>%;animation:yog-lotus-sway <?= 3 + ($lb['open'] % 3) ?>s ease-in-out infinite alternate;animation-delay:<?= $lb['delay'] ?>s">
      <div class="yog-lotus-pad" style="width:<?= $lb['size'] + 8 ?>px;height:<?= intval(($lb['size'] + 8) * .35) ?>px"></div>
      <div class="yog-lotus-bloom" style="bottom:<?= intval(($lb['size']+8)*.35) ?>px">
        <?php for ($p = 0; $p < 6; $p++): ?>
        <div class="yog-lotus-petal" style="
          width:<?= intval($lb['size'] * .35) ?>px;
          height:<?= intval($lb['size'] * .65) ?>px;
          background:<?= $lb['col'] ?>;
          transform-origin:bottom center;
          transform:rotate(<?= ($p * 60) - 150 ?>deg) translateY(-<?= intval($lb['size'] * .12) ?>px);
        "></div>
        <?php endfor; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Stone path -->
  <div class="yog-path" aria-hidden="true">
    <?php for ($p = 0; $p < 6; $p++): ?>
    <div class="yog-stone" style="width:<?= 32 - $p * 2 ?>px;height:<?= 12 - ($p > 3 ? 2 : 0) ?>px"></div>
    <?php endfor; ?>
  </div>

  <!-- Dojo building -->
  <div class="yog-dojo" aria-hidden="true">
    <div class="yog-dojo-roof-top"></div>
    <div class="yog-dojo-roof-main"></div>
    <div class="yog-dojo-body">
      <div class="yog-dojo-lantern yog-dojo-lantern-l"></div>
      <div class="yog-dojo-lantern yog-dojo-lantern-r"></div>
      <div class="yog-shoji yog-shoji-lit"></div>
      <div class="yog-shoji"></div>
      <div class="yog-dojo-door"></div>
      <div class="yog-shoji"></div>
      <div class="yog-shoji yog-shoji-lit"></div>
    </div>
  </div>

  <!-- Floating leaves -->
  <?php foreach ($yog_leaves as $lf): ?>
  <div class="yog-leaf-particle" style="
    left:<?= $lf['x'] ?>%;
    width:<?= $lf['size'] ?>px;
    height:<?= $lf['size'] ?>px;
    background:<?= $lf['col'] ?>;
    --leaf-dur:<?= $lf['dur'] ?>s;
    --leaf-del:<?= $lf['delay'] ?>s;
  " aria-hidden="true"></div>
  <?php endforeach; ?>

  <!-- Hero content -->
  <div class="yog-hero-content">
    <span class="yog-hero-badge">🧘 Yoga &amp; Wellness Studio</span>
    <h1 class="yog-hero-h1">Find Your<br><em>Serene Space</em></h1>
    <p class="yog-hero-tagline">Breathe. Move. Transform.</p>
    <div class="yog-hero-btns">
      <a href="#booking" class="yog-btn yog-btn-primary">Book a Class</a>
      <a href="#schedule" class="yog-btn yog-btn-ghost">View Schedule</a>
    </div>
  </div>

  <div class="yog-scroll-cue" aria-hidden="true">
    <span>Discover</span>
    <div class="yog-scroll-arrow"></div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     STATS BAND
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-stats" aria-label="Studio at a glance">
  <div class="yog-wrap">
    <div class="yog-stats-grid">
      <div class="yog-stat-item">
        <span class="yog-stat-num"><span class="yog-counter" data-target="850">0</span><span class="yog-stat-suf">+</span></span>
        <span class="yog-stat-label">Active Members</span>
      </div>
      <div class="yog-stat-item">
        <span class="yog-stat-num"><span class="yog-counter" data-target="4.9">0</span></span>
        <span class="yog-stat-label">Google Rating</span>
      </div>
      <div class="yog-stat-item">
        <span class="yog-stat-num"><span class="yog-counter" data-target="14">0</span></span>
        <span class="yog-stat-label">Weekly Classes</span>
      </div>
      <div class="yog-stat-item">
        <span class="yog-stat-num"><span class="yog-counter" data-target="8">0</span></span>
        <span class="yog-stat-label">Years of Practice</span>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     ABOUT
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-about" aria-labelledby="yog-about-h">
  <div class="yog-wrap">
    <div class="yog-about-grid">

      <!-- CSS Mandala art -->
      <div class="yog-about-visual" aria-hidden="true">
        <div class="yog-aura" style="width:300px;height:300px;background:var(--yog-sage);top:50%;left:50%;transform:translate(-50%,-50%)"></div>
        <div class="yog-mandala">
          <!-- Outer ring -->
          <div class="yog-mandala-ring" style="inset:0;border:2px solid rgba(138,106,74,.25);border-radius:50%"></div>
          <div class="yog-mandala-ring" style="inset:20px;border:1px solid rgba(200,168,96,.2);border-radius:50%"></div>
          <!-- Petals ring 1 -->
          <?php for ($p = 0; $p < 12; $p++): $hue = $mandala_colours[$p % count($mandala_colours)]; ?>
          <div class="yog-mandala-petal" style="
            margin-left:-12px;
            margin-top:-120px;
            background:<?= $hue ?>;
            transform:rotate(<?= $p * 30 ?>deg) translateY(-100px);
          "></div>
          <?php endfor; ?>
          <!-- Petals ring 2 -->
          <?php for ($p = 0; $p < 8; $p++): $hue2 = $mandala_colours[($p + 3) % count($mandala_colours)]; ?>
          <div class="yog-mandala-petal" style="
            margin-left:-10px;
            margin-top:-80px;
            width:20px;
            height:40px;
            background:<?= $hue2 ?>;
            opacity:.5;
            transform:rotate(<?= $p * 45 + 22 ?>deg) translateY(-60px);
          "></div>
          <?php endfor; ?>
          <!-- Inner circles -->
          <div class="yog-mandala-ring" style="inset:110px;border:2px solid rgba(138,106,74,.4);border-radius:50%"></div>
          <div class="yog-mandala-ring" style="inset:128px;border:1px solid rgba(200,168,96,.3);border-radius:50%"></div>
          <!-- Core glow -->
          <div class="yog-mandala-inner" style="width:50px;height:50px;margin-left:-25px;margin-top:-25px"></div>
        </div>
      </div>

      <!-- Text -->
      <div class="yog-about-text">
        <span class="yog-eyebrow">Our Philosophy</span>
        <h2 class="yog-h2" id="yog-about-h">A sanctuary for <em>body, mind</em> &amp; breath</h2>
        <div class="yog-ornament"><div class="yog-ornament-line"></div><span class="yog-ornament-sym">✿</span><div class="yog-ornament-line"></div></div>
        <p class="yog-lead">At Serene Space, we believe that yoga is not a performance — it is a practice. Our light-filled studio offers a welcoming home for practitioners of every level, from first-timers to seasoned teachers, guided by experienced instructors who honour both the ancient tradition and the modern body.</p>
        <div class="yog-about-values">
          <div class="yog-value-item">
            <div class="yog-value-icon">🌱</div>
            <div class="yog-value-body">
              <div class="yog-value-title">Accessible to All</div>
              <div class="yog-value-desc">Every class is taught with modifications so that no body is left behind. We celebrate where you are, not where you think you should be.</div>
            </div>
          </div>
          <div class="yog-value-item">
            <div class="yog-value-icon">🕊️</div>
            <div class="yog-value-body">
              <div class="yog-value-title">Traditional Roots</div>
              <div class="yog-value-desc">Our teaching draws from classical Indian lineages while remaining grounded in evidence-based anatomy and modern therapeutic understanding.</div>
            </div>
          </div>
          <div class="yog-value-item">
            <div class="yog-value-icon">🤝</div>
            <div class="yog-value-body">
              <div class="yog-value-title">Community at Heart</div>
              <div class="yog-value-desc">We are more than a studio — we are a community of seekers who support, inspire and challenge one another on and off the mat.</div>
            </div>
          </div>
        </div>
        <div style="margin-top:28px">
          <a href="#booking" class="yog-btn yog-btn-primary">Start Your Journey</a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     CLASS SCHEDULE
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-schedule-sec" id="schedule" aria-labelledby="yog-sch-h">
  <div class="yog-wrap">
    <div class="yog-schedule-header">
      <span class="yog-eyebrow">Weekly Timetable</span>
      <h2 class="yog-h2" id="yog-sch-h">Find your <em>perfect class</em></h2>
      <div class="yog-ornament" style="justify-content:center"><div class="yog-ornament-line"></div><span class="yog-ornament-sym">✿</span><div class="yog-ornament-line"></div></div>
      <p class="yog-lead yog-centre">All classes are available to book online or in the app. Spots are limited — we recommend reserving your place at least 24 hours in advance.</p>
    </div>

    <div style="overflow-x:auto">
      <table class="yog-schedule-table" aria-label="Class schedule">
        <thead>
          <tr>
            <th>Day</th>
            <th>Time</th>
            <th>Class</th>
            <th>Level</th>
            <th>Duration</th>
            <th>Instructor</th>
            <th>Spots</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($schedule as $cls):
            $spots_cls = $cls['spots'] <= 3 ? 'yog-spots-low' : ($cls['spots'] <= 7 ? 'yog-spots-med' : 'yog-spots-ok');
            $level_cls = match($cls['level']) {
              'Beginner'      => 'yog-level-beg',
              'Intermediate'  => 'yog-level-int',
              'Prenatal'      => 'yog-level-pre',
              'Kids 5–12'     => 'yog-level-kids',
              default         => 'yog-level-all',
            };
          ?>
          <tr class="yog-srow">
            <td><?= esc_html($cls['day']) ?></td>
            <td><?= esc_html($cls['time']) ?></td>
            <td><strong><?= esc_html($cls['name']) ?></strong></td>
            <td><span class="yog-level-badge <?= $level_cls ?>"><?= esc_html($cls['level']) ?></span></td>
            <td><?= esc_html($cls['dur']) ?></td>
            <td><?= esc_html($cls['instructor']) ?></td>
            <td>
              <span class="yog-spots-badge <?= $spots_cls ?>">
                <span class="yog-spots-dot"></span>
                <?= esc_html($cls['spots']) ?> left
              </span>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     INSTRUCTORS
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-instructors-sec" aria-labelledby="yog-inst-h">
  <div class="yog-wrap">
    <div class="yog-instructors-header">
      <span class="yog-eyebrow">Our Teachers</span>
      <h2 class="yog-h2" id="yog-inst-h">Guided by <em>experienced hands</em></h2>
      <div class="yog-ornament" style="justify-content:center"><div class="yog-ornament-line"></div><span class="yog-ornament-sym">✿</span><div class="yog-ornament-line"></div></div>
    </div>
    <div class="yog-instructors-grid">
      <?php foreach ($instructors as $idx => $inst):
        $arm_l_class = ($idx === 0 || $idx === 2) ? 'yog-fig-arm-up-l' : 'yog-fig-arm-l';
        $arm_r_class = ($idx === 0 || $idx === 2) ? 'yog-fig-arm-up-r' : 'yog-fig-arm-r';
        $bg_cols = ['#d8e8d8','#e0d8e8','#d8e0e8','#e8d8e0'];
      ?>
      <div class="yog-instructor-card">
        <div class="yog-instructor-art" style="background:linear-gradient(180deg,<?= $bg_cols[$idx] ?>,<?= $bg_cols[$idx] ?>99)">
          <div class="yog-fig-mat"></div>
          <div class="yog-fig">
            <div class="yog-fig-hair" style="background:<?= esc_attr($inst['hair']) ?>"></div>
            <?php if ($idx === 0 || $idx === 3): ?>
            <div class="yog-fig-bun" style="background:<?= esc_attr($inst['hair']) ?>"></div>
            <?php endif; ?>
            <div class="yog-fig-head" style="background:<?= esc_attr($inst['skin']) ?>"></div>
            <div class="yog-fig-body" style="background:<?= esc_attr($inst['top']) ?>">
              <div class="yog-fig-arm <?= $arm_l_class ?>" style="background:<?= esc_attr($inst['skin']) ?>"></div>
              <div class="yog-fig-arm <?= $arm_r_class ?>" style="background:<?= esc_attr($inst['skin']) ?>"></div>
              <?php if ($idx === 1): ?>
              <!-- Meditation cross-legs -->
              <div class="yog-fig-legs-cross" style="background:<?= esc_attr($inst['skin']) ?>;position:absolute;bottom:-10px;border-radius:8px"></div>
              <?php else: ?>
              <div class="yog-fig-legs">
                <div class="yog-fig-leg" style="background:<?= esc_attr($inst['skin']) ?>"></div>
                <div class="yog-fig-leg" style="background:<?= esc_attr($inst['skin']) ?>"></div>
              </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="yog-instructor-body">
          <div class="yog-instructor-name"><?= esc_html($inst['name']) ?></div>
          <div class="yog-instructor-role"><?= esc_html($inst['role']) ?></div>
          <div class="yog-instructor-cert"><?= esc_html($inst['cert']) ?> · <?= esc_html($inst['exp']) ?> experience</div>
          <p class="yog-instructor-bio"><?= esc_html($inst['bio']) ?></p>
          <div class="yog-instructor-specs">
            <?php foreach ($inst['spec'] as $sp): ?>
            <span class="yog-spec-tag"><?= esc_html($sp) ?></span>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     RETREAT PACKAGES
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-retreats-sec" aria-labelledby="yog-ret-h">
  <div class="yog-wrap">
    <div class="yog-retreats-header">
      <span class="yog-eyebrow">Deepen Your Practice</span>
      <h2 class="yog-h2" id="yog-ret-h">Retreat <em>Packages</em></h2>
      <div class="yog-ornament" style="justify-content:center"><div class="yog-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(200,168,96,.4),transparent)"></div><span class="yog-ornament-sym" style="color:var(--yog-gold)">✿</span><div class="yog-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(200,168,96,.4),transparent)"></div></div>
      <p class="yog-lead">Step away from the everyday. Our immersive retreat packages offer a structured path to deeper understanding of yourself and your practice.</p>
    </div>
    <div class="yog-retreats-grid">
      <?php foreach ($retreats as $ret): ?>
      <div class="yog-retreat-card <?= $ret['highlight'] ? 'yog-retreat-featured' : '' ?>">
        <?php if ($ret['highlight']): ?>
        <div class="yog-retreat-best">Most Popular</div>
        <?php endif; ?>
        <span class="yog-retreat-icon"><?= $ret['icon'] ?></span>
        <div class="yog-retreat-name"><?= esc_html($ret['name']) ?></div>
        <div class="yog-retreat-dur"><?= esc_html($ret['duration']) ?></div>
        <span class="yog-retreat-price"><?= esc_html($ret['price']) ?> <span>per person</span></span>
        <ul class="yog-retreat-includes">
          <?php foreach ($ret['includes'] as $inc): ?>
          <li><?= esc_html($inc) ?></li>
          <?php endforeach; ?>
        </ul>
        <button class="yog-retreat-cta" onclick="document.getElementById('booking').scrollIntoView({behavior:'smooth'})">
          Book This Retreat
        </button>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     TESTIMONIALS
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-testimonials-sec" aria-labelledby="yog-test-h">
  <div class="yog-wrap">
    <div class="yog-test-header">
      <span class="yog-eyebrow">Student Voices</span>
      <h2 class="yog-h2" id="yog-test-h">Words from our <em>community</em></h2>
      <div class="yog-ornament" style="justify-content:center"><div class="yog-ornament-line"></div><span class="yog-ornament-sym">✿</span><div class="yog-ornament-line"></div></div>
    </div>
    <div class="yog-test-grid">
      <?php foreach ($testimonials as $t): ?>
      <div class="yog-test-card">
        <div class="yog-test-stars"><?= str_repeat('★', $t['stars']) ?></div>
        <p class="yog-test-quote"><?= esc_html($t['quote']) ?></p>
        <div class="yog-test-author">
          <div class="yog-avatar" style="background:<?= esc_attr($t['avatar']['skin']) ?>88">
            <div class="yog-avatar-bg" style="background:<?= esc_attr($t['avatar']['skin']) ?>44"></div>
            <div class="yog-avatar-hair" style="background:<?= esc_attr($t['avatar']['hair']) ?>"></div>
            <div class="yog-avatar-head" style="background:<?= esc_attr($t['avatar']['skin']) ?>"></div>
            <div class="yog-avatar-body"></div>
          </div>
          <div>
            <div class="yog-test-meta-name"><?= esc_html($t['name']) ?></div>
            <div class="yog-test-meta-loc"><?= esc_html($t['loc']) ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     FAQ
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-faq-sec" aria-labelledby="yog-faq-h">
  <div class="yog-wrap">
    <div class="yog-faq-inner">
      <div class="yog-faq-header">
        <span class="yog-eyebrow">Questions &amp; Answers</span>
        <h2 class="yog-h2" id="yog-faq-h">Everything you <em>need to know</em></h2>
        <div class="yog-ornament" style="justify-content:center"><div class="yog-ornament-line"></div><span class="yog-ornament-sym">✿</span><div class="yog-ornament-line"></div></div>
      </div>
      <div class="yog-faq-list">
        <?php foreach ($faqs as $fi => $faq): ?>
        <div class="yog-faq-item" id="yog-faq-<?= $fi ?>">
          <button class="yog-faq-q" aria-expanded="false" aria-controls="yog-faq-a-<?= $fi ?>">
            <span><?= esc_html($faq['q']) ?></span>
            <span class="yog-faq-icon" aria-hidden="true">+</span>
          </button>
          <div class="yog-faq-a" id="yog-faq-a-<?= $fi ?>" role="region">
            <div class="yog-faq-a-inner"><?= esc_html($faq['a']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>

<!-- ═══════════════════════════════════════════════════════════════
     BOOKING FORM
═══════════════════════════════════════════════════════════════════ -->
<section class="yog-booking-sec" id="booking" aria-labelledby="yog-bk-h">
  <div class="yog-wrap">
    <div class="yog-booking-wrap">

      <div class="yog-booking-info">
        <span class="yog-eyebrow">Book a Class</span>
        <h2 class="yog-h2" id="yog-bk-h">Reserve your <em>space</em> on the mat</h2>
        <div class="yog-ornament"><div class="yog-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)"></div><span class="yog-ornament-sym" style="color:var(--yog-gold)">✿</span><div class="yog-ornament-line" style="background:linear-gradient(90deg,transparent,rgba(255,255,255,.3),transparent)"></div></div>
        <p class="yog-lead">Whether you're stepping onto the mat for the first time or returning to deepen your practice, we'd love to welcome you into the Serene Space community.</p>
        <div class="yog-booking-perks">
          <div class="yog-perk"><div class="yog-perk-icon">🧘</div><span>First class free for new students</span></div>
          <div class="yog-perk"><div class="yog-perk-icon">📱</div><span>Manage bookings in the Serene Space app</span></div>
          <div class="yog-perk"><div class="yog-perk-icon">🌿</div><span>Mat, blocks &amp; straps provided at no charge</span></div>
          <div class="yog-perk"><div class="yog-perk-icon">🕊️</div><span>Cancel up to 4 hours before class — no penalty</span></div>
        </div>
      </div>

      <div class="yog-form-card">
        <div class="yog-form-title">Reserve Your Mat</div>
        <form method="post" action="" novalidate>
          <?php wp_nonce_field('tf_yog_booking','tf_yog_nonce'); ?>
          <div class="yog-field-row">
            <div class="yog-field">
              <label for="yog-fname">First Name</label>
              <input type="text" id="yog-fname" name="tf_first_name" required autocomplete="given-name" placeholder="e.g. Anika">
            </div>
            <div class="yog-field">
              <label for="yog-lname">Last Name</label>
              <input type="text" id="yog-lname" name="tf_last_name" required autocomplete="family-name" placeholder="e.g. Sharma">
            </div>
          </div>
          <div class="yog-field">
            <label for="yog-email">Email Address</label>
            <input type="email" id="yog-email" name="tf_email" required autocomplete="email" placeholder="you@example.com">
          </div>
          <div class="yog-field">
            <label for="yog-phone">Phone Number</label>
            <input type="tel" id="yog-phone" name="tf_phone" autocomplete="tel" placeholder="+44 7700 000000">
          </div>
          <div class="yog-field">
            <label for="yog-class">Class / Session</label>
            <select id="yog-class" name="tf_class">
              <option value="">— Select a class —</option>
              <?php foreach ($schedule as $cls): ?>
              <option value="<?= esc_attr($cls['day'].'_'.$cls['time']) ?>"><?= esc_html($cls['day'].' '.$cls['time'].' — '.$cls['name']) ?></option>
              <?php endforeach; ?>
              <option value="retreat_weekend">Weekend Reset Retreat</option>
              <option value="retreat_week">Week of Renewal Retreat</option>
              <option value="retreat_month">Immersion Month Retreat</option>
            </select>
          </div>
          <div class="yog-field">
            <label for="yog-level">Your Experience Level</label>
            <select id="yog-level" name="tf_level">
              <option value="">— Select your level —</option>
              <option value="complete_beginner">Complete Beginner</option>
              <option value="some_experience">Some Experience (up to 1 year)</option>
              <option value="intermediate">Intermediate (1–5 years)</option>
              <option value="advanced">Advanced (5+ years)</option>
            </select>
          </div>
          <div class="yog-field">
            <label for="yog-notes">Any injuries or conditions we should know about?</label>
            <textarea id="yog-notes" name="tf_notes" placeholder="Optional — helps your instructor provide appropriate modifications…"></textarea>
          </div>
          <button type="submit" class="yog-form-submit">Reserve My Mat</button>
          <p class="yog-form-note">By submitting you agree to our booking terms. First-class-free offer applies to new students only.</p>
        </form>
      </div>

    </div>
  </div>
</section>
<script>
(function(){
  /* ── Animated counters ────────────────────────────────────────── */
  const easeOut = t => 1 - Math.pow(1 - t, 3);
  document.querySelectorAll('.yog-counter').forEach(el => {
    const raw = el.dataset.target;
    if (!raw) return;
    const isFloat = raw.indexOf('.') !== -1;
    const target  = parseFloat(raw);
    if (isNaN(target)) return;
    let started = false;
    const obs = new IntersectionObserver(entries => {
      if (!entries[0].isIntersecting || started) return;
      started = true;
      obs.disconnect();
      const dur = 1800, start = performance.now();
      const tick = now => {
        const t   = Math.min((now - start) / dur, 1);
        const val = target * easeOut(t);
        el.textContent = isFloat ? val.toFixed(1) : Math.round(val).toLocaleString();
        if (t < 1) requestAnimationFrame(tick);
        else el.textContent = isFloat ? target.toFixed(1) : target.toLocaleString();
      };
      requestAnimationFrame(tick);
    }, {threshold: .3});
    obs.observe(el);
  });

  /* ── FAQ accordion ────────────────────────────────────────────── */
  document.querySelectorAll('.yog-faq-q').forEach(btn => {
    btn.addEventListener('click', () => {
      const item   = btn.closest('.yog-faq-item');
      const answer = item.querySelector('.yog-faq-a');
      const isOpen = item.classList.contains('open');
      /* close all */
      document.querySelectorAll('.yog-faq-item.open').forEach(op => {
        op.classList.remove('open');
        op.querySelector('.yog-faq-a').style.maxHeight = '0';
        op.querySelector('.yog-faq-q').setAttribute('aria-expanded','false');
      });
      if (!isOpen) {
        item.classList.add('open');
        answer.style.maxHeight = answer.scrollHeight + 'px';
        btn.setAttribute('aria-expanded','true');
      }
    });
  });
})();
</script>
</div><!-- .yog-page -->
<?php get_footer(); ?>
