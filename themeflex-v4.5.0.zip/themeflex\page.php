<?php
/**
 * Page Template — ThemeFlex
 * Dark-first. Handles all static pages (About, Services, Contact, Pricing, etc.)
 *
 * @package ThemeFlex
 * @since 1.3.0
 */
get_header(); ?>
<main id="primary" class="site-main tf-page-main">
<style>
.tf-page-main{
  padding:80px 0 110px;
  background:linear-gradient(180deg,#06021d 0%,#0d1526 100%);
  min-height:70vh;
  --tc:#ff5e2e;--title:#f1f5f9;--txt:#94a3b8;--meta:#64748b;
  --border:rgba(255,255,255,.07);--bg2:#111827;
}
</style>
<div class="container" style="max-width:1220px;margin:0 auto;padding:0 24px;">
  <?php do_action( 'themeflex_before_loop' ); ?>
  <?php if ( have_posts() ) :
    while ( have_posts() ) : the_post();
      get_template_part( 'template-parts/content', 'page' );
      if ( comments_open() || get_comments_number() ) :
        comments_template();
      endif;
    endwhile;
  else :
    get_template_part( 'template-parts/content', 'none' );
  endif; ?>
  <?php do_action( 'themeflex_after_loop' ); ?>
</div>
</main>
<?php get_footer(); ?>
