#!/usr/bin/env python3
"""
Starter Flavor Theme - Build Script
Minifies CSS and JS files with reporting
"""

import os
import sys
import subprocess
import json
from datetime import datetime

THEME_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSS_DIR = os.path.join(THEME_ROOT, 'assets', 'css')
JS_DIR = os.path.join(THEME_ROOT, 'assets', 'js')

def log(message, level='INFO'):
    """Log messages with timestamp"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    prefix = f'[{timestamp}] [{level}]'
    print(f'{prefix} {message}')

def run_command(cmd):
    """Execute shell command"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.returncode, result.stdout, result.stderr

def main():
    log('Starting Starter Flavor theme build process...', 'START')
    print('=' * 80)

    # Run CSS minification
    log('Minifying CSS files...', 'INFO')
    returncode, stdout, stderr = run_command(f'python3 {os.path.join(THEME_ROOT, "scripts", "minify-css.py")}')
    if returncode != 0:
        log(f'CSS minification failed: {stderr}', 'ERROR')
        return 1
    print(stdout)

    # Run JS minification
    log('Minifying JavaScript files...', 'INFO')
    returncode, stdout, stderr = run_command(f'python3 {os.path.join(THEME_ROOT, "scripts", "minify-js.py")}')
    if returncode != 0:
        log(f'JS minification failed: {stderr}', 'ERROR')
        return 1
    print(stdout)

    print('=' * 80)
    log('Build process completed successfully!', 'SUCCESS')
    return 0

if __name__ == '__main__':
    sys.exit(main())
