#!/usr/bin/env python3
"""
CSS Minification Script for Starter Flavor Theme
Strips comments, collapses whitespace, removes unnecessary characters
"""

import os
import re
import sys
from pathlib import Path
from datetime import datetime

THEME_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CSS_DIR = os.path.join(THEME_ROOT, 'assets', 'css')

def log(message, level='INFO'):
    """Log messages with timestamp"""
    timestamp = datetime.now().strftime('%H:%M:%S')
    print(f'[{timestamp}] [{level}] {message}')

def get_file_size(filepath):
    """Get file size in bytes"""
    return os.path.getsize(filepath) if os.path.exists(filepath) else 0

def format_size(size):
    """Format bytes to human readable"""
    for unit in ['B', 'KB', 'MB']:
        if size < 1024:
            return f'{size:.2f} {unit}'
        size /= 1024
    return f'{size:.2f} GB'

def minify_css(content):
    """
    Minify CSS content
    - Remove comments
    - Remove unnecessary whitespace
    - Remove line breaks
    - Collapse multiple spaces
    - Remove spaces around special characters
    """

    # Remove multi-line comments /* ... */
    content = re.sub(r'/\*[\s\S]*?\*/', '', content)

    # Remove single-line comments (though rare in CSS)
    content = re.sub(r'//.*?$', '', content, flags=re.MULTILINE)

    # Remove leading/trailing whitespace from each line
    lines = content.split('\n')
    lines = [line.strip() for line in lines]

    # Join lines and remove extra newlines
    content = ' '.join(lines)

    # Remove spaces around special characters
    content = re.sub(r'\s*{\s*', '{', content)
    content = re.sub(r'\s*}\s*', '}', content)
    content = re.sub(r'\s*:\s*', ':', content)
    content = re.sub(r'\s*;\s*', ';', content)
    content = re.sub(r'\s*,\s*', ',', content)
    content = re.sub(r'\s*>\s*', '>', content)
    content = re.sub(r'\s*\+\s*', '+', content)
    content = re.sub(r'\s*~\s*', '~', content)

    # Remove spaces between selectors and opening brace
    content = re.sub(r'\s*{', '{', content)

    # Remove trailing semicolon before closing brace
    content = re.sub(r';+}', '}', content)

    # Collapse multiple spaces
    content = re.sub(r'\s+', ' ', content)

    # Clean up
    content = content.strip()

    return content

def process_css_file(filepath):
    """Process single CSS file and create minified version"""

    if filepath.endswith('.min.css'):
        return None  # Skip already minified files

    base_path = filepath[:-4]  # Remove .css
    output_path = base_path + '.min.css'

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        original_size = len(content.encode('utf-8'))
        minified = minify_css(content)
        minified_size = len(minified.encode('utf-8'))

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(minified)

        reduction = 100 * (original_size - minified_size) / original_size if original_size > 0 else 0

        filename = os.path.basename(filepath)
        log(
            f'{filename:45} {format_size(original_size):>10} → {format_size(minified_size):>10} ({reduction:>5.1f}% reduction)',
            'MINIFY'
        )

        return {
            'file': filename,
            'original': original_size,
            'minified': minified_size,
            'reduction_percent': reduction
        }

    except Exception as e:
        log(f'Error processing {filepath}: {str(e)}', 'ERROR')
        return None

def main():
    """Main entry point"""

    if not os.path.isdir(CSS_DIR):
        log(f'CSS directory not found: {CSS_DIR}', 'ERROR')
        return 1

    log(f'Processing CSS files in {CSS_DIR}', 'START')
    print('-' * 80)

    # Find all .css files (excluding .min.css)
    css_files = sorted([
        f for f in Path(CSS_DIR).glob('*.css')
        if not f.name.endswith('.min.css')
    ])

    if not css_files:
        log('No CSS files found to minify', 'WARN')
        return 0

    total_original = 0
    total_minified = 0
    processed = 0

    for css_file in css_files:
        result = process_css_file(str(css_file))
        if result:
            total_original += result['original']
            total_minified += result['minified']
            processed += 1

    print('-' * 80)

    if processed > 0:
        total_reduction = 100 * (total_original - total_minified) / total_original if total_original > 0 else 0
        log(
            f'Total: {format_size(total_original):>10} → {format_size(total_minified):>10} ({total_reduction:>5.1f}% reduction) - {processed} files',
            'SUMMARY'
        )
    else:
        log('No CSS files were processed', 'WARN')

    return 0

if __name__ == '__main__':
    sys.exit(main())
