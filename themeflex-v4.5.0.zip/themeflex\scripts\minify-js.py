#!/usr/bin/env python3
"""
JavaScript Minification Script for Starter Flavor Theme
Strips comments, collapses whitespace, removes unnecessary characters
Safe minification - no variable renaming to avoid breaking WordPress globals
"""

import os
import re
import sys
from pathlib import Path
from datetime import datetime

THEME_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JS_DIR = os.path.join(THEME_ROOT, 'assets', 'js')

def log(message, level='INFO'):
    """Log messages with timestamp"""
    timestamp = datetime.now().strftime('%H:%M:%S')
    print(f'[{timestamp}] [{level}] {message}')

def get_file_size(filepath):
    """Get file size in bytes"""
    return os.path.getsize(filepath) if os.path.exists(filepath) else 0

def format_size(size):
    """Format bytes to human readable"""
    for unit in ['B', 'KB', 'MB']:
        if size < 1024:
            return f'{size:.2f} {unit}'
        size /= 1024
    return f'{size:.2f} GB'

def minify_js(content):
    """
    Minify JavaScript content
    Safe minification that preserves WordPress globals and function names
    - Remove comments (// and /* */)
    - Remove unnecessary whitespace
    - Collapse multiple spaces
    - Remove line breaks where safe
    """

    # Remove multi-line comments /* ... */
    content = re.sub(r'/\*[\s\S]*?\*/', '', content)

    # Remove single-line comments but preserve others
    lines = content.split('\n')
    processed_lines = []

    for line in lines:
        # Remove single-line comments (preserve URLs in comments)
        if '//' in line:
            # Find the position of //
            idx = line.find('//')
            # Check if it's not in a string
            in_string = False
            quote_char = None
            for i, char in enumerate(line[:idx]):
                if char in ('"', "'") and (i == 0 or line[i-1] != '\\'):
                    if not in_string:
                        in_string = True
                        quote_char = char
                    elif char == quote_char:
                        in_string = False
            if not in_string:
                line = line[:idx].rstrip()
        processed_lines.append(line)

    content = '\n'.join(processed_lines)

    # Remove leading/trailing whitespace from each line
    lines = content.split('\n')
    lines = [line.strip() for line in lines if line.strip()]
    content = '\n'.join(lines)

    # Remove empty lines
    content = re.sub(r'\n\s*\n', '\n', content)

    # Replace newlines with space (but preserve necessary ones)
    content = re.sub(r'\n\s*', ' ', content)

    # Remove spaces around operators and punctuation (carefully)
    content = re.sub(r'\s*{\s*', '{', content)
    content = re.sub(r'\s*}\s*', '}', content)
    content = re.sub(r'\s*:\s*', ':', content)
    content = re.sub(r'\s*;\s*', ';', content)
    content = re.sub(r'\s*,\s*', ',', content)

    # Remove space before opening parenthesis in function calls
    content = re.sub(r'\s+\(', '(', content)

    # Remove spaces around = (except in comments which are already gone)
    content = re.sub(r'\s*=\s*', '=', content)

    # Collapse multiple spaces
    content = re.sub(r' +', ' ', content)

    # Remove semicolon before closing brace
    content = re.sub(r';+}', '}', content)

    # Clean up
    content = content.strip()

    return content

def process_js_file(filepath):
    """Process single JavaScript file and create minified version"""

    if filepath.endswith('.min.js'):
        return None  # Skip already minified files

    base_path = filepath[:-3]  # Remove .js
    output_path = base_path + '.min.js'

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()

        original_size = len(content.encode('utf-8'))
        minified = minify_js(content)
        minified_size = len(minified.encode('utf-8'))

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(minified)

        reduction = 100 * (original_size - minified_size) / original_size if original_size > 0 else 0

        filename = os.path.basename(filepath)
        log(
            f'{filename:45} {format_size(original_size):>10} → {format_size(minified_size):>10} ({reduction:>5.1f}% reduction)',
            'MINIFY'
        )

        return {
            'file': filename,
            'original': original_size,
            'minified': minified_size,
            'reduction_percent': reduction
        }

    except Exception as e:
        log(f'Error processing {filepath}: {str(e)}', 'ERROR')
        return None

def main():
    """Main entry point"""

    if not os.path.isdir(JS_DIR):
        log(f'JavaScript directory not found: {JS_DIR}', 'ERROR')
        return 1

    log(f'Processing JavaScript files in {JS_DIR}', 'START')
    print('-' * 80)

    # Find all .js files (excluding .min.js)
    js_files = sorted([
        f for f in Path(JS_DIR).glob('*.js')
        if not f.name.endswith('.min.js')
    ])

    if not js_files:
        log('No JavaScript files found to minify', 'WARN')
        return 0

    total_original = 0
    total_minified = 0
    processed = 0

    for js_file in js_files:
        result = process_js_file(str(js_file))
        if result:
            total_original += result['original']
            total_minified += result['minified']
            processed += 1

    print('-' * 80)

    if processed > 0:
        total_reduction = 100 * (total_original - total_minified) / total_original if total_original > 0 else 0
        log(
            f'Total: {format_size(total_original):>10} → {format_size(total_minified):>10} ({total_reduction:>5.1f}% reduction) - {processed} files',
            'SUMMARY'
        )
    else:
        log('No JavaScript files were processed', 'WARN')

    return 0

if __name__ == '__main__':
    sys.exit(main())
