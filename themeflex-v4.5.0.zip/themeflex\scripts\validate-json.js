#!/usr/bin/env node

/**
 * JSON Template Validator
 * Validates all Elementor templates are valid JSON with required keys
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const TEMPLATES_DIR = path.join(__dirname, '../elementor-templates');

// Three template formats supported:
// Format 1: { title, type, content }
// Format 2: { version, title, elements, elementor_version?, description? }
// Format 3: { title, type, sections }
const REQUIRED_KEYS_FORMAT1 = ['title', 'type', 'content'];
const REQUIRED_KEYS_FORMAT2 = ['version', 'title', 'elements'];
const REQUIRED_KEYS_FORMAT3 = ['title', 'type', 'sections'];
const VALID_TYPES = ['page', 'section', 'template'];

let passCount = 0;
let failCount = 0;
const errors = [];

console.log('🔍 Validating Elementor Templates JSON...\n');

// Read all JSON files
const files = fs.readdirSync(TEMPLATES_DIR).filter(f => f.endsWith('.json'));

console.log(`Found ${files.length} template files\n`);

files.forEach((file) => {
	const filePath = path.join(TEMPLATES_DIR, file);

	try {
		// Read file
		const content = fs.readFileSync(filePath, 'utf8');

		// Parse JSON
		let template;
		try {
			template = JSON.parse(content);
		} catch (parseError) {
			errors.push(`❌ ${file}: Invalid JSON - ${parseError.message}`);
			failCount++;
			return;
		}

		// Template must have a title
		if (!('title' in template)) {
			errors.push(`❌ ${file}: Missing required 'title' field`);
			failCount++;
			return;
		}

		// Validate title is non-empty string
		if (typeof template.title !== 'string' || template.title.trim() === '') {
			errors.push(`❌ ${file}: Title must be a non-empty string`);
			failCount++;
			return;
		}

		// Template must have content in one of these forms: content, elements, sections, or pages
		const hasContent = template.content !== undefined && template.content !== null;
		const hasElements = template.elements !== undefined && template.elements !== null;
		const hasSections = template.sections !== undefined && template.sections !== null;
		const hasPages = template.pages !== undefined && template.pages !== null;

		if (!hasContent && !hasElements && !hasSections && !hasPages) {
			errors.push(`❌ ${file}: Must have one of: 'content' (array/string), 'elements' (array), 'sections' (array), or 'pages' (array)`);
			failCount++;
			return;
		}

		// Validate that content arrays/strings are not empty
		if (hasContent) {
			if ((Array.isArray(template.content) && template.content.length === 0) ||
				(typeof template.content === 'string' && template.content.trim() === '')) {
				errors.push(`❌ ${file}: 'content' cannot be empty`);
				failCount++;
				return;
			}
		}

		if (hasElements && (!Array.isArray(template.elements) || template.elements.length === 0)) {
			errors.push(`❌ ${file}: 'elements' must be a non-empty array`);
			failCount++;
			return;
		}

		if (hasSections && (!Array.isArray(template.sections) || template.sections.length === 0)) {
			errors.push(`❌ ${file}: 'sections' must be a non-empty array`);
			failCount++;
			return;
		}

		if (hasPages && (!Array.isArray(template.pages) || template.pages.length === 0)) {
			errors.push(`❌ ${file}: 'pages' must be a non-empty array`);
			failCount++;
			return;
		}

		passCount++;
		console.log(`✓ ${file}`);

	} catch (error) {
		errors.push(`❌ ${file}: ${error.message}`);
		failCount++;
	}
});

console.log(`\n${'='.repeat(50)}`);
console.log(`Results: ${passCount} passed, ${failCount} failed\n`);

if (errors.length > 0) {
	console.log('Errors:\n');
	errors.forEach(error => console.log(error));
	console.log();
	process.exit(1);
} else {
	console.log('✅ All templates are valid!\n');
	process.exit(0);
}
