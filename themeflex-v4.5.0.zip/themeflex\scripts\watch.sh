#!/bin/bash
# Watch script for Starter Flavor Theme
# Monitors CSS and JS files and runs build on changes

THEME_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CSS_DIR="$THEME_ROOT/assets/css"
JS_DIR="$THEME_ROOT/assets/js"
BUILD_SCRIPT="$THEME_ROOT/scripts/build.py"

echo "Watching Starter Flavor theme assets for changes..."
echo "Press Ctrl+C to stop watching"
echo ""
echo "Watching directories:"
echo "  CSS: $CSS_DIR"
echo "  JS:  $JS_DIR"
echo ""

# Check if inotifywait is available (Linux)
if command -v inotifywait &> /dev/null; then
    echo "Using inotifywait for monitoring..."
    inotifywait -m -r -e modify "$CSS_DIR" "$JS_DIR" |
    while read -r path action file; do
        if [[ "$file" != *.min.* ]]; then
            echo ""
            echo ">>> Change detected: $file"
            python3 "$BUILD_SCRIPT"
        fi
    done

# Check if fswatch is available (macOS)
elif command -v fswatch &> /dev/null; then
    echo "Using fswatch for monitoring..."
    fswatch -r "$CSS_DIR" "$JS_DIR" |
    while read -r file; do
        if [[ "$file" != *.min.* ]]; then
            echo ""
            echo ">>> Change detected: $file"
            python3 "$BUILD_SCRIPT"
        fi
    done

# Fallback: basic polling
else
    echo "Using polling for monitoring (less efficient)..."
    echo "Install inotifywait (Linux) or fswatch (macOS) for better performance"
    echo ""

    declare -A file_times

    # Initialize file times
    for file in "$CSS_DIR"/*.css "$JS_DIR"/*.js; do
        if [[ -f "$file" && ! "$file" == *.min.* ]]; then
            file_times["$file"]=$(stat -c %Y "$file" 2>/dev/null || stat -f %m "$file" 2>/dev/null)
        fi
    done

    while true; do
        sleep 2

        for file in "$CSS_DIR"/*.css "$JS_DIR"/*.js; do
            if [[ -f "$file" && ! "$file" == *.min.* ]]; then
                current_time=$(stat -c %Y "$file" 2>/dev/null || stat -f %m "$file" 2>/dev/null)

                if [[ -z "${file_times[$file]}" ]] || [[ ${file_times[$file]} -ne $current_time ]]; then
                    echo ""
                    echo ">>> Change detected: $(basename "$file")"
                    python3 "$BUILD_SCRIPT"
                    file_times["$file"]=$current_time
                fi
            fi
        done
    done
fi
