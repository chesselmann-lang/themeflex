<?php
/**
 * Search Results Template
 *
 * @package ThemeFlex
 * @since   2.0.0
 */

get_header();
?>
<style>
/* ── Search Page — Dark-first ───────────────────────────────────────── */
.tf-search-page{
  padding:80px 0 110px;
  background:linear-gradient(180deg,#06021d 0%,#0d1526 100%);
  min-height:70vh;
  --tc:#ff5e2e;
  --bg2:#111827;--bg3:#0d1526;
  --border:rgba(255,255,255,.07);
  --title:#f1f5f9;--txt:#94a3b8;--meta:#64748b;
}
.tf-search-page .tf-container{max-width:1220px;margin:0 auto;padding:0 24px}
/* Header */
.tf-search-header{margin-bottom:8px}
.tf-search-count{font-size:.8rem;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--tc);margin-bottom:10px}
.tf-search-title{font-family:'Inter Tight',sans-serif;font-size:clamp(28px,4vw,44px);font-weight:900;color:var(--title);margin:0 0 40px;letter-spacing:-.4px;line-height:1.15}
.tf-search-query{color:var(--tc)}
/* Refine bar */
.tf-search-refine{display:flex;align-items:center;gap:16px;margin-bottom:48px;padding:16px 20px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:14px;flex-wrap:wrap}
.tf-search-refine-label{font-size:.8rem;font-weight:700;color:var(--meta);text-transform:uppercase;letter-spacing:.06em;white-space:nowrap}
.tf-search-refine-form{display:flex;gap:8px;flex:1;min-width:240px}
.tf-search-input{flex:1;padding:10px 16px;background:rgba(255,255,255,.06);border:1px solid var(--border);border-radius:10px;font-size:14px;color:var(--title);font-family:inherit;outline:none;transition:border-color .2s}
.tf-search-input:focus{border-color:var(--tc)}
.tf-search-input::placeholder{color:var(--meta)}
.tf-search-page .tf-btn-primary{padding:10px 20px;background:#ff5e2e;color:#fff;border:none;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit;transition:opacity .2s;white-space:nowrap}
.tf-search-page .tf-btn-primary:hover{opacity:.88}
/* Result items */
.tf-search-results{display:flex;flex-direction:column;gap:20px}
.tf-search-item{display:flex;gap:20px;background:var(--bg2);border:1px solid var(--border);border-radius:14px;overflow:hidden;transition:border-color .3s,transform .3s}
.tf-search-item:hover{border-color:rgba(255,94,46,.3);transform:translateX(4px)}
.tf-search-item__thumb{flex-shrink:0;width:120px}
.tf-search-item__img{width:120px;height:100%;object-fit:cover;display:block}
.tf-search-item__body{padding:18px 20px 18px 0;flex:1;display:flex;flex-direction:column;justify-content:center}
.tf-search-item:not(:has(.tf-search-item__thumb)) .tf-search-item__body{padding-left:20px}
.tf-search-item__type{font-size:.68rem;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--tc);margin-bottom:6px}
.tf-search-item__title{font-family:'Inter Tight',sans-serif;font-size:1.1rem;font-weight:800;color:var(--title);margin:0 0 8px;line-height:1.3}
.tf-search-item__link{color:inherit;text-decoration:none;transition:color .2s}
.tf-search-item__link:hover{color:var(--tc)}
.tf-search-item__excerpt{font-size:.875rem;color:var(--meta);line-height:1.6;margin:0 0 8px}
.tf-search-item__meta{font-size:.75rem;color:var(--meta);margin:0}
/* Pagination */
.tf-search-pagination{margin-top:56px;display:flex;justify-content:center;gap:6px}
.tf-search-pagination .page-numbers{display:inline-flex;align-items:center;justify-content:center;min-width:42px;height:42px;border-radius:10px;border:1px solid var(--border);color:var(--txt);text-decoration:none;font-size:.875rem;font-weight:600;transition:all .22s;padding:0 12px}
.tf-search-pagination .page-numbers:hover,.tf-search-pagination .page-numbers.current{background:var(--tc);color:#fff;border-color:var(--tc)}
/* Empty state */
.tf-search-empty{text-align:center;padding:80px 24px}
.tf-search-empty__icon{font-size:4rem;display:block;margin-bottom:20px}
.tf-search-empty__title{font-family:'Inter Tight',sans-serif;font-size:clamp(24px,4vw,36px);font-weight:800;color:var(--title);margin:0 0 14px}
.tf-search-empty__text{font-size:17px;color:var(--txt);line-height:1.7;margin-bottom:32px;max-width:460px;margin-left:auto;margin-right:auto}
.tf-search-empty .search-form{max-width:440px;margin:0 auto;display:flex;gap:8px}
.tf-search-empty .search-field{flex:1;padding:13px 18px;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:12px;font-size:15px;color:var(--title);font-family:inherit;outline:none}
.tf-search-empty .search-field:focus{border-color:var(--tc)}
.tf-search-empty .search-submit{padding:13px 22px;background:#ff5e2e;color:#fff;border:none;border-radius:12px;font-weight:700;font-size:14px;cursor:pointer;font-family:inherit}
@media(max-width:640px){.tf-search-item__thumb{display:none}.tf-search-item__body{padding:16px}}
</style>
<main id="primary" class="site-main tf-search-page">
	<div class="tf-container">

		<?php if ( have_posts() ) : ?>

			<header class="tf-search-header">
				<p class="tf-search-count">
					<?php
					printf(
						/* translators: %d: number of results */
						esc_html( _n( '%d Result', '%d Results', (int) $wp_query->found_posts, 'themeflex' ) ),
						(int) $wp_query->found_posts
					);
					?>
				</p>
				<h1 class="tf-search-title">
					<?php
					printf(
						/* translators: %s: search query */
						esc_html__( 'Search: %s', 'themeflex' ),
						'<span class="tf-search-query">' . esc_html( get_search_query() ) . '</span>'
					);
					?>
				</h1>
			</header>

			<div class="tf-search-refine">
				<span class="tf-search-refine-label"><?php esc_html_e( 'Refine:', 'themeflex' ); ?></span>
				<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="tf-search-refine-form">
					<input
						type="search"
						name="s"
						class="tf-search-input"
						value="<?php echo esc_attr( get_search_query() ); ?>"
						placeholder="<?php esc_attr_e( 'Search&hellip;', 'themeflex' ); ?>"
					/>
					<button type="submit" class="tf-btn tf-btn-primary">
						<?php esc_html_e( 'Search', 'themeflex' ); ?>
					</button>
				</form>
			</div>

			<div class="tf-search-results">

				<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class( 'tf-search-item' ); ?>>

					<?php if ( has_post_thumbnail() ) : ?>
					<a href="<?php the_permalink(); ?>" class="tf-search-item__thumb" tabindex="-1" aria-hidden="true">
						<?php the_post_thumbnail( 'thumbnail', array( 'class' => 'tf-search-item__img' ) ); ?>
					</a>
					<?php endif; ?>

					<div class="tf-search-item__body">
						<p class="tf-search-item__type">
							<?php
							$post_type_obj = get_post_type_object( get_post_type() );
							if ( $post_type_obj && isset( $post_type_obj->labels->singular_name ) ) {
								echo esc_html( $post_type_obj->labels->singular_name );
							}
							?>
						</p>
						<h2 class="tf-search-item__title">
							<a href="<?php the_permalink(); ?>" class="tf-search-item__link">
								<?php the_title(); ?>
							</a>
						</h2>
						<p class="tf-search-item__excerpt">
							<?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 20, '&hellip;' ) ); ?>
						</p>
						<p class="tf-search-item__meta">
							<?php the_date(); ?>
							<?php esc_html_e( 'by', 'themeflex' ); ?>
							<?php the_author(); ?>
						</p>
					</div>

				</article>

				<?php endwhile; ?>

			</div><!-- .tf-search-results -->

			<nav class="tf-search-pagination">
				<?php
				the_posts_pagination( array(
					'mid_size'  => 2,
					'prev_text' => '&larr; ' . esc_html__( 'Prev', 'themeflex' ),
					'next_text' => esc_html__( 'Next', 'themeflex' ) . ' &rarr;',
				) );
				?>
			</nav>

		<?php else : ?>

			<div class="tf-search-empty">
				<span class="tf-search-empty__icon" aria-hidden="true">&#x1F50D;</span>
				<h1 class="tf-search-empty__title">
					<?php esc_html_e( 'No results found', 'themeflex' ); ?>
				</h1>
				<p class="tf-search-empty__text">
					<?php esc_html_e( "We couldn't find anything matching your search. Try different keywords.", 'themeflex' ); ?>
				</p>
				<?php get_search_form(); ?>
			</div>

		<?php endif; ?>

	</div><!-- .tf-container -->
</main><!-- #primary -->

<?php get_footer(); ?>
