<?php
/**
 * Template for displaying search forms
 *
 * @package ThemeFlex
 * @since   2.0.0
 */

$unique_id = esc_attr( uniqid( 'search-form-' ) );
?>
<form role="search" method="get" class="tf-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo $unique_id; ?>">
		<?php esc_html_e( 'Search for:', 'themeflex' ); ?>
	</label>
	<div class="tf-search-form__inner">
		<input
			type="search"
			id="<?php echo $unique_id; ?>"
			class="tf-search-form__field"
			name="s"
			value="<?php echo esc_attr( get_search_query() ); ?>"
			placeholder="<?php esc_attr_e( 'Search&hellip;', 'themeflex' ); ?>"
		/>
		<button type="submit" class="tf-search-form__submit tf-btn tf-btn-primary">
			<span class="screen-reader-text"><?php esc_html_e( 'Search', 'themeflex' ); ?></span>
			<svg aria-hidden="true" focusable="false" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
				<circle cx="11" cy="11" r="8"></circle>
				<line x1="21" y1="21" x2="16.65" y2="16.65"></line>
			</svg>
		</button>
	</div>
</form>
