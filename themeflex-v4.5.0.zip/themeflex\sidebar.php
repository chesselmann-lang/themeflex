<?php
/**
 * The sidebar containing the main widget area
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! is_active_sidebar( 'main-sidebar' ) ) {
	return;
}

?>
<aside id="site-sidebar" class="site-sidebar sidebar" role="complementary" aria-label="<?php esc_attr_e( 'Primary Sidebar', 'themeflex' ); ?>">
	<div class="sidebar-content">
		<?php dynamic_sidebar( 'main-sidebar' ); ?>
	</div>
</aside><!-- #site-sidebar -->
