<?php
/**
 * Single Portfolio Project — ThemeFlex
 *
 * Dark-first project detail page with:
 *  - Full-width hero with featured image or gradient fallback
 *  - Project meta sidebar (client, year, categories, tags, URL, tech stack)
 *  - Rich content area with wide/full-width image support
 *  - "More Projects" related grid (3 items)
 *  - Prev / Next project navigation
 *  - CTA strip at bottom
 *
 * No Elementor dependency — fully standalone.
 *
 * @package ThemeFlex
 * @since 1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header(); ?>

<main id="primary" class="tf-spf-main">
<style>
/* ── Single Portfolio — Dark-first ─────────────────────────── */
.tf-spf-main {
  --tc:    #ff5e2e;
  --tc2:   #00d4ff;
  --bg:    #06021d;
  --bg2:   #0d1526;
  --bg3:   #111827;
  --border: rgba(255,255,255,.07);
  --title: #f1f5f9;
  --txt:   #94a3b8;
  --meta:  #64748b;
  background: var(--bg);
  min-height: 100vh;
}

/* ── Back link ───────────────────────────────────────────── */
.tf-spf-back {
  display: inline-flex; align-items: center; gap: 8px;
  color: var(--meta); font-size: .85rem; text-decoration: none;
  padding: 24px 24px 0; max-width: 1240px; margin: 0 auto; display: flex;
  transition: color .2s;
}
.tf-spf-back:hover { color: var(--tc); }
.tf-spf-back-wrap { max-width: 1240px; margin: 0 auto; padding: 24px 24px 0; }

/* ── Hero ─────────────────────────────────────────────────── */
.tf-spf-hero {
  position: relative;
  aspect-ratio: 21/9;
  overflow: hidden;
  background: linear-gradient(135deg, #0d1526, #111827);
  margin: 24px 0 0;
}
.tf-spf-hero img {
  width: 100%; height: 100%; object-fit: cover;
  position: absolute; inset: 0;
}
.tf-spf-hero-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(6,2,29,.85) 0%, rgba(6,2,29,.3) 50%, transparent 100%);
}
.tf-spf-hero-content {
  position: absolute; bottom: 0; left: 0; right: 0;
  max-width: 1240px; margin: 0 auto;
  padding: 48px 24px;
}
.tf-spf-cat-pill {
  display: inline-block; padding: 4px 14px; border-radius: 100px;
  background: rgba(255,94,46,.15); border: 1px solid rgba(255,94,46,.3);
  color: var(--tc); font-size: .7rem; font-weight: 700; letter-spacing: .08em;
  text-transform: uppercase; margin-bottom: 16px; text-decoration: none;
}
.tf-spf-hero h1 {
  font-size: clamp(1.8rem, 4vw, 3.2rem);
  font-weight: 900; color: var(--title); margin: 0 0 12px; line-height: 1.15;
  max-width: 720px;
}
.tf-spf-hero-sub {
  font-size: 1.1rem; color: var(--txt); max-width: 600px;
}

/* ── No image fallback hero ───────────────────────────────── */
.tf-spf-hero-fallback {
  display: flex; align-items: center; justify-content: center;
}
.tf-spf-hero-fallback-inner { display:flex; align-items:center; justify-content:center; width:80px; height:80px; }
.tf-spf-hero-fallback-inner svg { width:56px; height:56px; }

/* ── Content + Sidebar layout ─────────────────────────────── */
.tf-spf-body {
  max-width: 1240px; margin: 0 auto; padding: 64px 24px 100px;
  display: grid; grid-template-columns: 1fr 340px; gap: 60px;
}

/* ── Article content ──────────────────────────────────────── */
.tf-spf-content { min-width: 0; }
.tf-spf-content h2, .tf-spf-content h3, .tf-spf-content h4 {
  color: var(--title); font-weight: 800; line-height: 1.25; margin: 36px 0 14px;
}
.tf-spf-content h2 { font-size: 1.6rem; }
.tf-spf-content h3 { font-size: 1.25rem; }
.tf-spf-content p  { color: var(--txt); font-size: 1.025rem; line-height: 1.75; margin: 0 0 18px; }
.tf-spf-content a  { color: var(--tc); text-decoration: underline; text-underline-offset: 3px; }
.tf-spf-content a:hover { color: #ff8c5a; }
.tf-spf-content ul, .tf-spf-content ol {
  color: var(--txt); padding-left: 22px; margin: 0 0 18px; line-height: 1.75;
}
.tf-spf-content blockquote {
  border-left: 3px solid var(--tc); margin: 32px 0;
  padding: 16px 24px;
  background: rgba(255,94,46,.06); border-radius: 0 12px 12px 0;
  color: var(--txt); font-style: italic;
}
.tf-spf-content img {
  width: 100%; border-radius: 12px; margin: 24px 0;
  border: 1px solid var(--border);
}
.tf-spf-content figure { margin: 28px 0; }
.tf-spf-content figcaption {
  text-align: center; font-size: .8rem; color: var(--meta); margin-top: 8px;
}
.tf-spf-content pre {
  background: #0d1526; border: 1px solid var(--border);
  border-radius: 10px; padding: 20px; overflow-x: auto;
  font-size: .875rem; line-height: 1.6; color: #67e8f9;
}
.tf-spf-content code {
  background: rgba(255,255,255,.06); padding: 2px 6px;
  border-radius: 4px; font-size: .875em; color: #fda4af;
}

/* ── Sidebar ──────────────────────────────────────────────── */
.tf-spf-sidebar { }
.tf-spf-meta-card {
  background: var(--bg3); border: 1px solid var(--border);
  border-radius: 18px; padding: 28px; position: sticky; top: 100px;
}
.tf-spf-meta-card h3 {
  font-size: .72rem; font-weight: 800; color: var(--title);
  letter-spacing: .1em; text-transform: uppercase; margin: 0 0 22px;
}
.tf-spf-meta-row {
  display: flex; justify-content: space-between; align-items: flex-start;
  gap: 12px; padding: 12px 0;
  border-bottom: 1px solid var(--border);
}
.tf-spf-meta-row:last-child { border-bottom: none; }
.tf-spf-meta-label { font-size: .78rem; color: var(--meta); font-weight: 600; flex-shrink: 0; }
.tf-spf-meta-value { font-size: .88rem; color: var(--txt); text-align: right; }
.tf-spf-meta-value a { color: var(--tc); text-decoration: none; }
.tf-spf-meta-value a:hover { text-decoration: underline; }

/* Live URL button */
.tf-spf-live-btn {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  margin-top: 22px; padding: 12px 20px; border-radius: 12px;
  background: var(--tc); color: #fff; font-size: .85rem; font-weight: 700;
  text-decoration: none; transition: background .2s;
}
.tf-spf-live-btn:hover { background: #e04e22; }

/* Tags */
.tf-spf-tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 18px; }
.tf-spf-tag {
  padding: 4px 12px; border-radius: 20px; font-size: .7rem; font-weight: 600;
  background: rgba(255,255,255,.05); border: 1px solid var(--border); color: var(--meta);
}

/* ── Related projects ─────────────────────────────────────── */
.tf-spf-related {
  max-width: 1240px; margin: 0 auto; padding: 0 24px 100px;
  border-top: 1px solid var(--border); padding-top: 72px;
}
.tf-spf-related h2 {
  font-size: 1.5rem; font-weight: 800; color: var(--title); margin: 0 0 36px;
}
.tf-spf-related-grid {
  display: grid; grid-template-columns: repeat(3,1fr); gap: 24px;
}
.tf-spf-rel-card {
  border-radius: 14px; overflow: hidden; background: var(--bg3);
  border: 1px solid var(--border); text-decoration: none;
  transition: transform .3s, box-shadow .3s; display: block;
}
.tf-spf-rel-card:hover { transform: translateY(-5px); box-shadow: 0 20px 40px rgba(0,0,0,.4); }
.tf-spf-rel-thumb {
  aspect-ratio: 16/10; background: linear-gradient(135deg,#1e293b,#0f172a);
  display: flex; align-items: center; justify-content: center;
  position: relative; overflow: hidden;
}
.tf-spf-rel-thumb-icon { width:40px; height:40px; display:flex; align-items:center; justify-content:center; }
.tf-spf-rel-thumb-icon svg { width:28px; height:28px; }
.tf-spf-rel-thumb img { width:100%;height:100%;object-fit:cover;position:absolute;inset:0; }
.tf-spf-rel-body { padding: 16px 20px 20px; }
.tf-spf-rel-cat { font-size: .65rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--tc); margin-bottom: 6px; }
.tf-spf-rel-title { font-size: .95rem; font-weight: 700; color: var(--title); margin: 0; }

/* ── Prev / Next nav ──────────────────────────────────────── */
.tf-spf-nav {
  max-width: 1240px; margin: 0 auto; padding: 0 24px 80px;
  display: grid; grid-template-columns: 1fr 1fr; gap: 20px;
}
.tf-spf-nav-card {
  border-radius: 14px; border: 1px solid var(--border);
  background: var(--bg3); padding: 20px 24px; text-decoration: none;
  display: flex; flex-direction: column; gap: 8px; transition: border-color .2s;
}
.tf-spf-nav-card:hover { border-color: rgba(255,94,46,.3); }
.tf-spf-nav-label { font-size: .7rem; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; color: var(--meta); }
.tf-spf-nav-title { font-size: .95rem; font-weight: 700; color: var(--title); }
.tf-spf-nav-card.next { text-align: right; }

/* ── CTA strip ────────────────────────────────────────────── */
.tf-spf-cta {
  background: linear-gradient(135deg, rgba(255,94,46,.12), rgba(0,212,255,.06));
  border-top: 1px solid rgba(255,94,46,.15);
  text-align: center; padding: 72px 24px;
}
.tf-spf-cta h2 { font-size: 1.8rem; font-weight: 800; color: var(--title); margin: 0 0 12px; }
.tf-spf-cta p  { color: var(--txt); font-size: 1.05rem; margin: 0 0 32px; }
.tf-spf-cta-btn {
  display: inline-flex; align-items: center; gap: 10px;
  background: var(--tc); color: #fff; font-size: .95rem; font-weight: 700;
  padding: 15px 38px; border-radius: 100px; text-decoration: none;
  transition: background .2s, transform .2s;
}
.tf-spf-cta-btn:hover { background: #e04e22; transform: translateY(-2px); }

/* ── Responsive ───────────────────────────────────────────── */
@media(max-width:1024px) {
  .tf-spf-body { grid-template-columns: 1fr; gap: 40px; }
  .tf-spf-meta-card { position: static; }
  .tf-spf-related-grid { grid-template-columns: repeat(2,1fr); }
}
@media(max-width:640px) {
  .tf-spf-hero { aspect-ratio: 4/3; }
  .tf-spf-related-grid { grid-template-columns: 1fr; }
  .tf-spf-nav { grid-template-columns: 1fr; }
}
</style>

<?php while ( have_posts() ) : the_post();
  $cats     = wp_get_post_terms( get_the_ID(), 'sf_portfolio_cat' );
  $cat      = ( ! empty( $cats ) && ! is_wp_error( $cats ) ) ? $cats[0] : null;
  $tags     = wp_get_post_terms( get_the_ID(), 'sf_portfolio_tag' );
  $excerpt  = get_the_excerpt();

  /* Custom fields saved by class-portfolio.php meta box */
  $client   = get_post_meta( get_the_ID(), '_sf_client',       true );
  $year     = get_post_meta( get_the_ID(), '_sf_year',         true );
  $url      = get_post_meta( get_the_ID(), '_sf_project_url',  true );
  $role     = get_post_meta( get_the_ID(), '_sf_role',         true ); // optional, not in default meta box
  $tech     = get_post_meta( get_the_ID(), '_sf_services',     true ); // comma-separated (maps to "Services" field)

  /* SVG icon fallback by category */
  $_spf_svgs = array(
    'monitor'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    'cart'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
    'palette'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>',
    'phone'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>',
    'barchart' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
    'rocket'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',
    'coffee'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/></svg>',
    'camera'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>',
    'home'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
    'dollar'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
    'layers'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
    'star'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  );
  $emoji_map = array(
    'web-design'  => array('s'=>$_spf_svgs['monitor'], 'c'=>'rgba(99,102,241,.7)'),
    'e-commerce'  => array('s'=>$_spf_svgs['cart'],    'c'=>'rgba(234,179,8,.75)'),
    'branding'    => array('s'=>$_spf_svgs['palette'], 'c'=>'rgba(249,115,22,.75)'),
    'mobile-app'  => array('s'=>$_spf_svgs['phone'],   'c'=>'rgba(34,211,238,.75)'),
    'saas'        => array('s'=>$_spf_svgs['barchart'],'c'=>'rgba(16,185,129,.75)'),
    'landing-page'=> array('s'=>$_spf_svgs['rocket'],  'c'=>'rgba(255,94,46,.75)'),
    'restaurant'  => array('s'=>$_spf_svgs['coffee'],  'c'=>'rgba(217,119,6,.75)'),
    'photography' => array('s'=>$_spf_svgs['camera'],  'c'=>'rgba(139,92,246,.75)'),
    'fintech'     => array('s'=>$_spf_svgs['dollar'],  'c'=>'rgba(52,211,153,.75)'),
    'nft'         => array('s'=>$_spf_svgs['layers'],  'c'=>'rgba(168,85,247,.75)'),
  );
  $_spf_default = array('s'=>$_spf_svgs['star'],'c'=>'rgba(255,94,46,.7)');
  $_spf_entry   = $cat ? ( $emoji_map[ $cat->slug ] ?? $_spf_default ) : $_spf_default;
  $_spf_icon    = $_spf_entry['s'];
  $_spf_color   = $_spf_entry['c'];
?>

<!-- Back link -->
<div class="tf-spf-back-wrap">
  <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>" class="tf-spf-back">
    ← <?php esc_html_e( 'All Projects', 'themeflex' ); ?>
  </a>
</div>

<!-- ── Hero ─────────────────────────────────────────────────── -->
<div class="tf-spf-hero<?php echo has_post_thumbnail() ? '' : ' tf-spf-hero-fallback'; ?>">
  <?php if ( has_post_thumbnail() ) : ?>
    <?php the_post_thumbnail( 'full' ); ?>
    <div class="tf-spf-hero-overlay"></div>
    <div class="tf-spf-hero-content">
      <?php if ( $cat ) : ?>
        <a class="tf-spf-cat-pill" href="<?php echo esc_url( get_term_link( $cat ) ); ?>">
          <?php echo esc_html( $cat->name ); ?>
        </a>
      <?php endif; ?>
      <h1><?php the_title(); ?></h1>
      <?php if ( $excerpt ) : ?>
        <p class="tf-spf-hero-sub"><?php echo esc_html( $excerpt ); ?></p>
      <?php endif; ?>
    </div>
  <?php else : ?>
    <div class="tf-spf-hero-fallback-inner" style="color:<?php echo esc_attr($_spf_color); ?>" aria-hidden="true"><?php echo $_spf_icon; ?></div>
  <?php endif; ?>
</div>

<!-- ── Body ─────────────────────────────────────────────────── -->
<div class="tf-spf-body">

  <!-- Content -->
  <article class="tf-spf-content">
    <?php if ( ! has_post_thumbnail() ) : ?>
      <?php if ( $cat ) : ?>
        <a class="tf-spf-cat-pill" href="<?php echo esc_url( get_term_link( $cat ) ); ?>">
          <?php echo esc_html( $cat->name ); ?>
        </a>
      <?php endif; ?>
      <h1 style="font-size:2.4rem;font-weight:900;color:var(--title);margin:16px 0 24px;line-height:1.15">
        <?php the_title(); ?>
      </h1>
    <?php endif; ?>

    <?php the_content(); ?>
  </article>

  <!-- Sidebar meta -->
  <aside class="tf-spf-sidebar">
    <div class="tf-spf-meta-card">
      <h3><?php esc_html_e( 'Project Info', 'themeflex' ); ?></h3>

      <?php if ( $client ) : ?>
      <div class="tf-spf-meta-row">
        <span class="tf-spf-meta-label"><?php esc_html_e( 'Client', 'themeflex' ); ?></span>
        <span class="tf-spf-meta-value"><?php echo esc_html( $client ); ?></span>
      </div>
      <?php endif; ?>

      <?php if ( $year ) : ?>
      <div class="tf-spf-meta-row">
        <span class="tf-spf-meta-label"><?php esc_html_e( 'Year', 'themeflex' ); ?></span>
        <span class="tf-spf-meta-value"><?php echo esc_html( $year ); ?></span>
      </div>
      <?php endif; ?>

      <?php if ( $cat ) : ?>
      <div class="tf-spf-meta-row">
        <span class="tf-spf-meta-label"><?php esc_html_e( 'Category', 'themeflex' ); ?></span>
        <span class="tf-spf-meta-value">
          <a href="<?php echo esc_url( get_term_link( $cat ) ); ?>"><?php echo esc_html( $cat->name ); ?></a>
        </span>
      </div>
      <?php endif; ?>

      <?php if ( $role ) : ?>
      <div class="tf-spf-meta-row">
        <span class="tf-spf-meta-label"><?php esc_html_e( 'Role', 'themeflex' ); ?></span>
        <span class="tf-spf-meta-value"><?php echo esc_html( $role ); ?></span>
      </div>
      <?php endif; ?>

      <?php if ( $tech ) :
        $tech_list = array_map( 'trim', explode( ',', $tech ) );
      ?>
      <div class="tf-spf-meta-row" style="flex-direction:column;align-items:flex-start;gap:8px;">
        <span class="tf-spf-meta-label"><?php esc_html_e( 'Services', 'themeflex' ); ?></span>
        <div class="tf-spf-tags" style="justify-content:flex-start">
          <?php foreach ( $tech_list as $t ) : ?>
            <span class="tf-spf-tag"><?php echo esc_html( $t ); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if ( ! is_wp_error( $tags ) && ! empty( $tags ) ) : ?>
      <div class="tf-spf-meta-row" style="flex-direction:column;align-items:flex-start;gap:8px;">
        <span class="tf-spf-meta-label"><?php esc_html_e( 'Tags', 'themeflex' ); ?></span>
        <div class="tf-spf-tags">
          <?php foreach ( $tags as $tag ) : ?>
            <span class="tf-spf-tag"><?php echo esc_html( $tag->name ); ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if ( $url ) : ?>
        <a href="<?php echo esc_url( $url ); ?>" class="tf-spf-live-btn" target="_blank" rel="noopener noreferrer">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          <?php esc_html_e( 'Visit Live Site', 'themeflex' ); ?>
        </a>
      <?php endif; ?>
    </div>
  </aside>

</div><!-- .tf-spf-body -->

<?php endwhile; ?>

<!-- ── Related Projects ──────────────────────────────────────── -->
<?php
$current_id = get_the_ID();
$related_args = array(
  'post_type'      => 'sf_portfolio',
  'posts_per_page' => 3,
  'post__not_in'   => array( $current_id ),
  'orderby'        => 'rand',
  'post_status'    => 'publish',
);
// Try to get from same category first
if ( $cat ) {
  $related_args['tax_query'] = array(
    array( 'taxonomy' => 'sf_portfolio_cat', 'terms' => $cat->term_id ),
  );
}
$related = new WP_Query( $related_args );

if ( $related->have_posts() ) :
?>
<section class="tf-spf-related">
  <h2><?php esc_html_e( 'More Projects', 'themeflex' ); ?></h2>
  <div class="tf-spf-related-grid">
    <?php while ( $related->have_posts() ) : $related->the_post();
      $r_cats  = wp_get_post_terms( get_the_ID(), 'sf_portfolio_cat' );
      $r_cat   = ( ! empty( $r_cats ) && ! is_wp_error( $r_cats ) ) ? $r_cats[0] : null;
      $_r_entry = $r_cat ? ( $emoji_map[ $r_cat->slug ] ?? $_spf_default ) : $_spf_default;
      $_r_icon  = $_r_entry['s'];
      $_r_color = $_r_entry['c'];
    ?>
    <a href="<?php the_permalink(); ?>" class="tf-spf-rel-card" aria-label="<?php echo esc_attr( get_the_title() ); ?>">
      <div class="tf-spf-rel-thumb">
        <?php if ( has_post_thumbnail() ) : the_post_thumbnail( 'medium_large' );
        else : ?><div class="tf-spf-rel-thumb-icon" style="color:<?php echo esc_attr($_r_color); ?>" aria-hidden="true"><?php echo $_r_icon; ?></div><?php endif; ?>
      </div>
      <div class="tf-spf-rel-body">
        <?php if ( $r_cat ) : ?>
          <div class="tf-spf-rel-cat"><?php echo esc_html( $r_cat->name ); ?></div>
        <?php endif; ?>
        <div class="tf-spf-rel-title"><?php the_title(); ?></div>
      </div>
    </a>
    <?php endwhile; wp_reset_postdata(); ?>
  </div>
</section>
<?php endif; ?>

<!-- ── Prev / Next project navigation ─────────────────────── -->
<?php
$prev_post = get_adjacent_post( false, '', false, 'sf_portfolio_cat', 'sf_portfolio' );
$next_post = get_adjacent_post( false, '', true,  'sf_portfolio_cat', 'sf_portfolio' );
if ( $prev_post || $next_post ) :
?>
<nav class="tf-spf-nav" aria-label="<?php esc_attr_e( 'Portfolio navigation', 'themeflex' ); ?>">
  <?php if ( $prev_post ) : ?>
  <a href="<?php echo esc_url( get_permalink( $prev_post ) ); ?>" class="tf-spf-nav-card prev">
    <span class="tf-spf-nav-label">← <?php esc_html_e( 'Previous Project', 'themeflex' ); ?></span>
    <span class="tf-spf-nav-title"><?php echo esc_html( get_the_title( $prev_post ) ); ?></span>
  </a>
  <?php else : ?><div></div><?php endif; ?>

  <?php if ( $next_post ) : ?>
  <a href="<?php echo esc_url( get_permalink( $next_post ) ); ?>" class="tf-spf-nav-card next">
    <span class="tf-spf-nav-label"><?php esc_html_e( 'Next Project', 'themeflex' ); ?> →</span>
    <span class="tf-spf-nav-title"><?php echo esc_html( get_the_title( $next_post ) ); ?></span>
  </a>
  <?php endif; ?>
</nav>
<?php endif; ?>

<!-- ── CTA strip ─────────────────────────────────────────────── -->
<div class="tf-spf-cta">
  <h2><?php esc_html_e( 'Ready to Build Something Great?', 'themeflex' ); ?></h2>
  <p><?php esc_html_e( "Let's discuss your project — we deliver fast, beautiful WordPress solutions.", 'themeflex' ); ?></p>
  <a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="tf-spf-cta-btn">
    <?php esc_html_e( 'Start a Project', 'themeflex' ); ?>
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
  </a>
</div>

</main><!-- #primary -->

<?php get_footer(); ?>
