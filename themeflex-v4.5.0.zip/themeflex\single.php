<?php
/**
 * Single Post Template — ThemeFlex
 * Dark-first. Self-contained styling, no external CSS dependency.
 *
 * @package ThemeFlex
 * @since 1.3.0
 */
get_header(); ?>
<main id="primary" class="site-main tf-single-main">
<style>
/* ── Single Post — Dark-first ──────────────────────────────────────── */
.tf-single-main{
  padding:60px 0 100px;
  background:linear-gradient(180deg,#06021d 0%,#0d1526 100%);
  min-height:80vh;
  --tc:#ff5e2e;--tc2:#00d4ff;
  --bg:#06021d;--bg2:#0d1526;--bg3:#111827;
  --border:rgba(255,255,255,.07);
  --title:#f1f5f9;--txt:#94a3b8;--meta:#64748b;
}
.tf-single-wrap{
  max-width:1220px;margin:0 auto;padding:0 24px;
  display:grid;grid-template-columns:1fr 340px;gap:56px;align-items:start;
}
/* ── Article ── */
.tf-single-article{}
/* Hero image */
.tf-single-hero-img{
  margin-bottom:36px;border-radius:16px;overflow:hidden;
  aspect-ratio:16/7;
}
.tf-single-hero-img img{width:100%;height:100%;object-fit:cover;display:block;}
/* Category + meta row */
.tf-single-meta-row{
  display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:20px;
}
.tf-single-cat-badge{
  padding:4px 14px;background:rgba(255,94,46,.12);
  color:var(--tc);border-radius:20px;font-size:11px;font-weight:800;
  text-transform:uppercase;letter-spacing:.6px;text-decoration:none;
  transition:background .2s;border:1px solid rgba(255,94,46,.2);
}
.tf-single-cat-badge:hover{background:rgba(255,94,46,.22)}
.tf-single-meta-item{font-size:13px;color:var(--meta);}
/* Title */
.tf-single-title{
  font-family:'Inter Tight',sans-serif;
  font-size:clamp(26px,4vw,48px);font-weight:900;
  color:var(--title);line-height:1.12;letter-spacing:-.5px;
  margin:0 0 28px;
}
/* Author bar */
.tf-author-bar{
  display:flex;align-items:center;gap:14px;
  padding:20px 0;
  border-top:1px solid var(--border);border-bottom:1px solid var(--border);
  margin-bottom:40px;
}
.tf-author-bar img{width:40px;height:40px;border-radius:50%;object-fit:cover;flex-shrink:0;}
.tf-author-name{font-weight:700;font-size:14px;color:var(--title);}
.tf-author-role{font-size:12px;color:var(--meta);}
.tf-share-btns{margin-left:auto;display:flex;gap:8px;}
.tf-share-btn{
  display:inline-flex;align-items:center;justify-content:center;
  width:32px;height:32px;border-radius:8px;
  background:rgba(255,255,255,.06);border:1px solid var(--border);
  color:var(--meta);font-size:13px;text-decoration:none;
  transition:all .2s;
}
.tf-share-btn:hover{background:var(--tc);color:#fff;border-color:var(--tc);}
/* Content body */
.tf-article-body{
  font-size:17px;line-height:1.85;color:var(--txt);max-width:680px;
}
.tf-article-body h2,.tf-article-body h3,.tf-article-body h4{
  font-family:'Inter Tight',sans-serif;font-weight:800;
  color:var(--title);margin:2.2em 0 .8em;letter-spacing:-.3px;
}
.tf-article-body h2{font-size:1.7rem}
.tf-article-body h3{font-size:1.3rem}
.tf-article-body h4{font-size:1.1rem;color:var(--txt)}
.tf-article-body p{margin-bottom:1.6em}
.tf-article-body a{color:var(--tc);text-decoration:underline}
.tf-article-body a:hover{color:#ff8c5a}
.tf-article-body img{
  border-radius:12px;max-width:100%;height:auto;display:block;margin:24px 0;
}
.tf-article-body blockquote{
  border-left:4px solid var(--tc);
  padding:18px 24px;
  background:rgba(255,94,46,.06);
  border-radius:0 10px 10px 0;
  margin:2em 0;font-style:italic;color:var(--title);
}
.tf-article-body ul,.tf-article-body ol{padding-left:24px;margin-bottom:1.6em}
.tf-article-body li{margin-bottom:.5em;line-height:1.75}
.tf-article-body hr{border:none;border-top:1px solid var(--border);margin:2.5em 0}
.tf-article-body pre{
  background:#060e1a;border:1px solid var(--border);
  border-radius:12px;padding:22px;overflow-x:auto;line-height:1.7;
  font-family:'JetBrains Mono','Fira Code',monospace;font-size:13px;color:#e2e8f0;
}
.tf-article-body code{
  background:#060e1a;border:1px solid var(--border);
  border-radius:5px;padding:2px 7px;
  font-family:'JetBrains Mono','Fira Code',monospace;font-size:13px;color:#ff8c5a;
}
.tf-article-body pre code{background:none;border:none;padding:0;color:inherit}
.tf-article-body table{width:100%;border-collapse:collapse;margin:1.6em 0;font-size:15px}
.tf-article-body table th,.tf-article-body table td{
  padding:12px 16px;border:1px solid var(--border);text-align:left;
}
.tf-article-body table th{background:rgba(255,255,255,.04);font-weight:700;color:var(--title)}
/* Tags */
.tf-tag-row{
  display:flex;gap:8px;flex-wrap:wrap;
  margin-top:40px;padding-top:28px;border-top:1px solid var(--border);
}
.tf-tag-label{font-size:12px;font-weight:700;color:var(--meta);align-self:center}
.tf-tag-pill{
  padding:4px 13px;background:rgba(255,255,255,.05);
  border:1px solid var(--border);border-radius:20px;
  font-size:12px;color:var(--txt);text-decoration:none;transition:all .2s;
}
.tf-tag-pill:hover{background:var(--tc);color:#fff;border-color:var(--tc)}
/* Author box */
.tf-author-box{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:16px;padding:28px;margin-top:36px;
  display:flex;gap:20px;align-items:flex-start;
}
.tf-author-box img{width:68px;height:68px;border-radius:50%;object-fit:cover;flex-shrink:0;}
.tf-author-box-label{
  font-size:10px;font-weight:800;text-transform:uppercase;
  letter-spacing:1.2px;color:var(--tc);margin-bottom:5px;
}
.tf-author-box-name{font-size:16px;font-weight:800;color:var(--title);margin:0 0 8px;}
.tf-author-box-bio{font-size:14px;color:var(--txt);line-height:1.75;margin:0;}
/* Post navigation */
.tf-post-nav{
  display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:40px;
}
.tf-post-nav-item{
  padding:20px;background:var(--bg3);border:1px solid var(--border);
  border-radius:12px;text-decoration:none;display:block;transition:all .25s;
}
.tf-post-nav-item:hover{border-color:rgba(255,94,46,.4);background:rgba(255,94,46,.04)}
.tf-post-nav-item.next{text-align:right}
.tf-post-nav-dir{
  font-size:11px;font-weight:700;text-transform:uppercase;
  letter-spacing:.6px;color:var(--meta);margin-bottom:7px;display:block;
}
.tf-post-nav-title{font-weight:700;font-size:13px;color:var(--title);line-height:1.4;}
/* ── Sidebar ── */
.tf-single-sidebar{position:sticky;top:32px;}
.tf-sidebar-widget{
  background:var(--bg3);border:1px solid var(--border);
  border-radius:12px;padding:24px;margin-bottom:20px;
}
.tf-sidebar-widget h3{
  font-size:14px;font-weight:800;color:var(--title);
  margin:0 0 18px;text-transform:uppercase;letter-spacing:.08em;
}
/* Recent posts in sidebar */
.tf-sidebar-post{display:flex;gap:12px;margin-bottom:16px;align-items:flex-start;}
.tf-sidebar-post:last-child{margin-bottom:0}
.tf-sidebar-thumb{width:52px;height:52px;border-radius:8px;overflow:hidden;flex-shrink:0;background:var(--bg2)}
.tf-sidebar-thumb img{width:52px;height:52px;object-fit:cover;display:block}
.tf-sidebar-post-title{font-weight:600;font-size:13px;color:var(--title);line-height:1.4;margin-bottom:3px;text-decoration:none;display:block}
.tf-sidebar-post-title:hover{color:var(--tc)}
.tf-sidebar-post-date{font-size:11px;color:var(--meta)}
/* Categories in sidebar */
.tf-sidebar-cats{list-style:none;padding:0;margin:0}
.tf-sidebar-cats li{border-bottom:1px solid var(--border);padding:9px 0}
.tf-sidebar-cats li:last-child{border-bottom:none}
.tf-sidebar-cats a{
  display:flex;justify-content:space-between;align-items:center;
  color:var(--txt);text-decoration:none;font-size:14px;transition:color .2s;
}
.tf-sidebar-cats a:hover{color:var(--tc)}
.tf-sidebar-cats .count{
  background:rgba(255,255,255,.06);border:1px solid var(--border);
  border-radius:20px;padding:0 9px;font-size:11px;color:var(--meta);
}
/* Reading progress bar */
.tf-reading-progress{
  position:fixed;top:0;left:0;height:3px;width:0%;
  background:linear-gradient(90deg,#ff5e2e,#ff8c5a);
  z-index:9999;transition:width .1s linear;
}
/* WordPress native sidebar widgets — dark override */
.tf-single-sidebar .widget{
  background:var(--bg3)!important;border:1px solid var(--border)!important;
  border-radius:12px!important;padding:24px!important;margin-bottom:20px!important;
}
.tf-single-sidebar .widget-title,.tf-single-sidebar .widgettitle{
  font-size:13px!important;font-weight:800!important;color:var(--title)!important;
  margin:0 0 16px!important;text-transform:uppercase!important;letter-spacing:.08em!important;
}
.tf-single-sidebar .widget ul{list-style:none!important;padding:0!important;margin:0!important}
.tf-single-sidebar .widget ul li{
  border-bottom:1px solid var(--border)!important;padding:8px 0!important;
}
.tf-single-sidebar .widget ul li:last-child{border-bottom:none!important}
.tf-single-sidebar .widget ul li a{color:var(--txt)!important;font-size:14px!important;text-decoration:none!important;transition:color .2s}
.tf-single-sidebar .widget ul li a:hover{color:var(--tc)!important}
.tf-single-sidebar .widget_search .search-field{
  background:rgba(255,255,255,.06)!important;border:1px solid var(--border)!important;
  color:var(--title)!important;border-radius:8px!important;padding:10px 14px!important;
  width:100%!important;font-size:14px!important;
}
.tf-single-sidebar .widget_search .search-submit{
  background:var(--tc)!important;color:#fff!important;border:none!important;
  border-radius:8px!important;padding:10px 18px!important;
  margin-top:8px!important;width:100%!important;font-weight:700!important;cursor:pointer!important;
}

/* ── Table of Contents ── */
.tf-toc-box {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.07);
  border-left: 3px solid var(--tc);
  border-radius: 12px;
  padding: 24px 28px;
  margin: 36px 0;
}
.tf-toc-label {
  font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; color: var(--tc);
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 16px; cursor: pointer; user-select: none;
}
.tf-toc-label::before { content: '§'; font-style: normal; }
.tf-toc-label svg { width:14px; height:14px; stroke:var(--tc); transition:transform .3s; }
.tf-toc-label.collapsed svg { transform:rotate(-90deg); }
.tf-toc-list {
  list-style: none; padding: 0; margin: 0;
  display: flex; flex-direction: column; gap: 2px;
  transition: max-height .4s cubic-bezier(.16,1,.3,1), opacity .3s;
  overflow: hidden;
}
.tf-toc-list.collapsed { max-height: 0!important; opacity: 0; }
.tf-toc-list li a {
  display: block;
  font-size: .86rem; color: var(--txt); text-decoration: none;
  padding: 5px 0 5px 12px;
  border-left: 2px solid rgba(255,255,255,.06);
  line-height: 1.4;
  transition: color .2s, border-color .2s, padding-left .2s;
}
.tf-toc-list li a:hover { color: #fff; border-color: var(--tc); padding-left: 18px; }
.tf-toc-list li a.tf-toc-active { color: var(--tc); border-color: var(--tc); }
.tf-toc-list li.toc-h3 a { padding-left: 28px; font-size: .82rem; }
.tf-toc-list li.toc-h3 a:hover { padding-left: 34px; }

/* ── Related Posts ── */
.tf-related-posts {
  margin-top: 64px;
  padding-top: 48px;
  border-top: 1px solid rgba(255,255,255,.07);
}
.tf-related-label {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.2rem; font-weight: 900; color: var(--title);
  letter-spacing: -.03em; margin: 0 0 28px;
}
.tf-related-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}
.tf-related-card {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px;
  overflow: hidden;
  text-decoration: none;
  transition: transform .25s, box-shadow .25s, border-color .25s;
  display: flex; flex-direction: column;
}
.tf-related-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 16px 40px rgba(0,0,0,.35);
  border-color: rgba(255,94,46,.25);
}
.tf-related-thumb {
  aspect-ratio: 16/9; overflow: hidden;
  background: linear-gradient(135deg, #0d1526, #1a0a2e);
  position: relative;
}
.tf-related-thumb img { width:100%; height:100%; object-fit:cover; display:block; transition:transform .4s; }
.tf-related-card:hover .tf-related-thumb img { transform:scale(1.05); }
.tf-related-thumb-placeholder {
  width:100%; height:100%;
  display:flex; align-items:center; justify-content:center;
  font-size:2rem; opacity:.25;
}
.tf-related-body { padding: 18px 20px; flex: 1; display:flex; flex-direction:column; }
.tf-related-cat {
  font-size: .68rem; font-weight: 800; text-transform: uppercase;
  letter-spacing: .1em; color: var(--tc); margin-bottom: 8px;
}
.tf-related-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: .95rem; font-weight: 800; color: var(--title);
  letter-spacing: -.02em; line-height: 1.4;
  margin: 0 0 auto;
}
.tf-related-date {
  font-size: .75rem; color: var(--meta); margin-top: 12px;
}
@media(max-width:640px){
  .tf-related-grid { grid-template-columns: 1fr; }
}

/* ── Responsive ── */
@media(max-width:1024px){
  .tf-single-wrap{grid-template-columns:1fr!important}
  .tf-single-sidebar{display:none}
}
@media(max-width:600px){
  .tf-post-nav{grid-template-columns:1fr}
}
</style>

<!-- Reading progress -->
<div class="tf-reading-progress" id="tfReadingProgress"></div>

<div class="tf-single-wrap">
  <!-- Article -->
  <article id="post-<?php the_ID(); ?>" <?php post_class('tf-single-article'); ?>>
    <?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>

    <!-- Hero Image -->
    <?php if ( has_post_thumbnail() ) : ?>
    <div class="tf-single-hero-img">
      <?php the_post_thumbnail( 'full', ['loading' => 'eager', 'fetchpriority' => 'high'] ); ?>
    </div>
    <?php endif; ?>

    <!-- Category + Meta -->
    <div class="tf-single-meta-row">
      <?php $cats = get_the_category(); if ( $cats ) : ?>
        <a class="tf-single-cat-badge" href="<?php echo esc_url( get_category_link( $cats[0]->term_id ) ); ?>">
          <?php echo esc_html( $cats[0]->name ); ?>
        </a>
      <?php endif; ?>
      <span class="tf-single-meta-item"><?php echo esc_html( get_the_date( 'F j, Y' ) ); ?></span>
      <span class="tf-single-meta-item">·</span>
      <span class="tf-single-meta-item"><?php echo esc_html( max( 1, (int) ceil( str_word_count( strip_tags( get_the_content() ) ) / 200 ) ) ); ?> <?php esc_html_e( 'min read', 'themeflex' ); ?></span>
    </div>

    <!-- Title -->
    <h1 class="tf-single-title"><?php the_title(); ?></h1>

    <!-- Author bar -->
    <div class="tf-author-bar">
      <?php echo get_avatar( get_the_author_meta( 'ID' ), 40, '', '', ['class' => ''] ); ?>
      <div>
        <div class="tf-author-name"><?php the_author(); ?></div>
        <div class="tf-author-role"><?php echo esc_html( get_the_author_meta( 'description' ) ? wp_trim_words( get_the_author_meta( 'description' ), 8 ) : get_bloginfo( 'name' ) ); ?></div>
      </div>
      <div class="tf-share-btns">
        <a class="tf-share-btn" href="https://twitter.com/intent/tweet?url=<?php echo rawurlencode( get_permalink() ); ?>&text=<?php echo rawurlencode( get_the_title() ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Share on X', 'themeflex' ); ?>">
          <i class="fa-brands fa-x-twitter" aria-hidden="true"></i>
        </a>
        <a class="tf-share-btn" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo rawurlencode( get_permalink() ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Share on LinkedIn', 'themeflex' ); ?>">
          <i class="fa-brands fa-linkedin-in" aria-hidden="true"></i>
        </a>
        <a class="tf-share-btn" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode( get_permalink() ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Share on Facebook', 'themeflex' ); ?>">
          <i class="fa-brands fa-facebook-f" aria-hidden="true"></i>
        </a>
      </div>
    </div>

    <!-- Table of Contents (auto-generated by JS) -->
    <div class="tf-toc-box" id="tf-toc" style="display:none" aria-label="<?php esc_attr_e( 'Table of Contents', 'themeflex' ); ?>">
      <div class="tf-toc-label" id="tf-toc-toggle" tabindex="0" role="button" aria-expanded="true">
        <?php esc_html_e( 'Table of Contents', 'themeflex' ); ?>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
      </div>
      <ul class="tf-toc-list" id="tf-toc-list" role="list"></ul>
    </div>

    <!-- Content -->
    <div class="tf-article-body">
      <?php the_content(); ?>
      <?php wp_link_pages( ['before' => '<nav class="page-links">', 'after' => '</nav>'] ); ?>
    </div>

    <!-- Tags -->
    <?php $tags = get_the_tags(); if ( $tags ) : ?>
    <div class="tf-tag-row">
      <span class="tf-tag-label"><?php esc_html_e( 'Tags:', 'themeflex' ); ?></span>
      <?php foreach ( $tags as $tag ) : ?>
        <a class="tf-tag-pill" href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>">#<?php echo esc_html( $tag->name ); ?></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Related Posts -->
    <?php
    $current_cats = wp_get_post_categories( get_the_ID() );
    if ( $current_cats ) :
      $related = get_posts([
        'category__in'   => $current_cats,
        'post__not_in'   => [ get_the_ID() ],
        'posts_per_page' => 3,
        'orderby'        => 'rand',
      ]);
      if ( $related ) :
    ?>
    <div class="tf-related-posts">
      <h3 class="tf-related-label"><?php esc_html_e( 'Related Articles', 'themeflex' ); ?></h3>
      <div class="tf-related-grid">
        <?php foreach ( $related as $rp ) :
          $rcats = get_the_category( $rp->ID );
          $rcat  = $rcats ? $rcats[0]->name : '';
        ?>
        <a class="tf-related-card" href="<?php echo esc_url( get_permalink( $rp->ID ) ); ?>">
          <div class="tf-related-thumb">
            <?php if ( has_post_thumbnail( $rp->ID ) ) :
              echo get_the_post_thumbnail( $rp->ID, 'medium', ['loading' => 'lazy'] );
            else : ?>
              <div class="tf-related-thumb-placeholder" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="28" height="28" style="opacity:.2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg></div>
            <?php endif; ?>
          </div>
          <div class="tf-related-body">
            <?php if ( $rcat ) : ?>
              <div class="tf-related-cat"><?php echo esc_html( $rcat ); ?></div>
            <?php endif; ?>
            <div class="tf-related-title"><?php echo esc_html( get_the_title( $rp->ID ) ); ?></div>
            <div class="tf-related-date"><?php echo esc_html( get_the_date( 'F j, Y', $rp->ID ) ); ?></div>
          </div>
        </a>
        <?php endforeach; wp_reset_postdata(); ?>
      </div>
    </div>
    <?php endif; endif; ?>

    <!-- Author Box -->
    <div class="tf-author-box">
      <?php echo get_avatar( get_the_author_meta( 'ID' ), 68 ); ?>
      <div>
        <div class="tf-author-box-label"><?php esc_html_e( 'About the Author', 'themeflex' ); ?></div>
        <h3 class="tf-author-box-name"><?php the_author(); ?></h3>
        <p class="tf-author-box-bio"><?php echo esc_html( get_the_author_meta( 'description' ) ?: __( 'Passionate about design, WordPress, and building beautiful digital experiences.', 'themeflex' ) ); ?></p>
      </div>
    </div>

    <!-- Post Navigation -->
    <?php
    $prev_post = get_previous_post();
    $next_post = get_next_post();
    if ( $prev_post || $next_post ) : ?>
    <nav class="tf-post-nav" aria-label="<?php esc_attr_e( 'Post navigation', 'themeflex' ); ?>">
      <?php if ( $prev_post ) : ?>
        <a class="tf-post-nav-item prev" href="<?php echo esc_url( get_permalink( $prev_post ) ); ?>">
          <span class="tf-post-nav-dir">← <?php esc_html_e( 'Previous', 'themeflex' ); ?></span>
          <span class="tf-post-nav-title"><?php echo esc_html( get_the_title( $prev_post ) ); ?></span>
        </a>
      <?php else : ?><div></div><?php endif; ?>
      <?php if ( $next_post ) : ?>
        <a class="tf-post-nav-item next" href="<?php echo esc_url( get_permalink( $next_post ) ); ?>">
          <span class="tf-post-nav-dir"><?php esc_html_e( 'Next', 'themeflex' ); ?> →</span>
          <span class="tf-post-nav-title"><?php echo esc_html( get_the_title( $next_post ) ); ?></span>
        </a>
      <?php endif; ?>
    </nav>
    <?php endif; ?>

    <!-- Comments -->
    <?php if ( comments_open() || get_comments_number() ) : ?>
      <div style="margin-top:48px;"><?php comments_template(); ?></div>
    <?php endif; ?>

    <?php endwhile; ?>
  </article>

  <!-- Sidebar -->
  <aside class="tf-single-sidebar">
    <?php if ( is_active_sidebar( 'sidebar-primary' ) ) : ?>
      <?php dynamic_sidebar( 'sidebar-primary' ); ?>
    <?php else : ?>
      <!-- Recent Posts -->
      <div class="tf-sidebar-widget">
        <h3><?php esc_html_e( 'Recent Posts', 'themeflex' ); ?></h3>
        <?php $recent_posts = get_posts( ['numberposts' => 5] );
        foreach ( $recent_posts as $rpost ) : setup_postdata( $rpost ); ?>
        <div class="tf-sidebar-post">
          <?php if ( has_post_thumbnail( $rpost->ID ) ) : ?>
            <div class="tf-sidebar-thumb">
              <?php echo get_the_post_thumbnail( $rpost->ID, 'thumbnail' ); ?>
            </div>
          <?php endif; ?>
          <div>
            <a class="tf-sidebar-post-title" href="<?php echo esc_url( get_permalink( $rpost->ID ) ); ?>">
              <?php echo esc_html( get_the_title( $rpost->ID ) ); ?>
            </a>
            <span class="tf-sidebar-post-date"><?php echo esc_html( get_the_date( 'M j, Y', $rpost->ID ) ); ?></span>
          </div>
        </div>
        <?php endforeach; wp_reset_postdata(); ?>
      </div>
      <!-- Categories -->
      <div class="tf-sidebar-widget">
        <h3><?php esc_html_e( 'Categories', 'themeflex' ); ?></h3>
        <ul class="tf-sidebar-cats">
        <?php foreach ( get_categories( ['hide_empty' => true] ) as $scat ) : ?>
          <li>
            <a href="<?php echo esc_url( get_category_link( $scat->term_id ) ); ?>">
              <span><?php echo esc_html( $scat->name ); ?></span>
              <span class="count"><?php echo (int) $scat->count; ?></span>
            </a>
          </li>
        <?php endforeach; ?>
        </ul>
      </div>
      <!-- Newsletter CTA -->
      <div class="tf-sidebar-widget" style="background:linear-gradient(135deg,rgba(255,94,46,.12),rgba(255,94,46,.05));border-color:rgba(255,94,46,.2);">
        <h3 style="color:var(--tc);"><?php esc_html_e( 'Stay Updated', 'themeflex' ); ?></h3>
        <p style="font-size:13px;color:var(--txt);line-height:1.7;margin:0 0 16px;"><?php esc_html_e( 'Get the latest design tips and WordPress tutorials delivered to your inbox.', 'themeflex' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/#subscribe' ) ); ?>"
           style="display:block;text-align:center;padding:12px 20px;background:var(--tc);color:#fff;border-radius:10px;font-size:13px;font-weight:700;text-decoration:none;transition:background .2s;"
           onmouseover="this.style.background='#e04e22'" onmouseout="this.style.background='#ff5e2e'">
          <?php esc_html_e( 'Subscribe →', 'themeflex' ); ?>
        </a>
      </div>
    <?php endif; ?>
  </aside>
</div>

<script>
/* TOC auto-build + scroll spy */
(function(){
  var article = document.querySelector('.tf-article-body');
  var toc     = document.getElementById('tf-toc');
  var tocList = document.getElementById('tf-toc-list');
  var toggle  = document.getElementById('tf-toc-toggle');
  if (!article || !toc || !tocList) return;

  var headings = article.querySelectorAll('h2, h3');
  if (headings.length < 2) return;

  toc.style.display = '';
  var tocLinks = [];

  headings.forEach(function(h, i) {
    if (!h.id) h.id = 'tf-heading-' + i;
    var li = document.createElement('li');
    li.className = h.tagName === 'H3' ? 'toc-h3' : 'toc-h2';
    var a = document.createElement('a');
    a.href = '#' + h.id;
    a.textContent = h.textContent.replace(/^#+\s*/, '');
    a.addEventListener('click', function(e) {
      e.preventDefault();
      h.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    li.appendChild(a);
    tocList.appendChild(li);
    tocLinks.push({ el: h, link: a });
  });

  // Scroll spy
  if ('IntersectionObserver' in window) {
    var spy = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) {
        var found = tocLinks.find(function(t){ return t.el === e.target; });
        if (found) found.link.classList.toggle('tf-toc-active', e.isIntersecting);
      });
    }, { rootMargin: '-10% 0px -80% 0px' });
    headings.forEach(function(h){ spy.observe(h); });
  }

  // Collapse toggle
  if (toggle) {
    toggle.addEventListener('click', function() {
      var collapsed = tocList.classList.toggle('collapsed');
      toggle.classList.toggle('collapsed', collapsed);
      toggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
    });
    toggle.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle.click(); }
    });
    // Set initial max-height after render
    tocList.style.maxHeight = tocList.scrollHeight + 'px';
  }
})();

/* Reading progress bar */
(function(){
  var bar = document.getElementById('tfReadingProgress');
  if(!bar) return;
  var article = document.querySelector('.tf-article-body');
  if(!article) return;
  function updateProgress(){
    var rect = article.getBoundingClientRect();
    var total = article.offsetHeight - window.innerHeight;
    var scrolled = -rect.top;
    var pct = Math.max(0,Math.min(100, (scrolled/total)*100));
    bar.style.width = pct + '%';
  }
  window.addEventListener('scroll', updateProgress, {passive:true});
  updateProgress();
})();
</script>
</main>
<?php get_footer(); ?>
