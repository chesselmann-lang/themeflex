<?php
/**
 * Agency Skin Configuration
 *
 * Bold, modern digital agency design with electric blue branding,
 * glassmorphism card effects, and portfolio-focused styling.
 *
 * @package ThemeFlex
 * @subpackage Skins
 * @since 1.0.0
 */

namespace Starter_Flavor\Skins;

/**
 * Agency Skin Class
 *
 * Extends the base skin class with agency-specific customizations
 * including bold typography, modern color schemes, and portfolio layouts.
 */
class Agency_Skin {

	/**
	 * Constructor
	 *
	 * Initializes the Agency skin and registers hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register skin-specific hooks and filters
	 *
	 * @since 1.0.0
	 */
	private function register_hooks() {
		// Add skin-specific classes to body
		add_filter( 'body_class', array( $this, 'add_skin_class' ) );

		// Customize button styles
		add_filter( 'sf_button_classes', array( $this, 'customize_buttons' ) );

		// Portfolio-focused hero sections
		add_action( 'wp_head', array( $this, 'enqueue_skin_specific_styles' ) );
	}

	/**
	 * Add skin identifier class to body
	 *
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 *
	 * @since 1.0.0
	 */
	public function add_skin_class( $classes ) {
		$classes[] = 'skin-agency';
		$classes[] = 'agency-bold-typography';
		return $classes;
	}

	/**
	 * Customize button rendering for agency skin
	 *
	 * @param string $classes Button CSS classes
	 * @return string Modified button classes
	 *
	 * @since 1.0.0
	 */
	public function customize_buttons( $classes ) {
		$classes .= ' agency-button--modern';
		return $classes;
	}

	/**
	 * Enqueue skin-specific inline styles
	 *
	 * @since 1.0.0
	 */
	public function enqueue_skin_specific_styles() {
		// Additional inline styles can be added here if needed
		// Main styles are handled via CSS file
	}
}

// Initialize the skin
if ( ! function_exists( 'themeflex_init_agency_skin' ) ) {
	/**
	 * Initialize Agency skin on theme load
	 *
	 * @since 1.0.0
	 */
	function themeflex_init_agency_skin() {
		new Agency_Skin();
	}

	add_action( 'after_setup_theme', 'themeflex_init_agency_skin' );
}
