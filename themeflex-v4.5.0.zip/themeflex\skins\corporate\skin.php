<?php
/**
 * Corporate Skin Configuration
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Professional blue themed skin with serif typography
