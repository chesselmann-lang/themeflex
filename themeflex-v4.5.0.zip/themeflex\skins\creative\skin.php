<?php
/**
 * Creative Skin Configuration
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Modern green themed skin with gradient accents
