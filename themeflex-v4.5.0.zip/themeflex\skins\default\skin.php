<?php
/**
 * Default Skin Configuration
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// This file is loaded when the default skin is active.
// Add custom configurations, filters, or theme modifications here.

// Example: Customize theme options for this skin
if ( is_admin() ) {
	add_action( 'after_setup_theme', function() {
		// Set default values for this skin
		if ( ! get_theme_mod( 'themeflex_active_skin' ) ) {
			set_theme_mod( 'sf_color_primary', '#FF5E2E' );
			set_theme_mod( 'sf_color_secondary', '#1F242E' );
			set_theme_mod( 'sf_color_accent', '#00D4FF' );
		}
	}, 20 );
}
