<?php
/**
 * Freelancer Skin Configuration
 *
 * Creative, personal brand design with gradient purple-pink accents,
 * minimal cards, and portfolio/skills showcase focus.
 *
 * @package ThemeFlex
 * @subpackage Skins
 * @since 1.0.0
 */

namespace Starter_Flavor\Skins;

/**
 * Freelancer Skin Class
 *
 * Extends the base skin class with freelancer/creative-specific customizations
 * including gradient accents, portfolio layouts, and personal branding focus.
 */
class Freelancer_Skin {

	/**
	 * Constructor
	 *
	 * Initializes the Freelancer skin and registers hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register skin-specific hooks and filters
	 *
	 * @since 1.0.0
	 */
	private function register_hooks() {
		// Add skin-specific classes to body
		add_filter( 'body_class', array( $this, 'add_skin_class' ) );

		// Customize portfolio items
		add_filter( 'sf_portfolio_item_classes', array( $this, 'customize_portfolio' ) );

		// Freelancer-specific hooks
		add_action( 'wp_head', array( $this, 'enqueue_skin_specific_styles' ) );
	}

	/**
	 * Add skin identifier class to body
	 *
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 *
	 * @since 1.0.0
	 */
	public function add_skin_class( $classes ) {
		$classes[] = 'skin-freelancer';
		$classes[] = 'freelancer-creative';
		return $classes;
	}

	/**
	 * Customize portfolio item styling
	 *
	 * @param string $classes Portfolio CSS classes
	 * @return string Modified portfolio classes
	 *
	 * @since 1.0.0
	 */
	public function customize_portfolio( $classes ) {
		$classes .= ' portfolio-item--creative';
		return $classes;
	}

	/**
	 * Enqueue skin-specific inline styles
	 *
	 * @since 1.0.0
	 */
	public function enqueue_skin_specific_styles() {
		// Additional inline styles can be added here if needed
		// Main styles are handled via CSS file
	}
}

// Initialize the skin
if ( ! function_exists( 'themeflex_init_freelancer_skin' ) ) {
	/**
	 * Initialize Freelancer skin on theme load
	 *
	 * @since 1.0.0
	 */
	function themeflex_init_freelancer_skin() {
		new Freelancer_Skin();
	}

	add_action( 'after_setup_theme', 'themeflex_init_freelancer_skin' );
}
