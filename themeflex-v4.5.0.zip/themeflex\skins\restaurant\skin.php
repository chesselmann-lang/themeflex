<?php
/**
 * Restaurant Skin Configuration
 *
 * Elegant dining aesthetic with warm burgundy and gold accents,
 * sophisticated typography, and menu/pricing focus.
 *
 * @package ThemeFlex
 * @subpackage Skins
 * @since 1.0.0
 */

namespace Starter_Flavor\Skins;

/**
 * Restaurant Skin Class
 *
 * Extends the base skin class with restaurant-specific customizations
 * including elegant styling, menu layouts, and food-focused imagery.
 */
class Restaurant_Skin {

	/**
	 * Constructor
	 *
	 * Initializes the Restaurant skin and registers hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_hooks();
	}

	/**
	 * Register skin-specific hooks and filters
	 *
	 * @since 1.0.0
	 */
	private function register_hooks() {
		// Add skin-specific classes to body
		add_filter( 'body_class', array( $this, 'add_skin_class' ) );

		// Customize heading decoration
		add_filter( 'sf_heading_decoration', array( $this, 'add_ornamental_elements' ) );

		// Menu-specific styling
		add_action( 'wp_head', array( $this, 'enqueue_skin_specific_styles' ) );
	}

	/**
	 * Add skin identifier class to body
	 *
	 * @param array $classes Existing body classes
	 * @return array Modified body classes
	 *
	 * @since 1.0.0
	 */
	public function add_skin_class( $classes ) {
		$classes[] = 'skin-restaurant';
		$classes[] = 'restaurant-elegant';
		return $classes;
	}

	/**
	 * Add ornamental elements to headings
	 *
	 * @param string $content Heading content
	 * @return string Modified heading with ornamental elements
	 *
	 * @since 1.0.0
	 */
	public function add_ornamental_elements( $content ) {
		// Ornamental decorations handled via CSS
		return $content;
	}

	/**
	 * Enqueue skin-specific inline styles
	 *
	 * @since 1.0.0
	 */
	public function enqueue_skin_specific_styles() {
		// Additional inline styles can be added here if needed
		// Main styles are handled via CSS file
	}
}

// Initialize the skin
if ( ! function_exists( 'themeflex_init_restaurant_skin' ) ) {
	/**
	 * Initialize Restaurant skin on theme load
	 *
	 * @since 1.0.0
	 */
	function themeflex_init_restaurant_skin() {
		new Restaurant_Skin();
	}

	add_action( 'after_setup_theme', 'themeflex_init_restaurant_skin' );
}
