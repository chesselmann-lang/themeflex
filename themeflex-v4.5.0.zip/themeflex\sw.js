/**
 * ThemeFlex Service Worker
 * Minimal offline-first cache strategy for static assets.
 *
 * @package ThemeFlex
 * @version 3.2.0
 */

const CACHE_NAME  = 'themeflex-v3.2.0';
const CACHE_URLS  = []; // Populated dynamically — nothing to pre-cache.

self.addEventListener('install', event => {
    self.skipWaiting();
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            if (CACHE_URLS.length) return cache.addAll(CACHE_URLS);
        })
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(keys =>
            Promise.all(
                keys
                    .filter(key => key !== CACHE_NAME)
                    .map(key  => caches.delete(key))
            )
        ).then(() => self.clients.claim())
    );
});

/**
 * Network-first strategy for HTML; cache-first for static assets.
 */
self.addEventListener('fetch', event => {
    const { request } = event;
    const url = new URL(request.url);

    // Skip non-GET, admin, and REST API requests.
    if (
        request.method !== 'GET' ||
        url.pathname.startsWith('/wp-admin') ||
        url.pathname.startsWith('/wp-json') ||
        url.pathname.includes('wp-login')
    ) {
        return;
    }

    // Cache-first for theme static assets (CSS / JS / fonts / images).
    if (url.pathname.includes('/wp-content/themes/themeflex/')) {
        event.respondWith(
            caches.match(request).then(cached => {
                if (cached) return cached;
                return fetch(request).then(response => {
                    if (!response || response.status !== 200) return response;
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
                    return response;
                });
            })
        );
        return;
    }

    // Network-first for everything else (HTML pages).
    event.respondWith(
        fetch(request).catch(() => caches.match(request))
    );
});
