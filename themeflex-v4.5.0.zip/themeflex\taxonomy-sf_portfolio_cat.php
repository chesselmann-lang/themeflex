<?php
/**
 * Portfolio Category Taxonomy Archive
 *
 * Rendered when browsing /portfolio-category/{slug}/.
 * Dark-first, full-width masonry grid with category header.
 *
 * @package ThemeFlex
 * @since   2.4.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
get_header();

$term        = get_queried_object();
$term_name   = $term ? $term->name : esc_html__( 'Portfolio', 'themeflex' );
$term_desc   = $term ? $term->description : '';
$term_count  = $term ? (int) $term->count : 0;
?>
<main id="primary" class="tf-tax-main">
<style>
/* ══════════════════���═══════════════════════════════════════
   PORTFOLIO TAXONOMY ARCHIVE — ThemeFlex Dark-first
   ══════════════════════════════════════════════════════════ */
.tf-tax-main {
  --tc:     #ff5e2e;
  --tc2:    #00d4ff;
  --bg:     #06021d;
  --bg2:    #0d1526;
  --bg3:    #111827;
  --border: rgba(255,255,255,.07);
  --title:  #f1f5f9;
  --txt:    #94a3b8;
  --meta:   #64748b;
  background: var(--bg);
  min-height: 100vh;
  padding-bottom: 120px;
}

/* ── Hero ── */
.tf-tax-hero {
  position: relative;
  padding: 110px 24px 70px;
  text-align: center;
  background: radial-gradient(ellipse 65% 50% at 50% 0%,
    rgba(255,94,46,.16) 0%, transparent 68%), var(--bg);
  overflow: hidden;
}
.tf-tax-hero::before {
  content: '';
  position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.03) 1px, transparent 1px);
  background-size: 36px 36px;
  pointer-events: none;
}
.tf-tax-hero-inner { position: relative; z-index: 1; max-width: 680px; margin: 0 auto; }
.tf-tax-breadcrumb {
  display: flex; align-items: center; justify-content: center; gap: 8px;
  font-size: .78rem; font-weight: 600; color: var(--meta);
  margin-bottom: 20px;
}
.tf-tax-breadcrumb a { color: var(--tc); text-decoration: none; }
.tf-tax-breadcrumb a:hover { text-decoration: underline; }
.tf-tax-breadcrumb-sep { opacity: .4; }
.tf-tax-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: var(--tc); font-size: .7rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px;
  margin-bottom: 18px;
}
.tf-tax-eyebrow::before { content: '◆'; font-size: .55rem; }
.tf-tax-hero h1 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2.2rem, 5vw, 3.6rem);
  font-weight: 900; color: var(--title);
  letter-spacing: -.04em; line-height: 1.1;
  margin: 0 0 16px;
}
.tf-tax-hero h1 em {
  font-style: normal;
  background: linear-gradient(135deg, #ff5e2e, #a855f7);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.tf-tax-hero p {
  font-size: 1.05rem; color: var(--txt); line-height: 1.75;
  max-width: 520px; margin: 0 auto 28px;
}
.tf-tax-count-pill {
  display: inline-flex; align-items: center; gap: 6px;
  background: rgba(255,255,255,.06); border: 1px solid var(--border);
  border-radius: 100px; font-size: .78rem; font-weight: 700; color: var(--meta);
  padding: 5px 14px;
}
.tf-tax-count-pill strong { color: var(--title); }

/* ── Cat filter tabs (other cats) ── */
.tf-tax-cats {
  display: flex; flex-wrap: wrap; justify-content: center; gap: 8px;
  padding: 0 24px 56px;
  max-width: 960px; margin: 0 auto;
}
.tf-tax-cat-link {
  display: inline-flex; align-items: center;
  padding: 7px 18px; border-radius: 100px;
  font-size: .78rem; font-weight: 700; letter-spacing: .04em;
  text-decoration: none; transition: all .2s;
  background: rgba(255,255,255,.04);
  border: 1px solid var(--border);
  color: var(--txt);
}
.tf-tax-cat-link:hover,
.tf-tax-cat-link.is-active {
  background: var(--tc); border-color: var(--tc); color: #fff;
}

/* ── Grid ── */
.tf-tax-wrap { max-width: 1240px; margin: 0 auto; padding: 0 24px; }
.tf-tax-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
}

/* ── Card ── */
.tf-tax-card {
  position: relative; border-radius: 16px; overflow: hidden;
  aspect-ratio: 4/3;
  background: var(--bg3);
  border: 1px solid var(--border);
  text-decoration: none;
  display: block;
  transition: border-color .3s, transform .3s;
}
.tf-tax-card:hover { border-color: rgba(255,94,46,.3); transform: translateY(-4px); }

.tf-tax-card-img {
  width: 100%; height: 100%;
  object-fit: cover;
  transition: transform .6s cubic-bezier(.22,.68,0,1.2);
}
.tf-tax-card:hover .tf-tax-card-img { transform: scale(1.06); }

/* No-image placeholder */
.tf-tax-card-placeholder {
  position: absolute; inset: 0;
  display: flex; flex-direction: column;
  padding: 16px; gap: 8px; overflow: hidden;
  background: inherit;
}
.tf-tax-card-placeholder .ph-bar {
  height: 7px; border-radius: 4px;
  background: rgba(255,255,255,.07);
}
.tf-tax-card-placeholder .ph-hero {
  height: 34px; border-radius: 6px;
  background: var(--card-glow, rgba(255,94,46,.15));
}
.tf-tax-card-placeholder .ph-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 7px; flex: 1;
}
.tf-tax-card-placeholder .ph-block {
  border-radius: 8px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.07);
}
.tf-tax-card-placeholder .ph-block:last-child {
  background: var(--card-glow, rgba(255,94,46,.1));
  border: none; opacity: .6;
}

/* Overlay */
.tf-tax-card-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(180deg, transparent 40%, rgba(6,2,29,.92) 100%);
  transition: opacity .3s;
}
/* Body */
.tf-tax-card-body {
  position: absolute; bottom: 0; left: 0; right: 0;
  padding: 18px 20px; z-index: 2;
}
.tf-tax-card-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1rem; font-weight: 900; color: #fff;
  margin: 0 0 6px; line-height: 1.25; letter-spacing: -.02em;
}
.tf-tax-card-meta {
  display: flex; align-items: center; gap: 10px;
  font-size: .72rem; color: rgba(255,255,255,.5);
}
.tf-tax-card-meta-sep { opacity: .4; }
.tf-tax-card-meta a { color: rgba(255,255,255,.5); text-decoration: none; }

/* ── Pagination ── */
.tf-tax-pagination {
  display: flex; justify-content: center; gap: 6px;
  margin-top: 56px;
}
.tf-tax-pagination .page-numbers {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 42px; height: 42px; padding: 0 12px;
  border-radius: 10px; border: 1px solid var(--border);
  color: var(--txt); text-decoration: none;
  font-size: .875rem; font-weight: 700;
  transition: all .22s;
}
.tf-tax-pagination .page-numbers:hover,
.tf-tax-pagination .page-numbers.current {
  background: var(--tc); color: #fff; border-color: var(--tc);
}

/* ── No results ── */
.tf-tax-empty {
  text-align: center; padding: 80px 24px; color: var(--meta);
}
.tf-tax-empty h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.6rem; font-weight: 800; color: var(--title);
  margin: 0 0 14px;
}
.tf-tax-empty a {
  color: var(--tc); text-decoration: none; font-weight: 700;
}

/* ── Responsive ── */
@media (max-width: 900px) {
  .tf-tax-grid { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 580px) {
  .tf-tax-grid { grid-template-columns: 1fr; }
  .tf-tax-hero h1 { font-size: 2rem; }
}
</style>

<!-- Hero Header -->
<div class="tf-tax-hero">
  <div class="tf-tax-hero-inner">
    <nav class="tf-tax-breadcrumb" aria-label="<?php esc_attr_e( 'Breadcrumb', 'themeflex' ); ?>">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'themeflex' ); ?></a>
      <span class="tf-tax-breadcrumb-sep" aria-hidden="true">/</span>
      <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"><?php esc_html_e( 'Portfolio', 'themeflex' ); ?></a>
      <span class="tf-tax-breadcrumb-sep" aria-hidden="true">/</span>
      <span aria-current="page"><?php echo esc_html( $term_name ); ?></span>
    </nav>
    <div class="tf-tax-eyebrow"><?php esc_html_e( 'Portfolio', 'themeflex' ); ?></div>
    <h1><?php
      $words = explode( ' ', esc_html( $term_name ) );
      $last  = array_pop( $words );
      echo ( count( $words ) ? implode( ' ', $words ) . ' ' : '' ) . '<em>' . $last . '</em>';
    ?></h1>
    <?php if ( $term_desc ) : ?>
      <p><?php echo esc_html( $term_desc ); ?></p>
    <?php endif; ?>
    <div class="tf-tax-count-pill">
      <strong><?php echo number_format_i18n( $term_count ); ?></strong>
      <?php esc_html_e( 'projects', 'themeflex' ); ?>
    </div>
  </div>
</div>

<!-- Category filter tabs -->
<?php
$all_cats = get_terms( array(
  'taxonomy'   => 'sf_portfolio_cat',
  'hide_empty' => true,
) );
if ( ! empty( $all_cats ) && ! is_wp_error( $all_cats ) ) : ?>
<nav class="tf-tax-cats" aria-label="<?php esc_attr_e( 'Filter by category', 'themeflex' ); ?>">
  <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>"
     class="tf-tax-cat-link">
    <?php esc_html_e( 'All Work', 'themeflex' ); ?>
  </a>
  <?php foreach ( $all_cats as $cat ) : ?>
  <a href="<?php echo esc_url( get_term_link( $cat ) ); ?>"
     class="tf-tax-cat-link <?php echo ( $term && $term->term_id === $cat->term_id ) ? 'is-active' : ''; ?>">
    <?php echo esc_html( $cat->name ); ?>
  </a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>

<!-- Grid -->
<div class="tf-tax-wrap">

  <?php if ( have_posts() ) : ?>
  <div class="tf-tax-grid">
    <?php
    /* Glow colors per category slug */
    $glow_map = array(
      'web-design'  => 'rgba(59,130,246,.18)',
      'e-commerce'  => 'rgba(168,85,247,.18)',
      'branding'    => 'rgba(239,68,68,.18)',
      'saas'        => 'rgba(16,185,129,.18)',
      'mobile-app'  => 'rgba(139,92,246,.18)',
      'dashboard'   => 'rgba(20,184,166,.18)',
    );
    $i = 0;
    while ( have_posts() ) : the_post();
      $cats     = wp_get_post_terms( get_the_ID(), 'sf_portfolio_cat', array( 'fields' => 'all' ) );
      $cat_name = ( ! empty( $cats ) && ! is_wp_error( $cats ) ) ? $cats[0]->name : '';
      $slug     = ( ! empty( $cats ) && ! is_wp_error( $cats ) ) ? $cats[0]->slug : '';
      $glow     = isset( $glow_map[ $slug ] ) ? $glow_map[ $slug ] : 'rgba(255,94,46,.12)';
    ?>
    <a href="<?php the_permalink(); ?>" class="tf-tax-card"
       style="--card-glow:<?php echo esc_attr( $glow ); ?>"
       aria-label="<?php the_title_attribute(); ?>">

      <?php if ( has_post_thumbnail() ) : ?>
        <?php the_post_thumbnail( 'medium_large', array(
          'class'   => 'tf-tax-card-img',
          'loading' => $i < 6 ? 'eager' : 'lazy',
          'alt'     => get_the_title(),
        ) ); ?>
      <?php else : ?>
        <!-- CSS placeholder when no featured image -->
        <div class="tf-tax-card-placeholder" aria-hidden="true">
          <div class="ph-hero"></div>
          <div class="ph-bar" style="width:75%"></div>
          <div class="ph-bar" style="width:55%"></div>
          <div class="ph-grid">
            <div class="ph-block"></div>
            <div class="ph-block"></div>
          </div>
        </div>
      <?php endif; ?>

      <div class="tf-tax-card-overlay"></div>

      <div class="tf-tax-card-body">
        <h2 class="tf-tax-card-title"><?php the_title(); ?></h2>
        <div class="tf-tax-card-meta">
          <?php if ( $cat_name ) : ?>
            <span><?php echo esc_html( $cat_name ); ?></span>
            <span class="tf-tax-card-meta-sep">·</span>
          <?php endif; ?>
          <span><?php echo get_the_date( 'Y' ); ?></span>
        </div>
      </div>

    </a>
    <?php
    $i++;
    endwhile;
    ?>
  </div><!-- .tf-tax-grid -->

  <nav class="tf-tax-pagination" aria-label="<?php esc_attr_e( 'Portfolio navigation', 'themeflex' ); ?>">
    <?php
    the_posts_pagination( array(
      'mid_size'  => 2,
      'prev_text' => '&larr; ' . esc_html__( 'Prev', 'themeflex' ),
      'next_text' => esc_html__( 'Next', 'themeflex' ) . ' &rarr;',
    ) );
    ?>
  </nav>

  <?php else : ?>
  <div class="tf-tax-empty">
    <h2><?php esc_html_e( 'No projects yet', 'themeflex' ); ?></h2>
    <p>
      <?php esc_html_e( 'There are no portfolio items in this category yet.', 'themeflex' ); ?>
      <a href="<?php echo esc_url( home_url( '/portfolio/' ) ); ?>">
        <?php esc_html_e( 'View all work', 'themeflex' ); ?>
      </a>
    </p>
  </div>
  <?php endif; wp_reset_postdata(); ?>

</div><!-- .tf-tax-wrap -->
</main>

<?php get_footer(); ?>
