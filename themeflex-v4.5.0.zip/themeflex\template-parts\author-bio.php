<?php
/**
 * Template part for displaying author bio on single posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! get_the_author_meta( 'description' ) ) {
	return;
}

$author_pages = themeflex_author_pages();
$author_id = get_the_author_meta( 'ID' );
$socials = $author_pages->get_author_socials( $author_id );

?>

<aside class="author-bio-widget">
	<div class="author-bio-card">
		<div class="author-bio-avatar">
			<?php
			echo get_avatar(
				get_the_author_meta( 'user_email' ),
				100,
				'',
				get_the_author_meta( 'display_name' ),
				array( 'class' => 'avatar-image' )
			);
			?>
		</div>

		<div class="author-bio-info">
			<h3 class="author-bio-name">
				<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>">
					<?php the_author(); ?>
				</a>
			</h3>

			<p class="author-bio-description">
				<?php echo wp_kses_post( nl2br( get_the_author_meta( 'description' ) ) ); ?>
			</p>

			<?php if ( ! empty( $socials ) ) : ?>
				<div class="author-bio-socials">
					<?php
					foreach ( $socials as $platform => $social ) {
						$icon = $author_pages->get_social_icon( $platform );
						?>
						<a href="<?php echo esc_url( $social['url'] ); ?>" title="<?php echo esc_attr( $social['label'] ); ?>" class="author-social-link" target="_blank" rel="noopener noreferrer">
							<?php if ( ! empty( $icon ) ) : ?>
								<i class="<?php echo esc_attr( $icon ); ?>"></i>
							<?php else : ?>
								<?php echo esc_html( $social['label'] ); ?>
							<?php endif; ?>
						</a>
						<?php
					}
					?>
				</div>
			<?php endif; ?>

			<?php if ( get_the_author_meta( 'user_url' ) ) : ?>
				<a href="<?php echo esc_url( get_the_author_meta( 'user_url' ) ); ?>" class="author-bio-link button" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Visit Website', 'themeflex' ); ?>
				</a>
			<?php endif; ?>
		</div>
	</div>
</aside>
