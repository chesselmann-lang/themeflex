<?php
/**
 * Blog List Layout Template Part
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-layout-list' . ( has_post_thumbnail() ? ' has-post-thumbnail' : '' ) ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-thumbnail">
			<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php the_post_thumbnail( 'themeflex-thumb-small' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<div class="post-content">
		<header class="entry-header">
			<div class="entry-meta">
				<span class="entry-date">
					<?php echo esc_html( get_the_date( 'M d, Y' ) ); ?>
				</span>
				<?php if ( has_category() ) : ?>
					<span class="entry-categories">
						<?php echo wp_kses_post( themeflex_get_post_categories( get_the_ID() ) ); ?>
					</span>
				<?php endif; ?>
			</div>
			<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
		</header>

		<div class="entry-content">
			<?php the_excerpt(); ?>
		</div>

		<footer class="entry-footer">
			<?php if ( get_the_author_meta( 'ID' ) ) : ?>
				<span class="entry-author">
					<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
						<?php the_author(); ?>
					</a>
				</span>
			<?php endif; ?>
			<a href="<?php echo esc_url( get_permalink() ); ?>" class="read-more">
				<?php esc_html_e( 'Continue Reading', 'themeflex' ); ?> →
			</a>
		</footer>
	</div>
</article>
