<?php
/**
 * Blog Masonry Layout Template Part
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'blog-post blog-layout-masonry' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-thumbnail">
			<a href="<?php echo esc_url( get_permalink() ); ?>">
				<?php the_post_thumbnail( 'themeflex-thumb-med' ); ?>
			</a>
		</div>
	<?php endif; ?>

	<header class="entry-header">
		<div class="entry-meta">
			<span class="entry-date">
				<?php echo esc_html( get_the_date() ); ?>
			</span>
			<?php if ( has_category() ) : ?>
				<span class="entry-categories">
					<?php echo wp_kses_post( themeflex_get_post_categories( get_the_ID() ) ); ?>
				</span>
			<?php endif; ?>
		</div>
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' ); ?>
		<p class="entry-excerpt">
			<?php echo esc_html( themeflex_get_excerpt_by_length( 15 ) ); ?>
		</p>
	</header>

	<footer class="entry-footer">
		<a href="<?php echo esc_url( get_permalink() ); ?>" class="read-more">
			<?php esc_html_e( 'Read More', 'themeflex' ); ?>
		</a>
	</footer>
</article>
