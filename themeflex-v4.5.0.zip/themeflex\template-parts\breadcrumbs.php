<?php
/**
 * Template part for displaying breadcrumbs
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( is_home() || is_front_page() ) {
	return;
}

$seo = themeflex_seo();
$breadcrumbs = $seo->get_breadcrumbs();

if ( empty( $breadcrumbs ) ) {
	return;
}

?>

<nav class="breadcrumbs" aria-label="<?php esc_attr_e( 'Breadcrumb', 'themeflex' ); ?>">
	<ol class="breadcrumb-list">
		<?php
		foreach ( $breadcrumbs as $index => $breadcrumb ) {
			$is_last = ( $index === count( $breadcrumbs ) - 1 );
			?>
			<li class="breadcrumb-item <?php echo $is_last ? 'active' : ''; ?>">
				<?php if ( ! $is_last ) : ?>
					<a href="<?php echo esc_url( $breadcrumb['url'] ); ?>">
						<?php echo esc_html( $breadcrumb['title'] ); ?>
					</a>
					<span class="breadcrumb-separator">/</span>
				<?php else : ?>
					<span><?php echo esc_html( $breadcrumb['title'] ); ?></span>
				<?php endif; ?>
			</li>
			<?php
		}
		?>
	</ol>
</nav>
