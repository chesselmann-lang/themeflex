<?php
/**
 * Coming Soon / Maintenance Page Template
 * @package ThemeFlex
 */
$settings = get_option('sf_theme_settings', []);
$msg = $settings['coming_soon_text'] ?? __('We\'re launching soon! Stay tuned.','themeflex');
$logo_id  = get_theme_mod('custom_logo');
$logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'medium') : '';
status_header(200);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="robots" content="noindex,nofollow">
<title><?php esc_html_e('Coming Soon','themeflex'); ?> — <?php bloginfo('name'); ?></title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;background:linear-gradient(135deg,#06021D 0%,#1a1f29 50%,#06021D 100%);min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff;overflow:hidden}
.cs-wrap{text-align:center;padding:40px 24px;position:relative;z-index:1;max-width:560px}
.cs-logo{margin-bottom:32px}
.cs-logo img{max-height:60px;filter:brightness(10)}
.cs-logo-text{font-size:24px;font-weight:900;letter-spacing:-.5px;background:linear-gradient(135deg,#FF5E2E,#00D4FF);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
h1{font-size:clamp(28px,5vw,56px);font-weight:900;line-height:1.1;letter-spacing:-.5px;margin-bottom:20px}
p{font-size:17px;color:rgba(255,255,255,.7);line-height:1.8;margin-bottom:36px}
.cs-form{display:flex;gap:8px;max-width:400px;margin:0 auto 24px}
.cs-form input{flex:1;padding:12px 16px;border:1px solid rgba(255,255,255,.15);border-radius:10px;background:rgba(255,255,255,.06);color:#fff;font-size:15px;font-family:inherit;outline:none}
.cs-form input::placeholder{color:rgba(255,255,255,.4)}
.cs-form button{padding:12px 20px;background:linear-gradient(135deg,#FF5E2E,#ED4C1C);color:#fff;border:none;border-radius:10px;font-weight:700;font-size:14px;cursor:pointer;white-space:nowrap}
.cs-social{display:flex;justify-content:center;gap:12px}
.cs-social a{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;text-decoration:none;transition:all .2s;color:rgba(255,255,255,.8)}
.cs-social a svg{width:16px;height:16px}
.cs-social a:hover{background:rgba(255,94,46,.3);border-color:rgba(255,94,46,.5)}
/* Orbs */
.cs-orb{position:fixed;border-radius:50%;filter:blur(80px);opacity:.2;pointer-events:none}
.cs-orb-1{width:500px;height:500px;background:radial-gradient(#FF5E2E,transparent);top:-100px;right:-100px}
.cs-orb-2{width:400px;height:400px;background:radial-gradient(#7c3aed,transparent);bottom:-80px;left:-80px}
</style>
</head>
<body>
<div class="cs-orb cs-orb-1"></div>
<div class="cs-orb cs-orb-2"></div>
<div class="cs-wrap">
    <div class="cs-logo">
        <?php if ($logo_url): ?>
        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" />
        <?php else: ?>
        <div class="cs-logo-text"><?php bloginfo('name'); ?></div>
        <?php endif; ?>
    </div>
    <h1><?php esc_html_e('Coming Soon','themeflex'); ?></h1>
    <p><?php echo wp_kses_post($msg); ?></p>
    <form class="cs-form" action="<?php echo esc_url(home_url('/wp-login.php')); ?>" method="post">
        <input type="email" placeholder="<?php esc_attr_e('Notify me by email...','themeflex'); ?>" />
        <button type="button" onclick="this.previousElementSibling.disabled=true;this.textContent='✓ Done';"><?php esc_html_e('Notify Me','themeflex'); ?></button>
    </form>
    <div class="cs-social">
        <?php
        $_cs_social_svgs = array(
          'facebook'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>',
          'twitter'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4l16 16M4 20L20 4"/></svg>',
          'instagram' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>',
          'linkedin'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>',
        );
        foreach($_cs_social_svgs as $net => $ico):
            $url = get_theme_mod("sf_social_{$net}",'');
            if ($url): ?>
        <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo esc_attr(ucfirst($net)); ?>"><?php echo $_cs_social_svgs[$net]; ?></a>
        <?php endif; endforeach; ?>
    </div>
</div>
</body>
</html>
<?php exit; ?>
