<?php
/**
 * Template part for displaying posts in grid/card layout
 *
 * @package ThemeFlex
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry entry--grid' ); ?>>
	<div class="entry__card">
		<?php
		// Featured image as background or top image
		if ( has_post_thumbnail() ) {
			$thumbnail_id = get_post_thumbnail_id();
			$thumbnail_alt = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );

			echo '<div class="entry__card-image">';
			echo get_the_post_thumbnail(
				get_the_ID(),
				'medium',
				array(
					'alt' => esc_attr( $thumbnail_alt ),
					'class' => 'entry__card-img',
				)
			);

			// Category badge overlay
			$categories = get_the_category();
			if ( ! empty( $categories ) ) {
				echo '<div class="entry__card-category">';
				echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '" class="badge">';
				echo esc_html( $categories[0]->name );
				echo '</a>';
				echo '</div>';
			}

			echo '</div>';
		}
		?>

		<div class="entry__card-content">
			<header class="entry__header">
				<?php
				the_title( sprintf( '<h3 class="entry__title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
				?>
			</header><!-- .entry__header -->

			<div class="entry__excerpt">
				<?php
				if ( has_excerpt() ) {
					the_excerpt();
				} else {
					echo wp_kses_post( wp_trim_words( get_the_content(), 20 ) );
				}
				?>
			</div><!-- .entry__excerpt -->

			<div class="entry__meta entry__meta--grid">
				<span class="meta__date"><?php echo esc_html( get_the_date( 'M d, Y' ) ); ?></span>
				<?php
				$reading_time = themeflex_get_reading_time( get_the_content() );
				if ( $reading_time > 0 ) {
					echo '<span class="meta__reading-time">';
					printf(
						/* translators: %d: number of minutes. */
						esc_html( _n( '%d min read', '%d min read', $reading_time, 'themeflex' ) ),
						intval( $reading_time )
					);
					echo '</span>';
				}
				?>
			</div><!-- .entry__meta -->
		</div><!-- .entry__card-content -->
	</div><!-- .entry__card -->
</article><!-- #post-<?php the_ID(); ?> -->
