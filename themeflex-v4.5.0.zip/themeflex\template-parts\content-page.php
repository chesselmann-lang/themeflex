<?php
/**
 * Template part for displaying page content — ThemeFlex
 * Dark-first. Handles static page content rendering.
 *
 * @package ThemeFlex
 * @since 1.3.0
 */

// If this is an Elementor page, let Elementor handle its own rendering.
// This file provides the fallback for non-Elementor (classic editor) pages.
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'tf-page-article' ); ?>>
<style>
/* ── Page Article ──────────────────────────────────────────────────── */
.tf-page-article{color:#94a3b8}
/* Page title (shown when no Elementor content) */
.tf-page-header{margin-bottom:48px;padding-bottom:32px;border-bottom:1px solid rgba(255,255,255,.07)}
.tf-page-title{
  font-family:'Inter Tight',sans-serif;
  font-size:clamp(28px,5vw,52px);font-weight:900;
  color:#f1f5f9;margin:0 0 12px;
  letter-spacing:-.5px;line-height:1.12;
}
/* Breadcrumb */
.tf-page-breadcrumb{font-size:.78rem;color:#64748b;margin-bottom:20px}
.tf-page-breadcrumb a{color:#ff5e2e;text-decoration:none}
.tf-page-breadcrumb a:hover{text-decoration:underline}
/* Page content (classic editor) */
.tf-page-content{
  font-size:17px;line-height:1.85;color:#94a3b8;max-width:760px;
}
.tf-page-content h2,.tf-page-content h3,.tf-page-content h4{
  font-family:'Inter Tight',sans-serif;font-weight:800;color:#f1f5f9;
  margin:2em 0 .75em;letter-spacing:-.3px;
}
.tf-page-content h2{font-size:1.7rem}
.tf-page-content h3{font-size:1.3rem}
.tf-page-content h4{font-size:1.1rem}
.tf-page-content p{margin-bottom:1.5em}
.tf-page-content a{color:#ff5e2e;text-decoration:underline}
.tf-page-content a:hover{color:#ff8c5a}
.tf-page-content img{border-radius:10px;max-width:100%;height:auto;display:block;margin:24px 0}
.tf-page-content blockquote{
  border-left:4px solid #ff5e2e;
  padding:16px 24px;
  background:rgba(255,94,46,.05);
  border-radius:0 8px 8px 0;
  margin:1.5em 0;font-style:italic;
}
.tf-page-content ul,.tf-page-content ol{padding-left:24px;margin-bottom:1.5em}
.tf-page-content li{margin-bottom:.5em;line-height:1.7}
.tf-page-content hr{border:none;border-top:1px solid rgba(255,255,255,.08);margin:2em 0}
.tf-page-content table{width:100%;border-collapse:collapse;margin:1.5em 0;font-size:15px}
.tf-page-content table th,.tf-page-content table td{padding:12px 16px;border:1px solid rgba(255,255,255,.08);text-align:left}
.tf-page-content table th{background:rgba(255,255,255,.05);font-weight:700;color:#f1f5f9}
.tf-page-content code{
  background:#111827;border:1px solid rgba(255,255,255,.08);
  border-radius:4px;padding:2px 6px;font-family:'JetBrains Mono','Fira Code',monospace;font-size:13px;color:#f1f5f9;
}
.tf-page-content pre{
  background:#111827;border:1px solid rgba(255,255,255,.08);
  border-radius:10px;padding:20px;overflow-x:auto;line-height:1.7;
  font-family:'JetBrains Mono','Fira Code',monospace;font-size:13px;
}
/* Edit link */
.tf-page-edit{
  margin-top:40px;padding-top:20px;border-top:1px solid rgba(255,255,255,.07);
  font-size:13px;
}
.tf-page-edit a{color:#ff5e2e;text-decoration:none}
</style>

  <!-- Page Header -->
  <header class="tf-page-header">
    <!-- Breadcrumb -->
    <div class="tf-page-breadcrumb">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'themeflex' ); ?></a>
      <span> / </span>
      <span><?php the_title(); ?></span>
    </div>

    <?php if ( has_post_thumbnail() ) : ?>
      <div style="margin-bottom:32px;border-radius:16px;overflow:hidden;aspect-ratio:16/6;max-height:480px;">
        <?php the_post_thumbnail( 'full', ['style' => 'width:100%;height:100%;object-fit:cover;display:block;'] ); ?>
      </div>
    <?php endif; ?>

    <h1 class="tf-page-title"><?php the_title(); ?></h1>
  </header><!-- .tf-page-header -->

  <!-- Page Content -->
  <div class="tf-page-content">
    <?php
    the_content();
    wp_link_pages( [
      'before' => '<nav class="page-links" style="margin-top:32px;font-size:14px;color:#64748b;">' . esc_html__( 'Pages:', 'themeflex' ) . ' ',
      'after'  => '</nav>',
    ] );
    ?>
  </div><!-- .tf-page-content -->

  <?php if ( get_edit_post_link() ) : ?>
  <div class="tf-page-edit">
    <?php
    edit_post_link(
      sprintf(
        wp_kses( __( 'Edit <span class="screen-reader-text">"%s"</span>', 'themeflex' ), ['span' => ['class' => []]] ),
        wp_kses_post( get_the_title() )
      ),
      '', ''
    );
    ?>
  </div>
  <?php endif; ?>

</article><!-- #post-<?php the_ID(); ?> -->
