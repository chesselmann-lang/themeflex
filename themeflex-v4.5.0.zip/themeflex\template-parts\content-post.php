<?php
/**
 * Template part for displaying post content
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-item' ); ?>>
	<header class="post-header">
		<?php
		/**
		 * Featured image
		 *
		 * @since 1.0.0
		 */
		if ( has_post_thumbnail() ) {
			?>
			<div class="post-thumbnail">
				<?php
				if ( is_singular( 'post' ) ) {
					the_post_thumbnail( 'themeflex-thumb-big' );
				} else {
					?>
					<a href="<?php the_permalink(); ?>" class="post-thumbnail-link">
						<?php the_post_thumbnail( 'themeflex-thumb-med' ); ?>
					</a>
					<?php
				}
				?>
			</div>
			<?php
		}
		?>

		<h2 class="post-title">
			<?php
			if ( is_singular( 'post' ) ) {
				the_title();
			} else {
				?>
				<a href="<?php the_permalink(); ?>" rel="bookmark">
					<?php the_title(); ?>
				</a>
				<?php
			}
			?>
		</h2>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
			<span class="post-author">
				<?php esc_html_e( 'by', 'themeflex' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
			</span>
			<?php
			if ( has_category() ) {
				?>
				<span class="post-categories">
					<?php the_category( ', ' ); ?>
				</span>
				<?php
			}

			if ( has_tag() ) {
				?>
				<span class="post-tags">
					<?php the_tags( '', ', ' ); ?>
				</span>
				<?php
			}
			?>
		</div>
	</header><!-- .post-header -->

	<div class="post-content">
		<?php
		if ( is_singular( 'post' ) ) {
			the_content(
				sprintf(
					wp_kses(
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'themeflex' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				)
			);

			wp_link_pages(
				array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'themeflex' ),
					'after'  => '</div>',
				)
			);
		} else {
			the_excerpt();
			?>
			<a href="<?php the_permalink(); ?>" class="read-more-link button">
				<?php esc_html_e( 'Read More', 'themeflex' ); ?>
			</a>
			<?php
		}
		?>
	</div><!-- .post-content -->

	<?php
	if ( ! is_singular( 'post' ) ) {
		?>
		<footer class="post-footer">
			<?php
			if ( 0 !== comments_number() ) {
				?>
				<span class="post-comments">
					<?php comments_popup_link( esc_html__( 'No Comments', 'themeflex' ), esc_html__( '1 Comment', 'themeflex' ), esc_html__( '% Comments', 'themeflex' ) ); ?>
				</span>
				<?php
			}
			?>
		</footer><!-- .post-footer -->
		<?php
	}
	?>
</article><!-- #post-<?php the_ID(); ?> -->
