<?php
/**
 * Template part for displaying single post content
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
	<header class="post-header">
		<?php
		if ( has_post_thumbnail() ) {
			?>
			<div class="post-thumbnail">
				<?php the_post_thumbnail( 'themeflex-thumb-big' ); ?>
			</div>
			<?php
		}
		?>

		<h1 class="post-title"><?php the_title(); ?></h1>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
			<span class="post-author">
				<?php esc_html_e( 'by', 'themeflex' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
			</span>
			<?php
			if ( has_category() ) {
				?>
				<span class="post-categories">
					<?php the_category( ', ' ); ?>
				</span>
				<?php
			}

			if ( has_tag() ) {
				?>
				<span class="post-tags">
					<?php the_tags( '', ', ' ); ?>
				</span>
				<?php
			}
			?>
		</div>
	</header><!-- .post-header -->

	<div class="post-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'themeflex' ),
				'after'  => '</div>',
			)
		);
		?>
	</div><!-- .post-content -->

	<footer class="post-footer">
		<?php
		wp_list_categories( array(
			'title_li' => __( 'Category: ', 'themeflex' ),
		) );
		?>
	</footer><!-- .post-footer -->
</article><!-- #post-<?php the_ID(); ?> -->
