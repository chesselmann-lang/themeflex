<?php
/**
 * Template part for displaying aside format posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-aside post-format-aside' ); ?>>
	<div class="aside-content-wrapper">
		<div class="aside-content">
			<?php the_content(); ?>
		</div>

		<footer class="aside-meta">
			<a href="<?php the_permalink(); ?>" class="aside-permalink">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date( 'M j, Y H:i' ) ); ?>
				</time>
			</a>
		</footer>
	</div>
</article>
