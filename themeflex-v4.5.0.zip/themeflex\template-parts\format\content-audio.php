<?php
/**
 * Template part for displaying audio format posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

$post_formats = themeflex_post_formats();
$audio_url = $post_formats->get_audio_url();

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-audio post-format-audio' ); ?>>
	<?php if ( ! empty( $audio_url ) ) : ?>
		<div class="post-audio-player">
			<audio class="audio-player" controls>
				<source src="<?php echo esc_attr( $audio_url ); ?>" type="audio/mpeg">
				<?php esc_html_e( 'Your browser does not support the audio element.', 'themeflex' ); ?>
			</audio>
		</div>
	<?php endif; ?>

	<header class="post-header">
		<h1 class="post-title"><?php the_title(); ?></h1>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
			<span class="post-author">
				<?php esc_html_e( 'by', 'themeflex' ); ?> <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>"><?php the_author(); ?></a>
			</span>
		</div>
	</header>

	<div class="post-content">
		<?php the_content(); ?>
	</div>
</article>
