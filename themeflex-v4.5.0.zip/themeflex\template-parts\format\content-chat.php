<?php
/**
 * Template part for displaying chat format posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-chat post-format-chat' ); ?>>
	<header class="post-header">
		<h1 class="post-title"><?php the_title(); ?></h1>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
		</div>
	</header>

	<div class="post-chat-transcript">
		<?php
		$content = get_the_content();
		$lines = explode( "\n", $content );
		$speaker = 'person-a';

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( empty( $line ) ) {
				continue;
			}

			// Parse format: "Speaker: Message" or just "Message"
			if ( preg_match( '/^([^:]+):\s*(.+)$/', $line, $matches ) ) {
				$speaker_name = trim( $matches[1] );
				$message = trim( $matches[2] );
			} else {
				$speaker_name = '';
				$message = $line;
			}

			$class = 'person-a' === $speaker ? 'chat-message-a' : 'chat-message-b';
			?>
			<div class="chat-message <?php echo esc_attr( $class ); ?>">
				<?php if ( ! empty( $speaker_name ) ) : ?>
					<strong class="chat-speaker"><?php echo esc_html( $speaker_name ); ?></strong>
				<?php endif; ?>
				<p class="chat-text"><?php echo wp_kses_post( $message ); ?></p>
			</div>
			<?php

			// Alternate speaker
			$speaker = 'person-a' === $speaker ? 'person-b' : 'person-a';
		}
		?>
	</div>
</article>
