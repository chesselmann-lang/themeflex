<?php
/**
 * Template part for displaying image format posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-image post-format-image' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<div class="post-image-featured">
			<figure class="featured-image-figure">
				<?php the_post_thumbnail( 'full' ); ?>
			</figure>
		</div>
	<?php endif; ?>

	<div class="post-content">
		<h1 class="post-title"><?php the_title(); ?></h1>

		<div class="post-meta">
			<span class="post-date">
				<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
					<?php echo esc_html( get_the_date() ); ?>
				</time>
			</span>
		</div>

		<?php the_content(); ?>
	</div>
</article>
