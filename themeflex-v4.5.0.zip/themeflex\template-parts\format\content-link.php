<?php
/**
 * Template part for displaying link format posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

$post_formats = themeflex_post_formats();
$link_url = $post_formats->get_link_url();
$link_title = $post_formats->get_link_title();
$favicon = $post_formats->get_favicon( $link_url );

if ( empty( $link_title ) ) {
	$link_title = wp_parse_url( $link_url, PHP_URL_HOST );
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-link post-format-link' ); ?>>
	<?php if ( ! empty( $link_url ) ) : ?>
		<div class="post-link-card">
			<?php if ( ! empty( $favicon ) ) : ?>
				<div class="link-favicon">
					<img src="<?php echo esc_attr( $favicon ); ?>" alt="<?php esc_attr_e( 'Website Icon', 'themeflex' ); ?>" />
				</div>
			<?php endif; ?>

			<div class="link-content">
				<h3 class="link-title">
					<a href="<?php echo esc_url( $link_url ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo esc_html( $link_title ); ?>
						<span class="link-icon">↗</span>
					</a>
				</h3>

				<?php if ( ! empty( get_the_excerpt() ) ) : ?>
					<p class="link-description"><?php the_excerpt(); ?></p>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>

	<div class="post-content">
		<?php the_content(); ?>
	</div>
</article>
