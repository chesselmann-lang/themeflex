<?php
/**
 * Template part for displaying status format posts
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-status post-format-status' ); ?>>
	<div class="post-status-card">
		<div class="status-header">
			<div class="status-avatar">
				<?php
				echo get_avatar(
					get_the_author_meta( 'user_email' ),
					48,
					'',
					get_the_author_meta( 'display_name' ),
					array( 'class' => 'status-avatar-image' )
				);
				?>
			</div>

			<div class="status-info">
				<strong class="status-author">
					<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
						<?php the_author(); ?>
					</a>
				</strong>
				<div class="status-time">
					<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>">
						<?php echo esc_html( get_the_date( 'M j, Y H:i' ) ); ?>
					</time>
				</div>
			</div>
		</div>

		<div class="status-content">
			<?php the_content(); ?>
		</div>

		<div class="status-actions">
			<a href="<?php the_permalink(); ?>" class="status-permalink">
				<?php esc_html_e( 'View', 'themeflex' ); ?>
			</a>
		</div>
	</div>
</article>
