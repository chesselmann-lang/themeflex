<?php
/**
 * Front Page About v3.0 — Split layout with timeline + animated stats
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_about_enabled', true ) ) return;

$title    = get_theme_mod( 'sf_about_title',    'Engineered for Agencies Who Refuse to Settle' );
$subtitle = get_theme_mod( 'sf_about_subtitle', "We built ThemeFlex because every other theme we used had the same problem: great in the demo, painful in production. Slow load times, impossible customisation, and no real dark mode. So we started over." );
$tag      = get_theme_mod( 'sf_about_tag',      'About ThemeFlex' );
?>

<section class="tf-about-sec" id="sf-about" aria-label="<?php esc_attr_e('About','themeflex'); ?>">
<style>
/* ═══════════════════════════════════════════════════════════════
   ABOUT v3 — Split layout
   ═══════════════════════════════════════════════════════════════ */
.tf-about-sec {
  padding: 120px 0;
  background: #06021d;
  position: relative;
  overflow: hidden;
}
.tf-about-sec::after {
  content: '';
  position: absolute;
  bottom: -200px; right: -200px;
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(0,212,255,.06), transparent 70%);
  pointer-events: none;
}
.tf-about-wrap { max-width: 1260px; margin: 0 auto; padding: 0 32px; }

.tf-about-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
}

/* LEFT */
.tf-about-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 22px;
}
.tf-about-h2 {
  font-size: clamp(1.8rem, 3vw, 2.8rem);
  font-weight: 900; color: #f1f5f9; margin: 0 0 20px; line-height: 1.15; letter-spacing: -.02em;
}
.tf-about-p { font-size: 1rem; color: #64748b; line-height: 1.8; margin: 0 0 36px; }

/* Feature list */
.tf-about-checks { list-style: none; padding: 0; margin: 0 0 36px; display: flex; flex-direction: column; gap: 14px; }
.tf-about-check { display: flex; align-items: flex-start; gap: 12px; font-size: .9rem; color: #94a3b8; }
.tf-about-check-icon {
  width: 22px; height: 22px; border-radius: 50%; flex-shrink: 0; margin-top: 1px;
  background: rgba(16,185,129,.15); border: 1px solid rgba(16,185,129,.3);
  display: flex; align-items: center; justify-content: center;
  font-size: .7rem; color: #10b981;
}
.tf-about-cta {
  display: inline-flex; align-items: center; gap: 10px;
  background: transparent; border: 2px solid rgba(255,94,46,.3);
  color: #ff5e2e; font-size: .9rem; font-weight: 700;
  padding: 13px 28px; border-radius: 100px; text-decoration: none;
  transition: background .2s, border-color .2s;
}
.tf-about-cta:hover { background: rgba(255,94,46,.08); border-color: rgba(255,94,46,.5); }

/* RIGHT — Visual stack */
.tf-about-visual { position: relative; }

/* Main card */
.tf-about-main-card {
  background: #0d1526;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 20px;
  padding: 32px;
}
.tf-about-card-tag { font-size: .68rem; font-weight: 700; letter-spacing: .1em; text-transform: uppercase; color: #ff5e2e; margin-bottom: 16px; }
.tf-about-card-h { font-size: 1.1rem; font-weight: 800; color: #f1f5f9; margin-bottom: 20px; }

/* Mini stats grid */
.tf-about-stats-mini { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 24px; }
.tf-about-stat-mini {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.06);
  border-radius: 12px;
  padding: 16px;
}
.tf-about-stat-val { font-size: 1.8rem; font-weight: 900; color: #f1f5f9; line-height: 1; margin-bottom: 4px; }
.tf-about-stat-lbl { font-size: .72rem; color: #475569; font-weight: 600; }

/* Progress bars */
.tf-about-prog-label { display: flex; justify-content: space-between; font-size: .78rem; margin-bottom: 6px; }
.tf-about-prog-label-name { color: #94a3b8; font-weight: 600; }
.tf-about-prog-label-val { color: #ff5e2e; font-weight: 800; }
.tf-about-prog-bar { height: 6px; background: rgba(255,255,255,.06); border-radius: 100px; margin-bottom: 14px; overflow: hidden; }
.tf-about-prog-fill {
  height: 100%; border-radius: 100px;
  background: linear-gradient(90deg, #ff5e2e, #ff8c5a);
  width: 0;
  transition: width 1.5s ease;
}
.tf-about-prog-fill.tf-visible { width: var(--fill); }

/* Floating badge */
.tf-about-float-badge {
  position: absolute;
  bottom: -20px; left: -24px;
  background: rgba(16,185,129,.15);
  border: 1px solid rgba(16,185,129,.3);
  border-radius: 14px;
  padding: 12px 18px;
  display: flex; align-items: center; gap: 10px;
  box-shadow: 0 8px 24px rgba(0,0,0,.3);
  z-index: 5;
  animation: tfAboutBadge 5s ease-in-out infinite;
}
@keyframes tfAboutBadge { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
.tf-about-float-icon { font-size: 1.4rem; }
.tf-about-float-label { font-size: .78rem; font-weight: 800; color: #10b981; }
.tf-about-float-sub   { font-size: .65rem; color: #064e3b; }

/* Responsive */
@media(max-width:1024px) { .tf-about-grid { grid-template-columns: 1fr; gap: 48px; } .tf-about-visual { max-width: 560px; } }
</style>

<div class="tf-about-wrap">
<div class="tf-about-grid">

  <!-- LEFT -->
  <div class="tf-about-left">
    <div class="tf-about-eyebrow">◆ <?php echo esc_html($tag); ?></div>
    <h2 class="tf-about-h2"><?php echo esc_html($title); ?></h2>
    <p class="tf-about-p"><?php echo esc_html($subtitle); ?></p>

    <ul class="tf-about-checks">
      <?php
      $checks = array(
        __('Dark-first by default — every template, widget, and section.','themeflex'),
        __('97 PageSpeed on a fresh install. No plugins, no tricks.','themeflex'),
        __('80+ Elementor widgets that are actually production-ready.','themeflex'),
        __('8 colour skins that switch the entire visual language instantly.','themeflex'),
        __('12+ one-click demos that actually import cleanly.','themeflex'),
      );
      foreach($checks as $c) : ?>
      <li class="tf-about-check">
        <span class="tf-about-check-icon" aria-hidden="true">✓</span>
        <?php echo esc_html($c); ?>
      </li>
      <?php endforeach; ?>
    </ul>

    <a href="<?php echo esc_url(home_url('/about')); ?>" class="tf-about-cta">
      <?php esc_html_e('Our Full Story','themeflex'); ?> →
    </a>
  </div>

  <!-- RIGHT -->
  <div class="tf-about-visual">
    <div class="tf-about-main-card">
      <div class="tf-about-card-tag">◆ <?php esc_html_e('By the Numbers','themeflex'); ?></div>
      <div class="tf-about-card-h"><?php esc_html_e('Real metrics. No marketing.','themeflex'); ?></div>

      <div class="tf-about-stats-mini">
        <div class="tf-about-stat-mini">
          <div class="tf-about-stat-val">97</div>
          <div class="tf-about-stat-lbl"><?php esc_html_e('PageSpeed Score','themeflex'); ?></div>
        </div>
        <div class="tf-about-stat-mini">
          <div class="tf-about-stat-val">2K+</div>
          <div class="tf-about-stat-lbl"><?php esc_html_e('Active Installs','themeflex'); ?></div>
        </div>
        <div class="tf-about-stat-mini">
          <div class="tf-about-stat-val">4.9★</div>
          <div class="tf-about-stat-lbl"><?php esc_html_e('Rating','themeflex'); ?></div>
        </div>
        <div class="tf-about-stat-mini">
          <div class="tf-about-stat-val">80+</div>
          <div class="tf-about-stat-lbl"><?php esc_html_e('Widgets','themeflex'); ?></div>
        </div>
      </div>

      <!-- Progress bars -->
      <?php
      $progs = array(
        array('Performance Score','97%','97%'),
        array('Customer Satisfaction','98%','98%'),
        array('Code Quality (PHPCS)','96%','96%'),
        array('Accessibility (WCAG 2.1 AA)','100%','100%'),
      );
      foreach($progs as list($label,$pct,$fill)) : ?>
      <div>
        <div class="tf-about-prog-label">
          <span class="tf-about-prog-label-name"><?php echo esc_html($label); ?></span>
          <span class="tf-about-prog-label-val"><?php echo esc_html($pct); ?></span>
        </div>
        <div class="tf-about-prog-bar">
          <div class="tf-about-prog-fill" style="--fill:<?php echo esc_attr($fill); ?>" data-fill="<?php echo esc_attr($fill); ?>"></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Floating badge -->
    <div class="tf-about-float-badge" aria-hidden="true">
      <div class="tf-about-float-icon">⚡</div>
      <div>
        <div class="tf-about-float-label"><?php esc_html_e('0.6s FCP','themeflex'); ?></div>
        <div class="tf-about-float-sub"><?php esc_html_e('World-class performance','themeflex'); ?></div>
      </div>
    </div>
  </div>

</div>
</div>

<script>
(function(){
  var fills = document.querySelectorAll('.tf-about-prog-fill');
  if(!fills.length || !window.IntersectionObserver) return;
  var obs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting) {
        e.target.style.width = e.target.dataset.fill;
        obs.unobserve(e.target);
      }
    });
  }, {threshold:0.3});
  fills.forEach(function(f){ obs.observe(f); });
})();
</script>

</section>
