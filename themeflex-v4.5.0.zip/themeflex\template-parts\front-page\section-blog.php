<?php
/**
 * Front Page Blog Section — ThemeFlex v4.0 Magazine Layout
 *
 * Magazine-style: hero featured post left (60%) + 2 stacked posts right (40%).
 * Dark-first, self-contained, no external dependencies.
 *
 * @package ThemeFlex
 * @since   2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_blog_enabled', true ) ) return;

$tag            = get_theme_mod( 'sf_blog_tag',       'From the Blog' );
$title          = get_theme_mod( 'sf_blog_title',     'Insights & Ideas' );
$subtitle       = get_theme_mod( 'sf_blog_subtitle',  'Expert tips, design trends and WordPress know-how from the ThemeFlex team.' );
$cta_label      = get_theme_mod( 'sf_blog_cta_label', 'View All Articles' );
$cta_url        = get_theme_mod( 'sf_blog_cta_url',   home_url( '/blog/' ) );
$padding_top    = absint( get_theme_mod( 'sf_blog_padding_top',    120 ) );
$padding_bottom = absint( get_theme_mod( 'sf_blog_padding_bottom', 120 ) );
$custom_class   = sanitize_html_class( get_theme_mod( 'sf_blog_custom_class', '' ) );

/* Category → gradient map */
$cat_gradients = [
	'design'      => ['from'=>'#1a0a1a','to'=>'#2d0a2e','accent'=>'#a855f7'],
	'development' => ['from'=>'#021830','to'=>'#051f3a','accent'=>'#3b82f6'],
	'tutorial'    => ['from'=>'#1a1400','to'=>'#241c00','accent'=>'#f59e0b'],
	'seo'         => ['from'=>'#001a0a','to'=>'#002e14','accent'=>'#10b981'],
	'ecommerce'   => ['from'=>'#1a001a','to'=>'#2e0030','accent'=>'#ec4899'],
	'wordpress'   => ['from'=>'#001a2e','to'=>'#00264d','accent'=>'#0ea5e9'],
	'marketing'   => ['from'=>'#0a1a00','to'=>'#162400','accent'=>'#84cc16'],
	'tips'        => ['from'=>'#1a0a00','to'=>'#2e1600','accent'=>'#f97316'],
];
$grad_default = ['from'=>'#060821','to'=>'#0d1526','accent'=>'#ff5e2e'];

$q = new WP_Query([
	'post_type'      => 'post',
	'post_status'    => 'publish',
	'posts_per_page' => 3,
	'no_found_rows'  => true,
]);
if ( ! $q->have_posts() ) return;

$posts = [];
while ( $q->have_posts() ) { $q->the_post(); $posts[] = get_post(); }
wp_reset_postdata();

if ( ! function_exists( 'tf_blog_read_time' ) ) {
	function tf_blog_read_time( $post ) {
		$words = str_word_count( wp_strip_all_tags( $post->post_content ) );
		return max( 1, (int) ceil( $words / 200 ) );
	}
}
if ( ! function_exists( 'tf_blog_grad' ) ) {
	function tf_blog_grad( $post, $map, $default ) {
		$cats = get_the_category( $post->ID );
		$slug = $cats ? strtolower( $cats[0]->slug ) : '';
		return isset( $map[$slug] ) ? $map[$slug] : $default;
	}
}
?>
<section
	class="sf-blog-section <?php echo esc_attr( $custom_class ); ?>"
	id="blog"
	style="padding-top:<?php echo $padding_top; ?>px;padding-bottom:<?php echo $padding_bottom; ?>px;"
	aria-label="<?php esc_attr_e( 'Blog', 'themeflex' ); ?>"
>
<style>
/* ══════════════════════════════════════════════════════════
   BLOG SECTION v4 — Magazine Layout
   ══════════════════════════════════════════════════════════ */
.sf-blog-section {
  background: linear-gradient(180deg, #0d1526 0%, #06021d 100%);
  position: relative;
  overflow: hidden;
}
.sf-blog-section::before {
  content: '';
  position: absolute;
  top: -200px; right: -200px;
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(255,94,46,.07) 0%, transparent 70%);
  pointer-events: none;
}

/* ── Container ── */
.sf-blog-wrap { max-width: 1240px; margin: 0 auto; padding: 0 24px; }

/* ── Section Header ── */
.sf-blog-hd {
  display: flex; align-items: flex-end; justify-content: space-between;
  gap: 24px; margin-bottom: 52px; flex-wrap: wrap;
}
.sf-blog-hd-left { max-width: 560px; }
.sf-blog-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.22);
  color: #ff5e2e; font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px;
  margin-bottom: 18px;
}
.sf-blog-eyebrow::before { content: '✦'; font-size: .55rem; }
.sf-blog-hd-left h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 900; color: #fff; margin: 0 0 12px;
  letter-spacing: -.04em; line-height: 1.08;
}
.sf-blog-hd-left h2 span {
  background: linear-gradient(135deg, #ff5e2e, #ff9d5e);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.sf-blog-hd-left p { color: #94a3b8; font-size: .975rem; line-height: 1.7; margin: 0; }
.sf-blog-hd-cta {
  flex-shrink: 0;
  display: inline-flex; align-items: center; gap: 8px;
  border: 2px solid rgba(255,255,255,.12); color: #94a3b8;
  font-size: .8rem; font-weight: 700; letter-spacing: .05em;
  padding: 11px 24px; border-radius: 100px;
  text-decoration: none; transition: border-color .25s, color .25s, background .25s;
  white-space: nowrap;
}
.sf-blog-hd-cta:hover {
  border-color: #ff5e2e; color: #ff5e2e;
}
.sf-blog-hd-cta svg { width: 14px; height: 14px; transition: transform .25s; }
.sf-blog-hd-cta:hover svg { transform: translateX(4px); }

/* ── Magazine Grid ── */
.sf-blog-magazine {
  display: grid;
  grid-template-columns: 1.35fr 1fr;
  gap: 2px;
  background: rgba(255,255,255,.05);
  border-radius: 20px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,.07);
}

/* ── Featured (left) ── */
.sf-blog-featured {
  position: relative; overflow: hidden;
  display: flex; flex-direction: column;
  background: #0d1526; min-height: 520px;
  text-decoration: none;
}
.sf-blog-featured-img {
  position: absolute; inset: 0; overflow: hidden;
}
.sf-blog-featured-img img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform .6s ease;
}
.sf-blog-featured:hover .sf-blog-featured-img img { transform: scale(1.04); }
.sf-blog-featured-gradient {
  position: absolute; inset: 0;
  background: linear-gradient(180deg,
    transparent 0%,
    rgba(6,2,29,.3) 30%,
    rgba(6,2,29,.88) 75%,
    rgba(6,2,29,.98) 100%
  );
}
.sf-blog-featured-pseudo {
  position: absolute; inset: 0; background: inherit;
  transition: opacity .35s;
}
.sf-blog-featured-body {
  position: relative; z-index: 2;
  display: flex; flex-direction: column; justify-content: flex-end;
  height: 100%; padding: 36px;
}
.sf-blog-cat-badge {
  display: inline-flex; align-items: center;
  background: rgba(255,255,255,.12); backdrop-filter: blur(8px);
  color: #fff; font-size: .62rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 5px 12px; border-radius: 6px;
  margin-bottom: 14px; align-self: flex-start;
}
.sf-blog-cat-badge.--accent {
  background: var(--cat-accent, #ff5e2e);
}
.sf-blog-featured-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(1.25rem, 2.2vw, 1.65rem);
  font-weight: 900; color: #fff;
  margin: 0 0 10px; line-height: 1.2; letter-spacing: -.02em;
}
.sf-blog-featured-title:hover { color: #ff8a60; }
.sf-blog-featured-excerpt {
  font-size: .88rem; color: rgba(255,255,255,.7);
  line-height: 1.65; margin: 0 0 20px;
  display: -webkit-box; -webkit-line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
}
.sf-blog-meta {
  display: flex; align-items: center; gap: 12px;
  font-size: .74rem; color: rgba(255,255,255,.5);
}
.sf-blog-meta-avatar {
  width: 28px; height: 28px; border-radius: 50%;
  border: 2px solid rgba(255,255,255,.2); overflow: hidden; flex-shrink: 0;
}
.sf-blog-meta-avatar img { width: 100%; height: 100%; object-fit: cover; }
.sf-blog-meta-sep { opacity: .3; }
.sf-blog-readmore-arrow {
  margin-top: 18px; display: inline-flex; align-items: center; gap: 6px;
  font-size: .78rem; font-weight: 700; color: #ff5e2e;
  letter-spacing: .04em; text-decoration: none; align-self: flex-start;
  transition: gap .2s;
}
.sf-blog-featured:hover .sf-blog-readmore-arrow { gap: 10px; }

/* ── Secondary stack (right) ── */
.sf-blog-stack {
  display: flex; flex-direction: column; gap: 2px;
}
.sf-blog-card {
  flex: 1; background: #0d1526; display: flex; overflow: hidden;
  text-decoration: none; position: relative;
  transition: background .3s;
}
.sf-blog-card:hover { background: #111d35; }
.sf-blog-card-thumb {
  width: 120px; flex-shrink: 0; position: relative; overflow: hidden;
}
.sf-blog-card-thumb img {
  position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;
  transition: transform .5s ease;
}
.sf-blog-card:hover .sf-blog-card-thumb img { transform: scale(1.07); }
.sf-blog-card-thumb-placeholder {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center; font-size: 2rem;
}
.sf-blog-card-body {
  padding: 22px 22px 22px; flex: 1; display: flex; flex-direction: column;
  justify-content: center;
}
.sf-blog-card-cat {
  font-size: .62rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; color: #ff5e2e; margin-bottom: 6px;
}
.sf-blog-card-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: .95rem; font-weight: 800; color: #f1f5f9;
  margin: 0 0 8px; line-height: 1.3; letter-spacing: -.01em;
  display: -webkit-box; -webkit-line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
}
.sf-blog-card:hover .sf-blog-card-title { color: #ff8a60; }
.sf-blog-card-meta {
  font-size: .72rem; color: #64748b; margin-top: auto;
  display: flex; align-items: center; gap: 8px;
}

/* ── Below strip ── */
.sf-blog-strip {
  display: grid; grid-template-columns: repeat(3, 1fr);
  gap: 20px; margin-top: 20px;
}
.sf-blog-strip-card {
  background: rgba(255,255,255,.03); border: 1px solid rgba(255,255,255,.06);
  border-radius: 14px; overflow: hidden; text-decoration: none;
  transition: border-color .3s, transform .3s, background .3s;
}
.sf-blog-strip-card:hover {
  border-color: rgba(255,94,46,.3); transform: translateY(-4px);
  background: rgba(255,94,46,.04);
}
.sf-blog-strip-thumb {
  aspect-ratio: 16/8; position: relative; overflow: hidden;
}
.sf-blog-strip-thumb img {
  position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover;
  transition: transform .5s;
}
.sf-blog-strip-card:hover .sf-blog-strip-thumb img { transform: scale(1.05); }
.sf-blog-strip-thumb-bg {
  position: absolute; inset: 0;
  display: flex; align-items: center; justify-content: center; font-size: 2.5rem;
}
.sf-blog-strip-body { padding: 18px 20px 20px; }
.sf-blog-strip-cat {
  font-size: .62rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; color: #ff5e2e; margin-bottom: 6px;
}
.sf-blog-strip-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: .92rem; font-weight: 800; color: #e2e8f0;
  margin: 0 0 8px; line-height: 1.3;
  display: -webkit-box; -webkit-line-clamp: 2;
  -webkit-box-orient: vertical; overflow: hidden;
}
.sf-blog-strip-card:hover .sf-blog-strip-title { color: #ff8a60; }
.sf-blog-strip-meta {
  font-size: .72rem; color: #64748b;
  display: flex; align-items: center; gap: 6px;
}

/* ── Numbers ── */
.sf-blog-num {
  position: absolute; top: 14px; right: 14px; z-index: 3;
  font-size: .6rem; font-weight: 900; letter-spacing: .08em;
  color: rgba(255,255,255,.25);
  background: rgba(0,0,0,.35); backdrop-filter: blur(4px);
  padding: 4px 9px; border-radius: 6px;
}

/* ── Responsive ── */
@media (max-width: 920px) {
  .sf-blog-magazine { grid-template-columns: 1fr; }
  .sf-blog-featured { min-height: 380px; }
  .sf-blog-stack { flex-direction: row; }
  .sf-blog-card { flex-direction: column; }
  .sf-blog-card-thumb { width: 100%; height: 140px; }
  .sf-blog-strip { grid-template-columns: repeat(2, 1fr); }
}
@media (max-width: 600px) {
  .sf-blog-hd { flex-direction: column; align-items: flex-start; gap: 16px; }
  .sf-blog-magazine { display: flex; flex-direction: column; }
  .sf-blog-stack { flex-direction: column; }
  .sf-blog-strip { grid-template-columns: 1fr; }
}
</style>

<div class="sf-blog-wrap">

  <!-- Header -->
  <div class="sf-blog-hd">
    <div class="sf-blog-hd-left">
      <div class="sf-blog-eyebrow"><?php echo esc_html( $tag ); ?></div>
      <h2><?php echo wp_kses( preg_replace('/(&amp;|and|und)/i', '<span>$0</span>', esc_html( $title )), ['span'=>[]] ); ?></h2>
      <p><?php echo esc_html( $subtitle ); ?></p>
    </div>
    <?php if ( $cta_label && $cta_url ) : ?>
    <a href="<?php echo esc_url( $cta_url ); ?>" class="sf-blog-hd-cta">
      <?php echo esc_html( $cta_label ); ?>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
    </a>
    <?php endif; ?>
  </div>

  <?php
  /* Collect up to 6 posts */
  $q6 = new WP_Query([
    'post_type' => 'post', 'post_status' => 'publish',
    'posts_per_page' => 6, 'no_found_rows' => true,
  ]);
  $all_posts = [];
  while ( $q6->have_posts() ) { $q6->the_post(); $all_posts[] = get_post(); }
  wp_reset_postdata();
  if ( empty( $all_posts ) ) return;

  $featured   = $all_posts[0];
  $secondary  = array_slice( $all_posts, 1, 2 );
  $strip_posts = array_slice( $all_posts, 3, 3 );

  /* Featured gradient */
  $fg = tf_blog_grad( $featured, $cat_gradients, $grad_default );
  $fcats = get_the_category( $featured->ID );
  $fcat  = $fcats ? $fcats[0] : null;
  $fread = tf_blog_read_time( $featured );
  ?>

  <!-- Magazine Layout -->
  <div class="sf-blog-magazine">

    <!-- Featured Post -->
    <a href="<?php echo esc_url( get_permalink( $featured ) ); ?>" class="sf-blog-featured"
       aria-label="<?php echo esc_attr( get_the_title( $featured ) ); ?>">
      <div class="sf-blog-featured-img" style="background:linear-gradient(135deg,<?php echo esc_attr($fg['from']); ?>,<?php echo esc_attr($fg['to']); ?>)">
        <?php if ( has_post_thumbnail( $featured->ID ) ) :
          echo get_the_post_thumbnail( $featured->ID, 'large', ['loading'=>'eager'] );
        endif; ?>
      </div>
      <div class="sf-blog-featured-gradient"></div>
      <span class="sf-blog-num">#01</span>
      <div class="sf-blog-featured-body">
        <?php if ( $fcat ) : ?>
          <span class="sf-blog-cat-badge --accent" style="--cat-accent:<?php echo esc_attr($fg['accent']); ?>">
            <?php echo esc_html( $fcat->name ); ?>
          </span>
        <?php endif; ?>
        <h2 class="sf-blog-featured-title"><?php echo esc_html( get_the_title( $featured ) ); ?></h2>
        <p class="sf-blog-featured-excerpt"><?php
          $exc = $featured->post_excerpt ?: wp_trim_words( wp_strip_all_tags( $featured->post_content ), 22, '…' );
          echo esc_html( $exc );
        ?></p>
        <div class="sf-blog-meta">
          <span class="sf-blog-meta-avatar">
            <?php echo get_avatar( get_post_field( 'post_author', $featured->ID ), 28, '', '', ['style'=>'width:28px;height:28px;border-radius:50%;'] ); ?>
          </span>
          <span><?php echo esc_html( get_the_author_meta( 'display_name', get_post_field( 'post_author', $featured->ID ) ) ); ?></span>
          <span class="sf-blog-meta-sep">·</span>
          <span><?php echo esc_html( get_the_date( 'M j, Y', $featured ) ); ?></span>
          <span class="sf-blog-meta-sep">·</span>
          <span><?php echo $fread; ?> min read</span>
        </div>
        <span class="sf-blog-readmore-arrow"><?php esc_html_e( 'Read Article', 'themeflex' ); ?> →</span>
      </div>
    </a>

    <!-- Secondary stack -->
    <div class="sf-blog-stack">
      <?php foreach ( $secondary as $idx => $p ) :
        $sg   = tf_blog_grad( $p, $cat_gradients, $grad_default );
        $scats = get_the_category( $p->ID );
        $scat  = $scats ? $scats[0] : null;
        $sread = tf_blog_read_time( $p );
        $num   = sprintf( '#0%d', $idx + 2 );
      ?>
      <a href="<?php echo esc_url( get_permalink( $p ) ); ?>" class="sf-blog-card"
         aria-label="<?php echo esc_attr( get_the_title( $p ) ); ?>">
        <div class="sf-blog-card-thumb" style="background:linear-gradient(135deg,<?php echo esc_attr($sg['from']); ?>,<?php echo esc_attr($sg['to']); ?>)">
          <?php if ( has_post_thumbnail( $p->ID ) ) :
            echo get_the_post_thumbnail( $p->ID, 'thumbnail', ['loading'=>'lazy'] );
          else : ?>
            <div class="sf-blog-card-thumb-placeholder" aria-hidden="true">
              <?php echo $sg['accent'] ? '✦' : '✧'; ?>
            </div>
          <?php endif; ?>
        </div>
        <span class="sf-blog-num"><?php echo $num; ?></span>
        <div class="sf-blog-card-body">
          <?php if ( $scat ) : ?>
            <div class="sf-blog-card-cat"><?php echo esc_html( $scat->name ); ?></div>
          <?php endif; ?>
          <h3 class="sf-blog-card-title"><?php echo esc_html( get_the_title( $p ) ); ?></h3>
          <div class="sf-blog-card-meta">
            <span><?php echo esc_html( get_the_date( 'M j, Y', $p ) ); ?></span>
            <span>·</span>
            <span><?php echo $sread; ?> min</span>
          </div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>

  </div><!-- .sf-blog-magazine -->

  <?php if ( ! empty( $strip_posts ) ) : ?>
  <!-- Bottom strip -->
  <div class="sf-blog-strip">
    <?php foreach ( $strip_posts as $sp ) :
      $sg   = tf_blog_grad( $sp, $cat_gradients, $grad_default );
      $scats = get_the_category( $sp->ID );
      $scat  = $scats ? $scats[0] : null;
      $sread = tf_blog_read_time( $sp );
    ?>
    <a href="<?php echo esc_url( get_permalink( $sp ) ); ?>" class="sf-blog-strip-card"
       aria-label="<?php echo esc_attr( get_the_title( $sp ) ); ?>">
      <div class="sf-blog-strip-thumb" style="background:linear-gradient(135deg,<?php echo esc_attr($sg['from']); ?>,<?php echo esc_attr($sg['to']); ?>)">
        <?php if ( has_post_thumbnail( $sp->ID ) ) :
          echo get_the_post_thumbnail( $sp->ID, 'medium', ['loading'=>'lazy'] );
        else : ?>
          <div class="sf-blog-strip-thumb-bg" aria-hidden="true" style="background:linear-gradient(135deg,<?php echo esc_attr($sg['from']); ?>,<?php echo esc_attr($sg['to']); ?>)">✦</div>
        <?php endif; ?>
      </div>
      <div class="sf-blog-strip-body">
        <?php if ( $scat ) : ?>
          <div class="sf-blog-strip-cat"><?php echo esc_html( $scat->name ); ?></div>
        <?php endif; ?>
        <h3 class="sf-blog-strip-title"><?php echo esc_html( get_the_title( $sp ) ); ?></h3>
        <div class="sf-blog-strip-meta">
          <span><?php echo esc_html( get_the_date( 'M j, Y', $sp ) ); ?></span>
          <span>·</span>
          <span><?php echo $sread; ?> min</span>
        </div>
      </div>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>

</div>
</section>
