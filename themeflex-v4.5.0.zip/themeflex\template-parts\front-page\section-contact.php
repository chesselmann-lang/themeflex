<?php
/**
 * Front Page Contact v3.0 — Two-column contact section
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_contact_enabled', true ) ) return;

$title    = get_theme_mod( 'sf_contact_title',    "Let's Build Something Great Together" );
$subtitle = get_theme_mod( 'sf_contact_subtitle', 'Drop us a message or reach out directly. We respond within 24 hours on business days.' );
$tag      = get_theme_mod( 'sf_contact_tag',      'Get In Touch' );
?>

<section class="tf-ct-sec" id="sf-contact" aria-label="<?php esc_attr_e('Contact','themeflex'); ?>">
<style>
/* ═══════════════════════════════════════════════════════════════
   CONTACT v3
   ═══════════════════════════════════════════════════════════════ */
.tf-ct-sec { padding: 120px 0; background: #06021d; position: relative; }
.tf-ct-wrap { max-width: 1200px; margin: 0 auto; padding: 0 32px; }
.tf-ct-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: start; }

/* Left */
.tf-ct-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 22px;
}
.tf-ct-h2 { font-size: clamp(1.8rem, 3vw, 2.6rem); font-weight: 900; color: #f1f5f9; margin: 0 0 16px; line-height: 1.15; letter-spacing: -.02em; }
.tf-ct-p  { font-size: 1rem; color: #64748b; line-height: 1.75; margin: 0 0 40px; }

/* Channel cards */
.tf-ct-channels { display: flex; flex-direction: column; gap: 14px; }
.tf-ct-channel {
  display: flex; align-items: center; gap: 16px;
  background: #0d1526; border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px; padding: 18px 20px;
  text-decoration: none; transition: border-color .2s, transform .2s;
}
.tf-ct-channel:hover { border-color: rgba(255,94,46,.25); transform: translateX(4px); }
.tf-ct-channel-icon {
  width: 44px; height: 44px; border-radius: 12px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.15);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; color: #ff5e2e;
}
.tf-ct-channel-icon svg { width: 20px; height: 20px; display: block; }
.tf-ct-channel-label { font-size: .72rem; font-weight: 700; color: #475569; margin-bottom: 2px; text-transform: uppercase; letter-spacing: .06em; }
.tf-ct-channel-value { font-size: .9rem; font-weight: 700; color: #f1f5f9; }
.tf-ct-channel-arrow { margin-left: auto; color: #ff5e2e; font-size: 1rem; }

/* Status indicator */
.tf-ct-status {
  display: flex; align-items: center; gap: 10px; margin-top: 24px;
  padding: 12px 16px; background: rgba(16,185,129,.06);
  border: 1px solid rgba(16,185,129,.15); border-radius: 12px;
}
.tf-ct-status-dot {
  width: 8px; height: 8px; border-radius: 50%; background: #10b981;
  animation: tfStatusPulse 2s ease-in-out infinite;
}
@keyframes tfStatusPulse { 0%,100%{opacity:1} 50%{opacity:.3} }
.tf-ct-status-text { font-size: .82rem; color: #34d399; font-weight: 600; }

/* Right — Form card */
.tf-ct-form-card {
  background: #0d1526;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 24px;
  padding: 36px 32px;
}
.tf-ct-form-title { font-size: 1.1rem; font-weight: 800; color: #f1f5f9; margin: 0 0 6px; }
.tf-ct-form-sub   { font-size: .82rem; color: #64748b; margin: 0 0 28px; }

.tf-ct-row    { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px; }
.tf-ct-field  { margin-bottom: 14px; }
.tf-ct-label  { display: block; font-size: .75rem; font-weight: 700; color: #64748b; margin-bottom: 6px; letter-spacing: .03em; }
.tf-ct-input, .tf-ct-select, .tf-ct-textarea {
  width: 100%; padding: 12px 16px; border-radius: 10px;
  background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08);
  color: #f1f5f9; font-size: .88rem; font-family: inherit;
  outline: none; transition: border-color .2s;
  box-sizing: border-box;
}
.tf-ct-input:focus, .tf-ct-select:focus, .tf-ct-textarea:focus { border-color: rgba(255,94,46,.4); }
.tf-ct-input::placeholder, .tf-ct-textarea::placeholder { color: #334155; }
.tf-ct-select { appearance: none; cursor: pointer; }
.tf-ct-select option { background: #0d1526; }
.tf-ct-textarea { resize: vertical; min-height: 110px; }
.tf-ct-submit {
  width: 100%; padding: 14px; border: none; border-radius: 12px;
  background: #ff5e2e; color: #fff; font-size: .9rem; font-weight: 800;
  cursor: pointer; transition: background .2s, transform .2s; font-family: inherit;
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.tf-ct-submit:hover { background: #e04e22; transform: translateY(-1px); }
.tf-ct-note { font-size: .72rem; color: #334155; text-align: center; margin-top: 10px; }

/* Responsive */
@media(max-width:1024px) { .tf-ct-grid { grid-template-columns: 1fr; } }
@media(max-width:640px)  { .tf-ct-row { grid-template-columns: 1fr; } .tf-ct-form-card { padding: 24px 20px; } }
</style>

<div class="tf-ct-wrap">
<div class="tf-ct-grid">

  <!-- LEFT -->
  <div>
    <div class="tf-ct-eyebrow">◆ <?php echo esc_html($tag); ?></div>
    <h2 class="tf-ct-h2"><?php echo esc_html($title); ?></h2>
    <p class="tf-ct-p"><?php echo esc_html($subtitle); ?></p>

    <div class="tf-ct-channels">
      <a href="mailto:hello@themeflex.de" class="tf-ct-channel">
        <div class="tf-ct-channel-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M22 7l-10 7L2 7"/></svg></div>
        <div>
          <div class="tf-ct-channel-label"><?php esc_html_e('Email','themeflex'); ?></div>
          <div class="tf-ct-channel-value">hello@themeflex.de</div>
        </div>
        <span class="tf-ct-channel-arrow" aria-hidden="true">→</span>
      </a>
      <a href="https://themeforest.net/item/themeflex" target="_blank" rel="noopener" class="tf-ct-channel">
        <div class="tf-ct-channel-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg></div>
        <div>
          <div class="tf-ct-channel-label"><?php esc_html_e('ThemeForest Support','themeflex'); ?></div>
          <div class="tf-ct-channel-value"><?php esc_html_e('Post on item page (fastest)','themeflex'); ?></div>
        </div>
        <span class="tf-ct-channel-arrow" aria-hidden="true">→</span>
      </a>
      <a href="https://docs.themeflex.de" target="_blank" rel="noopener" class="tf-ct-channel">
        <div class="tf-ct-channel-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg></div>
        <div>
          <div class="tf-ct-channel-label"><?php esc_html_e('Documentation','themeflex'); ?></div>
          <div class="tf-ct-channel-value">docs.themeflex.de</div>
        </div>
        <span class="tf-ct-channel-arrow" aria-hidden="true">→</span>
      </a>
    </div>

    <div class="tf-ct-status">
      <div class="tf-ct-status-dot"></div>
      <span class="tf-ct-status-text"><?php esc_html_e('Team online · Avg response < 4 hours','themeflex'); ?></span>
    </div>
  </div>

  <!-- RIGHT — Mini contact form -->
  <div class="tf-ct-form-card">
    <div class="tf-ct-form-title"><?php esc_html_e('Send a Message','themeflex'); ?></div>
    <div class="tf-ct-form-sub"><?php esc_html_e("We'll reply within 24 hours on business days.",'themeflex'); ?></div>

    <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" novalidate>
      <input type="hidden" name="action" value="tf_contact_form">
      <?php wp_nonce_field('tf_contact_nonce','tf_nonce'); ?>
      <input type="hidden" name="redirect_to" value="<?php echo esc_url(home_url('/#sf-contact')); ?>">

      <div class="tf-ct-row">
        <div>
          <label class="tf-ct-label" for="tf_fp_name"><?php esc_html_e('Name','themeflex'); ?></label>
          <input class="tf-ct-input" type="text" id="tf_fp_name" name="tf_name" placeholder="Alex Johnson" required autocomplete="name">
        </div>
        <div>
          <label class="tf-ct-label" for="tf_fp_email"><?php esc_html_e('Email','themeflex'); ?></label>
          <input class="tf-ct-input" type="email" id="tf_fp_email" name="tf_email" placeholder="alex@co.com" required autocomplete="email">
        </div>
      </div>

      <div class="tf-ct-field">
        <label class="tf-ct-label" for="tf_fp_subject"><?php esc_html_e('Subject','themeflex'); ?></label>
        <select class="tf-ct-select" id="tf_fp_subject" name="tf_subject">
          <option value="general"><?php esc_html_e('General Enquiry','themeflex'); ?></option>
          <option value="purchase"><?php esc_html_e('Purchase Question','themeflex'); ?></option>
          <option value="support"><?php esc_html_e('Technical Support','themeflex'); ?></option>
          <option value="customisation"><?php esc_html_e('Customisation Request','themeflex'); ?></option>
        </select>
      </div>

      <div class="tf-ct-field">
        <label class="tf-ct-label" for="tf_fp_message"><?php esc_html_e('Message','themeflex'); ?></label>
        <textarea class="tf-ct-textarea" id="tf_fp_message" name="tf_message" placeholder="<?php esc_attr_e('Tell us about your project...','themeflex'); ?>" required rows="5"></textarea>
      </div>

      <!-- Honeypot -->
      <div style="display:none" aria-hidden="true"><input type="text" name="tf_website" tabindex="-1" autocomplete="off"></div>

      <button type="submit" class="tf-ct-submit">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
        <?php esc_html_e('Send Message','themeflex'); ?>
      </button>
      <div class="tf-ct-note"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="12" height="12" style="vertical-align:middle;margin-right:4px" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><?php esc_html_e('Your info stays private.','themeflex'); ?></div>
    </form>
  </div>

</div>
</div>
</section>
