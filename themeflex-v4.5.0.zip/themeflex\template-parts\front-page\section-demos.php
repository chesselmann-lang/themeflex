<?php
/**
 * Front Page Demo Showcase v1.0 — Salient-class horizontal demo slider
 *
 * Keyboard navigable, click-to-preview, filter tabs.
 * No jQuery dependency — vanilla JS.
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_demos_enabled', true ) ) return;

/* SVG icons per demo type — 24×24, stroke */
$_di = [
  'agency'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  'saas'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
  'ecommerce' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
  'portfolio' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  'restaurant'=> '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>',
  'medical'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
  'mobile'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>',
  'corporate' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>',
];
$demos = array(
  array('id'=>'agency',    'cat'=>'Agency',     'name'=>'NovaSpark Agency','desc'=>'Dark full-screen hero with split layout',            'color1'=>'#ff5e2e','color2'=>'#1e1b4b','icon'=>$_di['agency'],    'skin'=>'Default Orange'),
  array('id'=>'saas',      'cat'=>'SaaS',       'name'=>'GridOps Platform','desc'=>'Dashboard mockup, animated metrics, pricing',        'color1'=>'#7c3aed','color2'=>'#0a0018','icon'=>$_di['saas'],      'skin'=>'Midnight Violet'),
  array('id'=>'ecommerce', 'cat'=>'E-Commerce', 'name'=>'UrbanCart Store', 'desc'=>'WooCommerce product grid, dark checkout',            'color1'=>'#e11d48','color2'=>'#120008','icon'=>$_di['ecommerce'], 'skin'=>'Rose Crimson'),
  array('id'=>'portfolio', 'cat'=>'Portfolio',  'name'=>'Archviz Studio',  'desc'=>'Full-bleed image grid, large typography',            'color1'=>'#0891b2','color2'=>'#001520','icon'=>$_di['portfolio'], 'skin'=>'Ocean Teal'),
  array('id'=>'restaurant','cat'=>'Food & Drink','name'=>'Meridian Group', 'desc'=>'Menu, reservations, multi-location',                 'color1'=>'#d97706','color2'=>'#140800','icon'=>$_di['restaurant'],'skin'=>'Amber Gold'),
  array('id'=>'medical',   'cat'=>'Healthcare', 'name'=>'PulseHealth',     'desc'=>'HIPAA-ready, appointment booking, patient portal',  'color1'=>'#10b981','color2'=>'#001a0c','icon'=>$_di['medical'],   'skin'=>'Creative Green'),
  array('id'=>'mobile',    'cat'=>'App Landing','name'=>'FlowPulse iOS',   'desc'=>'App store screenshots, feature sections',            'color1'=>'#00f5ff','color2'=>'#000c10','icon'=>$_di['mobile'],    'skin'=>'Neon Cyan'),
  array('id'=>'corporate', 'cat'=>'Corporate',  'name'=>'LuminaTech',      'desc'=>'Enterprise, Lora headings, professional blue',       'color1'=>'#3b82f6','color2'=>'#000814','icon'=>$_di['corporate'], 'skin'=>'Corporate Blue'),
);

$cats = array_unique(array_column($demos,'cat'));
?>

<section class="tf-demo-sec" id="sf-demos" aria-label="<?php esc_attr_e('Theme demos','themeflex'); ?>">
<style>
/* ═══════════════════════════════════════════════════════════════
   DEMO SHOWCASE
   ═══════════════════════════════════════════════════════════════ */
.tf-demo-sec {
  padding: 120px 0 80px;
  background: #06021d;
  overflow: hidden;
  position: relative;
}
.tf-demo-sec::before {
  content: ''; position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.02) 1px, transparent 1px);
  background-size: 44px 44px; pointer-events: none;
}
.tf-demo-header {
  text-align: center; max-width: 680px; margin: 0 auto 48px; padding: 0 32px;
}
.tf-demo-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 22px;
}
.tf-demo-header h2 { font-size: clamp(1.9rem, 3.5vw, 2.8rem); font-weight: 900; color: #f1f5f9; margin: 0 0 14px; letter-spacing: -.02em; }
.tf-demo-header p  { font-size: 1rem; color: #64748b; line-height: 1.7; margin: 0; }

/* Filter tabs */
.tf-demo-tabs {
  display: flex; justify-content: center; gap: 8px; flex-wrap: wrap;
  margin-bottom: 48px; padding: 0 32px;
}
.tf-demo-tab {
  padding: 8px 20px; border-radius: 100px;
  font-size: .78rem; font-weight: 700;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  color: #64748b; cursor: pointer;
  transition: all .2s;
}
.tf-demo-tab:hover, .tf-demo-tab.active { background: rgba(255,94,46,.1); border-color: rgba(255,94,46,.3); color: #ff5e2e; }

/* Horizontal scroll track */
.tf-demo-track-wrap { position: relative; }
.tf-demo-track-wrap::after {
  content: ''; position: absolute; right: 0; top: 0; bottom: 0;
  width: 120px; background: linear-gradient(to left, #06021d, transparent);
  pointer-events: none; z-index: 2;
}
.tf-demo-track {
  display: flex; gap: 24px;
  overflow-x: auto; overflow-y: visible;
  padding: 0 32px 32px;
  scroll-snap-type: x mandatory;
  scroll-behavior: smooth;
  -ms-overflow-style: none; scrollbar-width: none;
}
.tf-demo-track::-webkit-scrollbar { display: none; }

/* Demo card */
.tf-demo-card {
  flex-shrink: 0;
  width: 320px;
  background: #0d1526;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 20px;
  overflow: hidden;
  scroll-snap-align: start;
  transition: border-color .3s, transform .3s, box-shadow .3s;
  cursor: pointer;
}
.tf-demo-card:hover {
  border-color: var(--demo-c1, rgba(255,94,46,.25));
  transform: translateY(-6px);
  box-shadow: 0 24px 48px rgba(0,0,0,.4);
}
.tf-demo-card.filtered { display: none; }

/* Preview area */
.tf-demo-preview {
  height: 200px;
  background: linear-gradient(135deg, var(--demo-c2, #0d1526), var(--demo-c1-dim, #1e293b));
  position: relative;
  overflow: hidden;
}
/* Mini UI mockup inside preview */
.tf-demo-mini-nav {
  background: rgba(0,0,0,.4);
  padding: 10px 14px;
  display: flex; align-items: center; justify-content: space-between;
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.tf-demo-mini-logo { width: 50px; height: 6px; background: var(--demo-c1, #ff5e2e); border-radius: 3px; }
.tf-demo-mini-navlinks { display: flex; gap: 8px; }
.tf-demo-mini-navlink { width: 28px; height: 5px; background: rgba(255,255,255,.2); border-radius: 3px; }
.tf-demo-mini-cta { width: 40px; height: 18px; background: var(--demo-c1, #ff5e2e); border-radius: 9px; }

.tf-demo-mini-hero { padding: 20px 14px 14px; }
.tf-demo-mini-h1-a { width: 85%; height: 12px; background: rgba(255,255,255,.7); border-radius: 3px; margin-bottom: 7px; }
.tf-demo-mini-h1-b { width: 65%; height: 12px; background: var(--demo-c1, #ff5e2e); border-radius: 3px; opacity: .8; margin-bottom: 14px; }
.tf-demo-mini-sub  { width: 90%; height: 6px; background: rgba(255,255,255,.25); border-radius: 3px; margin-bottom: 5px; }
.tf-demo-mini-sub2 { width: 70%; height: 6px; background: rgba(255,255,255,.15); border-radius: 3px; margin-bottom: 16px; }
.tf-demo-mini-btns { display: flex; gap: 8px; }
.tf-demo-mini-btn-p { width: 80px; height: 22px; background: var(--demo-c1, #ff5e2e); border-radius: 11px; }
.tf-demo-mini-btn-s { width: 65px; height: 22px; background: rgba(255,255,255,.08); border-radius: 11px; border: 1px solid rgba(255,255,255,.1); }

/* Icon overlay */
.tf-demo-icon {
  position: absolute; bottom: 14px; right: 14px;
  width: 32px; height: 32px;
  display: flex; align-items: center; justify-content: center;
  color: currentColor; opacity: .35;
}
.tf-demo-icon svg { width: 22px; height: 22px; display: block; }
/* Skin badge */
.tf-demo-skin-badge {
  position: absolute; top: 10px; left: 10px;
  padding: 3px 10px; border-radius: 20px;
  font-size: .6rem; font-weight: 800;
  background: rgba(0,0,0,.6); backdrop-filter: blur(8px);
  color: var(--demo-c1, #ff5e2e); border: 1px solid var(--demo-c1, #ff5e2e);
  opacity: .8;
}

/* Card body */
.tf-demo-card-body { padding: 18px 20px 20px; }
.tf-demo-cat-pill {
  display: inline-block; padding: 2px 10px; border-radius: 20px;
  font-size: .62rem; font-weight: 700;
  background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.07);
  color: #64748b; margin-bottom: 8px;
}
.tf-demo-card-name { font-size: .96rem; font-weight: 800; color: #f1f5f9; margin: 0 0 5px; }
.tf-demo-card-desc { font-size: .78rem; color: #64748b; margin: 0 0 16px; }
.tf-demo-card-footer { display: flex; justify-content: space-between; align-items: center; }
.tf-demo-card-link {
  display: inline-flex; align-items: center; gap: 6px;
  color: var(--demo-c1, #ff5e2e); font-size: .8rem; font-weight: 700; text-decoration: none;
  transition: gap .2s;
}
.tf-demo-card-link:hover { gap: 10px; }
.tf-demo-card-import {
  font-size: .68rem; color: #10b981; font-weight: 700;
  background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.2);
  padding: 3px 10px; border-radius: 20px;
}

/* Nav arrows */
.tf-demo-nav { display: flex; justify-content: center; gap: 10px; margin-top: 12px; }
.tf-demo-nav-btn {
  width: 42px; height: 42px; border-radius: 50%;
  background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.08);
  color: #64748b; cursor: pointer; font-size: 1rem;
  display: flex; align-items: center; justify-content: center;
  transition: all .2s; font-family: inherit;
}
.tf-demo-nav-btn:hover { background: rgba(255,94,46,.1); border-color: rgba(255,94,46,.3); color: #ff5e2e; }

/* Count */
.tf-demo-count { text-align: center; margin-top: 20px; font-size: .78rem; color: #334155; }
.tf-demo-count strong { color: #64748b; }

/* Responsive */
@media(max-width:640px) { .tf-demo-card { width: 280px; } }
</style>

<div class="tf-demo-header">
  <div class="tf-demo-eyebrow">◆ <?php esc_html_e('12+ Demo Sites','themeflex'); ?></div>
  <h2><?php esc_html_e('Find Your Perfect Starting Point','themeflex'); ?></h2>
  <p><?php esc_html_e('Every demo imports with one click — pages, images, settings, and content included. Switch skin, customise, ship.','themeflex'); ?></p>
</div>

<div class="tf-demo-tabs" role="group" aria-label="<?php esc_attr_e('Filter demos','themeflex'); ?>">
  <button class="tf-demo-tab active" data-cat="all"><?php esc_html_e('All Demos','themeflex'); ?></button>
  <?php foreach($cats as $cat): ?>
    <button class="tf-demo-tab" data-cat="<?php echo esc_attr($cat); ?>"><?php echo esc_html($cat); ?></button>
  <?php endforeach; ?>
</div>

<div class="tf-demo-track-wrap">
  <div class="tf-demo-track" id="tfDemoTrack">
    <?php foreach($demos as $d) :
      $hex = ltrim($d['color1'],'#');
      $r=hexdec(substr($hex,0,2)); $g=hexdec(substr($hex,2,2)); $b=hexdec(substr($hex,4,2));
      $hex2 = ltrim($d['color2'],'#');
    ?>
    <div
      class="tf-demo-card"
      data-cat="<?php echo esc_attr($d['cat']); ?>"
      style="--demo-c1:<?php echo esc_attr($d['color1']); ?>;--demo-c1-dim:rgba(<?php echo "$r,$g,$b"; ?>,.25);--demo-c2:<?php echo esc_attr($d['color2']); ?>"
    >
      <div class="tf-demo-preview">
        <div class="tf-demo-skin-badge"><?php echo esc_html($d['skin']); ?></div>
        <!-- Mini UI mockup -->
        <div class="tf-demo-mini-nav">
          <div class="tf-demo-mini-logo"></div>
          <div class="tf-demo-mini-navlinks"><div class="tf-demo-mini-navlink"></div><div class="tf-demo-mini-navlink"></div><div class="tf-demo-mini-navlink"></div></div>
          <div class="tf-demo-mini-cta"></div>
        </div>
        <div class="tf-demo-mini-hero">
          <div class="tf-demo-mini-h1-a"></div>
          <div class="tf-demo-mini-h1-b"></div>
          <div class="tf-demo-mini-sub"></div>
          <div class="tf-demo-mini-sub2"></div>
          <div class="tf-demo-mini-btns">
            <div class="tf-demo-mini-btn-p"></div>
            <div class="tf-demo-mini-btn-s"></div>
          </div>
        </div>
        <div class="tf-demo-icon" aria-hidden="true"><?php echo $d['icon']; ?></div>
      </div>
      <div class="tf-demo-card-body">
        <div class="tf-demo-cat-pill"><?php echo esc_html($d['cat']); ?></div>
        <div class="tf-demo-card-name"><?php echo esc_html($d['name']); ?></div>
        <div class="tf-demo-card-desc"><?php echo esc_html($d['desc']); ?></div>
        <div class="tf-demo-card-footer">
          <a href="<?php echo esc_url(home_url('/')); ?>" class="tf-demo-card-link" target="_blank" rel="noopener">
            <?php esc_html_e('Preview','themeflex'); ?> →
          </a>
          <span class="tf-demo-card-import">✓ 1-Click Import</span>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="tf-demo-nav">
  <button class="tf-demo-nav-btn" id="tfDemoPrev" aria-label="<?php esc_attr_e('Previous','themeflex'); ?>">←</button>
  <button class="tf-demo-nav-btn" id="tfDemoNext" aria-label="<?php esc_attr_e('Next','themeflex'); ?>">→</button>
</div>
<div class="tf-demo-count" aria-live="polite"><?php esc_html_e('Scroll to explore all','themeflex'); ?> &nbsp;<strong><?php echo count($demos); ?> demos</strong></div>

<script>
(function(){
  var track = document.getElementById('tfDemoTrack');
  if(!track) return;

  /* Navigation */
  document.getElementById('tfDemoPrev')?.addEventListener('click',function(){
    track.scrollBy({left:-360, behavior:'smooth'});
  });
  document.getElementById('tfDemoNext')?.addEventListener('click',function(){
    track.scrollBy({left:360, behavior:'smooth'});
  });

  /* Category filter */
  document.querySelectorAll('.tf-demo-tab').forEach(function(tab){
    tab.addEventListener('click',function(){
      document.querySelectorAll('.tf-demo-tab').forEach(function(t){t.classList.remove('active');});
      this.classList.add('active');
      var cat = this.dataset.cat;
      document.querySelectorAll('.tf-demo-card').forEach(function(card){
        card.style.display = (cat==='all' || card.dataset.cat===cat) ? '' : 'none';
      });
      track.scrollTo({left:0, behavior:'smooth'});
    });
  });
})();
</script>
</section>
