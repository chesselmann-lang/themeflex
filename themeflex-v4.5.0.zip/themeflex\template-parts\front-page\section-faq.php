<?php
/**
 * Front Page FAQ Section — ThemeFlex v1.0
 *
 * Split two-column accordion FAQ with schema.org markup, animated chevrons,
 * and smooth max-height transitions. Dark-first premium layout.
 *
 * @package ThemeFlex
 * @since   2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_faq_enabled', true ) ) return;

$tag      = get_theme_mod( 'sf_faq_tag',      'Got Questions?' );
$title    = get_theme_mod( 'sf_faq_title',    'Everything You Need to Know' );
$subtitle = get_theme_mod( 'sf_faq_subtitle', 'Can\'t find an answer? Drop us a line — we reply within 4 hours.' );
$pt       = absint( get_theme_mod( 'sf_faq_padding_top',    120 ) );
$pb       = absint( get_theme_mod( 'sf_faq_padding_bottom', 120 ) );

$faqs = [
    [
        'q' => 'How long does a typical project take?',
        'a' => 'A standard landing page or brochure site takes 2–3 weeks from kick-off to launch. More complex projects — e-commerce stores, SaaS platforms, or custom web apps — typically take 5–8 weeks. We provide a detailed timeline in your project brief before work begins.',
    ],
    [
        'q' => 'Do you work with existing WordPress installs?',
        'a' => 'Absolutely. We can migrate, refactor, or extend any existing WordPress site. We start with a full audit covering security, performance, and code quality before we touch a single file.',
    ],
    [
        'q' => 'What is included in the Support period?',
        'a' => 'Support covers bug fixes, minor content updates (text, images), plugin & WordPress core updates, uptime monitoring, and same-business-day response to critical issues. Feature additions are scoped separately as a new project or retainer.',
    ],
    [
        'q' => 'Can I see results before going live?',
        'a' => 'Yes — every project gets a private staging environment that mirrors production exactly. You review and approve every page, interaction, and edge case before we flip the switch. Nothing goes live without your sign-off.',
    ],
    [
        'q' => 'Do you offer ongoing retainer packages?',
        'a' => 'Yes. Monthly retainers start at €490/month and include a dedicated block of development hours, priority response, and access to our full design team. Retainer clients also get discounted rates on new projects.',
    ],
    [
        'q' => 'Which page builders do you support?',
        'a' => 'Our primary stack is Elementor Pro, which we extend with custom widgets and tokens. We also work with Bricks Builder, Oxygen, and Breakdance. For headless setups we use React/Next.js with a WordPress REST or GraphQL backend.',
    ],
    [
        'q' => 'How does billing work?',
        'a' => 'We work on a 50/50 milestone model — 50% upfront to start the project, 50% on delivery before handover. For retainers, billing is monthly in advance. All invoices are EUR and issued within 24 hours of milestone sign-off.',
    ],
    [
        'q' => 'What happens if I\'m not happy with the result?',
        'a' => 'We include two full rounds of revisions in every project. If after both revision rounds you\'re still not satisfied, we offer a partial or full refund within the first 14 days — no questions asked. We stand behind our work.',
    ],
];
?>
<section
    class="tf-faq-sec"
    id="sf-faq"
    style="padding-top:<?php echo $pt; ?>px;padding-bottom:<?php echo $pb; ?>px;"
    aria-label="<?php esc_attr_e( 'FAQ', 'themeflex' ); ?>"
    itemscope itemtype="https://schema.org/FAQPage"
>
<style>
/* ══════════════════════════════════════════════════════════
   FAQ SECTION — Split two-column accordion
   ══════════════════════════════════════════════════════════ */
.tf-faq-sec {
  background: linear-gradient(180deg, #06021d 0%, #0a0f1e 100%);
  position: relative; overflow: hidden;
}
.tf-faq-sec::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(59,130,246,.2), rgba(139,92,246,.2), transparent);
}

.tf-faq-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; }

/* ── Layout ── */
.tf-faq-layout {
  display: grid;
  grid-template-columns: 340px 1fr;
  gap: 80px;
  align-items: start;
}

/* ── Left col ── */
.tf-faq-left { position: sticky; top: 100px; }
.tf-faq-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(59,130,246,.1); border: 1px solid rgba(59,130,246,.25);
  color: #60a5fa; font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px; margin-bottom: 20px;
}
.tf-faq-eyebrow::before { content: '◈'; font-size: .6rem; }
.tf-faq-left h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3vw, 2.6rem);
  font-weight: 900; color: #fff; margin: 0 0 16px;
  letter-spacing: -.04em; line-height: 1.1;
}
.tf-faq-left p { color: #64748b; font-size: .95rem; line-height: 1.7; margin: 0 0 32px; }
.tf-faq-cta {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1);
  border: 1px solid rgba(255,94,46,.3);
  color: #ff7a54;
  font-size: .85rem; font-weight: 700; letter-spacing: .04em;
  padding: 12px 24px; border-radius: 100px;
  text-decoration: none;
  transition: background .2s, border-color .2s, color .2s;
}
.tf-faq-cta:hover { background: rgba(255,94,46,.2); border-color: rgba(255,94,46,.5); color: #ff5e2e; }

/* Decorative stat blobs */
.tf-faq-stat-cards { margin-top: 40px; display: flex; flex-direction: column; gap: 12px; }
.tf-faq-stat-card {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 14px;
  padding: 16px 20px;
  display: flex; align-items: center; gap: 14px;
}
.tf-faq-stat-icon { font-size: 1.4rem; }
.tf-faq-stat-num {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.4rem; font-weight: 900; color: #fff;
  letter-spacing: -.04em; line-height: 1;
}
.tf-faq-stat-lbl { font-size: .72rem; color: #64748b; font-weight: 600; margin-top: 2px; }

/* ── Right col — Accordion ── */
.tf-faq-list { display: flex; flex-direction: column; gap: 0; }
.tf-faq-item {
  border-bottom: 1px solid rgba(255,255,255,.06);
  opacity: 0; transform: translateY(16px);
  transition: opacity .5s, transform .5s;
}
.tf-faq-item.tf-faq-visible { opacity: 1; transform: none; }
.tf-faq-item:nth-child(1){transition-delay:0s}
.tf-faq-item:nth-child(2){transition-delay:.06s}
.tf-faq-item:nth-child(3){transition-delay:.12s}
.tf-faq-item:nth-child(4){transition-delay:.18s}
.tf-faq-item:nth-child(5){transition-delay:.24s}
.tf-faq-item:nth-child(6){transition-delay:.30s}
.tf-faq-item:nth-child(7){transition-delay:.36s}
.tf-faq-item:nth-child(8){transition-delay:.42s}

.tf-faq-q {
  width: 100%;
  background: none; border: none;
  display: flex; align-items: center; justify-content: space-between; gap: 16px;
  padding: 22px 0;
  text-align: left;
  cursor: pointer;
  color: #e2e8f0;
  font-family: 'Inter Tight', sans-serif;
  font-size: 1rem; font-weight: 700; letter-spacing: -.01em;
  line-height: 1.4;
  transition: color .2s;
}
.tf-faq-q:hover { color: #fff; }
.tf-faq-q[aria-expanded="true"] { color: #ff7a54; }

.tf-faq-chevron {
  width: 32px; height: 32px; border-radius: 50%;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  transition: background .3s, border-color .3s, transform .3s;
}
.tf-faq-chevron svg { width: 14px; height: 14px; stroke: #64748b; transition: stroke .3s; }
.tf-faq-q[aria-expanded="true"] .tf-faq-chevron {
  background: rgba(255,94,46,.15);
  border-color: rgba(255,94,46,.3);
  transform: rotate(180deg);
}
.tf-faq-q[aria-expanded="true"] .tf-faq-chevron svg { stroke: #ff5e2e; }

.tf-faq-body {
  overflow: hidden;
  max-height: 0;
  transition: max-height .4s cubic-bezier(.16,1,.3,1);
}
.tf-faq-body-inner {
  padding: 0 44px 22px 0;
  font-size: .92rem; color: #64748b; line-height: 1.75;
}

/* ── Responsive ── */
@media(max-width:900px) {
  .tf-faq-layout { grid-template-columns: 1fr; gap: 48px; }
  .tf-faq-left { position: static; }
}
</style>

<div class="tf-faq-wrap">
  <div class="tf-faq-layout">

    <!-- Left — Sticky heading -->
    <div class="tf-faq-left" data-reveal>
      <div class="tf-faq-eyebrow"><?php echo esc_html( $tag ); ?></div>
      <h2><?php echo esc_html( $title ); ?></h2>
      <p><?php echo esc_html( $subtitle ); ?></p>
      <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="tf-faq-cta">
        <?php esc_html_e( 'Ask Us Anything', 'themeflex' ); ?> →
      </a>

      <div class="tf-faq-stat-cards" aria-hidden="true">
        <div class="tf-faq-stat-card">
          <span class="tf-faq-stat-icon">⚡</span>
          <div>
            <div class="tf-faq-stat-num">&lt; 4h</div>
            <div class="tf-faq-stat-lbl"><?php esc_html_e( 'Average reply time', 'themeflex' ); ?></div>
          </div>
        </div>
        <div class="tf-faq-stat-card">
          <span class="tf-faq-stat-icon">⭐</span>
          <div>
            <div class="tf-faq-stat-num">4.9 / 5</div>
            <div class="tf-faq-stat-lbl"><?php esc_html_e( 'Client satisfaction', 'themeflex' ); ?></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Right — Accordion -->
    <div class="tf-faq-list" role="list">
      <?php foreach ( $faqs as $i => $faq ) :
        $faq_id = 'tf-faq-' . $i;
        $body_id = 'tf-faq-body-' . $i;
      ?>
      <div class="tf-faq-item" role="listitem" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
        <button
          class="tf-faq-q"
          id="<?php echo $faq_id; ?>"
          aria-expanded="false"
          aria-controls="<?php echo $body_id; ?>"
          itemprop="name"
        >
          <?php echo esc_html( $faq['q'] ); ?>
          <span class="tf-faq-chevron" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </span>
        </button>
        <div
          class="tf-faq-body"
          id="<?php echo $body_id; ?>"
          role="region"
          aria-labelledby="<?php echo $faq_id; ?>"
          itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer"
        >
          <div class="tf-faq-body-inner" itemprop="text">
            <?php echo esc_html( $faq['a'] ); ?>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

  </div>
</div>

<script>
(function(){
  // Accordion
  var buttons = document.querySelectorAll('#sf-faq .tf-faq-q');
  buttons.forEach(function(btn) {
    btn.addEventListener('click', function() {
      var expanded = this.getAttribute('aria-expanded') === 'true';
      var body = document.getElementById(this.getAttribute('aria-controls'));

      // Close all
      buttons.forEach(function(b) {
        b.setAttribute('aria-expanded', 'false');
        var bd = document.getElementById(b.getAttribute('aria-controls'));
        if (bd) bd.style.maxHeight = '0';
      });

      // Open clicked
      if (!expanded) {
        this.setAttribute('aria-expanded', 'true');
        body.style.maxHeight = body.scrollHeight + 'px';
      }
    });
  });

  // Stagger reveal on scroll
  var items = document.querySelectorAll('#sf-faq .tf-faq-item');
  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries) {
      entries.forEach(function(e) {
        if (e.isIntersecting) { e.target.classList.add('tf-faq-visible'); obs.unobserve(e.target); }
      });
    }, { threshold: 0.1 });
    items.forEach(function(el) { obs.observe(el); });
  } else {
    items.forEach(function(el) { el.classList.add('tf-faq-visible'); });
  }
})();
</script>

</section>
