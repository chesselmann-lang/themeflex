<?php
/**
 * Front Page Features — Bento Grid v2.0
 *
 * Salient-style asymmetric bento grid with animated stat cards,
 * hover effects, scroll entrance animations, and animated counters.
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! get_theme_mod( 'sf_features_enabled', true ) ) return;

$title    = get_theme_mod( 'sf_features_title',    'Built Different. Ships Perfect.' );
$subtitle = get_theme_mod( 'sf_features_subtitle', 'Every feature is engineered for agencies and product teams who need performance, flexibility, and design quality — all in one theme.' );
$tag      = get_theme_mod( 'sf_features_tag',      'Why ThemeFlex' );
?>
<section
  id="sf-features"
  class="tf-feat-section"
  aria-label="<?php esc_attr_e( 'Features', 'themeflex' ); ?>"
>
<style>
/* ═══════════════════════════════════════════════════════════════
   FEATURES — Bento Grid
   ═══════════════════════════════════════════════════════════════ */
.tf-feat-section {
  padding: 120px 0;
  background: #06021d;
  position: relative;
  overflow: hidden;
}
.tf-feat-section::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,94,46,.3), rgba(0,212,255,.2), transparent);
}
.tf-feat-wrap { max-width: 1260px; margin: 0 auto; padding: 0 32px; }

/* ── Section header ─────────────────────────────────────────── */
.tf-feat-header { text-align: center; max-width: 680px; margin: 0 auto 72px; }
.tf-feat-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 24px;
}
.tf-feat-header h2 {
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 900; color: #f1f5f9; margin: 0 0 16px; line-height: 1.15; letter-spacing: -.02em;
}
.tf-feat-header p { font-size: 1.1rem; color: #94a3b8; line-height: 1.75; margin: 0; }

/* ── Bento Grid ─────────────────────────────────────────────── */
.tf-bento {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  grid-auto-rows: 80px;
  gap: 16px;
}

.tf-bento-card {
  background: #0d1526;
  border: 1px solid rgba(255,255,255,.06);
  border-radius: 20px;
  padding: 28px;
  position: relative;
  overflow: hidden;
  transition: border-color .3s, transform .3s, box-shadow .3s;
  opacity: 0;
  transform: translateY(30px);
}
.tf-bento-card.tf-visible {
  opacity: 1;
  transform: translateY(0);
  transition: opacity .6s ease, transform .6s ease, border-color .3s, box-shadow .3s;
}
.tf-bento-card:hover {
  border-color: rgba(255,94,46,.2);
  box-shadow: 0 24px 48px rgba(0,0,0,.35);
}

/* accent top line */
.tf-bento-card::before {
  content: '';
  position: absolute;
  top: 0; left: 24px; right: 24px;
  height: 2px;
  border-radius: 0 0 4px 4px;
  background: var(--accent, rgba(255,94,46,.4));
  transform: scaleX(0);
  transform-origin: center;
  transition: transform .4s ease;
}
.tf-bento-card:hover::before { transform: scaleX(1); }

/* Grid placements */
.tf-bento-c1  { grid-column: span 4; grid-row: span 4; } /* Performance — tall */
.tf-bento-c2  { grid-column: span 5; grid-row: span 2; } /* Widgets */
.tf-bento-c3  { grid-column: span 3; grid-row: span 2; } /* Skins swatch */
.tf-bento-c4  { grid-column: span 5; grid-row: span 2; } /* Dark-first */
.tf-bento-c5  { grid-column: span 3; grid-row: span 2; } /* Child theme */
.tf-bento-c6  { grid-column: span 4; grid-row: span 3; } /* Stats */
.tf-bento-c7  { grid-column: span 4; grid-row: span 3; } /* Demo import */
.tf-bento-c8  { grid-column: span 4; grid-row: span 3; } /* Support */

/* Card content */
.tf-bento-icon {
  width: 48px; height: 48px;
  border-radius: 14px;
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 16px;
  flex-shrink: 0;
}
.tf-bento-icon svg { width: 22px; height: 22px; display: block; }
.tf-bento-h { font-size: 1rem; font-weight: 800; color: #f1f5f9; margin: 0 0 8px; line-height: 1.25; }
.tf-bento-p { font-size: .83rem; color: #64748b; line-height: 1.65; margin: 0; }

/* ── C1: Performance (big card) ─────────────────────────────── */
.tf-bento-c1 { --accent: rgba(16,185,129,.5); }
.tf-gauge-wrap { margin: 20px 0 12px; }
.tf-gauge {
  width: 120px; height: 120px;
  position: relative;
  margin: 0 auto;
}
.tf-gauge svg { transform: rotate(-90deg); }
.tf-gauge-track { fill: none; stroke: rgba(255,255,255,.06); stroke-width: 8; }
.tf-gauge-fill {
  fill: none; stroke: #10b981; stroke-width: 8;
  stroke-linecap: round;
  stroke-dasharray: 283;
  stroke-dashoffset: 283;
  transition: stroke-dashoffset 2s ease;
}
.tf-gauge.tf-visible .tf-gauge-fill { stroke-dashoffset: 17; } /* 94% */
.tf-gauge-num {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  font-size: 1.6rem;
  font-weight: 900;
  color: #f1f5f9;
}
.tf-gauge-num span { font-size: .6rem; font-weight: 700; color: #10b981; letter-spacing: .06em; text-transform: uppercase; }
.tf-vitals { display: flex; justify-content: space-around; margin-top: 12px; }
.tf-vital { text-align: center; }
.tf-vital-val { font-size: .85rem; font-weight: 800; color: #10b981; }
.tf-vital-label { font-size: .62rem; color: #475569; margin-top: 2px; }

/* ── C2: Widgets ────────────────────────────────────────────── */
.tf-bento-c2 { --accent: rgba(168,85,247,.4); }
.tf-widget-pills { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 14px; }
.tf-widget-pill {
  padding: 4px 12px; border-radius: 100px;
  font-size: .67rem; font-weight: 700;
  background: rgba(168,85,247,.12); color: #a78bfa;
  border: 1px solid rgba(168,85,247,.2);
}

/* ── C3: Skins ──────────────────────────────────────────────── */
.tf-bento-c3 { --accent: rgba(255,94,46,.4); }
.tf-skin-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 6px; margin-top: 14px; }
.tf-skin-swatch {
  aspect-ratio: 1;
  border-radius: 8px;
  border: 2px solid transparent;
  transition: transform .2s, border-color .2s;
  cursor: pointer;
}
.tf-skin-swatch:hover { transform: scale(1.15); border-color: rgba(255,255,255,.3); }

/* ── C4: Dark-first ─────────────────────────────────────────── */
.tf-bento-c4 { --accent: rgba(0,212,255,.3); }
.tf-dark-toggle {
  margin-top: 14px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  border-radius: 100px;
  padding: 4px;
  display: inline-flex;
  gap: 0;
}
.tf-dark-toggle-btn {
  padding: 6px 16px;
  border-radius: 100px;
  font-size: .72rem;
  font-weight: 700;
  cursor: pointer;
}
.tf-dark-toggle-btn.active { background: #0d1526; color: #00d4ff; }
.tf-dark-toggle-btn:not(.active) { color: #475569; }

/* ── C6: Stats ──────────────────────────────────────────────── */
.tf-bento-c6 { --accent: rgba(245,158,11,.4); }
.tf-stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-top: 14px; }
.tf-stat-item {}
.tf-stat-num {
  font-size: 1.8rem; font-weight: 900;
  color: #f1f5f9; line-height: 1;
  margin-bottom: 4px;
}
.tf-stat-num .tf-count { display: inline-block; }
.tf-stat-label { font-size: .72rem; color: #64748b; font-weight: 600; }

/* ── C7: Demo import ────────────────────────────────────────── */
.tf-bento-c7 { --accent: rgba(59,130,246,.4); }
.tf-demo-list { margin-top: 14px; display: flex; flex-direction: column; gap: 8px; }
.tf-demo-item {
  display: flex; align-items: center; gap: 10px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.06);
  border-radius: 10px;
  padding: 8px 12px;
  font-size: .75rem;
}
.tf-demo-item-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; }
.tf-demo-item-name { color: #94a3b8; font-weight: 600; }
.tf-demo-item-badge { margin-left: auto; font-size: .62rem; font-weight: 700; color: #10b981; }

/* ── C8: Support ────────────────────────────────────────────── */
.tf-bento-c8 { --accent: rgba(239,68,68,.4); }
.tf-support-row { margin-top: 14px; display: flex; flex-direction: column; gap: 10px; }
.tf-support-item { display: flex; align-items: center; gap: 10px; }
.tf-support-icon { width: 20px; height: 20px; flex-shrink: 0; color: #ff5e2e; }
.tf-support-icon svg { width: 16px; height: 16px; display: block; }
.tf-support-text { font-size: .78rem; color: #94a3b8; }
.tf-support-text strong { color: #f1f5f9; display: block; font-weight: 700; }

/* ── Scroll entrance ─────────────────────────────────────────── */
.tf-bento-card { transition-delay: var(--delay, 0s); }

/* ── Responsive ─────────────────────────────────────────────── */
@media(max-width:1024px) {
  .tf-bento { grid-template-columns: repeat(6,1fr); }
  .tf-bento-c1 { grid-column: span 3; grid-row: span 4; }
  .tf-bento-c2, .tf-bento-c4 { grid-column: span 3; }
  .tf-bento-c3, .tf-bento-c5 { grid-column: span 3; }
  .tf-bento-c6, .tf-bento-c7, .tf-bento-c8 { grid-column: span 6; grid-row: span 2; }
}
@media(max-width:640px) {
  .tf-bento { grid-template-columns: 1fr 1fr; gap: 12px; }
  .tf-bento-c1, .tf-bento-c6, .tf-bento-c7, .tf-bento-c8 { grid-column: span 2; }
}
</style>

<div class="tf-feat-wrap">

  <div class="tf-feat-header">
    <div class="tf-feat-eyebrow">◆ <?php echo esc_html( $tag ); ?></div>
    <h2><?php echo esc_html( $title ); ?></h2>
    <p><?php echo esc_html( $subtitle ); ?></p>
  </div>

  <div class="tf-bento" id="tfBento">

    <!-- C1: Performance (tall, left) -->
    <div class="tf-bento-card tf-bento-c1" style="--delay:.05s">
      <div class="tf-bento-icon" style="background:rgba(16,185,129,.12)">⚡</div>
      <div class="tf-bento-h"><?php esc_html_e( 'Blazing Performance', 'themeflex' ); ?></div>
      <div class="tf-bento-p"><?php esc_html_e( '97 PageSpeed. Sub-800ms LCP. WCAG 2.1 AA. No configuration needed.', 'themeflex' ); ?></div>
      <div class="tf-gauge-wrap">
        <div class="tf-gauge" id="tfGauge">
          <svg viewBox="0 0 100 100" width="120" height="120">
            <circle class="tf-gauge-track" cx="50" cy="50" r="45"/>
            <circle class="tf-gauge-fill" cx="50" cy="50" r="45"/>
          </svg>
          <div class="tf-gauge-num">
            97<span>PageSpeed</span>
          </div>
        </div>
      </div>
      <div class="tf-vitals">
        <div class="tf-vital"><div class="tf-vital-val">0.6s</div><div class="tf-vital-label">FCP</div></div>
        <div class="tf-vital"><div class="tf-vital-val">0.8s</div><div class="tf-vital-label">LCP</div></div>
        <div class="tf-vital"><div class="tf-vital-val">0.01</div><div class="tf-vital-label">CLS</div></div>
      </div>
    </div>

    <!-- C2: Widgets -->
    <div class="tf-bento-card tf-bento-c2" style="--delay:.10s">
      <div class="tf-bento-icon" style="background:rgba(168,85,247,.12);color:rgba(168,85,247,1)" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg></div>
      <div class="tf-bento-h"><?php esc_html_e( '80+ Elementor Widgets', 'themeflex' ); ?></div>
      <div class="tf-bento-p"><?php esc_html_e( 'Hero, Pricing, Team, Charts, Portfolio, WooCommerce — all built-in.', 'themeflex' ); ?></div>
      <div class="tf-widget-pills">
        <?php foreach ( array('Hero','Pricing','Portfolio','Team','Charts','Testimonials','WooCommerce','Counter','Timeline') as $w ) : ?>
          <span class="tf-widget-pill"><?php echo esc_html($w); ?></span>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- C3: Skins -->
    <div class="tf-bento-card tf-bento-c3" style="--delay:.15s">
      <div class="tf-bento-icon" style="background:rgba(255,94,46,.12);color:#ff5e2e" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z"/><path d="M22 12a10 10 0 0 1-10 10 4 4 0 0 1 0-8 4 4 0 0 0 0-8 10 10 0 0 1 10 6z"/></svg></div>
      <div class="tf-bento-h"><?php esc_html_e( '8 Colour Skins', 'themeflex' ); ?></div>
      <div class="tf-skin-grid">
        <?php
        foreach ( array('#ff5e2e','#3b82f6','#10b981','#7c3aed','#e11d48','#0891b2','#d97706','#00f5ff') as $c ) : ?>
          <div class="tf-skin-swatch" style="background:<?php echo esc_attr($c); ?>"></div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- C4: Dark-first -->
    <div class="tf-bento-card tf-bento-c4" style="--delay:.20s">
      <div class="tf-bento-icon" style="background:rgba(0,212,255,.12);color:#00d4ff" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></div>
      <div class="tf-bento-h"><?php esc_html_e( 'Dark-First by Default', 'themeflex' ); ?></div>
      <div class="tf-bento-p"><?php esc_html_e( 'Every section, widget, and template ships dark. Light mode toggle included — zero FOUC.', 'themeflex' ); ?></div>
      <div class="tf-dark-toggle">
        <div class="tf-dark-toggle-btn active"><?php esc_html_e( 'Dark', 'themeflex' ); ?></div>
        <div class="tf-dark-toggle-btn"><?php esc_html_e( 'Light', 'themeflex' ); ?></div>
      </div>
    </div>

    <!-- C5: Child theme / Dev-friendly -->
    <div class="tf-bento-card tf-bento-c5" style="--delay:.25s">
      <div class="tf-bento-icon" style="background:rgba(16,185,129,.12);color:#10b981" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg></div>
      <div class="tf-bento-h"><?php esc_html_e( 'Developer Friendly', 'themeflex' ); ?></div>
      <div class="tf-bento-p"><?php esc_html_e( 'Clean hooks, child theme, CSS custom props, skin API. Extend without touching core.', 'themeflex' ); ?></div>
    </div>

    <!-- C6: Stats -->
    <div class="tf-bento-card tf-bento-c6" style="--delay:.30s">
      <div class="tf-bento-h"><?php esc_html_e( 'By the Numbers', 'themeflex' ); ?></div>
      <div class="tf-stat-grid">
        <?php
        $stats = array(
          array( '2000', '+', 'Happy Customers' ),
          array( '97',   '',  'PageSpeed Score' ),
          array( '80',   '+', 'Elementor Widgets' ),
          array( '8',    '',  'Colour Skins' ),
        );
        foreach ( $stats as list( $num, $suffix, $label ) ) : ?>
        <div class="tf-stat-item">
          <div class="tf-stat-num">
            <span class="tf-count" data-target="<?php echo esc_attr($num); ?>">0</span><?php echo esc_html($suffix); ?>
          </div>
          <div class="tf-stat-label"><?php echo esc_html( $label ); ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- C7: Demo import -->
    <div class="tf-bento-card tf-bento-c7" style="--delay:.35s">
      <div class="tf-bento-icon" style="background:rgba(59,130,246,.12);color:#3b82f6" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg></div>
      <div class="tf-bento-h"><?php esc_html_e( '12+ One-Click Demos', 'themeflex' ); ?></div>
      <div class="tf-demo-list">
        <?php
        $demos = array(
          array('#ff5e2e','Agency Portfolio'),
          array('#3b82f6','SaaS Platform'),
          array('#10b981','E-Commerce Store'),
          array('#a855f7','Creative Studio'),
          array('#f59e0b','Restaurant & Food'),
        );
        foreach ( $demos as list($clr,$name) ) : ?>
        <div class="tf-demo-item">
          <div class="tf-demo-item-dot" style="background:<?php echo esc_attr($clr); ?>"></div>
          <span class="tf-demo-item-name"><?php echo esc_html($name); ?></span>
          <span class="tf-demo-item-badge">✓ Ready</span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- C8: Support -->
    <div class="tf-bento-card tf-bento-c8" style="--delay:.40s">
      <div class="tf-bento-icon" style="background:rgba(239,68,68,.12);color:#ef4444" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
      <div class="tf-bento-h"><?php esc_html_e( 'Real Support', 'themeflex' ); ?></div>
      <div class="tf-support-row">
        <div class="tf-support-item">
          <span class="tf-support-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>
          <div class="tf-support-text"><strong><?php esc_html_e( '< 24h Response Time', 'themeflex' ); ?></strong><?php esc_html_e( 'Mon–Fri, 9–18 CET', 'themeflex' ); ?></div>
        </div>
        <div class="tf-support-item">
          <span class="tf-support-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg></span>
          <div class="tf-support-text"><strong><?php esc_html_e( 'Full Documentation', 'themeflex' ); ?></strong><?php esc_html_e( 'Video + written guides', 'themeflex' ); ?></div>
        </div>
        <div class="tf-support-item">
          <span class="tf-support-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg></span>
          <div class="tf-support-text"><strong><?php esc_html_e( 'Lifetime Updates', 'themeflex' ); ?></strong><?php esc_html_e( 'Always current, always free', 'themeflex' ); ?></div>
        </div>
      </div>
    </div>

  </div><!-- /.tf-bento -->
</div><!-- /.tf-feat-wrap -->

<script>
/* ── Scroll entrance + animated counters ─────────────────────── */
(function(){
  var bento = document.getElementById('tfBento');
  var gauge = document.getElementById('tfGauge');
  if(!bento) return;

  var cards = bento.querySelectorAll('.tf-bento-card');
  var counters = bento.querySelectorAll('.tf-count');

  function countUp(el) {
    var target = parseInt(el.getAttribute('data-target'));
    var duration = 1800;
    var start = performance.now();
    function step(now) {
      var progress = Math.min((now-start)/duration, 1);
      var ease = 1 - Math.pow(1-progress, 3);
      el.textContent = Math.floor(ease * target).toLocaleString();
      if(progress < 1) requestAnimationFrame(step);
      else el.textContent = target.toLocaleString();
    }
    requestAnimationFrame(step);
  }

  var counted = false;
  var obs = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(!entry.isIntersecting) return;
      entry.target.classList.add('tf-visible');
      if(entry.target.classList.contains('tf-bento-c1') && gauge) {
        gauge.classList.add('tf-visible');
      }
      if(!counted && entry.target.classList.contains('tf-bento-c6')) {
        counted = true;
        counters.forEach(function(c){ countUp(c); });
      }
      obs.unobserve(entry.target);
    });
  }, { threshold: 0.15 });

  cards.forEach(function(card, i){
    card.style.transitionDelay = (i * 0.07) + 's';
    obs.observe(card);
  });
})();
</script>
<!-- Shape Divider -->
<div class="tf-shape-divider tf-shape-bottom" aria-hidden="true">
  <svg viewBox="0 0 1440 60" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0,20 C180,50 360,0 540,30 C720,55 900,5 1080,30 C1260,55 1380,15 1440,20 L1440,60 L0,60 Z" fill="#0d1526"/>
  </svg>
</div>

</section>