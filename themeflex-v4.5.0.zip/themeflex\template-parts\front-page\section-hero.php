<?php
/**
 * Front Page Hero Section v3.0 — Salient-Class Split Layout
 *
 * Split layout: Left copy + Right animated browser mockup
 * Animated blobs, floating badges, scroll indicator, entrance animations
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$hero_title      = get_theme_mod( 'sf_hero_title',   'The Premium WordPress Theme<br>Built for <span class="tf-typing-word" data-words="Dark-First,Agencies,SaaS,E-Commerce,Studios">Dark-First</span> <span class="tf-typing-cursor" aria-hidden="true"></span>Perfection' );
$hero_subtitle   = get_theme_mod( 'sf_hero_subtitle', 'ThemeFlex ships with 80+ Elementor widgets, 8 colour skins, and 12+ one-click demo sites — achieving 97 PageSpeed out of the box. Built for agencies, SaaS, and studios that refuse to compromise.' );
$cta1_text       = get_theme_mod( 'sf_hero_cta1_text', 'Get ThemeFlex — $59' );
$cta1_url        = get_theme_mod( 'sf_hero_cta1_url',  'https://themeforest.net/item/themeflex' );
$cta2_text       = get_theme_mod( 'sf_hero_cta2_text', 'View Live Demo' );
$cta2_url        = get_theme_mod( 'sf_hero_cta2_url',  home_url( '/portfolio' ) );
$hero_video_url  = get_theme_mod( 'sf_hero_video_url',    '' );
$hero_video_pos  = get_theme_mod( 'sf_hero_video_poster', '' );
$has_video       = ! empty( $hero_video_url );
?>

<?php $hero_cls = $has_video ? ' has-video' : ''; ?>
<section id="sf-hero" class="tf-hero<?php echo $hero_cls; ?>" aria-label="<?php esc_attr_e( 'Hero', 'themeflex' ); ?>">

<style>
/* ═══════════════════════════════════════════════════════════════
   HERO v3 — Salient-class split layout
   ═══════════════════════════════════════════════════════════════ */
.tf-hero {
  position: relative;
  min-height: 100vh;
  display: flex;
  align-items: center;
  overflow: hidden;
  background: #06021d;
  padding: 0;
}

/* ── Animated Blob Background ─────────────────────────────────── */
.tf-hero-blobs {
  position: absolute;
  inset: 0;
  z-index: 0;
  overflow: hidden;
}
.tf-hero-blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(80px);
  animation: tfBlobFloat 12s ease-in-out infinite alternate;
}
.tf-hero-blob-1 {
  width: 700px; height: 700px;
  background: radial-gradient(circle, rgba(255,94,46,.22) 0%, transparent 70%);
  top: -200px; left: -200px;
  animation-duration: 14s;
}
.tf-hero-blob-2 {
  width: 500px; height: 500px;
  background: radial-gradient(circle, rgba(0,212,255,.12) 0%, transparent 70%);
  bottom: -100px; right: 30%;
  animation-duration: 10s; animation-delay: -4s;
}
.tf-hero-blob-3 {
  width: 400px; height: 400px;
  background: radial-gradient(circle, rgba(168,85,247,.10) 0%, transparent 70%);
  top: 40%; right: -100px;
  animation-duration: 16s; animation-delay: -8s;
}
@keyframes tfBlobFloat {
  0%   { transform: translate(0,0) scale(1); }
  50%  { transform: translate(40px,-30px) scale(1.08); }
  100% { transform: translate(-20px,40px) scale(0.96); }
}

/* ── Dot Grid ─────────────────────────────────────────────────── */
.tf-hero::before {
  content: '';
  position: absolute;
  inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.03) 1px, transparent 1px);
  background-size: 44px 44px;
  z-index: 0;
  pointer-events: none;
}

/* ── Layout ───────────────────────────────────────────────────── */
.tf-hero-inner {
  position: relative;
  z-index: 2;
  max-width: 1320px;
  margin: 0 auto;
  padding: 120px 32px 80px;
  display: grid;
  grid-template-columns: 1.05fr 1fr;
  gap: 72px;
  align-items: center;
  width: 100%;
}

/* ── Left — Copy ──────────────────────────────────────────────── */
.tf-hero-copy { position: relative; }

.tf-hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: rgba(255,94,46,.12);
  border: 1px solid rgba(255,94,46,.28);
  color: #ff5e2e;
  font-size: .72rem;
  font-weight: 800;
  letter-spacing: .12em;
  text-transform: uppercase;
  padding: 7px 18px;
  border-radius: 100px;
  margin-bottom: 28px;
  opacity: 0;
  animation: tfFadeUp .6s .1s ease forwards;
}
.tf-hero-badge-dot {
  width: 6px; height: 6px; border-radius: 50%;
  background: #ff5e2e;
  animation: tfPulse 2s ease-in-out infinite;
}
@keyframes tfPulse { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.5;transform:scale(1.4)} }

.tf-hero-h1 {
  font-size: clamp(2.6rem, 4.2vw, 4.4rem);
  font-weight: 900;
  line-height: 1.08;
  letter-spacing: -.03em;
  color: #f1f5f9;
  margin: 0 0 24px;
  opacity: 0;
  animation: tfFadeUp .7s .2s ease forwards;
}
.tf-hero-h1 em {
  font-style: normal;
  background: linear-gradient(90deg, #ff5e2e 0%, #ff8c5a 50%, #00d4ff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  background-size: 200% auto;
  animation: tfGradientShift 4s linear infinite;
}
@keyframes tfGradientShift { 0%{background-position:0%} 100%{background-position:200%} }

.tf-hero-sub {
  font-size: 1.1rem;
  color: #94a3b8;
  line-height: 1.78;
  max-width: 520px;
  margin: 0 0 36px;
  opacity: 0;
  animation: tfFadeUp .7s .35s ease forwards;
}

/* ── CTAs ─────────────────────────────────────────────────────── */
.tf-hero-ctas {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
  align-items: center;
  margin-bottom: 40px;
  opacity: 0;
  animation: tfFadeUp .7s .5s ease forwards;
}
.tf-hero-cta-primary {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background: #ff5e2e;
  color: #fff;
  font-size: .95rem;
  font-weight: 800;
  letter-spacing: .02em;
  padding: 16px 36px;
  border-radius: 100px;
  text-decoration: none;
  position: relative;
  overflow: hidden;
  transition: transform .2s, box-shadow .2s;
  box-shadow: 0 8px 32px rgba(255,94,46,.35);
}
.tf-hero-cta-primary::before {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(255,255,255,.2), transparent);
  opacity: 0;
  transition: opacity .2s;
}
.tf-hero-cta-primary:hover { transform: translateY(-3px); box-shadow: 0 16px 48px rgba(255,94,46,.45); }
.tf-hero-cta-primary:hover::before { opacity: 1; }
.tf-hero-cta-arrow { transition: transform .2s; }
.tf-hero-cta-primary:hover .tf-hero-cta-arrow { transform: translateX(4px); }

.tf-hero-cta-secondary {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  background: transparent;
  border: 1.5px solid rgba(255,255,255,.15);
  color: #cbd5e1;
  font-size: .9rem;
  font-weight: 700;
  padding: 15px 28px;
  border-radius: 100px;
  text-decoration: none;
  transition: border-color .2s, color .2s, background .2s;
}
.tf-hero-cta-secondary:hover {
  border-color: rgba(255,94,46,.4);
  color: #ff5e2e;
  background: rgba(255,94,46,.06);
}
.tf-hero-play-icon {
  width: 28px; height: 28px;
  border-radius: 50%;
  background: rgba(255,255,255,.1);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  font-size: .6rem;
  transition: background .2s;
}
.tf-hero-cta-secondary:hover .tf-hero-play-icon { background: rgba(255,94,46,.2); }

/* ── Trust bar ────────────────────────────────────────────────── */
.tf-hero-trust {
  display: flex;
  align-items: center;
  gap: 24px;
  flex-wrap: wrap;
  opacity: 0;
  animation: tfFadeUp .7s .65s ease forwards;
}
.tf-hero-trust-divider { width: 1px; height: 24px; background: rgba(255,255,255,.1); }
.tf-hero-stars { color: #ff5e2e; letter-spacing: 1px; font-size: .9rem; }
.tf-hero-trust-text { font-size: .8rem; color: #64748b; font-weight: 600; }
.tf-hero-trust-text strong { color: #94a3b8; }

/* ── Right — Mockup ───────────────────────────────────────────── */
.tf-hero-visual {
  position: relative;
  opacity: 0;
  animation: tfFadeIn .9s .4s ease forwards;
}

/* Browser chrome */
.tf-browser {
  background: #0d1526;
  border-radius: 16px;
  border: 1px solid rgba(255,255,255,.08);
  box-shadow:
    0 40px 80px rgba(0,0,0,.5),
    0 0 0 1px rgba(255,255,255,.04),
    inset 0 1px 0 rgba(255,255,255,.06);
  overflow: hidden;
  position: relative;
  animation: tfMockupFloat 8s ease-in-out infinite;
}
@keyframes tfMockupFloat {
  0%,100% { transform: translateY(0) rotate(-.5deg); }
  50%      { transform: translateY(-18px) rotate(.5deg); }
}

.tf-browser-bar {
  background: #070f1e;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  border-bottom: 1px solid rgba(255,255,255,.05);
}
.tf-browser-dots { display: flex; gap: 6px; }
.tf-browser-dot {
  width: 10px; height: 10px; border-radius: 50%;
  transition: transform .2s;
}
.tf-browser-dot:nth-child(1) { background: #ff5f57; }
.tf-browser-dot:nth-child(2) { background: #febc2e; }
.tf-browser-dot:nth-child(3) { background: #28c840; }
.tf-browser-url {
  flex: 1;
  background: rgba(255,255,255,.06);
  border-radius: 8px;
  padding: 6px 14px;
  font-size: .72rem;
  color: #475569;
  font-family: monospace;
  letter-spacing: .02em;
}

/* Browser content */
.tf-browser-content {
  height: 420px;
  overflow: hidden;
  position: relative;
}
.tf-browser-scroll {
  animation: tfBrowserScroll 14s ease-in-out infinite;
}
@keyframes tfBrowserScroll {
  0%,15%  { transform: translateY(0); }
  40%,55% { transform: translateY(-30%); }
  75%,90% { transform: translateY(-60%); }
  100%    { transform: translateY(0); }
}

/* Mini theme preview inside browser */
.tf-mini-nav {
  background: rgba(6,2,29,.96);
  padding: 12px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-bottom: 1px solid rgba(255,255,255,.06);
  position: sticky;
  top: 0;
  z-index: 10;
}
.tf-mini-logo { display: flex; align-items: center; gap: 8px; }
.tf-mini-logo-mark {
  width: 22px; height: 22px;
  background: #ff5e2e;
  border-radius: 6px;
}
.tf-mini-logo-text { width: 70px; height: 8px; background: rgba(255,255,255,.6); border-radius: 4px; }
.tf-mini-nav-links { display: flex; gap: 14px; }
.tf-mini-nav-link { width: 40px; height: 6px; background: rgba(255,255,255,.2); border-radius: 3px; }
.tf-mini-cta { width: 60px; height: 24px; background: #ff5e2e; border-radius: 12px; }

/* Mini hero */
.tf-mini-hero {
  padding: 40px 20px 30px;
  background: linear-gradient(180deg, #06021d 0%, #0d1526 100%);
  position: relative;
  overflow: hidden;
}
.tf-mini-hero::before {
  content: '';
  position: absolute;
  top: -40px; left: -40px;
  width: 200px; height: 200px;
  background: radial-gradient(circle, rgba(255,94,46,.2), transparent 70%);
}
.tf-mini-h1-a { width: 80%; height: 18px; background: rgba(241,245,249,.85); border-radius: 4px; margin-bottom: 10px; }
.tf-mini-h1-b { width: 60%; height: 18px; background: rgba(255,94,46,.7); border-radius: 4px; margin-bottom: 18px; }
.tf-mini-sub  { width: 90%; height: 8px; background: rgba(255,255,255,.2); border-radius: 3px; margin-bottom: 8px; }
.tf-mini-sub2 { width: 70%; height: 8px; background: rgba(255,255,255,.15); border-radius: 3px; margin-bottom: 24px; }
.tf-mini-btns { display: flex; gap: 10px; }
.tf-mini-btn-p { width: 100px; height: 28px; background: #ff5e2e; border-radius: 14px; }
.tf-mini-btn-s { width: 80px; height: 28px; background: rgba(255,255,255,.08); border-radius: 14px; border: 1px solid rgba(255,255,255,.1); }

/* Mini features */
.tf-mini-features {
  padding: 24px 20px;
  background: #0d1526;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
}
.tf-mini-feat-card {
  background: #111827;
  border: 1px solid rgba(255,255,255,.06);
  border-radius: 10px;
  padding: 12px;
}
.tf-mini-feat-icon { width: 24px; height: 24px; border-radius: 6px; margin-bottom: 8px; }
.tf-mini-feat-t { width: 80%; height: 7px; background: rgba(255,255,255,.5); border-radius: 3px; margin-bottom: 5px; }
.tf-mini-feat-d { width: 90%; height: 5px; background: rgba(255,255,255,.2); border-radius: 3px; }
.tf-mini-feat-d2 { width: 60%; height: 5px; background: rgba(255,255,255,.15); border-radius: 3px; margin-top: 4px; }

/* Mini portfolio */
.tf-mini-portfolio {
  padding: 24px 20px;
  background: linear-gradient(180deg, #0a0f1e, #0f172a);
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}
.tf-mini-pf-card {
  border-radius: 10px;
  overflow: hidden;
  aspect-ratio: 4/3;
  position: relative;
}
.tf-mini-pf-thumb {
  width: 100%; height: 100%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.2rem;
}
.tf-mini-pf-label {
  position: absolute;
  bottom: 0; left: 0; right: 0;
  background: linear-gradient(to top, rgba(6,2,29,.9), transparent);
  padding: 8px;
}
.tf-mini-pf-l1 { width: 70%; height: 5px; background: rgba(255,255,255,.6); border-radius: 2px; margin-bottom: 3px; }
.tf-mini-pf-l2 { width: 50%; height: 4px; background: rgba(255,94,46,.6); border-radius: 2px; }

/* Mini pricing */
.tf-mini-pricing {
  padding: 24px 20px;
  background: #06021d;
  display: grid;
  grid-template-columns: 1fr 1fr 1fr;
  gap: 8px;
}
.tf-mini-price-card {
  border-radius: 10px;
  padding: 12px;
  border: 1px solid rgba(255,255,255,.06);
}
.tf-mini-price-card.featured { border-color: rgba(255,94,46,.4); background: rgba(255,94,46,.05); }
.tf-mini-price-name { width: 60%; height: 6px; background: rgba(255,255,255,.5); border-radius: 3px; margin-bottom: 8px; }
.tf-mini-price-amt  { width: 40%; height: 14px; background: rgba(255,255,255,.7); border-radius: 4px; margin-bottom: 12px; }
.tf-mini-price-amt.orange { background: rgba(255,94,46,.8); }
.tf-mini-price-feat { width: 80%; height: 4px; background: rgba(255,255,255,.15); border-radius: 2px; margin-bottom: 4px; }
.tf-mini-price-btn  { width: 100%; height: 20px; border-radius: 10px; margin-top: 10px; background: rgba(255,94,46,.2); }
.tf-mini-price-btn.solid { background: #ff5e2e; }

/* ── Floating Badges ─────────────────────────────────────────── */
.tf-hero-badge-float {
  position: absolute;
  background: rgba(13,21,38,.95);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid rgba(255,255,255,.1);
  border-radius: 12px;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 8px;
  box-shadow: 0 8px 24px rgba(0,0,0,.3);
  z-index: 10;
  white-space: nowrap;
}
.tf-badge-float-icon {
  width: 28px; height: 28px;
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: .9rem; flex-shrink: 0;
}
.tf-badge-float-label { font-size: .72rem; font-weight: 800; color: #f1f5f9; }
.tf-badge-float-sub   { font-size: .65rem; color: #64748b; }

.tf-badge-speed {
  top: -20px; right: 20px;
  animation: tfBadge1Float 6s ease-in-out infinite;
}
.tf-badge-widgets {
  bottom: 80px; left: -30px;
  animation: tfBadge2Float 7s ease-in-out infinite;
}
.tf-badge-rating {
  bottom: -10px; right: 60px;
  animation: tfBadge3Float 5s ease-in-out infinite;
}

@keyframes tfBadge1Float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
@keyframes tfBadge2Float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(10px)} }
@keyframes tfBadge3Float { 0%,100%{transform:translateY(0) translateX(0)} 50%{transform:translateY(-6px) translateX(4px)} }

/* ── Skin switcher strip ─────────────────────────────────────── */
.tf-hero-skins {
  margin-top: 40px;
  display: flex;
  align-items: center;
  gap: 10px;
  opacity: 0;
  animation: tfFadeUp .7s .8s ease forwards;
}
.tf-hero-skins-label { font-size: .72rem; font-weight: 700; color: #475569; letter-spacing: .06em; text-transform: uppercase; margin-right: 4px; }
.tf-skin-dot {
  width: 22px; height: 22px;
  border-radius: 50%;
  cursor: pointer;
  border: 2px solid transparent;
  transition: transform .2s, border-color .2s;
  box-shadow: 0 2px 8px rgba(0,0,0,.3);
}
.tf-skin-dot:hover { transform: scale(1.25); }
.tf-skin-dot.active { border-color: rgba(255,255,255,.5); transform: scale(1.15); }

/* ── Scroll indicator ────────────────────────────────────────── */
.tf-hero-scroll {
  position: absolute;
  bottom: 32px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  opacity: 0;
  animation: tfFadeIn .7s 1.2s ease forwards;
  text-decoration: none;
  z-index: 5;
}
.tf-hero-scroll-text { font-size: .68rem; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; color: #334155; }
.tf-hero-scroll-line {
  width: 1px; height: 40px;
  background: linear-gradient(to bottom, #334155, transparent);
  animation: tfScrollDrop 2s ease-in-out infinite;
}
@keyframes tfScrollDrop { 0%{transform:scaleY(0);transform-origin:top} 50%{transform:scaleY(1);transform-origin:top} 51%{transform-origin:bottom} 100%{transform:scaleY(0);transform-origin:bottom} }

/* ── Entrance animations ────────────────────────────────────── */
@keyframes tfFadeUp { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:translateY(0)} }
@keyframes tfFadeIn { from{opacity:0} to{opacity:1} }

/* ── Video background ───────────────────────────────────────── */
.tf-hero-video-wrap {
  position: absolute; inset: 0; z-index: 0;
  overflow: hidden;
}
.tf-hero-video-wrap video {
  width: 100%; height: 100%;
  object-fit: cover;
  pointer-events: none;
}
.tf-hero-video-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(
    135deg,
    rgba(6,2,29,.75) 0%,
    rgba(6,2,29,.55) 50%,
    rgba(6,2,29,.70) 100%
  );
  z-index: 1;
}
/* When video is active, reduce blob opacity */
.tf-hero.has-video .tf-hero-blobs { opacity: .4; z-index: 2; }
.tf-hero.has-video::before { opacity: .4; }

/* Video mute toggle */
.tf-hero-video-mute {
  position: absolute;
  bottom: 80px; right: 32px;
  z-index: 10;
  width: 40px; height: 40px;
  border-radius: 50%;
  background: rgba(255,255,255,.08);
  border: 1px solid rgba(255,255,255,.12);
  backdrop-filter: blur(8px);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer;
  transition: background .2s;
  color: #94a3b8;
}
.tf-hero-video-mute:hover { background: rgba(255,255,255,.15); }
.tf-hero-video-mute svg { width: 16px; height: 16px; }

/* ── Responsive ─────────────────────────────────────────────── */
@media(max-width:1100px) {
  .tf-hero-inner { grid-template-columns: 1fr; gap: 48px; padding-top: 100px; }
  .tf-hero-visual { max-width: 640px; margin: 0 auto; }
  .tf-hero-h1 { font-size: clamp(2.2rem, 5vw, 3.2rem); }
  .tf-hero-scroll { display: none; }
}
@media(max-width:640px) {
  .tf-hero-inner { padding: 90px 20px 60px; }
  .tf-hero-ctas { flex-direction: column; align-items: flex-start; }
  .tf-hero-cta-primary, .tf-hero-cta-secondary { width: 100%; justify-content: center; }
}
</style>

<?php if ( $has_video ) : ?>
<!-- Video Background -->
<div class="tf-hero-video-wrap" aria-hidden="true">
  <video
    autoplay muted loop playsinline
    <?php echo $hero_video_pos ? 'poster="' . esc_url($hero_video_pos) . '"' : ''; ?>
  >
    <source src="<?php echo esc_url( $hero_video_url ); ?>" type="video/mp4">
  </video>
  <div class="tf-hero-video-overlay"></div>
</div>
<?php endif; ?>

<!-- Blobs -->
<div class="tf-hero-blobs" aria-hidden="true">
  <div class="tf-hero-blob tf-hero-blob-1"></div>
  <div class="tf-hero-blob tf-hero-blob-2"></div>
  <div class="tf-hero-blob tf-hero-blob-3"></div>
</div>

<div class="tf-hero-inner">

  <!-- ── LEFT: COPY ─────────────────────────────────────────── -->
  <div class="tf-hero-copy">

    <div class="tf-hero-badge">
      <span class="tf-hero-badge-dot" aria-hidden="true"></span>
      <?php esc_html_e( 'ThemeForest Premium Theme', 'themeflex' ); ?>
      &nbsp;·&nbsp; <?php esc_html_e( '97 PageSpeed', 'themeflex' ); ?>
    </div>

    <h1 class="tf-hero-h1">
      <?php echo wp_kses( $hero_title, array( 'br' => array(), 'em' => array(), 'strong' => array(), 'span' => array( 'class' => array() ) ) ); ?>
    </h1>

    <p class="tf-hero-sub"><?php echo esc_html( $hero_subtitle ); ?></p>

    <div class="tf-hero-ctas">
      <a href="<?php echo esc_url( $cta1_url ); ?>" class="tf-hero-cta-primary" target="_blank" rel="noopener">
        <?php echo esc_html( $cta1_text ); ?>
        <svg class="tf-hero-cta-arrow" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
      </a>
      <a href="<?php echo esc_url( $cta2_url ); ?>" class="tf-hero-cta-secondary">
        <span class="tf-hero-play-icon" aria-hidden="true">
          <svg width="8" height="10" viewBox="0 0 8 10" fill="currentColor"><path d="M0 0l8 5-8 5V0z"/></svg>
        </span>
        <?php echo esc_html( $cta2_text ); ?>
      </a>
    </div>

    <!-- Trust bar -->
    <div class="tf-hero-trust">
      <div>
        <div class="tf-hero-stars">★★★★★</div>
        <div class="tf-hero-trust-text"><strong>4.9 / 5.0</strong> · <?php esc_html_e( '2,000+ Happy Customers', 'themeflex' ); ?></div>
      </div>
      <div class="tf-hero-trust-divider" aria-hidden="true"></div>
      <div class="tf-hero-trust-text">
        <?php esc_html_e( '14-day money-back guarantee', 'themeflex' ); ?>
      </div>
      <div class="tf-hero-trust-divider" aria-hidden="true"></div>
      <div class="tf-hero-trust-text"><?php esc_html_e( 'Lifetime updates', 'themeflex' ); ?></div>
    </div>

    <!-- Skin swatches -->
    <div class="tf-hero-skins">
      <span class="tf-hero-skins-label"><?php esc_html_e( '8 Skins', 'themeflex' ); ?></span>
      <?php
      $skins = array(
        array( '#ff5e2e', 'Default Orange', true ),
        array( '#3b82f6', 'Corporate Blue', false ),
        array( '#10b981', 'Creative Green', false ),
        array( '#7c3aed', 'Midnight Violet', false ),
        array( '#e11d48', 'Rose Crimson', false ),
        array( '#0891b2', 'Ocean Teal', false ),
        array( '#d97706', 'Amber Gold', false ),
        array( '#00f5ff', 'Neon Cyan', false ),
      );
      foreach ( $skins as list( $color, $label, $active ) ) : ?>
        <span
          class="tf-skin-dot<?php echo $active ? ' active' : ''; ?>"
          style="background:<?php echo esc_attr( $color ); ?>"
          title="<?php echo esc_attr( $label ); ?>"
          aria-label="<?php echo esc_attr( $label ); ?>"
        ></span>
      <?php endforeach; ?>
    </div>

  </div><!-- /.tf-hero-copy -->

  <!-- ── RIGHT: MOCKUP ──────────────────────────────────────── -->
  <div class="tf-hero-visual">

    <!-- Floating badges -->
    <div class="tf-hero-badge-float tf-badge-speed" aria-hidden="true">
      <div class="tf-badge-float-icon" style="background:rgba(16,185,129,.15)">⚡</div>
      <div>
        <div class="tf-badge-float-label">97 PageSpeed</div>
        <div class="tf-badge-float-sub"><?php esc_html_e( 'Out of the box', 'themeflex' ); ?></div>
      </div>
    </div>

    <div class="tf-hero-badge-float tf-badge-widgets" aria-hidden="true">
      <div class="tf-badge-float-icon" style="background:rgba(168,85,247,.15);color:rgba(168,85,247,1);display:flex;align-items:center;justify-content:center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg></div>
      <div>
        <div class="tf-badge-float-label">80+ Widgets</div>
        <div class="tf-badge-float-sub">Elementor Ready</div>
      </div>
    </div>

    <div class="tf-hero-badge-float tf-badge-rating" aria-hidden="true">
      <div class="tf-badge-float-icon" style="background:rgba(255,94,46,.15)">★</div>
      <div>
        <div class="tf-badge-float-label">4.9 / 5.0</div>
        <div class="tf-badge-float-sub">2,000+ Reviews</div>
      </div>
    </div>

    <!-- Browser mockup -->
    <div class="tf-browser">
      <div class="tf-browser-bar">
        <div class="tf-browser-dots">
          <span class="tf-browser-dot"></span>
          <span class="tf-browser-dot"></span>
          <span class="tf-browser-dot"></span>
        </div>
        <div class="tf-browser-url">themeflex.de</div>
      </div>

      <div class="tf-browser-content">
        <div class="tf-browser-scroll">

          <!-- Mini Nav -->
          <div class="tf-mini-nav">
            <div class="tf-mini-logo">
              <div class="tf-mini-logo-mark"></div>
              <div class="tf-mini-logo-text"></div>
            </div>
            <div class="tf-mini-nav-links">
              <div class="tf-mini-nav-link"></div>
              <div class="tf-mini-nav-link"></div>
              <div class="tf-mini-nav-link"></div>
              <div class="tf-mini-nav-link"></div>
            </div>
            <div class="tf-mini-cta"></div>
          </div>

          <!-- Mini Hero -->
          <div class="tf-mini-hero">
            <div class="tf-mini-h1-a"></div>
            <div class="tf-mini-h1-b"></div>
            <div class="tf-mini-sub"></div>
            <div class="tf-mini-sub2"></div>
            <div class="tf-mini-btns">
              <div class="tf-mini-btn-p"></div>
              <div class="tf-mini-btn-s"></div>
            </div>
          </div>

          <!-- Mini Features -->
          <div class="tf-mini-features">
            <?php
            $feat_colors = array( '#ff5e2e', '#3b82f6', '#10b981', '#a855f7', '#f59e0b', '#00d4ff' );
            for ( $i = 0; $i < 6; $i++ ) :
              $c = $feat_colors[$i];
            ?>
            <div class="tf-mini-feat-card">
              <div class="tf-mini-feat-icon" style="background:<?php echo esc_attr($c); ?>33;border:1px solid <?php echo esc_attr($c); ?>44;border-radius:4px;"></div>
              <div class="tf-mini-feat-t"></div>
              <div class="tf-mini-feat-d"></div>
              <div class="tf-mini-feat-d2"></div>
            </div>
            <?php endfor; ?>
          </div>

          <!-- Mini Portfolio -->
          <div class="tf-mini-portfolio">
            <?php
            $pf_items = array(
              array( '#1e293b', 'rgba(59,130,246,.6)',  'linear-gradient(135deg,rgba(59,130,246,.3),rgba(59,130,246,.08))' ),
              array( '#0d1a0a', 'rgba(16,185,129,.6)',  'linear-gradient(135deg,rgba(16,185,129,.3),rgba(16,185,129,.08))' ),
              array( '#1a0a1e', 'rgba(168,85,247,.6)',  'linear-gradient(135deg,rgba(168,85,247,.3),rgba(168,85,247,.08))' ),
            );
            foreach ( $pf_items as list( $bg, $accent, $thumb_grad ) ) : ?>
            <div class="tf-mini-pf-card" style="background:<?php echo esc_attr($bg); ?>;border:1px solid <?php echo esc_attr($accent); ?>40">
              <div class="tf-mini-pf-thumb" style="background:<?php echo esc_attr($thumb_grad); ?>"></div>
              <div class="tf-mini-pf-label">
                <div class="tf-mini-pf-l1"></div>
                <div class="tf-mini-pf-l2"></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>

          <!-- Mini Pricing -->
          <div class="tf-mini-pricing">
            <div class="tf-mini-price-card">
              <div class="tf-mini-price-name"></div>
              <div class="tf-mini-price-amt"></div>
              <div class="tf-mini-price-feat"></div>
              <div class="tf-mini-price-feat"></div>
              <div class="tf-mini-price-btn"></div>
            </div>
            <div class="tf-mini-price-card featured">
              <div class="tf-mini-price-name" style="background:rgba(255,94,46,.5)"></div>
              <div class="tf-mini-price-amt orange"></div>
              <div class="tf-mini-price-feat"></div>
              <div class="tf-mini-price-feat"></div>
              <div class="tf-mini-price-btn solid"></div>
            </div>
            <div class="tf-mini-price-card">
              <div class="tf-mini-price-name"></div>
              <div class="tf-mini-price-amt"></div>
              <div class="tf-mini-price-feat"></div>
              <div class="tf-mini-price-feat"></div>
              <div class="tf-mini-price-btn"></div>
            </div>
          </div>

        </div><!-- /.tf-browser-scroll -->
      </div><!-- /.tf-browser-content -->
    </div><!-- /.tf-browser -->

  </div><!-- /.tf-hero-visual -->

</div><!-- /.tf-hero-inner -->

<?php if ( $has_video ) : ?>
<!-- Video mute toggle -->
<button class="tf-hero-video-mute" id="tf-video-mute" aria-label="<?php esc_attr_e( 'Mute/unmute video', 'themeflex' ); ?>" aria-pressed="true">
  <svg id="tf-icon-mute" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>
  <svg id="tf-icon-sound" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
</button>
<?php endif; ?>

<!-- Scroll indicator -->
<a class="tf-hero-scroll" href="#sf-features" aria-label="<?php esc_attr_e( 'Scroll down', 'themeflex' ); ?>">
  <span class="tf-hero-scroll-text"><?php esc_html_e( 'Scroll', 'themeflex' ); ?></span>
  <span class="tf-hero-scroll-line" aria-hidden="true"></span>
</a>
<!-- Shape Divider -->
<div class="tf-shape-divider tf-shape-bottom" aria-hidden="true">
  <svg viewBox="0 0 1440 80" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0,40 C240,80 480,0 720,40 C960,80 1200,0 1440,40 L1440,80 L0,80 Z" fill="#06021d"/>
  </svg>
</div>


<script>
(function(){
  var el = document.querySelector('.tf-typing-word');
  var cursor = document.querySelector('#sf-hero .tf-typing-cursor');
  if (!el) return;

  var words = (el.dataset.words || '').split(',').filter(Boolean);
  if (!words.length) return;

  var wordIdx = 0;
  var charIdx = 0;
  var deleting = false;
  var pauseFrames = 0;

  function tick() {
    var word = words[wordIdx];
    if (deleting) {
      charIdx--;
      el.textContent = word.slice(0, charIdx);
      if (charIdx === 0) {
        deleting = false;
        wordIdx = (wordIdx + 1) % words.length;
        pauseFrames = 8;
      }
    } else {
      if (pauseFrames > 0) { pauseFrames--; setTimeout(tick, 60); return; }
      charIdx++;
      el.textContent = word.slice(0, charIdx);
      if (charIdx === word.length) {
        pauseFrames = 32; // pause at full word
        deleting = true;
      }
    }
    var delay = deleting ? 45 : (pauseFrames > 0 ? 800 : 90);
    setTimeout(tick, delay);
  }

  setTimeout(tick, 1200);
})();
</script>

<?php if ( $has_video ) : ?>
<script>
(function(){
  var btn    = document.getElementById('tf-video-mute');
  var video  = document.querySelector('#sf-hero video');
  var iconM  = document.getElementById('tf-icon-mute');
  var iconS  = document.getElementById('tf-icon-sound');
  if (!btn || !video) return;
  btn.addEventListener('click', function() {
    video.muted = !video.muted;
    iconM.style.display = video.muted ? '' : 'none';
    iconS.style.display = video.muted ? 'none' : '';
    btn.setAttribute('aria-pressed', video.muted ? 'true' : 'false');
  });
})();
</script>
<?php endif; ?>

</section>