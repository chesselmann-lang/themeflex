<?php
/**
 * Front Page Logo Cloud v1.0 — Infinite scroll brand strip
 *
 * Auto-scrolling logos of tools/partners, dark-first.
 * No images needed — text-based logos with distinct colors.
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_logocloud_enabled', true ) ) return;

$label = get_theme_mod( 'sf_logocloud_label', 'Trusted by teams using' );

$logos = array(
  array('name'=>'WordPress',    'color'=>'#3858e9', 'initial'=>'W'),
  array('name'=>'Elementor',    'color'=>'#92003b', 'initial'=>'E'),
  array('name'=>'WooCommerce',  'color'=>'#7f54b3', 'initial'=>'Woo'),
  array('name'=>'Cloudflare',   'color'=>'#f6821f', 'initial'=>'CF'),
  array('name'=>'Figma',        'color'=>'#f24e1e', 'initial'=>'F'),
  array('name'=>'GA4',          'color'=>'#e37400', 'initial'=>'GA4'),
  array('name'=>'Stripe',       'color'=>'#635bff', 'initial'=>'S'),
  array('name'=>'WP Rocket',    'color'=>'#ed3025', 'initial'=>'R'),
  array('name'=>'Yoast SEO',    'color'=>'#a4286a', 'initial'=>'Y'),
  array('name'=>'Gravity Forms','color'=>'#c9372c', 'initial'=>'GF'),
);
?>
<div class="tf-cloud-section" aria-label="<?php esc_attr_e('Trusted by teams using these tools','themeflex'); ?>">
<style>
.tf-cloud-section {
  padding: 40px 0;
  background: #0d1526;
  border-top: 1px solid rgba(255,255,255,.05);
  border-bottom: 1px solid rgba(255,255,255,.05);
  overflow: hidden;
}
.tf-cloud-label {
  text-align: center;
  font-size: .72rem;
  font-weight: 700;
  letter-spacing: .1em;
  text-transform: uppercase;
  color: #334155;
  margin-bottom: 24px;
}
.tf-cloud-track-wrap { position: relative; overflow: hidden; }
.tf-cloud-track-wrap::before,
.tf-cloud-track-wrap::after {
  content: '';
  position: absolute; top: 0; bottom: 0; width: 100px; z-index: 2; pointer-events: none;
}
.tf-cloud-track-wrap::before { left:0; background:linear-gradient(to right,#0d1526,transparent); }
.tf-cloud-track-wrap::after  { right:0; background:linear-gradient(to left,#0d1526,transparent); }
.tf-cloud-track {
  display: flex; gap: 16px; align-items: center;
  animation: tfCloudScroll 25s linear infinite;
  width: max-content;
}
.tf-cloud-track:hover { animation-play-state: paused; }
@keyframes tfCloudScroll { 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
.tf-cloud-item {
  display: flex; align-items: center; gap: 8px;
  padding: 10px 20px; border-radius: 100px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.07);
  white-space: nowrap;
  transition: border-color .2s, background .2s;
}
.tf-cloud-item:hover { background: rgba(255,255,255,.07); border-color: rgba(255,255,255,.12); }
.tf-cloud-item-icon {
  width: 22px; height: 22px; border-radius: 5px;
  display: flex; align-items: center; justify-content: center;
  font-size: .55rem; font-weight: 900; letter-spacing: -.02em;
  color: #fff; flex-shrink: 0; line-height: 1;
}
.tf-cloud-item-name { font-size: .8rem; font-weight: 700; color: #475569; }
</style>

<div class="tf-cloud-label"><?php echo esc_html($label); ?></div>
<div class="tf-cloud-track-wrap">
  <div class="tf-cloud-track">
    <?php
    $all = array_merge($logos, $logos); // duplicate for seamless
    foreach($all as $logo) : ?>
    <div class="tf-cloud-item">
      <span class="tf-cloud-item-icon" style="background:<?php echo esc_attr($logo['color']); ?>" aria-hidden="true"><?php echo esc_html($logo['initial']); ?></span>
      <span class="tf-cloud-item-name"><?php echo esc_html($logo['name']); ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>
</div>
