<?php
/**
 * Front Page Portfolio Section — ThemeFlex v4.0 Asymmetric Masonry
 *
 * Asymmetric masonry: first card is double-height hero, remaining 5 in grid.
 * Numbered overlays, category chips, project stats on hover.
 *
 * @package ThemeFlex
 * @since   2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_portfolio_enabled', true ) ) return;

$tag            = get_theme_mod( 'sf_portfolio_tag',      'Our Work' );
$title          = get_theme_mod( 'sf_portfolio_title',    'Crafted With Purpose' );
$subtitle       = get_theme_mod( 'sf_portfolio_subtitle', 'A selection of our most impactful projects — from bold brand identities to enterprise platforms.' );
$cta_label      = get_theme_mod( 'sf_portfolio_cta_label', 'View All Projects' );
$cta_url        = get_theme_mod( 'sf_portfolio_cta_url',   home_url( '/portfolio/' ) );
$padding_top    = absint( get_theme_mod( 'sf_portfolio_padding_top',    100 ) );
$padding_bottom = absint( get_theme_mod( 'sf_portfolio_padding_bottom', 100 ) );
$custom_class   = sanitize_html_class( get_theme_mod( 'sf_portfolio_custom_class', '' ) );

/* ── Category colour map ── */
$cat_colors = [
	'web design'    => ['bg'=>'rgba(59,130,246,.15)','text'=>'#60a5fa','glow'=>'#3b82f6'],
	'web-design'    => ['bg'=>'rgba(59,130,246,.15)','text'=>'#60a5fa','glow'=>'#3b82f6'],
	'e-commerce'    => ['bg'=>'rgba(168,85,247,.15)','text'=>'#c084fc','glow'=>'#a855f7'],
	'ecommerce'     => ['bg'=>'rgba(168,85,247,.15)','text'=>'#c084fc','glow'=>'#a855f7'],
	'branding'      => ['bg'=>'rgba(239,68,68,.15)', 'text'=>'#f87171','glow'=>'#ef4444'],
	'saas'          => ['bg'=>'rgba(16,185,129,.15)','text'=>'#34d399','glow'=>'#10b981'],
	'mobile app'    => ['bg'=>'rgba(139,92,246,.15)','text'=>'#a78bfa','glow'=>'#8b5cf6'],
	'mobile-app'    => ['bg'=>'rgba(139,92,246,.15)','text'=>'#a78bfa','glow'=>'#8b5cf6'],
	'dashboard'     => ['bg'=>'rgba(20,184,166,.15)','text'=>'#2dd4bf','glow'=>'#14b8a6'],
];
$color_default = ['bg'=>'rgba(255,94,46,.12)','text'=>'#ff8a60','glow'=>'#ff5e2e'];

/* ── Demo items for empty state ── */
$demo_items = [
	['cat'=>'Web Design',   'title'=>'NovaSpark Agency',       'desc'=>'Full website redesign with dark-first aesthetic and Elementor integration.','device'=>'browser', 'grad'=>'linear-gradient(135deg,#051228,#0d1a3a)','year'=>'2025','role'=>'Design & Dev',  'num'=>'01'],
	['cat'=>'E-Commerce',   'title'=>'Lumina Store Launch',    'desc'=>'WooCommerce luxury cosmetics store with custom checkout optimisation.',    'device'=>'browser', 'grad'=>'linear-gradient(135deg,#160b28,#230f3e)','year'=>'2025','role'=>'Full Stack',   'num'=>'02'],
	['cat'=>'Branding',     'title'=>'Forge Studios Identity', 'desc'=>'Complete brand identity — logo, colour palette and marketing collateral.', 'device'=>'display', 'grad'=>'linear-gradient(135deg,#280a0e,#3d0f14)','year'=>'2024','role'=>'Brand Design',  'num'=>'03'],
	['cat'=>'SaaS Product', 'title'=>'Dashtrek Analytics',    'desc'=>'B2B analytics SaaS with real-time data visualisations and dark UI.',      'device'=>'display', 'grad'=>'linear-gradient(135deg,#041a10,#08261a)','year'=>'2025','role'=>'Product',      'num'=>'04'],
	['cat'=>'Mobile App',   'title'=>'FlowPulse iOS Site',    'desc'=>'Marketing site for a productivity app with bold typography and motion.',   'device'=>'mobile',  'grad'=>'linear-gradient(135deg,#120a26,#1c1040)','year'=>'2024','role'=>'Web Design',   'num'=>'05'],
	['cat'=>'Dashboard',    'title'=>'Meridian Restaurant',   'desc'=>'Multi-location restaurant brand with reservation system and menu pages.',  'device'=>'display', 'grad'=>'linear-gradient(135deg,#1e0e04,#2e160a)','year'=>'2024','role'=>'Full Stack',   'num'=>'06'],
];

/* ── Query CPT ── */
$pq = new WP_Query([
	'post_type'      => 'sf_portfolio',
	'posts_per_page' => 6,
	'orderby'        => 'date', 'order' => 'DESC',
	'post_status'    => 'publish',
]);

/* Helper: get cat color */
if ( ! function_exists( 'tf_pf_color' ) ) {
	function tf_pf_color( $cat_name, $map, $default ) {
		$key = strtolower( $cat_name );
		return isset( $map[$key] ) ? $map[$key] : $default;
	}
}

/* Helper: map category to device type */
if ( ! function_exists( 'tf_pf_device_type' ) ) {
	function tf_pf_device_type( $cat_name ) {
		$map = [
			'mobile app'  => 'mobile',
			'mobile-app'  => 'mobile',
			'branding'    => 'display',
			'dashboard'   => 'display',
		];
		$key = strtolower( $cat_name );
		return isset( $map[$key] ) ? $map[$key] : 'browser';
	}
}

/* Helper: render CSS device mockup HTML */
if ( ! function_exists( 'tf_pf_device_html' ) ) {
	function tf_pf_device_html( $type ) {
		switch ( $type ) {
			case 'mobile':
				return '
<div class="sf-pf-device sf-pf-device--mobile" aria-hidden="true">
  <div class="sf-pf-dev-notch"><div class="sf-pf-dev-notch-island"></div></div>
  <div class="sf-pf-dev-screen-mobile">
    <div class="sf-pf-dev-app-bar"></div>
    <div class="sf-pf-dev-tab-row">
      <div class="sf-pf-dev-tab-pill sf-pf-dev-tab-pill--active"></div>
      <div class="sf-pf-dev-tab-pill"></div>
      <div class="sf-pf-dev-tab-pill"></div>
    </div>
    <div class="sf-pf-dev-thumb"></div>
    <div class="sf-pf-dev-line sf-pf-dev-line-75"></div>
    <div class="sf-pf-dev-line sf-pf-dev-line-55"></div>
  </div>
  <div class="sf-pf-dev-home-bar"></div>
</div>';

			case 'display':
				return '
<div class="sf-pf-device sf-pf-device--display" aria-hidden="true">
  <div class="sf-pf-dev-topbar">
    <div class="sf-pf-dev-topbar-title"></div>
    <div class="sf-pf-dev-topbar-btn"></div>
  </div>
  <div class="sf-pf-dev-dash-body">
    <div class="sf-pf-dev-sidebar">
      <div class="sf-pf-dev-nav sf-pf-dev-nav--active"></div>
      <div class="sf-pf-dev-nav"></div>
      <div class="sf-pf-dev-nav"></div>
      <div class="sf-pf-dev-nav"></div>
    </div>
    <div class="sf-pf-dev-main-content">
      <div class="sf-pf-dev-kpi-row">
        <div class="sf-pf-dev-kpi sf-pf-dev-kpi--accent"></div>
        <div class="sf-pf-dev-kpi"></div>
        <div class="sf-pf-dev-kpi"></div>
      </div>
      <div class="sf-pf-dev-chart-area">
        <div class="sf-pf-dev-chart-bar" style="left:4%;width:9%;height:45%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:15%;width:9%;height:70%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:26%;width:9%;height:55%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:37%;width:9%;height:90%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:48%;width:9%;height:65%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:59%;width:9%;height:80%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:70%;width:9%;height:50%"></div>
        <div class="sf-pf-dev-chart-bar" style="left:81%;width:9%;height:75%"></div>
      </div>
      <div class="sf-pf-dev-line sf-pf-dev-line-75"></div>
      <div class="sf-pf-dev-line sf-pf-dev-line-55"></div>
    </div>
  </div>
</div>';

			default: /* browser */
				return '
<div class="sf-pf-device sf-pf-device--browser" aria-hidden="true">
  <div class="sf-pf-dev-bar">
    <div class="sf-pf-dev-dot sf-pf-dev-dot-r"></div>
    <div class="sf-pf-dev-dot sf-pf-dev-dot-y"></div>
    <div class="sf-pf-dev-dot sf-pf-dev-dot-g"></div>
    <div class="sf-pf-dev-addr"></div>
  </div>
  <div class="sf-pf-dev-content">
    <div class="sf-pf-dev-hero-block"></div>
    <div class="sf-pf-dev-line sf-pf-dev-line-75"></div>
    <div class="sf-pf-dev-line sf-pf-dev-line-55"></div>
    <div class="sf-pf-dev-cards">
      <div class="sf-pf-dev-card"></div>
      <div class="sf-pf-dev-card sf-pf-dev-card--accent"></div>
    </div>
  </div>
</div>';
		}
	}
}
?>
<section
	class="sf-pf-section <?php echo esc_attr( $custom_class ); ?>"
	id="portfolio"
	style="padding-top:<?php echo $padding_top; ?>px;padding-bottom:<?php echo $padding_bottom; ?>px;"
	aria-label="<?php esc_attr_e( 'Portfolio', 'themeflex' ); ?>"
>
<style>
/* ══════════════════════════════════════════════════════════
   PORTFOLIO SECTION v4 — Asymmetric Masonry
   ══════════════════════════════════════════════════════════ */
.sf-pf-section {
  background: linear-gradient(180deg, #06021d 0%, #0a0f1e 100%);
  position: relative; overflow: hidden;
}
.sf-pf-section::before {
  content: '';
  position: absolute;
  bottom: -200px; left: -200px;
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(59,130,246,.06) 0%, transparent 70%);
  pointer-events: none;
}

.sf-pf-wrap { max-width: 1240px; margin: 0 auto; padding: 0 24px; }

/* ── Header ── */
.sf-pf-hd {
  display: flex; align-items: flex-end; justify-content: space-between;
  gap: 24px; margin-bottom: 52px; flex-wrap: wrap;
}
.sf-pf-hd-left { max-width: 560px; }
.sf-pf-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.22);
  color: #ff5e2e; font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px;
  margin-bottom: 18px;
}
.sf-pf-eyebrow::before { content: '◆'; font-size: .55rem; }
.sf-pf-hd-left h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 900; color: #fff; margin: 0 0 12px;
  letter-spacing: -.04em; line-height: 1.08;
}
.sf-pf-hd-left h2 em {
  font-style: normal;
  background: linear-gradient(135deg, #ff5e2e, #a855f7);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text;
}
.sf-pf-hd-left p { color: #94a3b8; font-size: .975rem; line-height: 1.7; margin: 0; }

/* ── Masonry grid ── */
.sf-pf-masonry {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-auto-rows: 240px;
  gap: 16px;
}

/* First card spans 2 rows = hero */
.sf-pf-masonry .sf-pf-item:first-child { grid-row: span 2; }

/* ── Card ── */
.sf-pf-item {
  position: relative; border-radius: 18px; overflow: hidden;
  display: block; text-decoration: none;
  background: #111827; border: 1px solid rgba(255,255,255,.07);
  cursor: pointer;
}
.sf-pf-item-bg {
  position: absolute; inset: 0;
  background: inherit; /* fallback */
}
.sf-pf-item-bg img {
  width: 100%; height: 100%; object-fit: cover;
  transition: transform .6s cubic-bezier(.22,.68,0,1.2);
}
.sf-pf-item:hover .sf-pf-item-bg img { transform: scale(1.07); }
/* ── CSS Device Mockups ── */
.sf-pf-device {
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%, -54%);
  z-index: 1; pointer-events: none; opacity: .9;
}
/* Browser frame */
.sf-pf-device--browser {
  width: 80%; border-radius: 8px;
  background: rgba(8,12,30,.97);
  border: 1px solid rgba(255,255,255,.11);
  box-shadow: 0 20px 56px rgba(0,0,0,.55), inset 0 1px 0 rgba(255,255,255,.07);
  overflow: hidden;
}
.sf-pf-dev-bar {
  display: flex; align-items: center; gap: 5px;
  padding: 7px 10px;
  background: rgba(255,255,255,.04);
  border-bottom: 1px solid rgba(255,255,255,.06);
}
.sf-pf-dev-dot { width: 6px; height: 6px; border-radius: 50%; }
.sf-pf-dev-dot-r { background:#ef4444; opacity:.7; }
.sf-pf-dev-dot-y { background:#f59e0b; opacity:.7; }
.sf-pf-dev-dot-g { background:#22c55e; opacity:.7; }
.sf-pf-dev-addr {
  flex:1; height:11px; max-width:52%;
  background: rgba(255,255,255,.07); border-radius:20px; margin-left:8px;
}
.sf-pf-dev-content {
  padding: 9px; display: flex; flex-direction: column; gap: 6px;
}
.sf-pf-dev-hero-block {
  height: 34px; border-radius: 5px;
  background: var(--cat-glow, #ff5e2e); opacity: .2;
}
.sf-pf-dev-line {
  height: 6px; border-radius: 3px;
  background: rgba(255,255,255,.07);
}
.sf-pf-dev-line-75 { width:75%; }
.sf-pf-dev-line-55 { width:55%; }
.sf-pf-dev-cards {
  display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-top:2px;
}
.sf-pf-dev-card {
  height:28px; border-radius:5px;
  background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.07);
}
.sf-pf-dev-card--accent {
  background:var(--cat-glow,#ff5e2e); opacity:.13; border:none;
}
/* Mobile frame */
.sf-pf-device--mobile {
  width: 36%; border-radius: 18px;
  background: rgba(8,12,30,.97);
  border: 2px solid rgba(255,255,255,.13);
  box-shadow: 0 20px 56px rgba(0,0,0,.55), inset 0 1px 0 rgba(255,255,255,.07);
  overflow: hidden;
}
.sf-pf-dev-notch {
  display:flex; justify-content:center; padding: 6px 0 3px;
}
.sf-pf-dev-notch-island {
  width:40%; height:10px;
  background:rgba(0,0,0,.85); border-radius:10px;
}
.sf-pf-dev-screen-mobile {
  padding:7px; display:flex; flex-direction:column; gap:5px;
}
.sf-pf-dev-app-bar {
  height:18px; border-radius:4px;
  background:var(--cat-glow,#ff5e2e); opacity:.2; margin-bottom:2px;
}
.sf-pf-dev-tab-row { display:flex; gap:4px; }
.sf-pf-dev-tab-pill {
  height:13px; border-radius:4px;
  background:rgba(255,255,255,.07); flex:1;
}
.sf-pf-dev-tab-pill--active {
  background:var(--cat-glow,#ff5e2e); opacity:.28;
}
.sf-pf-dev-thumb {
  height:36px; border-radius:5px;
  background:rgba(255,255,255,.04);
  border:1px solid rgba(255,255,255,.07);
}
.sf-pf-dev-home-bar {
  height:4px; background:rgba(255,255,255,.15); border-radius:2px;
  width:35%; margin: 5px auto 4px;
}
/* Display / Dashboard frame */
.sf-pf-device--display {
  width: 84%; border-radius: 7px;
  background: rgba(8,12,30,.97);
  border: 1px solid rgba(255,255,255,.11);
  box-shadow: 0 20px 56px rgba(0,0,0,.55), inset 0 1px 0 rgba(255,255,255,.07);
  overflow: hidden;
}
.sf-pf-dev-topbar {
  display:flex; align-items:center; gap:8px;
  padding:6px 10px;
  background:rgba(255,255,255,.03);
  border-bottom:1px solid rgba(255,255,255,.06);
}
.sf-pf-dev-topbar-title {
  flex:1; height:9px; border-radius:3px;
  background:rgba(255,255,255,.08); max-width:38%;
}
.sf-pf-dev-topbar-btn {
  width:32px; height:9px; border-radius:3px;
  background:var(--cat-glow,#ff5e2e); opacity:.25;
}
.sf-pf-dev-dash-body { display:flex; }
.sf-pf-dev-sidebar {
  width:26px; background:rgba(255,255,255,.02);
  border-right:1px solid rgba(255,255,255,.05);
  padding:8px 4px; display:flex; flex-direction:column; gap:5px;
}
.sf-pf-dev-nav {
  height:7px; border-radius:2px;
  background:rgba(255,255,255,.07);
}
.sf-pf-dev-nav--active {
  background:var(--cat-glow,#ff5e2e); opacity:.3;
}
.sf-pf-dev-main-content {
  flex:1; padding:8px; display:flex; flex-direction:column; gap:6px;
}
.sf-pf-dev-kpi-row {
  display:grid; grid-template-columns:repeat(3,1fr); gap:5px;
}
.sf-pf-dev-kpi {
  height:20px; border-radius:4px;
  background:rgba(255,255,255,.05);
  border:1px solid rgba(255,255,255,.07);
}
.sf-pf-dev-kpi--accent {
  background:var(--cat-glow,#ff5e2e); opacity:.12; border:none;
}
.sf-pf-dev-chart-area {
  height:28px; border-radius:4px;
  background:rgba(255,255,255,.03); position:relative; overflow:hidden;
}
.sf-pf-dev-chart-bar {
  position:absolute; bottom:0; border-radius:2px 2px 0 0;
  background:var(--cat-glow,#ff5e2e); opacity:.22;
}
/* Hero card tweaks (first item = double height) */
.sf-pf-item:first-child .sf-pf-dev-hero-block { height:52px; }
.sf-pf-item:first-child .sf-pf-dev-card { height:44px; }
.sf-pf-item:first-child .sf-pf-dev-chart-area { height:46px; }
.sf-pf-item:first-child .sf-pf-dev-kpi { height:30px; }
.sf-pf-item:first-child .sf-pf-dev-thumb { height:56px; }

/* Gradient overlay */
.sf-pf-item-overlay {
  position: absolute; inset: 0;
  background: linear-gradient(180deg,
    transparent 0%,
    rgba(6,2,29,.2) 40%,
    rgba(6,2,29,.9) 100%
  );
  transition: opacity .35s;
}
.sf-pf-item:hover .sf-pf-item-overlay {
  background: linear-gradient(180deg,
    rgba(6,2,29,.2) 0%,
    rgba(6,2,29,.75) 50%,
    rgba(6,2,29,.97) 100%
  );
}

/* Number badge */
.sf-pf-num {
  position: absolute; top: 18px; right: 18px; z-index: 3;
  font-size: .58rem; font-weight: 900; letter-spacing: .1em;
  color: rgba(255,255,255,.35);
  background: rgba(0,0,0,.4); backdrop-filter: blur(6px);
  padding: 4px 10px; border-radius: 6px;
}

/* ── Card body ── */
.sf-pf-item-body {
  position: absolute; bottom: 0; left: 0; right: 0; z-index: 2;
  padding: 22px 24px;
}
.sf-pf-item-cat {
  display: inline-flex; align-items: center;
  font-size: .62rem; font-weight: 800; letter-spacing: .1em; text-transform: uppercase;
  padding: 4px 11px; border-radius: 6px; margin-bottom: 10px;
  background: var(--cat-bg, rgba(255,94,46,.15));
  color: var(--cat-text, #ff8a60);
}
.sf-pf-item-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.05rem; font-weight: 900; color: #fff;
  margin: 0 0 6px; line-height: 1.25; letter-spacing: -.02em;
}
.sf-pf-item:first-child .sf-pf-item-title { font-size: 1.35rem; }
.sf-pf-item-desc {
  font-size: .82rem; color: rgba(255,255,255,.55); line-height: 1.55;
  margin: 0 0 14px;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
  max-height: 0; overflow: hidden;
  transition: max-height .35s ease, opacity .35s;
  opacity: 0;
}
.sf-pf-item:hover .sf-pf-item-desc { max-height: 60px; opacity: 1; }

/* Stats row */
.sf-pf-item-stats {
  display: flex; gap: 16px; align-items: center; flex-wrap: wrap;
  opacity: 0; transform: translateY(6px);
  transition: opacity .3s, transform .3s;
}
.sf-pf-item:hover .sf-pf-item-stats { opacity: 1; transform: translateY(0); }
.sf-pf-stat {
  font-size: .7rem; color: rgba(255,255,255,.5);
  display: flex; align-items: center; gap: 5px;
}
.sf-pf-stat span { color: rgba(255,255,255,.8); font-weight: 700; }
.sf-pf-view-pill {
  margin-left: auto;
  display: inline-flex; align-items: center; gap: 6px;
  background: var(--cat-glow, #ff5e2e); color: #fff;
  font-size: .72rem; font-weight: 800; letter-spacing: .06em; text-transform: uppercase;
  padding: 7px 16px; border-radius: 100px;
  opacity: 0; transform: translateY(6px);
  transition: opacity .3s .05s, transform .3s .05s;
}
.sf-pf-item:hover .sf-pf-view-pill { opacity: 1; transform: translateY(0); }

/* ── Footer ── */
.sf-pf-footer {
  display: flex; align-items: center; justify-content: space-between;
  margin-top: 40px; padding-top: 32px;
  border-top: 1px solid rgba(255,255,255,.06);
  flex-wrap: wrap; gap: 16px;
}
.sf-pf-counter {
  display: flex; gap: 40px;
}
.sf-pf-counter-item { text-align: center; }
.sf-pf-counter-num {
  display: block;
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.6rem; font-weight: 900; color: #fff;
  letter-spacing: -.03em; line-height: 1;
  margin-bottom: 4px;
}
.sf-pf-counter-label { font-size: .72rem; color: #64748b; text-transform: uppercase; letter-spacing: .08em; }
.sf-pf-cta {
  display: inline-flex; align-items: center; gap: 10px;
  background: linear-gradient(135deg, #ff5e2e, #ed4c1c);
  color: #fff; font-size: .88rem; font-weight: 800; letter-spacing: .04em;
  padding: 14px 32px; border-radius: 100px; text-decoration: none;
  box-shadow: 0 8px 24px rgba(255,94,46,.3);
  transition: transform .25s, box-shadow .25s;
}
.sf-pf-cta:hover { transform: translateY(-2px); box-shadow: 0 12px 32px rgba(255,94,46,.4); }
.sf-pf-cta svg { width: 16px; height: 16px; transition: transform .25s; }
.sf-pf-cta:hover svg { transform: translateX(4px); }

/* ── Responsive ── */
@media (max-width: 960px) {
  .sf-pf-masonry {
    grid-template-columns: repeat(2, 1fr);
    grid-auto-rows: 220px;
  }
  .sf-pf-masonry .sf-pf-item:first-child { grid-column: span 2; grid-row: span 1; }
}
@media (max-width: 600px) {
  .sf-pf-masonry { grid-template-columns: 1fr; grid-auto-rows: 220px; }
  .sf-pf-masonry .sf-pf-item:first-child { grid-column: 1; grid-row: span 1; }
  .sf-pf-counter { gap: 24px; }
  .sf-pf-footer { flex-direction: column; align-items: flex-start; }
}
</style>

<div class="sf-pf-wrap">

  <!-- Header -->
  <div class="sf-pf-hd">
    <div class="sf-pf-hd-left">
      <div class="sf-pf-eyebrow"><?php echo esc_html( $tag ); ?></div>
      <h2><?php
        $words = explode(' ', esc_html( $title ) );
        $last = array_pop( $words );
        echo implode(' ', $words) . ' <em>' . $last . '</em>';
      ?></h2>
      <p><?php echo esc_html( $subtitle ); ?></p>
    </div>
  </div>

  <!-- Masonry grid -->
  <div class="sf-pf-masonry">
  <?php
  $items_to_show = [];

  if ( $pq->have_posts() ) {
    while ( $pq->have_posts() ) {
      $pq->the_post();
      $pid = get_the_ID();
      $cats = wp_get_post_terms( $pid, 'sf_portfolio_cat', ['fields'=>'all'] );
      $cat  = !empty($cats) && !is_wp_error($cats) ? $cats[0] : null;
      $cname = $cat ? $cat->name : '';
      $color = tf_pf_color( $cname, $cat_colors, $color_default );
      $items_to_show[] = [
        'type'  => 'cpt',
        'id'    => $pid,
        'title' => get_the_title(),
        'desc'  => wp_trim_words( get_the_excerpt() ?: wp_strip_all_tags( get_the_content() ), 14, '…' ),
        'cat'   => $cname,
        'color' => $color,
        'url'   => get_permalink(),
        'year'  => get_the_date('Y'),
        'role'  => get_post_meta( $pid, '_sf_role', true ) ?: 'Web Design',
        'has_thumb' => has_post_thumbnail(),
      ];
    }
    wp_reset_postdata();
  } else {
    foreach ( $demo_items as $d ) {
      $color = tf_pf_color( strtolower($d['cat']), $cat_colors, $color_default );
      $items_to_show[] = [
        'type'  => 'demo',
        'grad'  => $d['grad'],
        'title' => $d['title'],
        'desc'  => $d['desc'],
        'cat'   => $d['cat'],
        'color' => $color,
        'emoji' => $d['emoji'],
        'url'   => '#',
        'year'  => $d['year'],
        'role'  => $d['role'],
        'num'   => $d['num'],
      ];
    }
  }

  foreach ( $items_to_show as $i => $item ) :
    $num_str = sprintf( '%02d', $i + 1 );
    $c = $item['color'];
  ?>
  <a href="<?php echo esc_url( $item['url'] ); ?>" class="sf-pf-item"
     style="--cat-bg:<?php echo esc_attr($c['bg']); ?>;--cat-text:<?php echo esc_attr($c['text']); ?>;--cat-glow:<?php echo esc_attr($c['glow']); ?>"
     aria-label="<?php echo esc_attr( $item['title'] ); ?>"
     <?php if ( $item['url'] === '#' ) : ?>role="presentation"<?php endif; ?>>

    <!-- Background -->
    <div class="sf-pf-item-bg"
         style="background:<?php echo $item['type']==='demo' ? esc_attr($item['grad']) : 'linear-gradient(135deg,#0d1526,#06021d)'; ?>">
      <?php if ( $item['type'] === 'cpt' && $item['has_thumb'] ) :
        echo get_the_post_thumbnail( $item['id'], 'medium_large', ['loading' => $i===0?'eager':'lazy'] );
      elseif ( $item['type'] === 'demo' ) : ?>
        <!-- Decorative UI lines -->
        <div aria-hidden="true" style="position:absolute;inset:0;padding:20px;display:flex;flex-direction:column;gap:10px;overflow:hidden;">
          <div style="display:flex;gap:6px;align-items:center;opacity:.5">
            <?php for($j=0;$j<3;$j++): ?><div style="width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.2)"></div><?php endfor; ?>
            <div style="flex:1;height:1px;background:rgba(255,255,255,.08);margin-left:6px"></div>
          </div>
          <div style="height:22px;background:<?php echo esc_attr($c['glow']); ?>;opacity:.18;border-radius:5px;width:55%"></div>
          <div style="height:7px;background:rgba(255,255,255,.07);border-radius:4px;width:75%"></div>
          <div style="height:7px;background:rgba(255,255,255,.05);border-radius:4px;width:55%"></div>
          <div style="flex:1;display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px">
            <div style="background:rgba(255,255,255,.04);border-radius:8px;border:1px solid rgba(255,255,255,.07)"></div>
            <div style="background:<?php echo esc_attr($c['glow']); ?>;opacity:.12;border-radius:8px"></div>
          </div>
        </div>
        <?php
          $device_type = isset( $item['device'] ) ? $item['device'] : tf_pf_device_type( $item['cat'] );
          echo tf_pf_device_html( $device_type );
        ?>
      <?php endif; ?>
    </div>

    <div class="sf-pf-item-overlay"></div>
    <span class="sf-pf-num"><?php echo $num_str; ?></span>

    <div class="sf-pf-item-body">
      <?php if ( $item['cat'] ) : ?>
        <span class="sf-pf-item-cat"><?php echo esc_html( $item['cat'] ); ?></span>
      <?php endif; ?>
      <h3 class="sf-pf-item-title"><?php echo esc_html( $item['title'] ); ?></h3>
      <p class="sf-pf-item-desc"><?php echo esc_html( $item['desc'] ); ?></p>
      <div class="sf-pf-item-stats">
        <div class="sf-pf-stat">Year <span><?php echo esc_html( $item['year'] ); ?></span></div>
        <div class="sf-pf-stat">Role <span><?php echo esc_html( $item['role'] ); ?></span></div>
        <span class="sf-pf-view-pill">View →</span>
      </div>
    </div>

  </a>
  <?php endforeach; ?>
  </div>

  <!-- Footer stats + CTA -->
  <div class="sf-pf-footer">
    <div class="sf-pf-counter">
      <div class="sf-pf-counter-item">
        <span class="sf-pf-counter-num">120+</span>
        <span class="sf-pf-counter-label">Projects Done</span>
      </div>
      <div class="sf-pf-counter-item">
        <span class="sf-pf-counter-num">97%</span>
        <span class="sf-pf-counter-label">Happy Clients</span>
      </div>
      <div class="sf-pf-counter-item">
        <span class="sf-pf-counter-num">8</span>
        <span class="sf-pf-counter-label">Industries</span>
      </div>
    </div>
    <?php if ( $cta_label && $cta_url ) : ?>
    <a href="<?php echo esc_url( $cta_url ); ?>" class="sf-pf-cta">
      <?php echo esc_html( $cta_label ); ?>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
    </a>
    <?php endif; ?>
  </div>

</div>
</section>
