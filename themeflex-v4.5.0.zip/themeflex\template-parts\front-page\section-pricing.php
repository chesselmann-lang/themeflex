<?php
/**
 * Front Page Pricing Section — ThemeFlex v1.0
 *
 * 3-column pricing table with monthly/annual toggle, highlighted popular card,
 * feature list with checkmarks, and CTA buttons. Dark-first premium layout.
 *
 * @package ThemeFlex
 * @since   2.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_pricing_enabled', true ) ) return;

$tag      = get_theme_mod( 'sf_pricing_tag',   'Transparent Pricing' );
$title    = get_theme_mod( 'sf_pricing_title', 'One Price. Everything Included.' );
$subtitle = get_theme_mod( 'sf_pricing_subtitle', "No hidden fees, no scope creep. Pick your plan and let's build something great." );
$pt       = absint( get_theme_mod( 'sf_pricing_padding_top',    120 ) );
$pb       = absint( get_theme_mod( 'sf_pricing_padding_bottom', 120 ) );

$plans = [
    [
        'name'       => 'Starter',
        'tagline'    => 'Perfect for landing pages',
        'price_mo'   => '1,490',
        'price_yr'   => '990',
        'currency'   => '€',
        'popular'    => false,
        'badge'      => '',
        'color'      => '#3b82f6',
        'cta'        => 'Get Started',
        'cta_url'    => '/contact/',
        'features'   => [
            ['text' => '1 Landing Page',           'yes' => true ],
            ['text' => 'Mobile Responsive',         'yes' => true ],
            ['text' => 'Basic SEO Setup',           'yes' => true ],
            ['text' => 'Contact Form',              'yes' => true ],
            ['text' => '30-day Support',            'yes' => true ],
            ['text' => 'E-Commerce Integration',   'yes' => false],
            ['text' => 'Custom Animations',         'yes' => false],
            ['text' => 'Analytics Dashboard',       'yes' => false],
        ],
    ],
    [
        'name'       => 'Professional',
        'tagline'    => 'For growing businesses',
        'price_mo'   => '3,490',
        'price_yr'   => '2,690',
        'currency'   => '€',
        'popular'    => true,
        'badge'      => 'Most Popular',
        'color'      => '#ff5e2e',
        'cta'        => 'Start a Project',
        'cta_url'    => '/contact/',
        'features'   => [
            ['text' => 'Up to 8 Pages',             'yes' => true ],
            ['text' => 'Mobile Responsive',         'yes' => true ],
            ['text' => 'Full SEO Package',          'yes' => true ],
            ['text' => 'Contact + Multi-step Forms','yes' => true ],
            ['text' => '90-day Priority Support',   'yes' => true ],
            ['text' => 'E-Commerce Integration',   'yes' => true ],
            ['text' => 'Custom Animations',         'yes' => true ],
            ['text' => 'Analytics Dashboard',       'yes' => false],
        ],
    ],
    [
        'name'       => 'Enterprise',
        'tagline'    => 'Full-scale digital product',
        'price_mo'   => '7,490',
        'price_yr'   => '5,990',
        'currency'   => '€',
        'popular'    => false,
        'badge'      => '',
        'color'      => '#10b981',
        'cta'        => "Let's Talk",
        'cta_url'    => '/contact/',
        'features'   => [
            ['text' => 'Unlimited Pages',           'yes' => true ],
            ['text' => 'Mobile Responsive',         'yes' => true ],
            ['text' => 'Full SEO Package',          'yes' => true ],
            ['text' => 'Custom Forms + CRM Sync',   'yes' => true ],
            ['text' => '1-year Dedicated Support',  'yes' => true ],
            ['text' => 'E-Commerce + Membership',  'yes' => true ],
            ['text' => 'Custom Animations + Video', 'yes' => true ],
            ['text' => 'Analytics Dashboard',       'yes' => true ],
        ],
    ],
];
?>
<section
    class="tf-price-sec"
    id="sf-pricing"
    style="padding-top:<?php echo $pt; ?>px;padding-bottom:<?php echo $pb; ?>px;"
    aria-label="<?php esc_attr_e( 'Pricing', 'themeflex' ); ?>"
>
<style>
/* ══════════════════════════════════════════════════════════
   PRICING SECTION — 3 column with toggle
   ══════════════════════════════════════════════════════════ */
.tf-price-sec {
  background: linear-gradient(180deg, #0a0f1e 0%, #06021d 100%);
  position: relative; overflow: hidden;
}
.tf-price-sec::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,94,46,.2), transparent);
}

/* Radial glow */
.tf-price-sec::after {
  content: '';
  position: absolute; top: -200px; left: 50%; transform: translateX(-50%);
  width: 800px; height: 800px;
  background: radial-gradient(circle, rgba(255,94,46,.04) 0%, transparent 70%);
  pointer-events: none;
}

.tf-price-wrap { max-width: 1200px; margin: 0 auto; padding: 0 24px; position: relative; z-index: 1; }

/* ── Header ── */
.tf-price-hd { text-align: center; margin-bottom: 56px; }
.tf-price-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff7a54; font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px; margin-bottom: 20px;
}
.tf-price-eyebrow::before { content: '◈'; font-size: .6rem; }
.tf-price-hd h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 900; color: #fff; margin: 0 0 14px;
  letter-spacing: -.04em; line-height: 1.1;
}
.tf-price-hd p { color: #94a3b8; font-size: 1rem; max-width: 520px; margin: 0 auto 32px; line-height: 1.7; }

/* ── Toggle ── */
.tf-price-toggle {
  display: inline-flex; align-items: center; gap: 14px;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.08);
  padding: 6px 8px; border-radius: 100px;
}
.tf-toggle-label { font-size: .82rem; font-weight: 700; color: #64748b; padding: 0 8px; cursor: pointer; transition: color .2s; }
.tf-toggle-label.active { color: #f1f5f9; }
.tf-toggle-switch {
  width: 48px; height: 26px;
  background: rgba(255,94,46,.3);
  border-radius: 13px;
  position: relative; cursor: pointer;
  transition: background .3s;
}
.tf-toggle-switch.annual { background: #ff5e2e; }
.tf-toggle-switch::after {
  content: ''; position: absolute;
  left: 3px; top: 3px;
  width: 20px; height: 20px;
  background: #fff; border-radius: 50%;
  transition: transform .3s;
  box-shadow: 0 2px 6px rgba(0,0,0,.3);
}
.tf-toggle-switch.annual::after { transform: translateX(22px); }
.tf-toggle-badge {
  display: inline-block;
  background: rgba(16,185,129,.15);
  border: 1px solid rgba(16,185,129,.3);
  color: #34d399;
  font-size: .62rem; font-weight: 800;
  padding: 2px 8px; border-radius: 100px;
  letter-spacing: .06em;
}

/* ── Grid ── */
.tf-price-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  align-items: start;
}

/* ── Card ── */
.tf-price-card {
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 24px;
  padding: 36px 32px;
  position: relative;
  transition: transform .3s, box-shadow .3s, border-color .3s;
}
.tf-price-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 24px 48px rgba(0,0,0,.3);
}
.tf-price-card.popular {
  background: rgba(255,94,46,.06);
  border-color: rgba(255,94,46,.35);
  transform: scale(1.04);
}
.tf-price-card.popular:hover {
  transform: scale(1.04) translateY(-6px);
  box-shadow: 0 32px 64px rgba(255,94,46,.2);
}

/* Popular badge */
.tf-price-popular-badge {
  position: absolute;
  top: -14px; left: 50%; transform: translateX(-50%);
  background: linear-gradient(135deg, #ff5e2e, #ff8c5a);
  color: #fff;
  font-size: .65rem; font-weight: 900; letter-spacing: .1em;
  text-transform: uppercase;
  padding: 5px 20px; border-radius: 100px;
  white-space: nowrap;
  box-shadow: 0 4px 16px rgba(255,94,46,.4);
}

/* Card header */
.tf-price-card-head { margin-bottom: 28px; padding-bottom: 28px; border-bottom: 1px solid rgba(255,255,255,.06); }
.tf-price-plan-dot {
  width: 10px; height: 10px; border-radius: 50%;
  display: inline-block; margin-right: 8px;
  box-shadow: 0 0 8px currentColor;
}
.tf-price-plan-name {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.1rem; font-weight: 900; color: #f1f5f9;
  margin: 12px 0 4px; letter-spacing: -.02em;
}
.tf-price-plan-tag { font-size: .8rem; color: #64748b; }

/* Price display */
.tf-price-amount {
  margin: 20px 0 0;
  display: flex; align-items: baseline; gap: 4px;
}
.tf-price-currency { font-size: 1.3rem; font-weight: 800; color: #94a3b8; line-height: 1; }
.tf-price-number {
  font-family: 'Inter Tight', sans-serif;
  font-size: 2.8rem; font-weight: 900; color: #fff;
  letter-spacing: -.04em; line-height: 1;
  transition: opacity .3s, transform .3s;
}
.tf-price-period { font-size: .8rem; color: #475569; align-self: flex-end; padding-bottom: 6px; }

/* Features list */
.tf-price-features { list-style: none; padding: 0; margin: 0 0 32px; }
.tf-price-features li {
  display: flex; align-items: center; gap: 12px;
  font-size: .88rem; color: #94a3b8;
  padding: 9px 0;
  border-bottom: 1px solid rgba(255,255,255,.04);
}
.tf-price-features li:last-child { border-bottom: none; }
.tf-price-features li.no { opacity: .4; text-decoration: line-through; }
.tf-price-check {
  width: 18px; height: 18px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; font-size: .65rem; font-weight: 900;
}
.tf-price-check.yes { background: rgba(16,185,129,.15); color: #34d399; }
.tf-price-check.no  { background: rgba(100,116,139,.1); color: #475569; }

/* CTA Button */
.tf-price-cta {
  display: block; text-align: center;
  padding: 14px 24px; border-radius: 100px;
  font-size: .9rem; font-weight: 800; letter-spacing: .04em;
  text-decoration: none;
  transition: transform .2s, box-shadow .2s;
}
.tf-price-cta.outline {
  border: 2px solid rgba(255,255,255,.12);
  color: #94a3b8;
  transition: border-color .2s, color .2s;
}
.tf-price-cta.outline:hover { border-color: var(--plan-color); color: #fff; }
.tf-price-cta.solid {
  background: linear-gradient(135deg, #ff5e2e, #ed4c1c);
  color: #fff;
  box-shadow: 0 8px 24px rgba(255,94,46,.35);
}
.tf-price-cta.solid:hover { transform: translateY(-2px); box-shadow: 0 14px 36px rgba(255,94,46,.45); }

/* ── Annual savings note ── */
.tf-price-savings {
  font-size: .72rem; color: #34d399; font-weight: 700;
  margin-top: 8px; display: none; letter-spacing: .02em;
}
body.tf-annual .tf-price-savings { display: block; }

/* ── Bottom strip ── */
.tf-price-guarantee {
  margin-top: 48px;
  display: flex; align-items: center; justify-content: center; gap: 32px;
  flex-wrap: wrap;
  padding: 24px 32px;
  background: rgba(255,255,255,.02);
  border: 1px solid rgba(255,255,255,.05);
  border-radius: 16px;
  font-size: .82rem; color: #64748b; font-weight: 600;
}
.tf-price-guarantee-item { display: flex; align-items: center; gap: 8px; }
.tf-price-guarantee-icon { display:inline-flex;align-items:center;justify-content:center;color:inherit; }
.tf-price-guarantee-icon svg { width:15px;height:15px;display:block; }

/* ── Responsive ── */
@media(max-width:900px) {
  .tf-price-grid { grid-template-columns: 1fr; max-width: 480px; margin: 0 auto; }
  .tf-price-card.popular { transform: none; }
  .tf-price-card.popular:hover { transform: translateY(-6px); }
}
</style>

<div class="tf-price-wrap">

  <!-- Header -->
  <div class="tf-price-hd">
    <div class="tf-price-eyebrow"><?php echo esc_html( $tag ); ?></div>
    <h2><?php echo esc_html( $title ); ?></h2>
    <p><?php echo esc_html( $subtitle ); ?></p>

    <!-- Toggle -->
    <div class="tf-price-toggle" role="group" aria-label="<?php esc_attr_e( 'Billing period', 'themeflex' ); ?>">
      <span class="tf-toggle-label active" id="tf-toggle-mo"><?php esc_html_e( 'Monthly', 'themeflex' ); ?></span>
      <button class="tf-toggle-switch" id="tf-price-toggle" aria-pressed="false" aria-label="<?php esc_attr_e( 'Toggle annual billing', 'themeflex' ); ?>"></button>
      <span class="tf-toggle-label" id="tf-toggle-yr"><?php esc_html_e( 'Annual', 'themeflex' ); ?></span>
      <span class="tf-toggle-badge">–20%</span>
    </div>
  </div>

  <!-- Cards -->
  <div class="tf-price-grid">
    <?php foreach ( $plans as $plan ) :
      $is_popular = $plan['popular'];
      $card_class = $is_popular ? ' popular' : '';
      $cta_class  = $is_popular ? 'solid' : 'outline';
    ?>
    <div class="tf-price-card<?php echo $card_class; ?>" style="--plan-color:<?php echo esc_attr( $plan['color'] ); ?>">
      <?php if ( $plan['badge'] ) : ?>
        <div class="tf-price-popular-badge"><?php echo esc_html( $plan['badge'] ); ?></div>
      <?php endif; ?>

      <div class="tf-price-card-head">
        <span class="tf-price-plan-dot" style="background:<?php echo esc_attr( $plan['color'] ); ?>;color:<?php echo esc_attr( $plan['color'] ); ?>"></span>
        <div class="tf-price-plan-name"><?php echo esc_html( $plan['name'] ); ?></div>
        <div class="tf-price-plan-tag"><?php echo esc_html( $plan['tagline'] ); ?></div>

        <div class="tf-price-amount">
          <span class="tf-price-currency"><?php echo esc_html( $plan['currency'] ); ?></span>
          <span class="tf-price-number" data-mo="<?php echo esc_attr( $plan['price_mo'] ); ?>" data-yr="<?php echo esc_attr( $plan['price_yr'] ); ?>"><?php echo esc_html( $plan['price_mo'] ); ?></span>
          <span class="tf-price-period"><?php esc_html_e( '/ project', 'themeflex' ); ?></span>
        </div>
        <div class="tf-price-savings">
          <?php esc_html_e( 'Save ~20% with annual billing', 'themeflex' ); ?>
        </div>
      </div>

      <ul class="tf-price-features" role="list">
        <?php foreach ( $plan['features'] as $feat ) :
          $yes = $feat['yes'];
          $li_class = $yes ? '' : ' class="no"';
          $check_class = $yes ? 'yes' : 'no';
          $check_char  = $yes ? '✓' : '✕';
        ?>
        <li<?php echo $li_class; ?>>
          <span class="tf-price-check <?php echo $check_class; ?>" aria-hidden="true"><?php echo $check_char; ?></span>
          <?php echo esc_html( $feat['text'] ); ?>
        </li>
        <?php endforeach; ?>
      </ul>

      <a href="<?php echo esc_url( home_url( $plan['cta_url'] ) ); ?>" class="tf-price-cta <?php echo $cta_class; ?>">
        <?php echo esc_html( $plan['cta'] ); ?>
        <?php if ( $is_popular ) echo ' →'; ?>
      </a>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Guarantee strip -->
  <div class="tf-price-guarantee">
    <div class="tf-price-guarantee-item">
      <span class="tf-price-guarantee-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></span>
      <?php esc_html_e( '14-day money-back guarantee', 'themeflex' ); ?>
    </div>
    <div class="tf-price-guarantee-item">
      <span class="tf-price-guarantee-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg></span>
      <?php esc_html_e( 'Free revisions included', 'themeflex' ); ?>
    </div>
    <div class="tf-price-guarantee-item">
      <span class="tf-price-guarantee-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.69 3.18 2 2 0 0 1 3.68 1h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L7.91 8.5a16 16 0 0 0 6 6l1.06-1.06a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></span>
      <?php esc_html_e( 'Dedicated project manager', 'themeflex' ); ?>
    </div>
    <div class="tf-price-guarantee-item">
      <span class="tf-price-guarantee-icon" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg></span>
      <?php esc_html_e( 'Fast turnaround — 3 to 6 weeks', 'themeflex' ); ?>
    </div>
  </div>

</div><!-- /.tf-price-wrap -->

<script>
(function(){
  var toggle   = document.getElementById('tf-price-toggle');
  var labelMo  = document.getElementById('tf-toggle-mo');
  var labelYr  = document.getElementById('tf-toggle-yr');
  var numbers  = document.querySelectorAll('#sf-pricing .tf-price-number');
  if (!toggle) return;

  var annual = false;

  function update() {
    annual = !annual;
    toggle.classList.toggle('annual', annual);
    toggle.setAttribute('aria-pressed', annual ? 'true' : 'false');
    labelMo.classList.toggle('active', !annual);
    labelYr.classList.toggle('active', annual);
    document.body.classList.toggle('tf-annual', annual);

    numbers.forEach(function(n) {
      n.style.opacity = '0';
      n.style.transform = 'translateY(8px)';
      setTimeout(function() {
        n.textContent = annual ? n.dataset.yr : n.dataset.mo;
        n.style.opacity = '1';
        n.style.transform = 'translateY(0)';
      }, 150);
    });
  }

  toggle.addEventListener('click', update);

  // CSS transition for numbers
  numbers.forEach(function(n) {
    n.style.transition = 'opacity .15s, transform .15s';
  });
})();
</script>

</section>
