<?php
/**
 * Front Page Process Section — ThemeFlex v1.0
 *
 * "How it works" — numbered steps with connecting line, icons, stagger animations.
 * Dark-first, self-contained. Premium ThemeForest-class quality.
 *
 * @package ThemeFlex
 * @since   2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_process_enabled', true ) ) return;

$tag      = get_theme_mod( 'sf_process_tag',      'How It Works' );
$title    = get_theme_mod( 'sf_process_title',    'From Idea to Launch in Four Steps' );
$subtitle = get_theme_mod( 'sf_process_subtitle', 'Our battle-tested workflow delivers polished results on time, every time.' );
$pt       = absint( get_theme_mod( 'sf_process_pt', 120 ) );
$pb       = absint( get_theme_mod( 'sf_process_pb', 120 ) );

$steps = [
	[
		'num'   => '01',
		'title' => 'Discovery & Strategy',
		'desc'  => 'We deep-dive into your goals, audience and competitive landscape. You get a clear project brief and technical roadmap before a single line of code is written.',
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
		'color' => '#3b82f6',
	],
	[
		'num'   => '02',
		'title' => 'Design & Prototype',
		'desc'  => 'High-fidelity Figma mockups in your brand palette. Interactive prototypes let you experience the product before development starts — zero surprises.',
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
		'color' => '#8b5cf6',
	],
	[
		'num'   => '03',
		'title' => 'Build & Integrate',
		'desc'  => 'Clean, semantic code meets pixel-perfect design. We handle performance tuning, SEO scaffolding, and all third-party integrations in one sprint cycle.',
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
		'color' => '#ff5e2e',
	],
	[
		'num'   => '04',
		'title' => 'Launch & Support',
		'desc'  => 'Comprehensive QA, staging review, and a smooth go-live. Post-launch we monitor uptime, push updates, and stay on call so you can focus on your business.',
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
		'color' => '#10b981',
	],
];
?>
<section
	class="tf-proc-sec"
	id="sf-process"
	style="padding-top:<?php echo $pt; ?>px;padding-bottom:<?php echo $pb; ?>px;"
	aria-label="<?php esc_attr_e( 'Process', 'themeflex' ); ?>"
>
<style>
/* ══════════════════════════════════════════════════════════
   PROCESS SECTION v1 — Four Steps with connector line
   ══════════════════════════════════════════════════════════ */
.tf-proc-sec {
  background: linear-gradient(180deg, #0d1526 0%, #0a0f1e 100%);
  position: relative; overflow: hidden;
}
.tf-proc-sec::before {
  content: '';
  position: absolute; top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(139,92,246,.25), rgba(59,130,246,.25), transparent);
}
.tf-proc-wrap { max-width: 1240px; margin: 0 auto; padding: 0 24px; }

/* ── Header ── */
.tf-proc-hd { text-align: center; margin-bottom: 72px; }
.tf-proc-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(139,92,246,.1); border: 1px solid rgba(139,92,246,.25);
  color: #a78bfa; font-size: .68rem; font-weight: 800; letter-spacing: .14em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px; margin-bottom: 20px;
}
.tf-proc-eyebrow::before { content: '◈'; font-size: .6rem; }
.tf-proc-hd h2 {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 900; color: #fff; margin: 0 0 14px;
  letter-spacing: -.04em; line-height: 1.1;
}
.tf-proc-hd p { color: #94a3b8; font-size: 1rem; max-width: 520px; margin: 0 auto; line-height: 1.7; }

/* ── Steps grid ── */
.tf-proc-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 0;
  position: relative;
}

/* Connecting line between steps */
.tf-proc-grid::before {
  content: '';
  position: absolute;
  top: 36px; /* center of icon */
  left: calc(12.5%); /* start at center of first icon */
  right: calc(12.5%); /* end at center of last icon */
  height: 1px;
  background: linear-gradient(90deg,
    #3b82f6,
    #8b5cf6,
    #ff5e2e,
    #10b981
  );
  opacity: .35;
  z-index: 0;
}

/* ── Step card ── */
.tf-proc-step {
  padding: 0 24px 0;
  position: relative; z-index: 1;
  text-align: center;
  opacity: 0; transform: translateY(24px);
  transition: opacity .6s cubic-bezier(.16,1,.3,1), transform .6s cubic-bezier(.16,1,.3,1);
}
.tf-proc-step.tf-proc-visible {
  opacity: 1; transform: none;
}
.tf-proc-step:nth-child(1) { transition-delay: 0s; }
.tf-proc-step:nth-child(2) { transition-delay: .12s; }
.tf-proc-step:nth-child(3) { transition-delay: .24s; }
.tf-proc-step:nth-child(4) { transition-delay: .36s; }

/* ── Icon circle ── */
.tf-proc-icon {
  width: 72px; height: 72px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 24px;
  position: relative;
  background: #0a0f1e;
  border: 1px solid rgba(255,255,255,.1);
  transition: transform .35s, box-shadow .35s;
}
.tf-proc-icon svg {
  width: 28px; height: 28px;
}
.tf-proc-icon::before {
  content: '';
  position: absolute; inset: -1px;
  border-radius: 50%;
  background: var(--step-color, #3b82f6);
  opacity: .12;
  transition: opacity .35s;
}
.tf-proc-step:hover .tf-proc-icon {
  transform: translateY(-4px) scale(1.08);
  box-shadow: 0 0 0 4px var(--step-color, #3b82f6), 0 0 0 8px rgba(255,255,255,.04);
}
.tf-proc-step:hover .tf-proc-icon::before { opacity: .22; }

/* Number badge */
.tf-proc-step-num {
  position: absolute;
  top: -6px; right: -6px;
  width: 22px; height: 22px;
  border-radius: 50%;
  background: var(--step-color, #3b82f6);
  color: #fff;
  font-size: .58rem; font-weight: 900; letter-spacing: .05em;
  display: flex; align-items: center; justify-content: center;
}

/* ── Text ── */
.tf-proc-step-title {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.05rem; font-weight: 900; color: #f1f5f9;
  margin: 0 0 10px; letter-spacing: -.02em;
}
.tf-proc-step-desc {
  font-size: .86rem; color: #64748b; line-height: 1.7; margin: 0;
}

/* ── Bottom CTA band ── */
.tf-proc-cta-band {
  margin-top: 64px;
  background: rgba(255,255,255,.03);
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 20px;
  padding: 36px 48px;
  display: flex; align-items: center; justify-content: space-between; gap: 24px;
  flex-wrap: wrap;
}
.tf-proc-cta-band-text h3 {
  font-family: 'Inter Tight', sans-serif;
  font-size: 1.35rem; font-weight: 900; color: #fff;
  margin: 0 0 6px; letter-spacing: -.03em;
}
.tf-proc-cta-band-text p { font-size: .88rem; color: #64748b; margin: 0; }
.tf-proc-cta-btns { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; flex-shrink: 0; }
.tf-proc-btn-primary {
  display: inline-flex; align-items: center; gap: 8px;
  background: linear-gradient(135deg, #ff5e2e, #ed4c1c);
  color: #fff; font-size: .88rem; font-weight: 800; letter-spacing: .04em;
  padding: 13px 28px; border-radius: 100px; text-decoration: none;
  box-shadow: 0 6px 20px rgba(255,94,46,.3);
  transition: transform .25s, box-shadow .25s;
}
.tf-proc-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(255,94,46,.4); }
.tf-proc-btn-secondary {
  display: inline-flex; align-items: center; gap: 8px;
  border: 2px solid rgba(255,255,255,.14); color: #94a3b8;
  font-size: .88rem; font-weight: 700; letter-spacing: .04em;
  padding: 11px 26px; border-radius: 100px; text-decoration: none;
  transition: border-color .25s, color .25s;
}
.tf-proc-btn-secondary:hover { border-color: rgba(255,255,255,.3); color: #fff; }

/* ── Responsive ── */
@media (max-width: 860px) {
  .tf-proc-grid { grid-template-columns: repeat(2, 1fr); gap: 40px 0; }
  .tf-proc-grid::before { display: none; }
  .tf-proc-cta-band { flex-direction: column; text-align: center; align-items: center; }
}
@media (max-width: 540px) {
  .tf-proc-grid { grid-template-columns: 1fr; gap: 36px; }
  .tf-proc-cta-band { padding: 28px 24px; }
}
</style>

<div class="tf-proc-wrap">

  <!-- Header -->
  <div class="tf-proc-hd">
    <div class="tf-proc-eyebrow"><?php echo esc_html( $tag ); ?></div>
    <h2><?php echo esc_html( $title ); ?></h2>
    <p><?php echo esc_html( $subtitle ); ?></p>
  </div>

  <!-- Steps -->
  <div class="tf-proc-grid">
    <?php foreach ( $steps as $step ) : ?>
    <div class="tf-proc-step" style="--step-color:<?php echo esc_attr($step['color']); ?>">
      <div class="tf-proc-icon" aria-hidden="true">
        <?php echo $step['icon']; ?>
        <span class="tf-proc-step-num"><?php echo esc_html($step['num']); ?></span>
      </div>
      <h3 class="tf-proc-step-title"><?php echo esc_html($step['title']); ?></h3>
      <p class="tf-proc-step-desc"><?php echo esc_html($step['desc']); ?></p>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- CTA Band -->
  <div class="tf-proc-cta-band">
    <div class="tf-proc-cta-band-text">
      <h3><?php esc_html_e( "Ready to start your next project?", 'themeflex' ); ?></h3>
      <p><?php esc_html_e( "Book a free 30-minute discovery call and get a project estimate within 48 hours.", 'themeflex' ); ?></p>
    </div>
    <div class="tf-proc-cta-btns">
      <a href="<?php echo esc_url( home_url('/contact/') ); ?>" class="tf-proc-btn-primary">
        <?php esc_html_e( 'Start a Project', 'themeflex' ); ?> →
      </a>
      <a href="<?php echo esc_url( home_url('/portfolio/') ); ?>" class="tf-proc-btn-secondary">
        <?php esc_html_e( 'View Our Work', 'themeflex' ); ?>
      </a>
    </div>
  </div>

</div>

<script>
(function(){
  var steps = document.querySelectorAll('.tf-proc-step');
  if (!steps.length || !('IntersectionObserver' in window)) {
    steps.forEach(function(s){ s.classList.add('tf-proc-visible'); });
    return;
  }
  var obs = new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ e.target.classList.add('tf-proc-visible'); obs.unobserve(e.target); }
    });
  },{ threshold: 0.15 });
  steps.forEach(function(s){ obs.observe(s); });
})();
</script>

</section>
