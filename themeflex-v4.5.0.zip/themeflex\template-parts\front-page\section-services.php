<?php
/**
 * Front Page Services v3.0 — Salient-class split grid
 *
 * Large number index, hover gradient reveal, animated icon,
 * two-column alternating layout
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_services_enabled', true ) ) return;

$title    = get_theme_mod( 'sf_services_title',    'Full-Service Digital Studio' );
$subtitle = get_theme_mod( 'sf_services_subtitle', 'Everything from strategy and design to WordPress development, WooCommerce, and ongoing performance optimisation.' );
$tag      = get_theme_mod( 'sf_services_tag',      'Our Services' );

/* SVG icon strings — stroke style, currentColor, 24×24 viewBox */
$_si = array(
  'design'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z"/><path d="M22 12a10 10 0 0 1-10 10 4 4 0 0 1 0-8 4 4 0 0 0 0-8 10 10 0 0 1 10 6z"/></svg>',
  'code'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
  'cart'     => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
  'zap'      => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
  'search'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><polyline points="8 11 10 13 15 8" stroke-width="1.5"/></svg>',
  'shield'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10" stroke-width="1.5"/></svg>',
);

$services = array(
  array( 'num' => '01', 'icon' => $_si['design'], 'color' => '#a855f7', 'title' => 'UI/UX Design',
    'desc' => 'Research-led design that converts. Figma prototypes, design systems, and user-tested experiences that your audience actually understands.',
    'tags' => array('Figma','Design Systems','Prototyping','User Research') ),
  array( 'num' => '02', 'icon' => $_si['code'],   'color' => '#3b82f6', 'title' => 'WordPress Development',
    'desc' => 'Bespoke WordPress builds using ThemeFlex as the foundation. Pixel-perfect, performance-obsessed, and maintainable.',
    'tags' => array('WordPress','Elementor','PHP 8','REST API') ),
  array( 'num' => '03', 'icon' => $_si['cart'],   'color' => '#10b981', 'title' => 'E-Commerce',
    'desc' => 'WooCommerce stores built to sell. Custom product pages, optimised checkout flows, and conversion-focused design.',
    'tags' => array('WooCommerce','Stripe','Checkout CRO','Subscriptions') ),
  array( 'num' => '04', 'icon' => $_si['zap'],    'color' => '#f59e0b', 'title' => 'Performance Optimisation',
    'desc' => '97 PageSpeed isn\'t a claim — it\'s our baseline. Core Web Vitals, CDN, caching, and image pipelines that actually move the needle.',
    'tags' => array('Core Web Vitals','Cloudflare','WP Rocket','Image CDN') ),
  array( 'num' => '05', 'icon' => $_si['search'], 'color' => '#00d4ff', 'title' => 'SEO & Analytics',
    'desc' => 'Technical SEO audits, schema markup, GA4 setup, and keyword strategies built around real search intent.',
    'tags' => array('Technical SEO','GA4','Schema','Search Console') ),
  array( 'num' => '06', 'icon' => $_si['shield'], 'color' => '#ef4444', 'title' => 'Security & Maintenance',
    'desc' => 'Monthly WordPress maintenance retainers — updates, backups, uptime monitoring, and 24h incident response.',
    'tags' => array('Wordfence','Backups','Uptime','2FA') ),
);
?>

<section class="tf-srv-sec" id="sf-services" aria-label="<?php esc_attr_e('Services','themeflex'); ?>">
<style>
/* ═══════════════════════════════════════════════════════════════
   SERVICES v3
   ═══════════════════════════════════════════════════════════════ */
.tf-srv-sec {
  padding: 120px 0;
  background: #0a0f1e;
  position: relative;
  overflow: hidden;
}
.tf-srv-sec::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(0,212,255,.2), rgba(168,85,247,.2), transparent);
}
.tf-srv-sec-wrap { max-width: 1260px; margin: 0 auto; padding: 0 32px; }

/* Header */
.tf-srv-sec-head { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 64px; gap: 32px; flex-wrap: wrap; }
.tf-srv-sec-head-left {}
.tf-srv-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 20px;
}
.tf-srv-sec-head h2 {
  font-size: clamp(2rem, 3.5vw, 3rem);
  font-weight: 900; color: #f1f5f9; margin: 0; letter-spacing: -.02em; line-height: 1.1;
}
.tf-srv-sec-head p { font-size: 1rem; color: #64748b; max-width: 380px; line-height: 1.7; margin: 0; }
.tf-srv-sec-link {
  display: inline-flex; align-items: center; gap: 8px;
  color: #ff5e2e; font-size: .9rem; font-weight: 700; text-decoration: none;
  white-space: nowrap; flex-shrink: 0;
  transition: gap .2s;
}
.tf-srv-sec-link:hover { gap: 14px; }

/* Grid */
.tf-srv-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 2px;
  background: rgba(255,255,255,.04);
  border-radius: 20px;
  overflow: hidden;
  border: 1px solid rgba(255,255,255,.06);
}

.tf-srv-item {
  background: #0a0f1e;
  padding: 40px 36px;
  position: relative;
  overflow: hidden;
  transition: background .35s;
  cursor: default;
}
.tf-srv-item::before {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 0% 100%, var(--sc, rgba(255,94,46,.1)) 0%, transparent 60%);
  opacity: 0;
  transition: opacity .4s;
}
.tf-srv-item:hover::before { opacity: 1; }
.tf-srv-item:hover { background: #0d1226; }

.tf-srv-num {
  font-size: 3.5rem;
  font-weight: 900;
  line-height: 1;
  color: rgba(255,255,255,.05);
  position: absolute;
  top: 24px; right: 28px;
  font-feature-settings: 'tnum';
  letter-spacing: -.04em;
  transition: color .35s;
}
.tf-srv-item:hover .tf-srv-num { color: rgba(255,255,255,.08); }

.tf-srv-icon-wrap {
  width: 56px; height: 56px;
  border-radius: 16px;
  background: var(--sc-bg, rgba(255,94,46,.1));
  border: 1px solid var(--sc-bd, rgba(255,94,46,.2));
  display: flex; align-items: center; justify-content: center;
  color: var(--sc-color, #ff8a60);
  margin-bottom: 20px;
  transition: transform .3s;
  flex-shrink: 0;
}
.tf-srv-icon-wrap svg { width: 24px; height: 24px; display: block; }
.tf-srv-item:hover .tf-srv-icon-wrap { transform: scale(1.1) rotate(-3deg); }

.tf-srv-title {
  font-size: 1.05rem;
  font-weight: 800;
  color: #f1f5f9;
  margin: 0 0 10px;
  line-height: 1.3;
}
.tf-srv-desc {
  font-size: .85rem;
  color: #64748b;
  line-height: 1.7;
  margin: 0 0 18px;
}
.tf-srv-tags { display: flex; flex-wrap: wrap; gap: 6px; }
.tf-srv-tag {
  padding: 3px 10px; border-radius: 20px;
  font-size: .65rem; font-weight: 700;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.07);
  color: #475569;
  transition: border-color .2s, color .2s;
}
.tf-srv-item:hover .tf-srv-tag { border-color: var(--sc-bd, rgba(255,94,46,.2)); color: #94a3b8; }

/* Bottom CTA strip */
.tf-srv-cta-strip {
  margin-top: 40px;
  display: flex; justify-content: center; align-items: center; gap: 32px;
  flex-wrap: wrap;
}
.tf-srv-cta-btn {
  display: inline-flex; align-items: center; gap: 10px;
  background: #ff5e2e; color: #fff; font-size: .9rem; font-weight: 800;
  padding: 14px 32px; border-radius: 100px; text-decoration: none;
  transition: background .2s, transform .2s;
  box-shadow: 0 8px 24px rgba(255,94,46,.3);
}
.tf-srv-cta-btn:hover { background: #e04e22; transform: translateY(-2px); }
.tf-srv-cta-txt { font-size: .85rem; color: #475569; }

/* Responsive */
@media(max-width:1024px) { .tf-srv-grid { grid-template-columns: repeat(2,1fr); } }
@media(max-width:640px)  { .tf-srv-grid { grid-template-columns: 1fr; } .tf-srv-sec-head { flex-direction: column; align-items: flex-start; } }
</style>

<div class="tf-srv-sec-wrap">
  <div class="tf-srv-sec-head">
    <div class="tf-srv-sec-head-left">
      <div class="tf-srv-eyebrow">◆ <?php echo esc_html($tag); ?></div>
      <h2><?php echo esc_html($title); ?></h2>
    </div>
    <p><?php echo esc_html($subtitle); ?></p>
    <a href="<?php echo esc_url(home_url('/services')); ?>" class="tf-srv-sec-link">
      <?php esc_html_e('All Services','themeflex'); ?> →
    </a>
  </div>

  <div class="tf-srv-grid">
    <?php foreach($services as $s) :
      $r = hexdec(substr($s['color'],1,2));
      $g = hexdec(substr($s['color'],3,2));
      $b = hexdec(substr($s['color'],5,2));
    ?>
    <div class="tf-srv-item"
      style="--sc:rgba(<?php echo "$r,$g,$b"; ?>,.12);--sc-bg:rgba(<?php echo "$r,$g,$b"; ?>,.1);--sc-bd:rgba(<?php echo "$r,$g,$b"; ?>,.2);--sc-color:rgba(<?php echo "$r,$g,$b"; ?>,1);">
      <div class="tf-srv-num" aria-hidden="true"><?php echo esc_html($s['num']); ?></div>
      <div class="tf-srv-icon-wrap" aria-hidden="true"><?php echo $s['icon']; ?></div>
      <div class="tf-srv-title"><?php echo esc_html($s['title']); ?></div>
      <div class="tf-srv-desc"><?php echo esc_html($s['desc']); ?></div>
      <div class="tf-srv-tags">
        <?php foreach($s['tags'] as $t) : ?><span class="tf-srv-tag"><?php echo esc_html($t); ?></span><?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="tf-srv-cta-strip">
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="tf-srv-cta-btn">
      <?php esc_html_e('Start a Project','themeflex'); ?> →
    </a>
    <span class="tf-srv-cta-txt"><?php esc_html_e('Free consultation · 24h response · No commitment','themeflex'); ?></span>
  </div>
</div>
</section>
