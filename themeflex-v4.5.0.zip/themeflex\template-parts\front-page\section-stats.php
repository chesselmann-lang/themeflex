<?php
/**
 * Front Page Stats Section — ThemeFlex v1.0
 *
 * Full-width animated counter bar — projects, clients, years, rating.
 * Dark glass-morphism with glow accents. Fires counters on scroll.
 *
 * @package ThemeFlex
 * @since   2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_stats_enabled', true ) ) return;

/* SVG icons for stats — 20×20, stroke, currentColor */
$_stat_icons = [
  'rocket' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4.5 16.5c-1.5 1.5-1.5 3.5 0 5a3.5 3.5 0 0 0 5-5L12 14"/><path d="M12 14c2.5-2.5 4-6 4-10a10 10 0 0 0-10 4L12 14"/><path d="M12 14l2 2"/></svg>',
  'star'   => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  'award'  => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"/></svg>',
  'gem'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3h12l4 6-10 13L2 9z"/><path d="M11 3L8 9l4 13 4-13-3-6"/><path d="M2 9h20"/></svg>',
  'zap'    => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
];
$stats = [
	['value' => '120', 'suffix' => '+', 'label' => 'Projects Delivered', 'icon' => $_stat_icons['rocket'], 'color' => '#ff5e2e'],
	['value' => '98',  'suffix' => '+', 'label' => 'Happy Clients',      'icon' => $_stat_icons['star'],   'color' => '#f59e0b'],
	['value' => '8',   'suffix' => '',  'label' => 'Years Experience',   'icon' => $_stat_icons['award'],  'color' => '#8b5cf6'],
	['value' => '4.9', 'suffix' => '',  'label' => 'Average Rating',     'icon' => $_stat_icons['gem'],    'color' => '#10b981'],
	['value' => '97',  'suffix' => '',  'label' => 'PageSpeed Score',    'icon' => $_stat_icons['zap'],    'color' => '#3b82f6'],
];
?>
<section
	class="tf-stats-sec"
	id="sf-stats"
	aria-label="<?php esc_attr_e( 'Statistics', 'themeflex' ); ?>"
>
<style>
/* ══════════════════════════════════════════════════════════
   STATS SECTION — Animated counter bar
   ══════════════════════════════════════════════════════════ */
.tf-stats-sec {
  background: #06021d;
  padding: 0;
  position: relative; overflow: hidden;
}
.tf-stats-inner {
  background: linear-gradient(135deg,
    rgba(255,94,46,.07) 0%,
    rgba(139,92,246,.06) 35%,
    rgba(59,130,246,.06) 65%,
    rgba(16,185,129,.05) 100%
  );
  border-top: 1px solid rgba(255,255,255,.06);
  border-bottom: 1px solid rgba(255,255,255,.06);
  padding: 52px 24px;
}
.tf-stats-inner::before {
  content: '';
  position: absolute; inset: 0;
  background: url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff' fill-opacity='0.015'%3E%3Ccircle cx='20' cy='20' r='1'/%3E%3C/g%3E%3C/svg%3E");
  pointer-events: none;
}
.tf-stats-grid {
  max-width: 1200px; margin: 0 auto;
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 0;
  position: relative; z-index: 1;
}
.tf-stats-item {
  text-align: center;
  padding: 0 24px;
  position: relative;
}
.tf-stats-item + .tf-stats-item::before {
  content: '';
  position: absolute; left: 0; top: 10%;
  height: 80%; width: 1px;
  background: rgba(255,255,255,.07);
}
.tf-stats-icon {
  width: 36px; height: 36px;
  margin: 0 auto 8px;
  display: flex; align-items: center; justify-content: center;
  color: var(--stat-color, #ff5e2e);
}
.tf-stats-icon svg { width: 20px; height: 20px; display: block; }
.tf-stats-number {
  font-family: 'Inter Tight', sans-serif;
  font-size: clamp(2rem, 3vw, 3rem);
  font-weight: 900; color: #fff;
  letter-spacing: -.04em; line-height: 1;
  margin-bottom: 6px; display: flex;
  align-items: baseline; justify-content: center; gap: 1px;
}
.tf-stats-count { display: inline-block; }
.tf-stats-suffix {
  font-size: .65em; opacity: .7;
  font-weight: 700;
}
.tf-stats-label {
  font-size: .72rem; color: #64748b;
  text-transform: uppercase; letter-spacing: .1em; font-weight: 700;
  line-height: 1.3;
}

/* Glow bar under each number */
.tf-stats-bar {
  width: 32px; height: 2px;
  background: var(--stat-color, #ff5e2e);
  border-radius: 2px;
  margin: 10px auto 0;
  box-shadow: 0 0 8px var(--stat-color, #ff5e2e);
}

/* Count-up animation */
.tf-stats-count { opacity: 0; transform: translateY(12px); transition: opacity .5s, transform .5s; }
.tf-stats-count.tf-counted { opacity: 1; transform: none; }

@media (max-width: 860px) {
  .tf-stats-grid { grid-template-columns: repeat(3, 1fr); gap: 32px 0; }
}
@media (max-width: 560px) {
  .tf-stats-grid { grid-template-columns: repeat(2, 1fr); gap: 28px 0; }
  .tf-stats-grid .tf-stats-item:last-child { grid-column: span 2; }
}
</style>

<div class="tf-stats-inner">
  <div class="tf-stats-grid">
    <?php foreach ( $stats as $stat ) : ?>
    <div class="tf-stats-item" style="--stat-color:<?php echo esc_attr($stat['color']); ?>">
      <div class="tf-stats-icon" aria-hidden="true"><?php echo $stat['icon']; ?></div>
      <div class="tf-stats-number">
        <span class="tf-stats-count" data-target="<?php echo esc_attr($stat['value']); ?>" data-decimals="<?php echo str_contains($stat['value'],'.') ? '1' : '0'; ?>">0</span>
        <span class="tf-stats-suffix"><?php echo esc_html($stat['suffix']); ?></span>
      </div>
      <div class="tf-stats-label"><?php echo esc_html($stat['label']); ?></div>
      <div class="tf-stats-bar"></div>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<script>
(function(){
  var items = document.querySelectorAll('#sf-stats .tf-stats-count');
  if (!items.length) return;

  function countUp(el) {
    var target = parseFloat(el.dataset.target);
    var decimals = parseInt(el.dataset.decimals) || 0;
    var duration = 1800;
    var startTime = null;
    var startVal = 0;

    function step(ts) {
      if (!startTime) startTime = ts;
      var progress = Math.min((ts - startTime) / duration, 1);
      var eased = 1 - Math.pow(1 - progress, 3);
      var current = startVal + (target - startVal) * eased;
      el.textContent = decimals ? current.toFixed(decimals) : Math.round(current).toString();
      if (progress < 1) requestAnimationFrame(step);
      else el.textContent = decimals ? target.toFixed(decimals) : Math.round(target).toString();
    }
    el.classList.add('tf-counted');
    requestAnimationFrame(step);
  }

  if ('IntersectionObserver' in window) {
    var obs = new IntersectionObserver(function(entries){
      if (entries[0].isIntersecting) {
        items.forEach(function(el, i){
          setTimeout(function(){ countUp(el); }, i * 120);
        });
        obs.disconnect();
      }
    }, { threshold: 0.4 });
    obs.observe(document.getElementById('sf-stats'));
  } else {
    items.forEach(function(el){ countUp(el); });
  }
})();
</script>

</section>
