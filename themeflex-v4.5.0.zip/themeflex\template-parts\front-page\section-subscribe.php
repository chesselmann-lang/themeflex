<?php
/**
 * Front Page Subscribe v3.0 — Bold CTA section
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'themeflex_subscribe_enabled', true ) ) return;

$title    = get_theme_mod( 'themeflex_subscribe_title',    'Get Updates Before Anyone Else' );
$subtitle = get_theme_mod( 'themeflex_subscribe_subtitle', 'Theme updates, design tips, WordPress performance guides. No spam. Unsubscribe any time.' );
?>

<section class="tf-sub-sec" id="sf-subscribe" aria-label="<?php esc_attr_e('Newsletter','themeflex'); ?>">
<style>
.tf-sub-sec {
  padding: 100px 0;
  background: #06021d;
  position: relative;
  overflow: hidden;
}
.tf-sub-inner {
  max-width: 860px; margin: 0 auto; padding: 0 32px;
  text-align: center;
  position: relative; z-index: 1;
}
/* Gradient background card */
.tf-sub-card {
  background: linear-gradient(135deg, rgba(255,94,46,.15) 0%, rgba(0,212,255,.08) 50%, rgba(168,85,247,.1) 100%);
  border: 1px solid rgba(255,94,46,.2);
  border-radius: 28px;
  padding: 72px 56px;
  position: relative;
  overflow: hidden;
}
.tf-sub-card::before {
  content: '';
  position: absolute; inset: 0;
  background-image: radial-gradient(rgba(255,255,255,.02) 1px, transparent 1px);
  background-size: 36px 36px;
}
.tf-sub-card::after {
  content: '';
  position: absolute;
  top: -80px; left: 50%;
  transform: translateX(-50%);
  width: 400px; height: 400px;
  background: radial-gradient(circle, rgba(255,94,46,.12), transparent 70%);
  pointer-events: none;
}
.tf-sub-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.15); border: 1px solid rgba(255,94,46,.3);
  color: #ff5e2e; font-size: .7rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 5px 16px; border-radius: 100px; margin-bottom: 22px;
  position: relative; z-index: 1;
}
.tf-sub-card h2 {
  font-size: clamp(1.8rem, 3vw, 2.8rem);
  font-weight: 900; color: #f1f5f9; margin: 0 0 16px; letter-spacing: -.02em; line-height: 1.15;
  position: relative; z-index: 1;
}
.tf-sub-card p { font-size: 1rem; color: #94a3b8; margin: 0 0 36px; line-height: 1.7; position: relative; z-index: 1; }

/* Form */
.tf-sub-form {
  display: flex; gap: 10px; max-width: 500px; margin: 0 auto 20px;
  position: relative; z-index: 1;
}
.tf-sub-input {
  flex: 1; padding: 15px 20px;
  background: rgba(255,255,255,.08); border: 1px solid rgba(255,255,255,.12);
  border-radius: 100px; color: #f1f5f9; font-size: .9rem; font-family: inherit;
  outline: none; transition: border-color .2s;
}
.tf-sub-input::placeholder { color: #475569; }
.tf-sub-input:focus { border-color: rgba(255,94,46,.4); }
.tf-sub-btn {
  padding: 15px 28px; border: none; border-radius: 100px; cursor: pointer;
  background: #ff5e2e; color: #fff; font-size: .9rem; font-weight: 800;
  white-space: nowrap; transition: background .2s, transform .2s;
  font-family: inherit;
}
.tf-sub-btn:hover { background: #e04e22; transform: scale(1.02); }

.tf-sub-note {
  font-size: .75rem; color: #334155;
  position: relative; z-index: 1;
}
.tf-sub-note a { color: #475569; }

/* Stats row */
.tf-sub-stats {
  display: flex; justify-content: center; gap: 32px; margin-top: 32px; flex-wrap: wrap;
  position: relative; z-index: 1;
}
.tf-sub-stat { text-align: center; }
.tf-sub-stat-num { font-size: 1.3rem; font-weight: 900; color: #f1f5f9; }
.tf-sub-stat-lbl { font-size: .72rem; color: #475569; font-weight: 600; }

/* Responsive */
@media(max-width:640px) {
  .tf-sub-card { padding: 48px 24px; }
  .tf-sub-form { flex-direction: column; }
  .tf-sub-input, .tf-sub-btn { border-radius: 14px; }
}
</style>

<div class="tf-sub-inner">
<div class="tf-sub-card">
  <div class="tf-sub-eyebrow">✉ <?php esc_html_e('Newsletter','themeflex'); ?></div>
  <h2><?php echo esc_html($title); ?></h2>
  <p><?php echo esc_html($subtitle); ?></p>

  <div class="tf-sub-form">
    <input
      type="email"
      class="tf-sub-input"
      placeholder="<?php esc_attr_e('your@email.com','themeflex'); ?>"
      aria-label="<?php esc_attr_e('Email address','themeflex'); ?>"
    >
    <button type="button" class="tf-sub-btn">
      <?php esc_html_e('Subscribe','themeflex'); ?>
    </button>
  </div>

  <p class="tf-sub-note">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="12" height="12" style="vertical-align:middle;margin-right:4px;opacity:.5" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><?php esc_html_e('No spam. No sharing. Unsubscribe in one click.','themeflex'); ?>
  </p>

  <div class="tf-sub-stats">
    <div class="tf-sub-stat"><div class="tf-sub-stat-num">2,000+</div><div class="tf-sub-stat-lbl"><?php esc_html_e('Subscribers','themeflex'); ?></div></div>
    <div class="tf-sub-stat"><div class="tf-sub-stat-num">2×/month</div><div class="tf-sub-stat-lbl"><?php esc_html_e('Send frequency','themeflex'); ?></div></div>
    <div class="tf-sub-stat"><div class="tf-sub-stat-num">62%</div><div class="tf-sub-stat-lbl"><?php esc_html_e('Open rate','themeflex'); ?></div></div>
  </div>
</div>
</div>
</section>
