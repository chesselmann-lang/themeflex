<?php
/**
 * Front Page Team v3.0 — Horizontal cards with hover bio
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_team_enabled', true ) ) return;

$title    = get_theme_mod( 'sf_team_title',    'The Minds Behind ThemeFlex' );
$subtitle = get_theme_mod( 'sf_team_subtitle', 'A small, focused team of developers and designers who obsess over performance, design quality, and developer experience.' );
$tag      = get_theme_mod( 'sf_team_tag',      'Our Team' );

$members = array(
  array('initials'=>'CW','name'=>'Chris Werner','role'=>'Founder & Lead Developer','bio'=>'10+ years building WordPress themes. Former Automattic contractor. Obsessed with Core Web Vitals and dark mode design systems.','color'=>'#ff5e2e','skills'=>array('PHP','WordPress','Performance'),'twitter'=>'#','linkedin'=>'#'),
  array('initials'=>'SK','name'=>'Sara Köhler','role'=>'Lead UI/UX Designer','bio'=>'Previously at a top-10 Berlin agency. Figma power user. Believes great design is invisible — it just feels right.','color'=>'#a855f7','skills'=>array('Figma','Design Systems','UX Research'),'twitter'=>'#','linkedin'=>'#'),
  array('initials'=>'MB','name'=>'Marc Baumann','role'=>'Elementor Developer','bio'=>'Built 200+ Elementor widgets. Knows every quirk of Elementor\'s internals. Makes complex layouts look effortless.','color'=>'#3b82f6','skills'=>array('Elementor','JavaScript','CSS'),'twitter'=>'#','linkedin'=>'#'),
  array('initials'=>'LA','name'=>'Lena Auer','role'=>'Support & Docs Lead','bio'=>'Customer success expert who writes documentation that developers actually read. 98% ticket satisfaction rate.','color'=>'#10b981','skills'=>array('Documentation','Support','Testing'),'twitter'=>'#','linkedin'=>'#'),
);
?>

<section class="tf-team-sec" id="sf-team" aria-label="<?php esc_attr_e('Team','themeflex'); ?>">
<style>
/* ═══════════════════════════════════════════════════════════════
   TEAM v3
   ═══════════════════════════════════════════════════════════════ */
.tf-team-sec { padding: 120px 0; background: #06021d; position: relative; }
.tf-team-sec::before {
  content: ''; position: absolute; top: -200px; left: -200px;
  width: 600px; height: 600px;
  background: radial-gradient(circle, rgba(168,85,247,.06), transparent 70%);
  pointer-events: none;
}
.tf-team-wrap { max-width: 1260px; margin: 0 auto; padding: 0 32px; }

.tf-team-header { text-align: center; margin-bottom: 60px; }
.tf-team-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 20px;
}
.tf-team-header h2 { font-size: clamp(1.9rem, 3.5vw, 2.8rem); font-weight: 900; color: #f1f5f9; margin: 0 0 14px; letter-spacing: -.02em; }
.tf-team-header p { font-size: 1rem; color: #64748b; max-width: 520px; margin: 0 auto; }

/* Grid */
.tf-team-grid { display: grid; grid-template-columns: repeat(4,1fr); gap: 20px; }

/* Card */
.tf-team-card {
  background: #0d1526;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 20px;
  overflow: hidden;
  position: relative;
  transition: border-color .3s, transform .3s;
  cursor: default;
}
.tf-team-card:hover { border-color: var(--tc, rgba(255,94,46,.25)); transform: translateY(-6px); }

/* Avatar area */
.tf-team-avatar-wrap {
  padding: 36px 28px 24px;
  background: linear-gradient(180deg, rgba(255,255,255,.02), transparent);
  display: flex; flex-direction: column; align-items: center;
  position: relative;
}
.tf-team-avatar {
  width: 80px; height: 80px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: 1.4rem; font-weight: 900; color: #fff;
  background: var(--tc, #ff5e2e);
  border: 3px solid rgba(255,255,255,.15);
  margin-bottom: 16px;
  position: relative;
  z-index: 1;
}
/* Glow ring */
.tf-team-avatar::after {
  content: '';
  position: absolute; inset: -6px;
  border-radius: 50%;
  background: var(--tc, #ff5e2e);
  opacity: .12;
  animation: tfAvatarPulse 3s ease-in-out infinite;
}
@keyframes tfAvatarPulse { 0%,100%{transform:scale(1);opacity:.12} 50%{transform:scale(1.15);opacity:.06} }

.tf-team-name { font-size: .96rem; font-weight: 800; color: #f1f5f9; margin-bottom: 4px; text-align: center; }
.tf-team-role { font-size: .75rem; color: #64748b; text-align: center; font-weight: 600; }

/* Body */
.tf-team-body { padding: 0 20px 24px; }
.tf-team-bio { font-size: .82rem; color: #64748b; line-height: 1.7; margin: 0 0 16px; }

/* Skills */
.tf-team-skills { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 18px; }
.tf-team-skill {
  padding: 3px 10px; border-radius: 20px;
  font-size: .65rem; font-weight: 700;
  background: rgba(255,255,255,.04);
  border: 1px solid rgba(255,255,255,.07);
  color: #475569;
}

/* Social */
.tf-team-social { display: flex; gap: 8px; }
.tf-team-social-link {
  width: 32px; height: 32px; border-radius: 8px;
  background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.07);
  color: #475569; text-decoration: none;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem;
  transition: all .2s;
}
.tf-team-social-link:hover { background: var(--tc, #ff5e2e); border-color: var(--tc, #ff5e2e); color: #fff; }

/* Bottom join CTA */
.tf-team-join {
  margin-top: 52px;
  text-align: center;
  padding: 40px;
  background: rgba(255,255,255,.02);
  border: 1px solid rgba(255,255,255,.06);
  border-radius: 20px;
}
.tf-team-join h3 { font-size: 1.3rem; font-weight: 800; color: #f1f5f9; margin: 0 0 10px; }
.tf-team-join p { font-size: .9rem; color: #64748b; margin: 0 0 22px; }
.tf-team-join-btn {
  display: inline-flex; align-items: center; gap: 8px;
  background: transparent; border: 2px solid rgba(255,255,255,.1);
  color: #94a3b8; font-size: .85rem; font-weight: 700;
  padding: 10px 24px; border-radius: 100px; text-decoration: none;
  transition: all .2s;
}
.tf-team-join-btn:hover { border-color: rgba(255,94,46,.3); color: #ff5e2e; }

/* Responsive */
@media(max-width:1024px) { .tf-team-grid { grid-template-columns: repeat(2,1fr); } }
@media(max-width:580px)  { .tf-team-grid { grid-template-columns: 1fr; } }
</style>

<div class="tf-team-wrap">
  <div class="tf-team-header">
    <div class="tf-team-eyebrow">◆ <?php echo esc_html($tag); ?></div>
    <h2><?php echo esc_html($title); ?></h2>
    <p><?php echo esc_html($subtitle); ?></p>
  </div>

  <div class="tf-team-grid">
    <?php foreach($members as $m) : ?>
    <div class="tf-team-card" style="--tc:<?php echo esc_attr($m['color']); ?>">
      <div class="tf-team-avatar-wrap">
        <div class="tf-team-avatar"><?php echo esc_html($m['initials']); ?></div>
        <div class="tf-team-name"><?php echo esc_html($m['name']); ?></div>
        <div class="tf-team-role"><?php echo esc_html($m['role']); ?></div>
      </div>
      <div class="tf-team-body">
        <p class="tf-team-bio"><?php echo esc_html($m['bio']); ?></p>
        <div class="tf-team-skills">
          <?php foreach($m['skills'] as $s): ?><span class="tf-team-skill"><?php echo esc_html($s); ?></span><?php endforeach; ?>
        </div>
        <div class="tf-team-social">
          <a href="<?php echo esc_url($m['twitter']); ?>" class="tf-team-social-link" aria-label="Twitter">✕</a>
          <a href="<?php echo esc_url($m['linkedin']); ?>" class="tf-team-social-link" aria-label="LinkedIn">in</a>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="tf-team-join">
    <h3><?php esc_html_e('We\'re Hiring','themeflex'); ?></h3>
    <p><?php esc_html_e('Love WordPress, performance, and dark mode? We\'d love to hear from you.','themeflex'); ?></p>
    <a href="<?php echo esc_url(home_url('/contact')); ?>" class="tf-team-join-btn">
      <?php esc_html_e('View Open Positions','themeflex'); ?> →
    </a>
  </div>
</div>
</section>
