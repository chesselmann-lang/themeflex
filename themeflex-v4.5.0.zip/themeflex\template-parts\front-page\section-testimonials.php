<?php
/**
 * Front Page Testimonials v3.0 — Premium Salient-class
 *
 * Auto-sliding carousel + large quote + rated badge + gradient overlays
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! get_theme_mod( 'sf_testimonials_enabled', true ) ) return;

$title    = get_theme_mod( 'sf_testimonials_title',    'Trusted by 2,000+ Teams Worldwide' );
$subtitle = get_theme_mod( 'sf_testimonials_subtitle', 'Agencies, SaaS founders, and freelancers who chose ThemeFlex and never looked back.' );
$tag      = get_theme_mod( 'sf_testimonials_tag',      'Customer Stories' );

$testimonials = array(
  array(
    'quote'   => "We switched from Avada after 4 years. ThemeFlex loads in under 800ms and the dark-first approach is exactly what our tech clients expect. The bento layout on the features section alone sold us.",
    'name'    => 'Marcus Webb',
    'title'   => 'Founder, NovaSpark Agency',
    'avatar'  => 'MW',
    'color'   => '#ff5e2e',
    'rating'  => 5,
    'company' => 'Agency',
  ),
  array(
    'quote'   => "97 PageSpeed out of the box sounds like marketing — but we measured it ourselves on a fresh install. 94 mobile, 99 desktop. The FOUC prevention is genuinely clever engineering.",
    'name'    => 'Aisha Okonkwo',
    'title'   => 'Lead Developer, Cipher Studio',
    'avatar'  => 'AO',
    'color'   => '#3b82f6',
    'rating'  => 5,
    'company' => 'Development',
  ),
  array(
    'quote'   => "Our WooCommerce conversion rate went up 23% after switching themes. The checkout templates are clean, the mobile UX is excellent, and the dark skin makes our products look premium.",
    'name'    => 'Tomás Ferreria',
    'title'   => 'E-Commerce Director, Lumina Store',
    'avatar'  => 'TF',
    'color'   => '#10b981',
    'rating'  => 5,
    'company' => 'E-Commerce',
  ),
  array(
    'quote'   => "80+ Elementor widgets sounds impressive but the quality is what matters. Every widget I've tried is production-ready — no janky CSS overrides, no z-index hell. Just works.",
    'name'    => 'Sandra Kowalski',
    'title'   => 'UI Designer, PixelLab Berlin',
    'avatar'  => 'SK',
    'color'   => '#a855f7',
    'rating'  => 5,
    'company' => 'Design',
  ),
  array(
    'quote'   => "The one-click demo import actually works. I had a client site looking like the portfolio demo in 20 minutes — featured images, layout, colours, the lot. Saved me days.",
    'name'    => 'James Oduya',
    'title'   => 'Freelance WordPress Developer',
    'avatar'  => 'JO',
    'color'   => '#f59e0b',
    'rating'  => 5,
    'company' => 'Freelance',
  ),
  array(
    'quote'   => "We run 12 client sites on ThemeFlex. The child theme API is clean, the skin system means we can white-label easily, and support responds in hours — not days. Best ThemeForest purchase we've made.",
    'name'    => 'Claire Dubois',
    'title'   => 'Managing Director, Atelier Digital',
    'avatar'  => 'CD',
    'color'   => '#00d4ff',
    'rating'  => 5,
    'company' => 'Agency',
  ),
);
?>

<section class="tf-testi-section" id="sf-testimonials" aria-label="<?php esc_attr_e( 'Customer testimonials', 'themeflex' ); ?>">
<style>
/* ═══════════════════════════════════════════════════════════════
   TESTIMONIALS v3 — Salient-class carousel
   ═══════════════════════════════════════════════════════════════ */
.tf-testi-section {
  padding: 120px 0;
  background: linear-gradient(180deg, #06021d 0%, #080420 100%);
  position: relative;
  overflow: hidden;
}

/* Decorative bg */
.tf-testi-section::before {
  content: '';
  position: absolute;
  top: 50%; left: 50%;
  transform: translate(-50%,-50%);
  width: 800px; height: 800px;
  background: radial-gradient(circle, rgba(255,94,46,.06) 0%, transparent 70%);
  pointer-events: none;
}

.tf-testi-wrap { max-width: 1260px; margin: 0 auto; padding: 0 32px; }

.tf-testi-header { text-align: center; margin-bottom: 64px; }
.tf-testi-eyebrow {
  display: inline-flex; align-items: center; gap: 8px;
  background: rgba(255,94,46,.1); border: 1px solid rgba(255,94,46,.25);
  color: #ff5e2e; font-size: .72rem; font-weight: 800; letter-spacing: .12em;
  text-transform: uppercase; padding: 6px 18px; border-radius: 100px; margin-bottom: 22px;
}
.tf-testi-header h2 {
  font-size: clamp(1.9rem, 3.5vw, 2.8rem);
  font-weight: 900; color: #f1f5f9; margin: 0 0 14px; letter-spacing: -.02em;
}
.tf-testi-header p { font-size: 1.05rem; color: #64748b; max-width: 520px; margin: 0 auto; }

/* ── Rating aggregate ─────────────────────────────────────────── */
.tf-testi-aggregate {
  display: flex; justify-content: center; align-items: center; gap: 20px;
  margin-top: 18px; flex-wrap: wrap;
}
.tf-testi-agg-stars { color: #ff5e2e; font-size: 1rem; letter-spacing: 2px; }
.tf-testi-agg-text { font-size: .85rem; color: #94a3b8; font-weight: 600; }

/* ── Carousel ─────────────────────────────────────────────────── */
.tf-testi-track-wrap {
  position: relative;
  overflow: hidden;
}
/* Fade edges */
.tf-testi-track-wrap::before,
.tf-testi-track-wrap::after {
  content: '';
  position: absolute;
  top: 0; bottom: 0;
  width: 120px;
  z-index: 2;
  pointer-events: none;
}
.tf-testi-track-wrap::before { left: 0; background: linear-gradient(to right, #06021d, transparent); }
.tf-testi-track-wrap::after  { right: 0; background: linear-gradient(to left, #06021d, transparent); }

.tf-testi-track {
  display: flex;
  gap: 24px;
  animation: tfTestiScroll 35s linear infinite;
  width: max-content;
}
.tf-testi-track:hover { animation-play-state: paused; }
@keyframes tfTestiScroll {
  0%   { transform: translateX(0); }
  100% { transform: translateX(-50%); }
}

/* ── Card ─────────────────────────────────────────────────────── */
.tf-testi-card {
  width: 380px;
  flex-shrink: 0;
  background: #0d1526;
  border: 1px solid rgba(255,255,255,.07);
  border-radius: 20px;
  padding: 32px;
  position: relative;
  overflow: hidden;
  transition: border-color .3s, transform .3s;
}
.tf-testi-card:hover {
  border-color: rgba(255,94,46,.2);
  transform: translateY(-4px);
}
.tf-testi-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: var(--tcard-color, #ff5e2e);
  opacity: .5;
}

/* Big quote mark */
.tf-testi-quote-mark {
  position: absolute;
  top: 20px; right: 24px;
  font-size: 5rem;
  line-height: 1;
  color: var(--tcard-color, #ff5e2e);
  opacity: .08;
  font-family: Georgia, serif;
  pointer-events: none;
}

.tf-testi-stars {
  display: flex; gap: 3px; margin-bottom: 18px;
}
.tf-testi-star { color: #ff5e2e; font-size: .9rem; }

.tf-testi-text {
  font-size: .92rem;
  line-height: 1.78;
  color: #94a3b8;
  margin: 0 0 24px;
  position: relative;
  z-index: 1;
}
.tf-testi-text::before {
  content: '\201C';
  color: var(--tcard-color, #ff5e2e);
  font-size: 1.2rem;
  font-family: Georgia, serif;
  margin-right: 2px;
}
.tf-testi-text::after {
  content: '\201D';
  color: var(--tcard-color, #ff5e2e);
  font-size: 1.2rem;
  font-family: Georgia, serif;
  margin-left: 2px;
}

.tf-testi-author { display: flex; align-items: center; gap: 14px; }
.tf-testi-avatar {
  width: 44px; height: 44px;
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  font-size: .75rem; font-weight: 800; color: #fff;
  flex-shrink: 0;
  border: 2px solid var(--tcard-color, #ff5e2e);
}
.tf-testi-name { font-size: .88rem; font-weight: 800; color: #f1f5f9; margin-bottom: 2px; }
.tf-testi-role { font-size: .75rem; color: #64748b; }
.tf-testi-badge {
  margin-left: auto;
  padding: 3px 10px;
  border-radius: 20px;
  font-size: .62rem;
  font-weight: 700;
  background: rgba(255,255,255,.05);
  border: 1px solid rgba(255,255,255,.08);
  color: #64748b;
  white-space: nowrap;
}

/* ── Second row (reverse direction) ──────────────────────────── */
.tf-testi-row-2 {
  margin-top: 24px;
}
.tf-testi-row-2 .tf-testi-track {
  animation-direction: reverse;
  animation-duration: 40s;
}

/* ── Responsive ─────────────────────────────────────────────── */
@media(max-width:640px) {
  .tf-testi-card { width: 300px; }
}
</style>

<div class="tf-testi-wrap">
  <div class="tf-testi-header">
    <div class="tf-testi-eyebrow">◆ <?php echo esc_html($tag); ?></div>
    <h2><?php echo esc_html($title); ?></h2>
    <p><?php echo esc_html($subtitle); ?></p>
    <div class="tf-testi-aggregate">
      <div class="tf-testi-agg-stars">★★★★★</div>
      <div class="tf-testi-agg-text"><?php esc_html_e('4.9 / 5.0 from 2,000+ customers on ThemeForest','themeflex'); ?></div>
    </div>
  </div>
</div>

<?php
// Build two rows of cards (Row 1 = testimonials 0,1,2,3; Row 2 = 4,5 + repeats)
$row1 = array_slice($testimonials, 0, 4);
$row2 = array_slice($testimonials, 4);
if(count($row2) < 3) {
  $row2 = array_merge($row2, array_slice($testimonials, 0, 4-count($row2)));
}

// Each row is duplicated for seamless loop
function tf_render_testi_row($items, $row_class='') { ?>
<div class="tf-testi-track-wrap <?php echo esc_attr($row_class); ?>">
  <div class="tf-testi-track">
    <?php foreach(array_merge($items, $items) as $t) { // duplicate for seamless ?>
    <div class="tf-testi-card" style="--tcard-color:<?php echo esc_attr($t['color']); ?>">
      <span class="tf-testi-quote-mark" aria-hidden="true">"</span>
      <div class="tf-testi-stars">
        <?php for($s=0;$s<$t['rating'];$s++) echo '<span class="tf-testi-star">★</span>'; ?>
      </div>
      <p class="tf-testi-text"><?php echo esc_html($t['quote']); ?></p>
      <div class="tf-testi-author">
        <div class="tf-testi-avatar" style="background:<?php echo esc_attr($t['color']); ?>22"><?php echo esc_html($t['avatar']); ?></div>
        <div>
          <div class="tf-testi-name"><?php echo esc_html($t['name']); ?></div>
          <div class="tf-testi-role"><?php echo esc_html($t['title']); ?></div>
        </div>
        <div class="tf-testi-badge"><?php echo esc_html($t['company']); ?></div>
      </div>
    </div>
    <?php } ?>
  </div>
</div>
<?php }

tf_render_testi_row($row1);
tf_render_testi_row($row2, 'tf-testi-row-2');
?>
<!-- Shape Divider -->
<div class="tf-shape-divider tf-shape-bottom" aria-hidden="true">
  <svg viewBox="0 0 1440 56" preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M0,56 L0,28 Q360,0 720,28 Q1080,56 1440,28 L1440,56 Z" fill="#0d1526"/>
  </svg>
</div>

</section>