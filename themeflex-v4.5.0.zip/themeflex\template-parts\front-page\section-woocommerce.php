<?php
/**
 * Front Page WooCommerce Section
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

$title = get_theme_mod( 'sf_woocommerce_title', esc_html__( 'Featured Products', 'themeflex' ) );
$count = get_theme_mod( 'sf_woocommerce_count', '8' );
$bg_color = get_theme_mod( 'sf_woocommerce_bg_color', '#ffffff' );
$padding_top = get_theme_mod( 'sf_woocommerce_padding_top', '60' );
$padding_bottom = get_theme_mod( 'sf_woocommerce_padding_bottom', '60' );
$custom_class = get_theme_mod( 'sf_woocommerce_custom_class' );
?>

<section class="sf-woocommerce-section <?php echo esc_attr( $custom_class ); ?>" style="padding-top: <?php echo absint( $padding_top ); ?>px; padding-bottom: <?php echo absint( $padding_bottom ); ?>px; background-color: <?php echo esc_attr( $bg_color ); ?>;">
	<div class="container">
		<?php if ( $title ) : ?>
			<h2 class="sf-section-title"><?php echo wp_kses_post( $title ); ?></h2>
		<?php endif; ?>

		<div class="sf-products-grid">
			<?php echo do_shortcode( '[products limit="' . absint( $count ) . '" columns="4"]' ); ?>
		</div>
	</div>
</section>
