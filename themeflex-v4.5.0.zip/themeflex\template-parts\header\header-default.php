<?php
/**
 * Template part for displaying the default header layout
 *
 * @package ThemeFlex
 */

?>

<header id="masthead" class="site-header">
	<?php
	// Top bar (optional)
	$show_topbar = get_theme_mod( 'themeflex_show_topbar', false );
	if ( $show_topbar ) {
		echo '<div class="topbar">';
		echo '<div class="container">';
		echo '<div class="topbar__content">';

		// Left side - contact info
		echo '<div class="topbar__left">';
		$phone = get_theme_mod( 'themeflex_topbar_phone' );
		$email = get_theme_mod( 'themeflex_topbar_email' );

		if ( ! empty( $phone ) ) {
			echo '<a href="tel:' . esc_attr( $phone ) . '" class="topbar__link">';
			echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="13" height="13" style="vertical-align:middle;margin-right:5px" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.69 3.18 2 2 0 0 1 3.68 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.5a16 16 0 0 0 6 6l1.06-1.06a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg> ' . esc_html( $phone );
			echo '</a>';
		}

		if ( ! empty( $email ) ) {
			echo '<a href="mailto:' . esc_attr( $email ) . '" class="topbar__link">';
			echo '<span class="icon">✉</span> ' . esc_html( $email );
			echo '</a>';
		}

		echo '</div>';

		// Right side - social links
		echo '<div class="topbar__right">';
		$social_links = get_theme_mod( 'themeflex_social_links', array() );
		if ( ! empty( $social_links ) ) {
			echo '<div class="social-links">';
			foreach ( $social_links as $link ) {
				echo '<a href="' . esc_url( $link['url'] ) . '" class="social-link" aria-label="' . esc_attr( $link['label'] ) . '" target="_blank" rel="noopener noreferrer">';
				echo esc_html( $link['label'] );
				echo '</a>';
			}
			echo '</div>';
		}
		echo '</div>';

		echo '</div>';
		echo '</div>';
		echo '</div>';
	}
	?>

	<div class="header-main">
		<div class="container">
			<div class="header-main__content">
				<!-- Logo -->
				<div class="site-branding">
					<?php get_template_part( 'template-parts/header/header', 'logo' ); ?>
				</div><!-- .site-branding -->

				<!-- Main Navigation -->
				<nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'themeflex' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'menu_id'        => 'primary-menu',
							'fallback_cb'    => 'wp_page_menu',
							'depth'          => 3,
						)
					);
					?>
				</nav><!-- #site-navigation -->

				<!-- Right side icons -->
				<div class="header-main__right">
					<?php
					// Search icon
					echo '<button class="header-search-toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Open search', 'themeflex' ) . '">';
					echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>';
					echo '</button>';

					<?php
					// Dark Mode Toggle
					if ( themeflex_get_theme_option( 'enable_dark_mode' ) ) {
						?>
						<button class="dark-mode-toggle" id="dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'themeflex' ); ?>" aria-pressed="false">
							<span class="dark-mode-icon" aria-hidden="true">
								<svg class="light-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
								</svg>
								<svg class="dark-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
								</svg>
							</span>
						</button>
						<?php
					}
					?>

					// WooCommerce cart icon (if WooCommerce is active)
					if ( class_exists( 'WooCommerce' ) ) {
						echo '<a href="' . esc_url( wc_get_cart_url() ) . '" class="header-cart-link" aria-label="' . esc_attr__( 'View cart', 'themeflex' ) . '">';
						echo '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="18" height="18" aria-hidden="true"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>';
						$cart_count = WC()->cart->get_cart_contents_count();
						if ( $cart_count > 0 ) {
							echo '<span class="cart-count">' . intval( $cart_count ) . '</span>';
						}
						echo '</a>';
					}
					?>

					<!-- Mobile menu toggle -->
					<button id="mobile-menu-toggle" class="mobile-menu-toggle" aria-expanded="false" aria-label="<?php esc_attr_e( 'Toggle mobile menu', 'themeflex' ); ?>">
						<span class="hamburger">
							<span class="hamburger__line"></span>
							<span class="hamburger__line"></span>
							<span class="hamburger__line"></span>
						</span>
					</button>
				</div><!-- .header-main__right -->
			</div><!-- .header-main__content -->
		</div><!-- .container -->
	</div><!-- .header-main -->

	<!-- Search overlay -->
	<div id="header-search" class="header-search" role="search">
		<div class="container">
			<div class="header-search__inner">
				<?php get_search_form(); ?>
				<button class="header-search-close" aria-label="<?php esc_attr_e( 'Close search', 'themeflex' ); ?>">
					<span class="icon">✕</span>
				</button>
			</div>
		</div>
	</div><!-- #header-search -->
</header><!-- #masthead -->
