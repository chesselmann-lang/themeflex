<?php
/**
 * Template part for displaying the logo
 *
 * @package ThemeFlex
 */

?>

<?php
$custom_logo_id = get_theme_mod( 'custom_logo' );
$blog_name       = get_bloginfo( 'name' );
$blog_desc       = get_bloginfo( 'description' );

if ( $custom_logo_id ) {
	// Use custom logo
	$logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
	$logo_alt = get_post_meta( $custom_logo_id, '_wp_attachment_image_alt', true );

	echo '<a href="' . esc_url( home_url( '/' ) ) . '" class="custom-logo-link" rel="home">';
	echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $logo_alt ?: $blog_name ) . '" class="custom-logo">';
	echo '</a>';

	// Retina logo support - check for high DPI version
	$logo_retina_url = get_theme_mod( 'themeflex_custom_logo_retina' );
	if ( ! empty( $logo_retina_url ) ) {
		echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr( $blog_name ) . '">';
	}
} else {
	// Text logo fallback
	if ( ! empty( $blog_name ) ) {
		echo '<a href="' . esc_url( home_url( '/' ) ) . '" class="site-logo-text" rel="home">';
		echo '<span class="site-title">' . esc_html( $blog_name ) . '</span>';

		if ( ! empty( $blog_desc ) ) {
			echo '<span class="site-description">' . esc_html( $blog_desc ) . '</span>';
		}

		echo '</a>';
	}
}
?>
