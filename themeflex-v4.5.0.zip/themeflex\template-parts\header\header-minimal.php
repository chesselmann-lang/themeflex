<?php
/**
 * Minimal Header (Hamburger Only)
 *
 * @package ThemeFlex
 * @since 1.0.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<header <?php echo implode( ' ', ThemeFlex_Header_Advanced::get_header_classes() ); ?>>
	<div class="container">
		<div class="site-header-inner">
			<div class="site-branding">
				<?php the_custom_logo(); ?>
				<?php if ( is_home() || is_front_page() ) : ?>
					<h1 class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php bloginfo( 'name' ); ?>
						</a>
					</h1>
				<?php else : ?>
					<p class="site-title">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
							<?php bloginfo( 'name' ); ?>
						</a>
					</p>
				<?php endif; ?>
			</div>

			<?php
			if ( themeflex_get_theme_option( 'enable_dark_mode' ) ) : ?>
			<button class="dark-mode-toggle" id="dark-mode-toggle" aria-label="<?php esc_attr_e( 'Toggle dark mode', 'themeflex' ); ?>" aria-pressed="false">
				<span class="dark-mode-icon" aria-hidden="true">
					<svg class="light-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
					</svg>
					<svg class="dark-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
						<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
					</svg>
				</span>
			</button>
			<?php endif; ?>

			<button class="mobile-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle menu', 'themeflex' ); ?>">
				<?php echo wp_kses_post( ThemeFlex_Icons::get_icon( 'menu', 24 ) ); ?>
			</button>
		</div>
	</div>
</header>
