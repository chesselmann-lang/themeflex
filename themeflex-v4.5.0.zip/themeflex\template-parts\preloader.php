<?php
/**
 * Preloader — ThemeFlex Premium v2.0
 *
 * Animated logo + progress bar + fade out on load.
 *
 * @package ThemeFlex
 * @since 2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! apply_filters( 'sf_show_preloader', get_theme_mod( 'sf_preloader_enabled', true ) ) ) return;
?>
<div class="tf-pl" id="tfPreloader" role="status" aria-label="<?php esc_attr_e('Loading','themeflex'); ?>">
  <div class="tf-pl-inner">
    <div class="tf-pl-logo">
      <span class="tf-pl-logo-mark" aria-hidden="true"></span>
      <span class="tf-pl-logo-text"><?php echo esc_html(get_bloginfo('name') ?: 'ThemeFlex'); ?></span>
    </div>
    <div class="tf-pl-bar-wrap">
      <div class="tf-pl-bar"></div>
    </div>
    <div class="tf-pl-pct" aria-live="polite">0%</div>
  </div>
</div>

<style>
.tf-pl {
  position: fixed; inset: 0; z-index: 999999;
  background: #06021d;
  display: flex; align-items: center; justify-content: center;
  transition: opacity .6s ease, visibility .6s ease;
}
.tf-pl.tf-pl-done { opacity: 0; visibility: hidden; pointer-events: none; }
.tf-pl-inner { display: flex; flex-direction: column; align-items: center; gap: 20px; }
.tf-pl-logo { display: flex; align-items: center; gap: 10px; }
.tf-pl-logo-mark {
  width: 28px; height: 28px; border-radius: 8px; background: #ff5e2e;
  display: block;
  animation: tfPlMarkPulse 1.5s ease-in-out infinite;
}
@keyframes tfPlMarkPulse { 0%,100%{transform:scale(1)} 50%{transform:scale(0.9);opacity:.7} }
.tf-pl-logo-text {
  font-size: 1.2rem; font-weight: 900; color: #f1f5f9;
  letter-spacing: -.02em; font-family: 'Inter Tight', system-ui, sans-serif;
}
.tf-pl-bar-wrap {
  width: 160px; height: 2px;
  background: rgba(255,255,255,.08); border-radius: 100px; overflow: hidden;
}
.tf-pl-bar {
  height: 100%; background: #ff5e2e; border-radius: 100px;
  width: 0; transition: width .1s ease;
}
.tf-pl-pct { font-size: .72rem; font-weight: 700; color: #334155; letter-spacing: .08em; }
</style>

<script>
(function(){
  var pl = document.getElementById('tfPreloader');
  var bar = pl ? pl.querySelector('.tf-pl-bar') : null;
  var pct = pl ? pl.querySelector('.tf-pl-pct') : null;
  if(!pl) return;

  var progress = 0;
  var interval = setInterval(function(){
    progress += Math.random() * 18;
    if(progress > 90) progress = 90;
    if(bar) bar.style.width = progress + '%';
    if(pct) pct.textContent = Math.round(progress) + '%';
  }, 120);

  window.addEventListener('load', function(){
    clearInterval(interval);
    if(bar) bar.style.width = '100%';
    if(pct) pct.textContent = '100%';
    setTimeout(function(){
      pl.classList.add('tf-pl-done');
      setTimeout(function(){ if(pl.parentNode) pl.parentNode.removeChild(pl); }, 700);
    }, 300);
  });
})();
</script>
